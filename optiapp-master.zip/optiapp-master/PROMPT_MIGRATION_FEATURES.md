# Prompt — Migration des features vers l'autre app

> **Contexte** : Cette app est un TMS (Transport Management System) développé sous Next.js + Supabase.  
> Les modules ci-dessous ont été développés et doivent être portés dans une autre app identique  
> (même stack : Next.js 15+ / TypeScript / Supabase / Tailwind CSS / Radix UI).  
> L'app cible a déjà la structure de base (auth, layout, RBAC) mais il lui manque les modules listés ici.

---

## Stack technique (source & cible)

- **Framework** : Next.js 15+ (App Router, Server Components, Server Actions)
- **Database** : Supabase (PostgreSQL + RLS + Storage)
- **UI** : Tailwind CSS 4 + Radix UI + shadcn/ui (`components/ui/`)
- **Auth** : Supabase Auth + middleware SSR
- **Toasts** : Sonner (via `lib/flash.ts` → cookie → composant `<Toaster />`)
- **Maps** : Leaflet (`react-leaflet`) — uniquement pour le planning
- **Validation** : Zod (schemas centralisés dans `lib/validation.ts`)
- **Formatting** : Fonctions dans `lib/format.ts` (`formatCurrency`, `formatDate`, `formatNumber`, `pct`)

---

## MODULE 1 — Système de Facturation

### 1.1 Schéma SQL à appliquer

```sql
-- Clients facturables
CREATE TABLE IF NOT EXISTS public.invoice_clients (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  name        text NOT NULL,
  address     text, postal_code text, city text,
  email       text, phone text,
  rcs text, code_ape text, id_tva text,
  legal_form text, capital numeric,
  iban text, bic text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Factures (en-tête)
CREATE TABLE IF NOT EXISTS public.invoices (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid,
  invoice_number  text NOT NULL,
  issue_date      date NOT NULL DEFAULT current_date,
  period          text,
  invoice_type    text NOT NULL DEFAULT 'transport', -- 'transport' | 'location'
  driver_name     text, vehicle_plate text,

  -- Client snapshot (copie au moment de la création)
  client_id           uuid REFERENCES public.invoice_clients(id) ON DELETE SET NULL,
  client_name         text NOT NULL,
  client_address text, client_postal_code text, client_city text,
  client_email text, client_phone text,
  client_rcs text, client_code_ape text, client_id_tva text,
  client_legal_form text, client_capital numeric,

  -- Vendeur (société émettrice)
  seller_name text, seller_address text, seller_postal_code text, seller_city text,
  seller_email text, seller_phone text,
  seller_rcs text, seller_code_naf text, seller_tva text,
  seller_legal_form text, seller_capital numeric,

  compte text,
  tva_rate numeric NOT NULL DEFAULT 20,
  image_rights_rate numeric NOT NULL DEFAULT 1,
  payment_beneficiary text, payment_bic text, payment_iban text,

  status text NOT NULL DEFAULT 'Brouillon', -- 'Brouillon' | 'Envoyée' | 'Payée'
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Lignes de facture
CREATE TABLE IF NOT EXISTS public.invoice_lines (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id  uuid NOT NULL REFERENCES public.invoices(id) ON DELETE CASCADE,
  sort_order  int NOT NULL DEFAULT 0,
  -- Transport
  line_date date, ref text,
  exp_address text, dest_address text,
  poids_kg numeric, qty_trips numeric, qty_taxable numeric,
  total_ht numeric NOT NULL DEFAULT 0,
  ecotaxe numeric NOT NULL DEFAULT 0,
  -- Location sans chauffeur
  rental_start_date date, rental_end_date date,
  qty_days numeric, unit_price numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Paramètres de facturation (1 seule ligne par app)
CREATE TABLE IF NOT EXISTS public.invoice_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_name text NOT NULL DEFAULT '',
  seller_address text NOT NULL DEFAULT '',
  seller_postal_code text NOT NULL DEFAULT '',
  seller_city text NOT NULL DEFAULT '',
  seller_email text NOT NULL DEFAULT '',
  seller_phone text NOT NULL DEFAULT '',
  seller_rcs text NOT NULL DEFAULT '',
  seller_code_naf text NOT NULL DEFAULT '',
  seller_tva text NOT NULL DEFAULT '',
  seller_legal_form text NOT NULL DEFAULT '',
  seller_capital numeric,
  invoice_prefix text NOT NULL DEFAULT 'F',
  tva_rate numeric NOT NULL DEFAULT 20,
  payment_beneficiary text NOT NULL DEFAULT '',
  payment_bic text NOT NULL DEFAULT '',
  payment_iban text NOT NULL DEFAULT '',
  compte_template text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- RLS (open pour authenticated)
ALTER TABLE public.invoice_clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_lines   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth_all_invoice_clients" ON public.invoice_clients FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_invoices"        ON public.invoices        FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_invoice_lines"   ON public.invoice_lines   FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_invoice_settings" ON public.invoice_settings FOR ALL TO authenticated USING (true) WITH CHECK (true);
```

### 1.2 Fichiers à créer

#### `lib/invoice-queries.ts`
Fonctions :
- `listInvoices(companyId)` → `InvoiceRow[]` avec totaux calculés (HT, TVA, TTC)
- `getInvoiceById(id)` → `{ invoice, lines }` complet
- `computeInvoiceTotals(lines, tvaRate)` → `{ totalHt, totalEcotaxe, totalTva, totalTtc }`
- `getInvoiceSettings()` → settings de l'app (1 seule ligne)
- `getInvoiceForecastItems(companyId)` → factures non payées pour la trésorerie
- Types TypeScript : `Invoice`, `InvoiceLine`, `InvoiceClient`, `InvoiceSettings`

Logique de calcul des totaux par ligne :
- **Transport** : `total_ht + ecotaxe` puis `× (1 + tva_rate/100)` = TTC
- **Location** : `qty_days × unit_price` = total_ht, puis même calcul TVA
- Image rights : `total_ht × (image_rights_rate / 100)` s'ajoute au TTC

#### `app/facturation/page.tsx` (Server Component)
KPIs en haut de page :
- CA Total (TTC) toutes factures confondues
- Factures payées (montant + count)
- Factures envoyées/en attente (montant + count)
- Factures en brouillon (count)

Liste des factures avec colonnes : N° facture | Date | Client | Période | Statut | Montant HT | Montant TTC | Actions

#### `app/facturation/invoice-list.tsx` (Client Component)
- Table filtrée par statut (tabs : Toutes / Brouillon / Envoyée / Payée)
- Bouton "Changer statut" → server action
- Bouton "Supprimer" avec confirmation
- Lien vers `/facturation/[id]`

#### `app/facturation/nouvelle/page.tsx` + `invoice-form.tsx` (Client Component)
Formulaire multi-étapes :
1. **Informations client** :
   - Recherche/sélection d'un client existant (combobox) → auto-remplissage
   - OU lookup SIRET via `https://recherche-entreprises.api.gouv.fr/search?q={siret}&mtq=2`
   - Champs : nom, adresse, CP, ville, email, tél, RCS, code APE, N° TVA, forme juridique, capital
2. **Informations vendeur** : pré-rempli depuis `invoice_settings`, éditable
3. **Type de facture** : radio "Transport" / "Location sans chauffeur"
4. **Lignes** :
   - Pour transport : date, référence, adresse expéditeur, adresse destinataire, poids (kg), nb colis taxés, total HT, éco-taxe
   - Pour location : date début, date fin, nb jours (calculé auto), prix unitaire, total HT
   - Bouton "Ajouter une ligne"
   - Totaux calculés en temps réel (HT, TVA, TTC)
5. **Options** : chauffeur, immatriculation, compte, notes, droits image
6. **Paiement** : bénéficiaire, BIC, IBAN

Server Actions dans `app/facturation/actions.ts` :
- `createInvoiceAction(formData)` → insère invoice + lines, retourne `{ id }`
- `updateInvoiceStatusAction(id, status)` → change Brouillon→Envoyée→Payée
- `deleteInvoiceAction(id)` → supprime
- `updateInvoiceSettingsAction(formData)` → met à jour `invoice_settings`
- `upsertInvoiceClientAction(formData)` → crée/met à jour client

#### `app/facturation/[id]/page.tsx` + `invoice-view.tsx`
- Vue complète de la facture (lecture + édition)
- Affichage PDF-like : en-tête société, client, tableau des lignes, totaux
- Boutons : "Modifier" | "Changer statut" | "Dupliquer" | "Supprimer"
- Section totaux avec HT, TVA (taux%), éco-taxe, droits image, **TTC en gras**

#### `app/facturation/clients/page.tsx`
- Liste des clients avec colonnes : Nom | Ville | Email | Tél | RCS | Actions
- Modal création/édition (Server Action)
- Bouton suppression (si aucune facture liée)

#### `app/facturation/parametres/page.tsx`
- Formulaire de mise à jour de `invoice_settings` (infos société, IBAN, préfixe N° facture, TVA par défaut)
- Server Action `updateInvoiceSettingsAction`

---

## MODULE 2 — Pré-facturation

> **But** : grouper les tournées par client et générer des factures en masse.

### 2.1 Schéma SQL (complément sur `tournees`)

```sql
-- Ajouter sur la table tournees existante :
ALTER TABLE public.tournees
  ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES public.invoice_clients(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS billed_invoice_id uuid REFERENCES public.invoices(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_tournees_client_id      ON public.tournees(client_id);
CREATE INDEX IF NOT EXISTS idx_tournees_billed_invoice ON public.tournees(billed_invoice_id);
```

### 2.2 Fichiers à créer

#### `lib/prefacturation-queries.ts`
Types :
```typescript
type TourneeAFacturer = {
  id: string
  reference: string
  name: string | null
  scheduled_date: string
  client_id: string | null
  client_name: string | null
  billed_invoice_id: string | null
  flat_rate_revenue: number | null
  surcharge_fuel: number | null
  surcharge_adr: number | null
  surcharge_wait: number | null
  surcharge_other: number | null
  other_revenue: number | null
  // revenu HT calculé = somme de tous les champs revenue
}

type GroupeClient = {
  client_id: string
  client_name: string
  tournees: TourneeAFacturer[]
  total_ht: number
  count: number
}
```

Fonctions :
- `getTourneesAFacturer(companyId, dateDebut, dateFin, nonFactureesOnly?)` 
  → Requête sur `tournees` jointe sur `invoice_clients`
  → Si `nonFactureesOnly=true`, filtre `billed_invoice_id IS NULL`
- `grouperParClient(tournees: TourneeAFacturer[])` → `GroupeClient[]`
- `computePrefacKpis(groupes)` → `{ totalHt, clientsCount, tourneesCount }`

#### `app/facturation/prefacturation/page.tsx` (Server Component)
Fetche les tournées de la période sélectionnée

#### `app/facturation/prefacturation/prefac-client.tsx` (Client Component)
- Sélecteur de mois/année (DatePicker)
- Toggle "Afficher seulement les non facturées" (checkbox)
- KPIs : Total HT | Clients | Tournées
- Pour chaque client : tableau des tournées avec checkbox
- Bouton "Générer les factures" → server action qui crée 1 facture par client
  avec toutes les tournées sélectionnées en lignes (reference comme `ref`, adresses si dispo)

#### `app/facturation/prefacturation/actions.ts`
- `genererFacturesAction(groupes: GroupeClient[], period: string)` :
  - Pour chaque groupe : crée une invoice + N invoice_lines (une par tournée)
  - Met à jour `tournees.billed_invoice_id` avec l'id de la facture créée
  - Retourne `{ created: number, errors: string[] }`

---

## MODULE 3 — Trésorerie

### 3.1 Schéma SQL

```sql
CREATE TABLE IF NOT EXISTS public.cash_accounts (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid,
  label      text NOT NULL,
  iban       text,
  balance    numeric NOT NULL DEFAULT 0,
  currency   text NOT NULL DEFAULT 'EUR',
  is_default boolean NOT NULL DEFAULT false,
  notes      text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Mouvements réalisés : amount > 0 = encaissement | < 0 = décaissement
CREATE TABLE IF NOT EXISTS public.cash_transactions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  account_id  uuid REFERENCES public.cash_accounts(id) ON DELETE SET NULL,
  date        date NOT NULL DEFAULT current_date,
  label       text NOT NULL,
  amount      numeric NOT NULL,
  category    text NOT NULL DEFAULT 'Autre',
  source      text NOT NULL DEFAULT 'manual', -- 'manual'|'invoice'|'payroll'|'ledger'
  source_id   uuid,
  reconciled  boolean NOT NULL DEFAULT false,
  notes       text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Prévisions : amount > 0 = entrée | < 0 = sortie
CREATE TABLE IF NOT EXISTS public.cash_forecast (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid,
  expected_date date NOT NULL,
  label         text NOT NULL,
  amount        numeric NOT NULL,
  category      text NOT NULL DEFAULT 'Autre',
  source        text NOT NULL DEFAULT 'manual',
  source_id     uuid,
  is_realized   boolean NOT NULL DEFAULT false,
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- RLS
ALTER TABLE public.cash_accounts     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cash_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cash_forecast     ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth_all_cash_accounts"     ON public.cash_accounts     FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_cash_transactions" ON public.cash_transactions FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "auth_all_cash_forecast"     ON public.cash_forecast     FOR ALL TO authenticated USING (true) WITH CHECK (true);
```

### 3.2 Catégories de transactions

**Encaissements** : `Facture client` | `Subvention` | `Remboursement` | `Autre recette`  
**Décaissements** : `Salaires` | `Charges sociales` | `Carburant` | `Loyer` | `Fournisseur` | `TVA/URSSAF` | `Entretien véhicule` | `Assurance` | `Autre`

### 3.3 Fichiers à créer

#### `lib/treasury-queries.ts`
Types :
```typescript
type CashAccount = { id, company_id, label, iban, balance, currency, is_default, notes }
type CashTransaction = { id, company_id, account_id, date, label, amount, category, source, reconciled, notes }
type CashForecastEntry = { id, company_id, expected_date, label, amount, category, source, is_realized, notes }
type WeeklyBucket = { weekLabel: string, income: number, expense: number, net: number }
```

Fonctions :
- `listCashAccounts(companyId)` → `CashAccount[]`
- `listCashTransactions(companyId, limit?)` → `CashTransaction[]` (desc par date)
- `listForecastEntries(companyId, fromDate?)` → `CashForecastEntry[]` (non réalisées)
- `getInvoiceForecastItems(companyId)` → Lit les factures `status IN ('Envoyée')` et les formate comme prévisions
- `buildWeeklyBuckets(transactions: CashTransaction[], forecast: CashForecastEntry[])` → `WeeklyBucket[]`
  - Agrège par semaine ISO sur les 12 prochaines semaines
  - Buckets passés = réalisé, futurs = prévision
- `computeBalanceSummary(accounts, transactions, forecast)` → `{ totalBalance, monthIncome, monthExpense, projected30d }`

#### `app/tresorerie/page.tsx` (Server Component)
Charge comptes + transactions + prévisions + factures non payées

#### `app/tresorerie/actions.ts`
- `createAccountAction(formData)` → insère `cash_accounts`
- `updateAccountAction(id, formData)` → met à jour
- `deleteAccountAction(id)` → supprime
- `createTransactionAction(formData)` → insère `cash_transactions`
- `deleteTransactionAction(id)` → supprime
- `createForecastEntryAction(formData)` → insère `cash_forecast`
- `realizeForecastEntryAction(id)` → passe `is_realized=true`
- `deleteForecastEntryAction(id)` → supprime

#### `components/treasury/forecast-chart.tsx` (Client Component)
- Graphique à barres groupées (Recharts `BarChart`)
- X = semaines (label "S23", "S24"…)
- Barres : Encaissements (vert) + Décaissements (rouge) + Solde net (line)
- Données : `WeeklyBucket[]` en props

#### `components/treasury/treasury-calendar.tsx` (Client Component)
- Grille calendrier mensuelle (construite manuellement, pas de lib)
- Marqueurs colorés sur les jours avec mouvements
- Clic sur un jour → liste des transactions du jour
- Props : `transactions: CashTransaction[]`, `forecast: CashForecastEntry[]`

Page layout de `/tresorerie` :
```
[KPIs : Solde total | Encaissements mois | Décaissements mois | Solde projeté 30j]
[Graphique hebdo] [Calendrier]
[Comptes bancaires] [Transactions récentes]
[Prévisions à venir]
```

---

## MODULE 4 — Planning & Tournées

### 4.1 Schéma SQL (`tournees` et `missions`)

```sql
-- Table tournées principale
CREATE TABLE IF NOT EXISTS public.tournees (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id            uuid,
  reference             text,
  name                  text,
  status                text NOT NULL DEFAULT 'draft', -- draft|scheduled|in_progress|completed|cancelled
  scheduled_date        date,
  scheduled_start       time,
  scheduled_end         time,
  driver_id             uuid,
  vehicle_id            uuid,
  subcontractor_id      uuid REFERENCES public.contractors(id) ON DELETE SET NULL,
  client_id             uuid REFERENCES public.invoice_clients(id) ON DELETE SET NULL,
  billed_invoice_id     uuid REFERENCES public.invoices(id) ON DELETE SET NULL,
  -- Revenus
  flat_rate_revenue     numeric,
  surcharge_fuel        numeric,
  surcharge_adr         numeric,
  surcharge_wait        numeric,
  surcharge_other       numeric,
  other_revenue         numeric,
  -- Coûts (overrides)
  fuel_cost_override    numeric,
  driver_cost_override  numeric,
  vehicle_cost_override numeric,
  subcontractor_cost    numeric,
  cold_unit_cost_override numeric,
  toll_cost             numeric,
  maintenance_cost_override numeric,
  tire_cost_override    numeric,
  misc_cost             numeric,
  -- Métriques
  total_distance_km     numeric,
  actual_start          timestamptz,
  actual_end            timestamptz,
  estimated_hours       numeric,
  notes                 text,
  recurrence_type       text,
  recurrence_group_id   uuid,
  created_at            timestamptz NOT NULL DEFAULT now()
);

-- Missions (livraisons individuelles)
CREATE TABLE IF NOT EXISTS public.missions (
  id                    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id            uuid,
  reference             text,
  status                text NOT NULL DEFAULT 'scheduled',
  scheduled_date        date,
  scheduled_time        time,
  pickup_city           text, pickup_address text,
  pickup_lat            numeric, pickup_lng numeric,
  delivery_city         text, delivery_address text,
  delivery_lat          numeric, delivery_lng numeric,
  delivery_window_start time, delivery_window_end time,
  distance_km           numeric,
  cargo_description     text,
  price                 numeric,
  priority              text DEFAULT 'Normal',
  driver_id             uuid,
  vehicle_id            uuid,
  client_id             uuid REFERENCES public.invoice_clients(id) ON DELETE SET NULL,
  client_name           text,
  requires_adr          boolean DEFAULT false,
  created_at            timestamptz NOT NULL DEFAULT now()
);

-- Lien tournée ↔ missions
CREATE TABLE IF NOT EXISTS public.tournee_missions (
  tournee_id uuid REFERENCES public.tournees(id) ON DELETE CASCADE,
  mission_id uuid REFERENCES public.missions(id) ON DELETE CASCADE,
  "order"    int NOT NULL DEFAULT 0,
  PRIMARY KEY (tournee_id, mission_id)
);
```

### 4.2 Fichiers à créer

#### `lib/planning.ts`
Types :
```typescript
type PlanningTournee = {
  // Tous les champs de tournees
  // + missions: Mission[] (liées)
  // + profitability: ProfitabilityBreakdown
  // + driver_name: string | null
  // + vehicle_plate: string | null
  // + client_name: string | null
  // + subcontractor_name: string | null
}

type PlanningPayload = {
  tournees: PlanningTournee[]
  looseMissions: Mission[]  // missions sans tournée
  stats: {
    totalTournees: number
    totalDistance: number
    totalRevenue: number
    totalCost: number
    marginPct: number
    byStatus: Record<string, number>
  }
  drivers: { id: string, full_name: string }[]
  vehicles: { id: string, plate: string, brand: string, model: string }[]
}
```

Fonctions :
- `getPlanning(companyId, startDate, endDate)` → `PlanningPayload`
  - Joint tournées + missions + profiles (driver) + tms_vehicles + invoice_clients + contractors
  - Pour chaque tournée, appelle `computeProfitability()`
  - Sépare les missions non liées à une tournée
- `getMapData(companyId, startDate, endDate)` → coordonnées pour la carte

#### `lib/profitability.ts`
```typescript
type ProfitabilityInputs = {
  flat_rate_revenue?: number
  surcharge_fuel?: number, surcharge_adr?: number, surcharge_wait?: number, surcharge_other?: number
  other_revenue?: number
  total_distance_km?: number
  estimated_hours?: number
  fuel_cost_override?: number
  driver_cost_override?: number
  vehicle_cost_override?: number
  subcontractor_cost?: number
  cold_unit_cost_override?: number
  toll_cost?: number
  maintenance_cost_override?: number
  tire_cost_override?: number
  misc_cost?: number
  missions_revenue?: number  // si pas de flat_rate
}

type ProfitabilityBreakdown = {
  totalRevenue: number
  totalCost: number
  margin: number
  marginPct: number
  revenueItems: { label: string, amount: number }[]
  costItems: { label: string, amount: number }[]
}

function computeProfitability(inputs: ProfitabilityInputs): ProfitabilityBreakdown
```

Logique :
- Revenue = flat_rate_revenue (si défini) ou missions_revenue, + tous les surcharges + other_revenue
- Coût = somme de tous les `*_override` ou `*_cost` non-null (fuel, driver, vehicle, subcontractor, cold_unit, toll, maintenance, tire, misc)
- margin = revenue - cost
- marginPct = margin / revenue × 100 (ou 0 si revenue = 0)

#### `app/tournees/page.tsx` (Server Component)
Charge `getPlanning(companyId, startDate, endDate)` avec dates de la semaine courante

#### `components/planning/tournee-planning.tsx` (Client Component)
- Tabs : **Vue liste** | **Carte** | **Statistiques**
- Vue liste :
  - Chaque tournée = card avec : référence, statut (badge coloré), date, heure, chauffeur, véhicule, client, distance, revenue HT, coût, marge %
  - Actions : Assigner chauffeur/véhicule (modal), Voir détail, Supprimer
  - Section "Missions non assignées" en bas
- Vue statistiques :
  - Cards : Total tournées | Km total | CA HT | Coût total | Marge %
  - Répartition par statut

#### `components/planning/assign-modal.tsx` (Client Component)
- Modal dialog (Radix)
- Sélecteur chauffeur (parmi les drivers de la company)
- Sélecteur véhicule (parmi les véhicules disponibles)
- Server action `assignTourneeAction(tourneeId, driverId, vehicleId)`

#### `components/planning/quick-create-modal.tsx` (Client Component)
- Modal formulaire création rapide de tournée
- Champs : référence (auto-générée), date, heure début/fin, client (optionnel), notes
- Server action `createTourneeAction(formData)`

#### `components/planning/live-map.tsx` (Client Component)
```
'use client'
// Import dynamique pour éviter le SSR (Leaflet n'est pas compatible SSR)
import dynamic from 'next/dynamic'
```
- `react-leaflet` MapContainer + TileLayer (OpenStreetMap)
- Markers pour chaque mission (pickup = vert, delivery = rouge)
- Markers pour position des chauffeurs (bleu) depuis `profiles.last_lat/lng`
- Popup au clic avec info tournée/mission
- Polylines pour relier pickup → delivery d'une même mission

#### `app/actions.ts` (server actions globales)
- `assignTourneeAction(tourneeId, driverId, vehicleId)` → met à jour tournees
- `createTourneeAction(formData)` → crée une tournée
- `updateTourneeStatusAction(id, status)` → change le statut
- `deleteTourneeAction(id)` → supprime (CASCADE sur tournee_missions)
- `updateMyPositionAction(lat, lng)` → met à jour `profiles.last_lat, last_lng, last_position_at` pour le chauffeur connecté

---

## MODULE 5 — Social / RH / Paie

### 5.1 Schéma SQL

```sql
CREATE TABLE IF NOT EXISTS public.employees (
  id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id              text,
  site_id                 uuid,
  first_name              text NOT NULL, last_name text NOT NULL,
  email text, phone text,
  social_security_number  text,
  birth_date date, birth_place text, nationality text,
  residence_permit_expiry date,
  address text,
  role text,  -- 'Chauffeur livreur'|'Chef d'équipe'|'Exploitant transport'|'Assistant administratif'|'Responsable site'
  contract_type text, -- 'CDI'|'CDD'|'Interim'|'Sous-traitance'
  status text DEFAULT 'Actif', -- 'Actif'|'Congé'|'Arrêt maladie'|'Fin de contrat'
  hire_date date,
  pay_mode text DEFAULT 'mensualise', -- 'mensualise'|'horaire'
  monthly_gross_salary    numeric,
  hourly_rate             numeric,
  contract_hours          numeric DEFAULT 151.67,
  meal_allowance_daily    numeric DEFAULT 15.96,
  tournee_rate            numeric,
  hourly_cost_rate        numeric,
  pay_notes text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.payroll_variables (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id          uuid REFERENCES public.employees(id) ON DELETE CASCADE,
  period               text NOT NULL, -- 'YYYY-MM'
  overtime_hours       numeric DEFAULT 0,
  bonus_amount         numeric DEFAULT 0,
  deductions           numeric DEFAULT 0,
  worked_days          int DEFAULT 0,
  meal_allowance_amount numeric,  -- override si null, calculé depuis employee
  km_allowance         numeric DEFAULT 0,
  unpaid_absence_hours numeric DEFAULT 0,
  variable_status      text DEFAULT 'Ébauche', -- 'Ébauche'|'Pret paie'|'Bloque'|'Envoye paie'
  UNIQUE (employee_id, period)
);

CREATE TABLE IF NOT EXISTS public.absences (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id   uuid REFERENCES public.employees(id) ON DELETE CASCADE,
  reason        text NOT NULL, -- 'Congé'|'Arrêt maladie'|'Autre'
  start_date    date NOT NULL,
  end_date      date NOT NULL,
  duration_days numeric NOT NULL
);
```

### 5.2 Fichiers à créer

#### `lib/payroll.ts`
```typescript
const PAYROLL_DEFAULTS = {
  employeeChargesRate: 0.22,  // ~22% charges salariales
  employerChargesRate: 0.42,  // ~42% charges patronales
  ot25Threshold: 8,           // heures au-delà desquelles on passe à 50%
  defaultContractHours: 151.67,
  legalMonthlyHours: 151.67,
}

type PayrollInputs = {
  pay_mode: 'mensualise' | 'horaire'
  monthly_gross_salary?: number
  hourly_rate?: number
  contract_hours?: number
  meal_allowance_daily?: number
  overtime_hours?: number
  bonus_amount?: number
  deductions?: number
  worked_days?: number
  meal_allowance_amount?: number  // override
  km_allowance?: number
  unpaid_absence_hours?: number
}

type PayrollComputation = {
  baseSalary: number
  absenceDeduction: number
  overtime25Amount: number
  overtime50Amount: number
  bonusAmount: number
  deductions: number
  grossTaxable: number
  mealAllowance: number
  kmAllowance: number
  employeeCharges: number
  netBeforeIndemnities: number
  netPayable: number
  employerCharges: number
  totalEmployerCost: number
  hourlyCost: number
}

function computePayroll(inputs: PayrollInputs): PayrollComputation
```

Logique :
1. baseSalary = si mensualise → monthly_gross_salary, si horaire → hourly_rate × contract_hours
2. baseHourlyRate = baseSalary / LEGAL_MONTHLY_HOURS
3. absenceDeduction = unpaid_absence_hours × baseHourlyRate
4. OT : first min(overtime_hours, ot25Threshold) heures à ×1.25, reste à ×1.5
5. grossTaxable = baseSalary - absenceDeduction + OT + bonus - deductions
6. mealAllowance = meal_allowance_amount ?? (worked_days × meal_allowance_daily)
7. employeeCharges = grossTaxable × 0.22
8. netBeforeIndemnities = grossTaxable - employeeCharges
9. netPayable = netBeforeIndemnities + mealAllowance + km_allowance
10. employerCharges = grossTaxable × 0.42
11. totalEmployerCost = grossTaxable + employerCharges
12. hourlyCost = employerCharges / LEGAL_MONTHLY_HOURS

#### `app/social/page.tsx` (Server Component)
Charge effectifs + variables du mois courant + absences

#### `app/social/pre-paie/` (Server Component + Client)
- Sélecteur de période (mois/année)
- Tableau des employés avec pour chacun :
  - Nom, poste, contrat
  - Champs éditables (via formulaire inline) : heures supp, jours travaillés, prime, indemnités, absences
  - Résultat calculé : Brut imposable | Charges salarié | Net payable | Coût employeur
  - Statut (badge) : Ébauche → Prêt paie → Bloqué → Envoyé
- Bouton "Calculer tout" → recalcule tous les salaires
- Bouton "Passer en Prêt paie" par ligne

Section **Pré-paie** (composant `components/social/prepaie-section.tsx`) :
- Affichage résumé : Total masse salariale brute | Total charges patronales | Total coût employeur
- Export (optionnel)

---

## MODULE 6 — Dashboard (KPIs financiers + RPCs)

### 6.1 RPCs Supabase à créer

```sql
-- Snapshot de la company (finance, employés, factures)
CREATE OR REPLACE FUNCTION public.get_dashboard_company_overview(p_company_id text)
RETURNS TABLE (
  period text,
  revenue_period numeric,
  expenses_period numeric,
  margin_period numeric,
  invoices_overdue_count int,
  invoices_overdue_amount numeric,
  invoices_outstanding_count int,
  invoices_outstanding_amount numeric,
  employees_active int,
  drivers_active int
)
-- Calcul depuis cash_transactions (mois courant) + invoices (statuts)
-- Voir migration 20260625_dashboard_company_overview.sql pour l'implémentation complète

-- Tendance finance (mois courant vs mois précédent)
CREATE OR REPLACE FUNCTION public.get_dashboard_finance_trend(p_company_id text DEFAULT NULL)
RETURNS TABLE (
  period text, prev_period text,
  revenue_period numeric, revenue_prev numeric,
  expenses_period numeric, expenses_prev numeric,
  margin_period numeric, margin_prev numeric
)
-- Calcul depuis cash_transactions sur les 2 derniers mois

-- Factures en retard
CREATE OR REPLACE FUNCTION public.get_dashboard_company_overdue_invoices(p_company_id text, p_limit int DEFAULT 6)
RETURNS TABLE (
  id uuid, invoice_number text, total_amount numeric,
  status text, issued_at date, due_at date, days_overdue int, client_name text
)
```

### 6.2 Fichiers à modifier

#### `app/page.tsx` (Server Component — dashboard principal)
KPIs à afficher :
- **Finance** : CA mois (vs mois précédent en %), Dépenses mois, Marge mois
- **Facturation** : Factures en attente (nb + montant), Factures en retard (nb + montant, avec alerte rouge si > 0)
- **RH** : Employés actifs, Chauffeurs actifs

#### `components/dashboard/dashboard-client.tsx` (Client Component)
- Graphique de tendance financière (Recharts LineChart ou BarChart)
- X = derniers 7 jours ou 2 mois selon vue
- Données depuis `get_dashboard_finance_trend`

---

## MODULE 7 — Admin Utilisateurs

### 7.1 Fichiers à créer

#### `app/admin/layout.tsx`
- Guard : seuls `super_admin` et `gerant_groupe` peuvent accéder
- Redirect vers `/` sinon

#### `app/admin/utilisateurs/page.tsx` (Server Component)
- Liste de tous les users (`profiles`) avec : nom, email, rôle (badge coloré), company, site, actif/inactif
- Boutons : inviter, modifier, activer/désactiver, supprimer

#### `app/admin/utilisateurs/invite-modal.tsx` (Client Component)
- Form : email, rôle, company_id
- Server action `inviteUserAction(email, role, companyId)` → `supabase.auth.admin.inviteUserByEmail()`

#### `app/admin/utilisateurs/toggle-active-button.tsx` (Client Component)
- Server action `toggleActiveAction(userId, isActive)` → met à jour `profiles.is_active`

#### `app/admin/utilisateurs/[id]/page.tsx` + `user-edit-form.tsx`
- Édition : rôle, company_id, site_id
- Server action `updateUserAction(id, formData)`

#### `app/admin/utilisateurs/[id]/delete-user-button.tsx`
- Confirmation dialog avant suppression
- Server action `deleteUserAction(userId)` → `supabase.auth.admin.deleteUser()`
- Utilise `lib/supabase-admin.ts` (client avec SERVICE_ROLE_KEY)

#### `lib/supabase-admin.ts`
```typescript
import { createClient } from '@supabase/supabase-js'
export const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { autoRefreshToken: false, persistSession: false } }
)
```

---

## Conventions et patterns à respecter

### Server Actions pattern
```typescript
'use server'
import { requireUser } from '@/lib/session'
import { setFlash } from '@/lib/flash'
import { revalidatePath } from 'next/cache'

export async function myAction(formData: FormData) {
  const user = await requireUser()
  // validation avec zod
  // mutation Supabase (service role ou anon selon le cas)
  setFlash({ kind: 'success', message: 'Opération réussie' })
  revalidatePath('/ma-page')
}
```

### Gestion des erreurs
- Toujours encapsuler dans try/catch dans les server actions
- `setFlash({ kind: 'error', message: err.message })` en cas d'erreur
- Ne pas throw côté serveur sauf pour redirect

### Client vs Server Components
- Pages (data-fetching) = Server Components (async function)
- Formulaires interactifs, filtres, modals = Client Components (`'use client'`)
- Passer les données initiales en props aux Client Components

### Structure des fichiers
```
app/[module]/
  page.tsx          ← Server Component (fetch + affichage)
  loading.tsx       ← Skeleton (optionnel)
  actions.ts        ← Server Actions du module
  [module]-client.tsx ← Client Component principal (si interactivité)

components/[module]/
  [composant].tsx   ← Composants réutilisables

lib/
  [module]-queries.ts ← Fonctions de lecture Supabase
```

### Supabase clients
- **Lecture dans Server Components** : `createServerClient()` depuis `lib/supabase-server.ts`
- **Lecture dans Client Components** : `createBrowserClient()` depuis `lib/supabase-browser.ts`
- **Mutations dans Server Actions** : client avec service_role depuis `lib/db-server.ts`

### Composants UI disponibles
Tous depuis `components/ui/` (shadcn) : `Button`, `Input`, `Select`, `Dialog`, `Table`, `Badge`, `Card`, `Tabs`, `Checkbox`, `DatePicker`, `Skeleton`, `Separator`, `Label`, `Textarea`

---

## Ordre d'implémentation recommandé

1. **Migrations SQL** (dans l'ordre : invoicing_system → invoice_settings → invoice_location → treasury → prefacturation → tournees_subcontractor → dashboard_overview)
2. **lib/invoice-queries.ts** + **lib/treasury-queries.ts** + **lib/planning.ts** + **lib/profitability.ts** + **lib/payroll.ts**
3. **Facturation** : clients → nouvelle → liste → détail → paramètres
4. **Pré-facturation** : queries → client component → actions
5. **Trésorerie** : actions → queries → chart → calendrier → page
6. **Planning/Tournées** : planning → assign-modal → quick-create → live-map
7. **Social/RH** : employees CRUD → payroll → pre-paie section
8. **Dashboard** : RPCs SQL → dashboard-client → page
9. **Admin utilisateurs** : layout guard → liste → invite → edit → delete

---

## Variables d'environnement requises

```env
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
ENCRYPTION_KEY=   # 32 bytes hex, pour AES-256-GCM (URSSAF si applicable)
```
