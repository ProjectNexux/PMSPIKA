import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { AppShell } from "@/components/app-shell";
import { CommandPalette } from "@/components/command-palette";
import { Toaster } from "@/components/toaster";
import { UserScopeProvider, type ScopedUser } from "@/components/user-scope";
import { consumeFlash } from "@/lib/flash";
import { getCurrentUser } from "@/lib/session";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: "PIKA TRANSPORT",
  description: "Pilotage administratif, social, comptable et opérationnel — PIKA TRANSPORT",
  icons: { icon: "/pika-logo.svg" },
};

export default async function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const user = await getCurrentUser();
  const flash = await consumeFlash();
  const scoped: ScopedUser | null = user
    ? {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        role: user.role,
        company_id: user.company_id,
        site_id: user.site_id,
        company_name: user.company_name,
        is_admin: user.is_admin,
        is_super_admin: user.is_super_admin,
      }
    : null;

  return (
    <html lang="fr" className={inter.variable}>
      <body>
        <UserScopeProvider user={scoped}>
          <AppShell>{children}</AppShell>
          {scoped && <CommandPalette />}
        </UserScopeProvider>
        <Toaster flash={flash} />
      </body>
    </html>
  );
}
