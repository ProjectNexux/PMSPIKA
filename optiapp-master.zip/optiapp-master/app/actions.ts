"use server";

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { z } from "zod";
import { getServerSupabase } from "@/lib/db-server";
import { computeMissionPrice } from "@/lib/pricing-queries";
import { inviteUserByEmail } from "@/lib/supabase-admin";
import { logAudit } from "@/lib/audit";
import { requireUser } from "@/lib/session";
import { setFlash, type FlashKind } from "@/lib/flash";
import {
  parseFormData,
  zCheckbox,
  zDateOpt,
  zEmailOpt,
  zId,
  zNonEmpty,
  zNumber,
  zNumberOpt,
  zOptional,
  zUuid,
} from "@/lib/validation";

/**
 * Toutes les mutations passent par la SERVICE ROLE (cf. lib/db-server.ts) :
 *   - bypass RLS (les garde-fous sont applicatifs via `requireRole`)
 *   - permet de supprimer les anciennes policies `anon_all_*` (Lot 2.f).
 *
 * Les lectures côté pages (lib/queries.ts) restent sur le client anon pour
 * l'instant ; migration prévue dans un lot ultérieur.
 */
const supabase = getServerSupabase();

async function siteCompany(siteId: string | null) {
  if (!siteId) return null;
  const { data } = await supabase.from("sites").select("company_id").eq("id", siteId).single();
  return data?.company_id ?? null;
}

function value(formData: FormData, key: string) {
  const raw = formData.get(key);
  return typeof raw === "string" && raw.trim() ? raw.trim() : null;
}

function numberValue(formData: FormData, key: string) {
  const raw = value(formData, key);
  return raw ? Number(raw.replace(",", ".")) : 0;
}

// Coût horaire employeur déduit du salaire mensuel brut.
// Formule : brut × charges patronales (1.42) / heures mensuelles (151.67).
const EMPLOYER_LOAD_COEF = 1.42;
const MONTHLY_LEGAL_HOURS = 151.67;
function computeHourlyCost(monthlyGross: number | null): number | null {
  if (!monthlyGross || monthlyGross <= 0) return null;
  return Math.round((monthlyGross * EMPLOYER_LOAD_COEF / MONTHLY_LEGAL_HOURS) * 100) / 100;
}

function finalize(formData: FormData, defaultPath: string) {
  const target = value(formData, "redirect_to");
  if (target && target.startsWith("/")) {
    revalidatePath(target);
    revalidatePath("/");
    redirect(target);
  }
  revalidatePath("/");
  revalidatePath(defaultPath);
}

/**
 * Variante async de `finalize` qui pose un toast flash avant redirect.
 * À privilégier pour toute nouvelle server action. Les actions existantes
 * peuvent être migrées progressivement.
 */
async function flashAndFinalize(
  formData: FormData,
  defaultPath: string,
  message: string,
  kind: FlashKind = "success",
) {
  await setFlash({ kind, message });
  finalize(formData, defaultPath);
}

/**
 * Valide `formData` avec un schéma Zod. Si invalide, pose un toast d'erreur
 * agrégé et redirige vers `defaultPath` (ne retourne jamais).
 * Sinon, renvoie l'objet typé.
 *
 * Cf. lib/validation.ts pour les primitives (zUuid, zNumber, zDateOpt…).
 */
async function validate<T>(
  schema: z.ZodType<T>,
  formData: FormData,
  defaultPath: string,
): Promise<T> {
  const result = parseFormData(schema, formData);
  if (result.ok === true) return result.data;
  const errorMessage = result.error;
  await flashAndFinalize(formData, defaultPath, errorMessage, "error");
  // `finalize` peut ne pas redirect (pas de redirect_to + même path) :
  // on lève alors pour s'assurer de court-circuiter l'action.
  throw new Error(errorMessage);
}

const CreateTaskSchema = z.object({
  title: zNonEmpty,
  domain: zOptional,
  priority: zOptional,
  due_date: zDateOpt,
  owner: zOptional,
  company_id: zOptional,
  site_id: zOptional,
  notes: zOptional,
}).passthrough();

export async function createTask(formData: FormData) {
  await validate(CreateTaskSchema, formData, "/pilotage");
  const siteId = value(formData, "site_id");
  const explicitCompanyId = value(formData, "company_id");
  await supabase.from("tasks").insert({
    id: randomUUID(),
    title: value(formData, "title"),
    domain: value(formData, "domain") ?? "Operations",
    priority: value(formData, "priority") ?? "Moyenne",
    status: "A faire",
    due_date: value(formData, "due_date"),
    owner: value(formData, "owner") ?? "A assigner",
    company_id: explicitCompanyId ?? await siteCompany(siteId),
    site_id: siteId,
    notes: value(formData, "notes"),
  });

  await flashAndFinalize(formData, "/pilotage", "Tâche créée");
}

const UpdateTaskStatusSchema = z.object({
  id: zNonEmpty,
  status: zOptional,
}).passthrough();

export async function updateTaskStatus(formData: FormData) {
  const data = await validate(UpdateTaskStatusSchema, formData, "/pilotage");
  await supabase.from("tasks").update({ status: data.status ?? "A faire" }).eq("id", data.id);

  await flashAndFinalize(formData, "/pilotage", "Statut mis à jour");
}

const CreateDocumentSchema = z.object({
  title: zNonEmpty,
  category: zOptional,
  status: zOptional,
  due_date: zDateOpt,
  owner_type: zOptional,
  owner_name: zOptional,
  company_id: zOptional,
  site_id: zOptional,
  vehicle_id: zOptional,
  notes: zOptional,
}).passthrough();

export async function createDocument(formData: FormData) {
  await validate(CreateDocumentSchema, formData, "/documents");
  const siteId = value(formData, "site_id");
  const companyId = value(formData, "company_id") ?? await siteCompany(siteId);
  await supabase.from("documents").insert({
    id: randomUUID(),
    title: value(formData, "title"),
    category: value(formData, "category") ?? "Administratif",
    status: value(formData, "status") ?? "A classer",
    due_date: value(formData, "due_date"),
    owner_type: value(formData, "owner_type") ?? "Site",
    owner_name: value(formData, "owner_name") ?? "Non renseigne",
    company_id: companyId,
    site_id: siteId,
    vehicle_id: value(formData, "vehicle_id"),
    notes: value(formData, "notes"),
  });

  await flashAndFinalize(formData, "/documents", "Document ajouté");
}

const CreateLedgerEntrySchema = z.object({
  label: zNonEmpty,
  type: zOptional,
  amount: zNumber,
  tax_rate: zNumberOpt,
  status: zOptional,
  period: zOptional,
  due_date: zDateOpt,
  company_id: zOptional,
  site_id: zOptional,
}).passthrough();

export async function createLedgerEntry(formData: FormData) {
  await validate(CreateLedgerEntrySchema, formData, "/comptabilite");
  const siteId = value(formData, "site_id");
  const companyId = value(formData, "company_id") ?? await siteCompany(siteId);
  await supabase.from("ledger_entries").insert({
    id: randomUUID(),
    label: value(formData, "label"),
    type: value(formData, "type") ?? "Depense",
    amount: numberValue(formData, "amount"),
    tax_rate: numberValue(formData, "tax_rate") || 20,
    status: value(formData, "status") ?? "A classer",
    period: value(formData, "period") ?? "2026-06",
    due_date: value(formData, "due_date"),
    company_id: companyId,
    site_id: siteId,
    attachment_required: 1,
  });

  await flashAndFinalize(formData, "/comptabilite", "Écriture comptable ajoutée");
}

// ── Provisionnement du compte de connexion d'un salarié ─────────────────────
// Reconstruit l'origine publique de l'app depuis les en-têtes de la requête,
// pour générer un lien de redirection valide dans l'email d'invitation.
async function appOrigin(): Promise<string> {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host");
  const proto = h.get("x-forwarded-proto") ?? "https";
  if (host) return `${proto}://${host}`;
  return process.env.NEXT_PUBLIC_SITE_URL ?? "";
}

/**
 * Crée le compte de connexion d'un salarié (rôle chauffeur) :
 *   1. invite le salarié par email via Supabase Auth (email d'activation de
 *      son espace, où il définit son mot de passe) ;
 *   2. provisionne / met à jour son profil (rôle, société, site, lien salarié) ;
 *   3. relie le salarié au profil créé.
 *
 * N'échoue jamais en exception : renvoie un statut pour que la création du
 * salarié aboutisse même si l'envoi de l'invitation échoue.
 */
async function provisionEmployeeAccount(opts: {
  employeeId: string;
  email: string;
  fullName: string;
  phone: string | null;
  companyId: string | null;
  siteId: string | null;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  try {
    const origin = await appOrigin();
    const redirectTo = origin
      ? `${origin}/auth/callback?next=/chauffeur`
      : undefined;

    const { data, error } = await inviteUserByEmail(opts.email, {
      data: {
        full_name: opts.fullName,
        role: "chauffeur",
        company_id: opts.companyId,
        site_id: opts.siteId,
        employee_id: opts.employeeId,
      },
      redirectTo,
    });

    if (error || !data?.user) {
      return { ok: false, error: error?.message ?? "Invitation impossible." };
    }

    const userId = data.user.id;

    // Provisionne / met à jour le profil (service role → bypass RLS).
    const { error: profileError } = await supabase.from("profiles").upsert(
      {
        id: userId,
        email: opts.email,
        full_name: opts.fullName,
        role: "chauffeur",
        company_id: opts.companyId,
        site_id: opts.siteId,
        employee_id: opts.employeeId,
        phone: opts.phone,
        is_active: true,
      },
      { onConflict: "id" },
    );
    if (profileError) {
      return { ok: false, error: profileError.message };
    }

    // Relie le salarié au profil créé.
    await supabase
      .from("employees")
      .update({ profile_id: userId, profile_label: opts.fullName })
      .eq("id", opts.employeeId);

    return { ok: true };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Erreur inconnue.";
    return { ok: false, error: message };
  }
}

const CreateEmployeeSchema = z.object({
  first_name: zNonEmpty,
  last_name: zNonEmpty,
  role: zOptional,
  contract_type: zOptional,
  hire_date: zDateOpt,
  email: zEmailOpt,
  phone: zOptional,
  site_id: zOptional,
  monthly_gross_salary: zNumberOpt,
}).passthrough();

export async function createEmployee(formData: FormData) {
  await validate(CreateEmployeeSchema, formData, "/social");
  const siteId = value(formData, "site_id");
  const companyId = await siteCompany(siteId);
  const monthlyGross = numberValue(formData, "monthly_gross_salary") || null;

  const employeeId = randomUUID();
  const firstName = value(formData, "first_name");
  const lastName = value(formData, "last_name");
  const email = value(formData, "email");
  const phone = value(formData, "phone");

  await supabase.from("employees").insert({
    id: employeeId,
    first_name: firstName,
    last_name: lastName,
    role: value(formData, "role") ?? "Chauffeur livreur",
    contract_type: value(formData, "contract_type") ?? "CDI",
    status: "Actif",
    hire_date: value(formData, "hire_date") ?? new Date().toISOString().slice(0, 10),
    email,
    phone,
    company_id: companyId,
    site_id: siteId,
    // Identité RH
    social_security_number: value(formData, "social_security_number"),
    birth_date:              value(formData, "birth_date"),
    birth_place:             value(formData, "birth_place"),
    nationality:             value(formData, "nationality"),
    residence_permit_expiry: value(formData, "residence_permit_expiry"),
    address:                 value(formData, "address"),
    // Rémunération
    monthly_gross_salary: monthlyGross,
    hourly_cost_rate:     computeHourlyCost(monthlyGross),
  });

  // Crée automatiquement le compte de connexion à l'espace chauffeur.
  if (email) {
    const fullName = [firstName, lastName].filter(Boolean).join(" ").trim() || email;
    const account = await provisionEmployeeAccount({
      employeeId,
      email,
      fullName,
      phone,
      companyId,
      siteId,
    });

    if (account.ok) {
      await logAudit({
        action: "create_driver_account",
        entity: "profiles",
        entity_id: employeeId,
      });
      await flashAndFinalize(
        formData,
        "/social",
        `Salarié ajouté · Invitation envoyée à ${email} pour activer son espace chauffeur`,
      );
      return;
    }

    if ("error" in account) {
      await flashAndFinalize(
        formData,
        "/social",
        `Salarié ajouté, mais le compte de connexion n'a pas pu être créé : ${account.error}`,
        "error",
      );
    }
    return;
  }

  await flashAndFinalize(
    formData,
    "/social",
    "Salarié ajouté (aucun email fourni : compte de connexion non créé)",
    "info",
  );
}

const UpdateEmployeeSchema = z.object({
  id: zNonEmpty,
  first_name: zOptional,
  last_name: zOptional,
  email: zEmailOpt,
  monthly_gross_salary: zNumberOpt,
}).passthrough();

export async function updateEmployee(formData: FormData) {
  const { id } = await validate(UpdateEmployeeSchema, formData, "/social");
  const monthlyGross = numberValue(formData, "monthly_gross_salary") || null;
  await supabase.from("employees").update({
    first_name: value(formData, "first_name"),
    last_name:  value(formData, "last_name"),
    role:       value(formData, "role"),
    contract_type: value(formData, "contract_type"),
    status:     value(formData, "status"),
    site_id:    value(formData, "site_id"),
    email:      value(formData, "email"),
    phone:      value(formData, "phone"),
    // Identité RH
    social_security_number:  value(formData, "social_security_number"),
    birth_date:              value(formData, "birth_date"),
    birth_place:             value(formData, "birth_place"),
    nationality:             value(formData, "nationality"),
    residence_permit_expiry: value(formData, "residence_permit_expiry"),
    address:                 value(formData, "address"),
    // Rémunération : coût horaire auto-déduit du brut mensuel
    monthly_gross_salary: monthlyGross,
    hourly_cost_rate:     computeHourlyCost(monthlyGross),
  }).eq("id", id);
  await flashAndFinalize(formData, "/social", "Salarié mis à jour");
}

export async function deleteEmployee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("employees").delete().eq("id", id);
  await logAudit({ action: "delete_employee", entity: "employees", entity_id: id });
  await flashAndFinalize(formData, "/social", "Salarié supprimé");
}

// ── Dossier salarié : documents personnels ───────────────────────────────────

/** Upload un fichier vers `employee-docs` et retourne { url, path, size, mime }. */
async function uploadEmployeeFile(
  formData: FormData,
  field: string,
  employeeId: string,
  docId: string,
): Promise<{ url: string; path: string; size: number; mime: string } | null> {
  const file = formData.get(field);
  if (!file || !(file instanceof File) || file.size === 0) return null;
  const ext = (file.name.split(".").pop() ?? "bin").toLowerCase().replace(/[^a-z0-9]/g, "");
  const path = `${employeeId}/${docId}.${ext || "bin"}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  const mime = file.type || "application/octet-stream";
  const { error } = await supabase.storage
    .from("employee-docs")
    .upload(path, buffer, { contentType: mime, upsert: true });
  if (error) return null;
  const { data } = supabase.storage.from("employee-docs").getPublicUrl(path);
  return { url: data.publicUrl, path, size: file.size, mime };
}

export async function uploadEmployeeDocument(formData: FormData) {
  const employeeId = value(formData, "employee_id");
  const category = value(formData, "category");
  if (!employeeId || !category) return;

  const docId = randomUUID();
  const uploaded = await uploadEmployeeFile(formData, "file", employeeId, docId);

  await supabase.from("employee_documents").insert({
    id: docId,
    employee_id: employeeId,
    category,
    title: value(formData, "title"),
    file_url: uploaded?.url ?? null,
    file_path: uploaded?.path ?? null,
    mime_type: uploaded?.mime ?? null,
    file_size: uploaded?.size ?? null,
    issued_on: value(formData, "issued_on"),
    expires_on: value(formData, "expires_on"),
    notes: value(formData, "notes"),
  });

  await flashAndFinalize(formData, "/social", "Document salarié ajouté");
}

export async function deleteEmployeeDocument(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  // Récupère le file_path avant suppression pour nettoyer le storage
  const { data } = await supabase
    .from("employee_documents")
    .select("file_path")
    .eq("id", id)
    .single();
  const filePath = (data as { file_path: string | null } | null)?.file_path;
  if (filePath) {
    await supabase.storage.from("employee-docs").remove([filePath]);
  }
  await supabase.from("employee_documents").delete().eq("id", id);
  await logAudit({ action: "delete_employee_document", entity: "employee_documents", entity_id: id });
  await flashAndFinalize(formData, "/social", "Document salarié supprimé");
}

// ── Paie : socle de rémunération du salarié ──────────────────────────────────

export async function updateEmployeePay(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  const payMode = (value(formData, "pay_mode") ?? "mensualise") === "horaire" ? "horaire" : "mensualise";
  const monthlyGross = numberValue(formData, "monthly_gross_salary") || null;
  await supabase.from("employees").update({
    pay_mode: payMode,
    monthly_gross_salary: monthlyGross,
    hourly_rate: numberValue(formData, "hourly_rate") || null,
    contract_hours: numberValue(formData, "contract_hours") || 151.67,
    meal_allowance_daily: numberValue(formData, "meal_allowance_daily") || 0,
    tournee_rate: numberValue(formData, "tournee_rate") || 0,
    pay_notes: value(formData, "pay_notes"),
    // Maintient le coût horaire employeur en phase avec le brut mensuel
    hourly_cost_rate: computeHourlyCost(monthlyGross),
  }).eq("id", id);

  // Liaison salarié <-> profil TMS (optionnel)
  const profileIdRaw = value(formData, "profile_id");
  if (profileIdRaw !== null) {
    await supabase.rpc("link_employee_profile", {
      p_employee_id: id,
      p_profile_id: profileIdRaw === "" ? null : profileIdRaw,
    });
  }

  await flashAndFinalize(formData, "/social", "Rémunération mise à jour");
}

export async function recalculatePayrollPeriod(formData: FormData) {
  const period = value(formData, "period");
  if (!period) return;
  const companyId = value(formData, "company_id");
  await supabase.rpc("recalc_payroll_for_period", {
    p_period: period,
    p_company_id: companyId,
  });
  await flashAndFinalize(formData, "/social", "Pré-paie recalculée");
}

// ── Pré-paie : variables mensuelles d'un salarié ─────────────────────────────

const UpsertPayrollVariableSchema = z.object({
  employee_id: zNonEmpty,
  period: zNonEmpty,
  overtime_hours: zNumberOpt,
  bonus_amount: zNumberOpt,
  deductions: zNumberOpt,
  worked_days: zNumberOpt,
  km_allowance: zNumberOpt,
  unpaid_absence_hours: zNumberOpt,
}).passthrough();

export async function upsertPayrollVariable(formData: FormData) {
  const { employee_id: employeeId, period } = await validate(
    UpsertPayrollVariableSchema,
    formData,
    "/social",
  );

  const existingId = value(formData, "variable_id");
  const mealRaw = value(formData, "meal_allowance_amount");

  const payload = {
    employee_id: employeeId,
    period,
    overtime_hours: numberValue(formData, "overtime_hours"),
    bonus_amount: numberValue(formData, "bonus_amount"),
    deductions: numberValue(formData, "deductions"),
    worked_days: numberValue(formData, "worked_days"),
    meal_allowance_amount: mealRaw != null ? numberValue(formData, "meal_allowance_amount") : null,
    km_allowance: numberValue(formData, "km_allowance"),
    unpaid_absence_hours: numberValue(formData, "unpaid_absence_hours"),
    status: value(formData, "status") ?? "A valider",
    notes: value(formData, "notes"),
  };

  if (existingId) {
    await supabase.from("payroll_variables").update(payload).eq("id", existingId);
  } else {
    await supabase.from("payroll_variables").upsert(
      { id: randomUUID(), ...payload },
      { onConflict: "employee_id,period" }
    );
  }

  await flashAndFinalize(formData, "/social", "Variables de paie enregistrées");
}

export async function deletePayrollVariable(formData: FormData) {
  const id = value(formData, "variable_id") ?? value(formData, "id");
  if (!id) return;
  await supabase.from("payroll_variables").delete().eq("id", id);
  await flashAndFinalize(formData, "/social", "Variable de paie supprimée");
}

// Verrouillage / déverrouillage d'une période complète (basculer toutes les
// variables d'une période — éventuellement filtrées par société — vers "Prêt paie").
export async function setPayrollPeriodStatus(formData: FormData) {
  const period = value(formData, "period");
  const status = value(formData, "status") ?? "Pret paie";
  const companyId = value(formData, "company_id");
  if (!period) return;

  // Pour ne basculer que les salariés de la société (s'il y a un scope), on
  // sélectionne d'abord leurs identifiants puis on filtre la mise à jour.
  let employeeIds: string[] | null = null;
  if (companyId) {
    const { data } = await supabase.from("employees").select("id").eq("company_id", companyId);
    employeeIds = (data ?? []).map((e) => e.id);
    if (employeeIds.length === 0) {
      await flashAndFinalize(formData, "/social", "Aucun salarié à mettre à jour", "info");
      return;
    }
  }

  let query = supabase.from("payroll_variables").update({ status }).eq("period", period);
  if (employeeIds) query = query.in("employee_id", employeeIds);
  await query;

  await logAudit({
    action: "set_payroll_period_status",
    entity: "payroll_variables",
    company_id: companyId,
    metadata: { period, status, employees: employeeIds?.length ?? "*" },
  });
  await flashAndFinalize(formData, "/social", `Période ${period} basculée en « ${status} »`);
}

// ── Sites ─────────────────────────────────────────────────────────────────────

const CreateSiteSchema = z.object({
  company_id: zOptional,
  name: zNonEmpty,
  region: zOptional,
  mode: zOptional,
  monthly_routes: zNumberOpt,
  vehicles_target: zNumberOpt,
  employees_target: zNumberOpt,
  observations: zOptional,
}).passthrough();

export async function createSite(formData: FormData) {
  await validate(CreateSiteSchema, formData, "/sites");
  const user = await requireUser();
  const companyId = value(formData, "company_id") ?? user.company_id;
  if (!companyId) {
    await flashAndFinalize(formData, "/sites", "Société manquante pour créer le site", "error");
    return;
  }

  const { error } = await supabase.from("sites").insert({
    id: randomUUID(),
    company_id: companyId,
    name: value(formData, "name"),
    region: value(formData, "region") ?? "",
    mode: value(formData, "mode") ?? "Propre",
    monthly_routes: numberValue(formData, "monthly_routes"),
    vehicles_target: numberValue(formData, "vehicles_target"),
    employees_target: numberValue(formData, "employees_target"),
    observations: value(formData, "observations"),
  });
  if (error) {
    await flashAndFinalize(formData, "/sites", `Erreur création site : ${error.message}`, "error");
    return;
  }
  await flashAndFinalize(formData, "/sites", "Site créé");
}

export async function updateSite(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  const { error } = await supabase.from("sites").update({
    name: value(formData, "name"),
    region: value(formData, "region"),
    mode: value(formData, "mode"),
    monthly_routes: numberValue(formData, "monthly_routes"),
    vehicles_target: numberValue(formData, "vehicles_target"),
    employees_target: numberValue(formData, "employees_target"),
    observations: value(formData, "observations"),
  }).eq("id", id);
  if (error) {
    await flashAndFinalize(formData, "/sites", `Erreur mise à jour site : ${error.message}`, "error");
    return;
  }
  await flashAndFinalize(formData, "/sites", "Site mis à jour");
}

export async function deleteSite(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  const { error } = await supabase.from("sites").delete().eq("id", id);
  if (error) {
    await flashAndFinalize(formData, "/sites", `Erreur suppression site : ${error.message}`, "error");
    return;
  }
  await logAudit({ action: "delete_site", entity: "sites", entity_id: id });
  await flashAndFinalize(formData, "/sites", "Site supprimé");
}

// ── Véhicules TMS ─────────────────────────────────────────────────────────────

/** Upload a vehicle document file to Supabase Storage and return the public URL. */
async function uploadVehicleDoc(
  formData: FormData,
  field: string,
  vehicleId: string,
): Promise<string | null> {
  const file = formData.get(field);
  if (!file || !(file instanceof File) || file.size === 0) return null;
  const ext = file.name.split(".").pop() ?? "pdf";
  const path = `${vehicleId}/${field}.${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  const { error } = await supabase.storage
    .from("vehicle-docs")
    .upload(path, buffer, { contentType: file.type || "application/octet-stream", upsert: true });
  if (error) return null;
  const { data } = supabase.storage.from("vehicle-docs").getPublicUrl(path);
  return data.publicUrl;
}

const CreateTmsVehicleSchema = z.object({
  company_id: zNonEmpty,
  plate_number: zNonEmpty,
  brand: zOptional,
  model: zOptional,
  year: zNumberOpt,
  fuel_type: zOptional,
  mileage: zNumberOpt,
  insurance_expiry: zDateOpt,
  technical_control_expiry: zDateOpt,
}).passthrough();

export async function createTmsVehicle(formData: FormData) {
  const { company_id: companyId } = await validate(CreateTmsVehicleSchema, formData, "/vehicules");
  const vehicleId = randomUUID();
  const [registrationDoc, insuranceDoc, inspectionDoc] = await Promise.all([
    uploadVehicleDoc(formData, "registration_doc", vehicleId),
    uploadVehicleDoc(formData, "insurance_doc", vehicleId),
    uploadVehicleDoc(formData, "inspection_doc", vehicleId),
  ]);
  await supabase.from("tms_vehicles").insert({
    id: vehicleId,
    company_id: companyId,
    plate_number: value(formData, "plate_number"),
    brand: value(formData, "brand"),
    model: value(formData, "model"),
    year: numberValue(formData, "year") || null,
    fuel_type: value(formData, "fuel_type") ?? "diesel",
    status: "available",
    mileage: numberValue(formData, "mileage") || 0,
    max_payload_kg: numberValue(formData, "max_payload_kg") || null,
    insurance_expiry: value(formData, "insurance_expiry"),
    technical_control_expiry: value(formData, "technical_control_expiry"),
    next_maintenance_date: value(formData, "next_maintenance_date"),
    vin: value(formData, "vin"),
    notes: value(formData, "notes"),
    registration_doc: registrationDoc,
    insurance_doc: insuranceDoc,
    inspection_doc: inspectionDoc,
    // Coûts d'exploitation (taux par défaut utilisés par les calculs de rentabilité)
    fuel_consumption_l_100km: numberValue(formData, "fuel_consumption_l_100km") || null,
    fuel_price_per_l:         numberValue(formData, "fuel_price_per_l")         || null,
    amortization_per_km:      numberValue(formData, "amortization_per_km")      || null,
    tire_cost_per_km:         numberValue(formData, "tire_cost_per_km")         || null,
    maintenance_cost_per_km:  numberValue(formData, "maintenance_cost_per_km")  || null,
    has_cold_unit:            formData.get("has_cold_unit") === "on",
    cold_unit_cost_per_hour:  numberValue(formData, "cold_unit_cost_per_hour")  || null,
  });
  await flashAndFinalize(formData, "/vehicules", "Véhicule ajouté");
}

export async function updateTmsVehicle(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  // Upload new files if provided; fall back to existing URL from hidden fields
  const [newRegDoc, newInsDoc, newInspDoc] = await Promise.all([
    uploadVehicleDoc(formData, "registration_doc_file", id),
    uploadVehicleDoc(formData, "insurance_doc_file", id),
    uploadVehicleDoc(formData, "inspection_doc_file", id),
  ]);
  await supabase.from("tms_vehicles").update({
    plate_number: value(formData, "plate_number"),
    brand: value(formData, "brand"),
    model: value(formData, "model"),
    year: numberValue(formData, "year") || null,
    fuel_type: value(formData, "fuel_type"),
    status: value(formData, "status"),
    mileage: numberValue(formData, "mileage") || 0,
    max_payload_kg: numberValue(formData, "max_payload_kg") || null,
    insurance_expiry: value(formData, "insurance_expiry"),
    technical_control_expiry: value(formData, "technical_control_expiry"),
    next_maintenance_date: value(formData, "next_maintenance_date"),
    vin: value(formData, "vin"),
    notes: value(formData, "notes"),
    registration_doc: newRegDoc ?? value(formData, "registration_doc"),
    insurance_doc: newInsDoc ?? value(formData, "insurance_doc"),
    inspection_doc: newInspDoc ?? value(formData, "inspection_doc"),
    // Coûts d'exploitation
    fuel_consumption_l_100km: numberValue(formData, "fuel_consumption_l_100km") || null,
    fuel_price_per_l:         numberValue(formData, "fuel_price_per_l")         || null,
    amortization_per_km:      numberValue(formData, "amortization_per_km")      || null,
    tire_cost_per_km:         numberValue(formData, "tire_cost_per_km")         || null,
    maintenance_cost_per_km:  numberValue(formData, "maintenance_cost_per_km")  || null,
    has_cold_unit:            formData.get("has_cold_unit") === "on",
    cold_unit_cost_per_hour:  numberValue(formData, "cold_unit_cost_per_hour")  || null,
  }).eq("id", id);
  await flashAndFinalize(formData, "/vehicules", "Véhicule mis à jour");
}

export async function deleteTmsVehicle(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tms_vehicles").delete().eq("id", id);
  await logAudit({ action: "delete_vehicle", entity: "tms_vehicles", entity_id: id });
  await flashAndFinalize(formData, "/vehicules", "Véhicule supprimé");
}

export async function createMaintenanceRecord(formData: FormData) {
  const vehicleId = value(formData, "vehicle_id");
  if (!vehicleId) return;
  const serviceDate = value(formData, "service_date") ?? new Date().toISOString().slice(0, 10);
  await supabase.from("maintenance_records").insert({
    id: randomUUID(),
    vehicle_id: vehicleId,
    maintenance_type: value(formData, "maintenance_type") ?? "revision",
    description: value(formData, "description"),
    service_date: serviceDate,
    mileage_at_service: numberValue(formData, "mileage_at_service") || null,
    cost: numberValue(formData, "cost") || null,
    provider: value(formData, "provider"),
    next_service_date: value(formData, "next_service_date"),
    next_service_mileage: numberValue(formData, "next_service_mileage") || null,
  });
  // update vehicle last_maintenance_date
  await supabase.from("tms_vehicles").update({
    last_maintenance_date: serviceDate,
    ...(value(formData, "next_service_date") ? { next_maintenance_date: value(formData, "next_service_date") } : {}),
  }).eq("id", vehicleId);
  await flashAndFinalize(formData, "/vehicules", "Entretien enregistré");
}

// ── Tournées ──────────────────────────────────────────────────────────────────

function genRef(prefix: string) {
  const y = new Date().getFullYear();
  const n = Date.now().toString().slice(-4);
  return `${prefix}-${y}-${n}`;
}

const CreateTourneeSchema = z.object({
  company_id: zNonEmpty,
  name: zOptional,
  scheduled_date: zDateOpt,
  driver_id: zOptional,
  vehicle_id: zOptional,
  subcontractor_id: zOptional,
  total_distance_km: zNumberOpt,
  estimated_hours: zNumberOpt,
  flat_rate_revenue: zNumberOpt,
  status: zOptional,
  recurrence_type: zOptional,
  recurrence_end_date: zDateOpt,
  recurrence_interval: zOptional,
  recurrence_days: zOptional,
  recurrence_end_mode: zOptional,
  recurrence_end_count: zOptional,
  recurrence_skip_weekends: zOptional,
  notes: zOptional,
}).passthrough();

type StopInput = {
  pickup_address: string;
  pickup_city: string;
  delivery_address: string;
  delivery_city: string;
  scheduled_time?: string | null;
  cargo_description?: string | null;
  distance_km?: number | null;
  price?: number | null;
};

interface RecurrenceParams {
  start: string;
  type: string;
  endMode: "date" | "count";
  endDate: string | null;
  endCount: number;
  interval: number;    // every N days/weeks/months
  days: number[];      // ISO weekday Mon=0…Sun=6 (used for multi-day weekly)
  skipWeekends: boolean;
}

function _rrParseDate(s: string): Date {
  const [y, m, d] = s.split("-").map(Number);
  return new Date(y, m - 1, d);
}
function _rrFmtDate(d: Date): string {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function _rrIsoWeekday(d: Date): number {
  return (d.getDay() + 6) % 7; // Mon=0…Sun=6
}

function generateRecurrenceDates({
  start, type, endMode, endDate, endCount, interval, days, skipWeekends,
}: RecurrenceParams): string[] {
  if (type === "none") return [start];

  const MAX = 365;
  const result: string[] = [];
  const maxCount = endMode === "count" ? Math.min(endCount, MAX) : MAX;
  const limitDate = endMode === "date" && endDate && endDate >= start ? endDate : null;
  if (endMode === "date" && !limitDate) return [start];

  // ── Weekly with explicit day selection ──────────────────────────────────
  if (type === "weekly" && days.length > 0) {
    const startD = _rrParseDate(start);
    const weekStart = new Date(startD);
    weekStart.setDate(startD.getDate() - _rrIsoWeekday(startD)); // Monday of start-week
    let wo = 0;
    outer: while (result.length < maxCount) {
      if (wo % interval === 0) {
        for (const day of [...days].sort((a, b) => a - b)) {
          const d = new Date(weekStart);
          d.setDate(weekStart.getDate() + wo * 7 + day);
          if (d < startD) continue;
          const s = _rrFmtDate(d);
          if (limitDate && s > limitDate) break outer;
          if (result.length >= maxCount) break outer;
          result.push(s);
        }
      }
      if (++wo > 1040) break; // safety: ~20 years
    }
    return result;
  }

  // ── Monthly ─────────────────────────────────────────────────────────────
  if (type === "monthly") {
    const startD = _rrParseDate(start);
    const origDay = startD.getDate();
    for (let i = 0; result.length < maxCount && i < 1200; i++) {
      const mo = i * interval;
      const y = startD.getFullYear() + Math.floor((startD.getMonth() + mo) / 12);
      const m = (startD.getMonth() + mo) % 12;
      const d = new Date(y, m, Math.min(origDay, new Date(y, m + 1, 0).getDate()));
      const s = _rrFmtDate(d);
      if (limitDate && s > limitDate) break;
      result.push(s);
    }
    return result;
  }

  // ── Daily / weekly (no day selection) ───────────────────────────────────
  const cur = _rrParseDate(start);
  let safety = 0;
  while (result.length < maxCount && safety++ < 5000) {
    const s = _rrFmtDate(cur);
    if (limitDate && s > limitDate) break;
    const isWeekend = cur.getDay() === 0 || cur.getDay() === 6;
    if (!skipWeekends || !isWeekend) result.push(s);
    if (type === "daily") cur.setDate(cur.getDate() + interval);
    else if (type === "weekly") cur.setDate(cur.getDate() + 7 * interval);
    else break;
  }
  return result;
}

async function insertTourneeStops(
  tourneeId: string,
  companyId: string,
  scheduledDate: string,
  driverId: string | null,
  vehicleId: string | null,
  stops: StopInput[],
) {
  for (let i = 0; i < stops.length; i++) {
    const s = stops[i];
    if (!s.pickup_city && !s.pickup_address && !s.delivery_city && !s.delivery_address) continue;
    const missionId = randomUUID();
    await supabase.from("missions").insert({
      id: missionId,
      company_id: companyId,
      reference: genRef("MIS"),
      status: driverId ? "assigned" : "draft",
      scheduled_date: scheduledDate,
      scheduled_time: s.scheduled_time || null,
      pickup_address: s.pickup_address || "",
      pickup_city: s.pickup_city || "",
      delivery_address: s.delivery_address || "",
      delivery_city: s.delivery_city || "",
      cargo_description: s.cargo_description || null,
      distance_km: s.distance_km ?? null,
      // If no explicit price is provided, compute one using pricing rules
      price: s.price ?? null,
      price_computed: null,
      price_breakdown: null,
      fuel_price_used: null,
      fuel_surcharge_percent: null,
      driver_id: driverId,
      vehicle_id: vehicleId,
      client_id: null,
      requires_adr: false,
      priority: "normal",
    });
    await supabase.from("tournee_missions").insert({
      id: randomUUID(),
      tournee_id: tourneeId,
      mission_id: missionId,
      order: i + 1,
    });
    // Compute price if not provided
    if (s.price == null) {
      try {
        const result = await computeMissionPrice({
          company_id: companyId,
          distance_km: s.distance_km ?? null,
          requires_adr: false,
          priority: "normal",
        });
        await supabase.from("missions").update({
          price: result.price,
          price_computed: result.price,
          price_breakdown: result.breakdown,
          fuel_price_used: result.fuel_price_used,
          fuel_surcharge_percent: result.fuel_surcharge_percent,
        }).eq("id", missionId);
      } catch (e) {
        // best-effort: don't block creation on pricing errors
      }
    }
  }
}

export async function createTournee(formData: FormData) {
  const { company_id: companyId } = await validate(CreateTourneeSchema, formData, "/tournees");
  const rawStatus = value(formData, "status");
  const status = rawStatus === "draft" ? "draft" : "scheduled";
  const scheduledDate = value(formData, "scheduled_date") ?? new Date().toISOString().slice(0, 10);
  const driverId = value(formData, "driver_id") || null;
  const vehicleId = value(formData, "vehicle_id") || null;
  const subcontractorId = value(formData, "subcontractor_id") || null;
  const name = value(formData, "name") ?? "Nouvelle tournée";
  const recurrenceType = value(formData, "recurrence_type") ?? "none";
  const recurrenceEndDate = value(formData, "recurrence_end_date") || null;
  const recurrenceInterval = Math.max(1, parseInt(value(formData, "recurrence_interval") ?? "1", 10) || 1);
  const recurrenceDaysRaw = value(formData, "recurrence_days") ?? "";
  const recurrenceDays = recurrenceDaysRaw
    ? recurrenceDaysRaw.split(",").map(Number).filter((n) => !isNaN(n) && n >= 0 && n <= 6)
    : [];
  const recurrenceEndMode = (value(formData, "recurrence_end_mode") === "count" ? "count" : "date") as "date" | "count";
  const recurrenceEndCount = Math.max(1, parseInt(value(formData, "recurrence_end_count") ?? "1", 10) || 1);
  const recurrenceSkipWeekends = value(formData, "recurrence_skip_weekends") === "true";

  // Parse stops
  let stops: StopInput[] = [];
  try {
    const raw = value(formData, "stops_json");
    if (raw) stops = JSON.parse(raw) as StopInput[];
  } catch { /* ignore malformed JSON */ }

  const dates = generateRecurrenceDates({
    start: scheduledDate,
    type: recurrenceType,
    endMode: recurrenceEndMode,
    endDate: recurrenceEndDate,
    endCount: recurrenceEndCount,
    interval: recurrenceInterval,
    days: recurrenceDays,
    skipWeekends: recurrenceSkipWeekends,
  });
  const groupId = dates.length > 1 ? randomUUID() : null;

  for (const date of dates) {
    const tourneeId = randomUUID();
    const { error } = await supabase.from("tournees").insert({
      id: tourneeId,
      company_id: companyId,
      reference: genRef("TRN"),
      name,
      status,
      scheduled_date: date,
      driver_id: driverId,
      vehicle_id: vehicleId,
      subcontractor_id: subcontractorId,
      total_distance_km: numberValue(formData, "total_distance_km") || null,
      estimated_hours: numberValue(formData, "estimated_hours") || null,
      flat_rate_revenue: numberValue(formData, "flat_rate_revenue") || null,
      notes: value(formData, "notes"),
      recurrence_type: recurrenceType !== "none" ? recurrenceType : null,
      recurrence_group_id: groupId,
    });
    if (error) {
      console.error("[createTournee] insert failed:", error.message);
      await flashAndFinalize(formData, "/tournees", `Erreur création tournée : ${error.message}`, "error");
      return;
    }
    if (stops.length > 0) {
      await insertTourneeStops(tourneeId, companyId, date, driverId, vehicleId, stops);
    }
  }

  const msg = dates.length > 1
    ? `${dates.length} tournées créées (récurrence ${recurrenceType})`
    : "Tournée créée";
  await flashAndFinalize(formData, "/tournees", msg);
}

export async function updateTourneeStatus(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tournees").update({
    status: value(formData, "status"),
    driver_id: value(formData, "driver_id") || null,
    vehicle_id: value(formData, "vehicle_id") || null,
  }).eq("id", id);
  await flashAndFinalize(formData, "/tournees", "Tournée mise à jour");
}

export async function deleteTournee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tournees").delete().eq("id", id);
  await logAudit({ action: "delete_tournee", entity: "tournees", entity_id: id });
  await flashAndFinalize(formData, "/tournees", "Tournée supprimée");
}

/* ── Affectation et cycle de vie d'une tournée ─────────────────────────────── */

/** Affecte (ou réaffecte) chauffeur / véhicule / date à une tournée. */
export async function assignTournee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  const update: Record<string, unknown> = {};
  if (formData.has("driver_id"))      update.driver_id      = value(formData, "driver_id") || null;
  if (formData.has("vehicle_id"))     update.vehicle_id     = value(formData, "vehicle_id") || null;
  if (formData.has("scheduled_date")) update.scheduled_date = value(formData, "scheduled_date") || null;
  if (formData.has("name"))           update.name           = value(formData, "name") || "Tournée";
  if (formData.has("notes"))          update.notes          = value(formData, "notes");
  if (formData.has("total_distance_km"))
    update.total_distance_km = numberValue(formData, "total_distance_km") || null;

  // Champs rentabilité (tous numériques, null si vide)
  const PROFITABILITY_FIELDS = [
    "flat_rate_revenue", "surcharge_fuel", "surcharge_adr", "surcharge_wait",
    "surcharge_other", "other_revenue", "toll_cost", "fuel_cost_override",
    "driver_cost_override", "vehicle_cost_override", "subcontractor_cost",
    "cold_unit_cost_override", "maintenance_cost_override", "tire_cost_override",
    "misc_cost", "estimated_hours",
  ] as const;
  for (const f of PROFITABILITY_FIELDS) {
    if (formData.has(f)) {
      const raw = value(formData, f);
      update[f] = raw ? Number(raw.replace(",", ".")) : null;
    }
  }

  if (Object.keys(update).length === 0) return;
  const { error } = await supabase.from("tournees").update(update).eq("id", id);
  if (error) {
    console.error("[assignTournee]", error);
    await flashAndFinalize(formData, "/tournees", `Erreur affectation : ${error.message}`, "error");
    return;
  }
  await flashAndFinalize(formData, "/tournees", "Affectation mise à jour");
}

/** Démarrer une tournée (=> in_progress, actual_start = now). */
export async function startTournee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tournees").update({
    status: "in_progress",
    actual_start: new Date().toISOString(),
  }).eq("id", id);
  await flashAndFinalize(formData, "/tournees", "Tournée démarrée");
}

/** Terminer une tournée (=> completed, actual_end = now). */
export async function completeTournee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tournees").update({
    status: "completed",
    actual_end: new Date().toISOString(),
  }).eq("id", id);
  await flashAndFinalize(formData, "/tournees", "Tournée terminée");
}

/** Réinitialiser une tournée terminée/annulée (=> scheduled). */
export async function resetTournee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tournees").update({
    status: "scheduled",
    actual_start: null,
    actual_end: null,
  }).eq("id", id);
  await flashAndFinalize(formData, "/tournees", "Tournée réinitialisée");
}

/** Annuler une tournée. */
export async function cancelTournee(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("tournees").update({ status: "cancelled" }).eq("id", id);
  await flashAndFinalize(formData, "/tournees", "Tournée annulée");
}

/** Dupliquer une tournée vers une nouvelle date. */
export async function duplicateTournee(formData: FormData) {
  const id = value(formData, "id");
  const newDate = value(formData, "scheduled_date");
  if (!id || !newDate) return;
  const { data: src } = await supabase
    .from("tournees")
    .select("company_id, name, driver_id, vehicle_id, site_id, total_distance_km, notes")
    .eq("id", id)
    .single();
  if (!src) return;
  const keepAssign = formData.get("keep_assign") === "on";
  await supabase.from("tournees").insert({
    id: randomUUID(),
    company_id: src.company_id,
    reference: genRef("TRN"),
    name: src.name,
    status: "scheduled",
    scheduled_date: newDate,
    driver_id:  keepAssign ? src.driver_id  : null,
    vehicle_id: keepAssign ? src.vehicle_id : null,
    site_id: src.site_id,
    total_distance_km: src.total_distance_km,
    notes: src.notes,
  });
  await flashAndFinalize(formData, "/tournees", "Tournée dupliquée");
}

/** Rattacher une mission à une tournée (à la fin par défaut). */
export async function attachMissionToTournee(formData: FormData) {
  const tourneeId = value(formData, "tournee_id");
  const missionId = value(formData, "mission_id");
  if (!tourneeId || !missionId) return;

  // Détacher la mission de toute autre tournée d'abord
  await supabase.from("tournee_missions").delete().eq("mission_id", missionId);

  // Calculer le prochain order
  const { data: existing } = await supabase
    .from("tournee_missions")
    .select("order")
    .eq("tournee_id", tourneeId)
    .order("order", { ascending: false })
    .limit(1);
  const orderRaw = value(formData, "order");
  const order = orderRaw ? Number(orderRaw) : ((existing?.[0]?.order ?? 0) + 1);

  await supabase.from("tournee_missions").insert({
    id: randomUUID(),
    tournee_id: tourneeId,
    mission_id: missionId,
    order,
  });

  // Propager driver / vehicle de la tournée à la mission si non assignés
  const { data: t } = await supabase
    .from("tournees")
    .select("driver_id, vehicle_id, scheduled_date")
    .eq("id", tourneeId)
    .single();
  if (t) {
    await supabase.from("missions").update({
      driver_id: t.driver_id,
      vehicle_id: t.vehicle_id,
      scheduled_date: t.scheduled_date,
      status: "assigned",
    }).eq("id", missionId);
  }

  await flashAndFinalize(formData, "/tournees", "Mission rattachée à la tournée");
}

/** Détacher une mission d'une tournée. */
export async function detachMissionFromTournee(formData: FormData) {
  const missionId = value(formData, "mission_id");
  if (!missionId) return;
  await supabase.from("tournee_missions").delete().eq("mission_id", missionId);
  await flashAndFinalize(formData, "/tournees", "Mission détachée");
}

/** Réordonner les missions d'une tournée. Reçoit "mission_ids" = "id1,id2,id3". */
export async function reorderTourneeMissions(formData: FormData) {
  const tourneeId = value(formData, "tournee_id");
  const ids = value(formData, "mission_ids");
  if (!tourneeId || !ids) return;
  const list = ids.split(",").map((s) => s.trim()).filter(Boolean);
  for (let i = 0; i < list.length; i++) {
    await supabase
      .from("tournee_missions")
      .update({ order: i + 1 })
      .eq("tournee_id", tourneeId)
      .eq("mission_id", list[i]);
  }
  await flashAndFinalize(formData, "/tournees", "Ordre des missions mis à jour");
}

// ── Missions ──────────────────────────────────────────────────────────────────

export async function createMission(formData: FormData) {
  const companyId = value(formData, "company_id");
  if (!companyId) return;
  const clientId = value(formData, "client_id");
  if (!clientId) return;
  const missionId = randomUUID();
  const reference = genRef("MIS");

  // Pre-compute price if none provided
  let manualPrice = numberValue(formData, "price");
  let computed: null | Awaited<ReturnType<typeof computeMissionPrice>> = null;
  if (!manualPrice) {
    try {
      const distance = numberValue(formData, "distance_km") || null;
      computed = await computeMissionPrice({
        company_id: companyId,
        distance_km: distance,
        requires_adr: formData.get("requires_adr") === "on",
        priority: value(formData, "priority") ?? "normal",
      });
    } catch {
      computed = null;
    }
  }

  await supabase.from("missions").insert({
    id: missionId,
    company_id: companyId,
    reference,
    status: "draft",
    client_id: clientId,
    scheduled_date: value(formData, "scheduled_date") ?? new Date().toISOString().slice(0, 10),
    scheduled_time: value(formData, "scheduled_time"),
    pickup_address: value(formData, "pickup_address") ?? "",
    pickup_city: value(formData, "pickup_city") ?? "",
    delivery_address: value(formData, "delivery_address") ?? "",
    delivery_city: value(formData, "delivery_city") ?? "",
    cargo_description: value(formData, "cargo_description"),
    distance_km: numberValue(formData, "distance_km") || null,
    price: manualPrice || (computed ? computed.price : null),
    price_computed: computed ? computed.price : null,
    price_breakdown: computed ? computed.breakdown : null,
    fuel_price_used: computed ? computed.fuel_price_used : null,
    fuel_surcharge_percent: computed ? computed.fuel_surcharge_percent : null,
    driver_id: value(formData, "driver_id") || null,
    vehicle_id: value(formData, "vehicle_id") || null,
    notes: value(formData, "notes"),
    requires_adr: formData.get("requires_adr") === "on",
    priority: value(formData, "priority") ?? "normal",
  });
  await flashAndFinalize(formData, "/missions", "Mission créée");
}

export async function updateMissionStatus(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("missions").update({
    status: value(formData, "status"),
    driver_id: value(formData, "driver_id") || null,
    vehicle_id: value(formData, "vehicle_id") || null,
  }).eq("id", id);
  await flashAndFinalize(formData, "/missions", "Statut mission mis à jour");
}

export async function deleteMission(formData: FormData) {
  const id = value(formData, "id");
  if (!id) return;
  await supabase.from("missions").delete().eq("id", id);
  await logAudit({ action: "delete_mission", entity: "missions", entity_id: id });
  await flashAndFinalize(formData, "/missions", "Mission supprimée");
}
