"use server";

/**
 * app/chauffeur/actions.ts
 * Server action : push de la position GPS du chauffeur connecté dans profiles.
 */

import { getSupabaseServer } from "@/lib/supabase-server";

export async function updateMyPositionAction(
  lat: number,
  lng: number,
  speedKmh?: number | null,
  heading?: number | null,
) {
  if (
    typeof lat !== "number" || typeof lng !== "number" ||
    !isFinite(lat) || !isFinite(lng) ||
    lat < -90 || lat > 90 || lng < -180 || lng > 180
  ) {
    return { ok: false as const, error: "invalid_coords" };
  }

  const supabase = await getSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { ok: false as const, error: "unauthenticated" };

  const now = new Date().toISOString();

  // 1) Position courante sur le profil (pour la carte flotte) + company_id.
  // RLS : profiles_update_scoped autorise un user à mettre à jour son propre profil.
  const { data: prof, error } = await supabase
    .from("profiles")
    .update({ last_lat: lat, last_lng: lng, last_position_at: now })
    .eq("id", user.id)
    .select("company_id")
    .maybeSingle();

  if (error) return { ok: false as const, error: error.message };

  // 2) Historique de positions (best-effort, n'échoue pas l'action).
  await supabase.from("driver_positions").insert({
    driver_id: user.id,
    company_id: (prof as { company_id: string | null } | null)?.company_id ?? null,
    lat,
    lng,
    speed_kmh: typeof speedKmh === "number" && isFinite(speedKmh) ? speedKmh : null,
    heading: typeof heading === "number" && isFinite(heading) ? heading : null,
    recorded_at: now,
  });

  return { ok: true as const };
}
