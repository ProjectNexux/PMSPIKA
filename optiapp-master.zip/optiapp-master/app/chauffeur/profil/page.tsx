/**
 * app/chauffeur/profil/page.tsx
 * Vue profil simplifiée pour le chauffeur connecté.
 */

import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function ChauffeurProfilPage() {
  const user = await requireUser();

  return (
    <div className="ch-page">
      <section className="ch-card">
        <h2>Mon profil</h2>
        <dl className="ch-profile">
          <div>
            <dt>Nom</dt>
            <dd>{user.full_name || "—"}</dd>
          </div>
          <div>
            <dt>Email</dt>
            <dd>{user.email || "—"}</dd>
          </div>
          <div>
            <dt>Société</dt>
            <dd>{user.company_name || "—"}</dd>
          </div>
          <div>
            <dt>Site</dt>
            <dd>{user.site_name || "—"}</dd>
          </div>
          <div>
            <dt>Identifiant salarié</dt>
            <dd>{user.employee_id || "—"}</dd>
          </div>
        </dl>
      </section>
    </div>
  );
}
