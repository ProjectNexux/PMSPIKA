/**
 * app/chauffeur/livraison/[missionId]/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Écran chauffeur de validation d'une livraison (POD).
 */

import { notFound } from "next/navigation";
import Link from "next/link";
import { requireUser } from "@/lib/session";
import { getMissionDelivery } from "@/lib/pod-queries";
import { PodCapture } from "@/components/chauffeur/pod-capture";

export const dynamic = "force-dynamic";

const STAFF_ROLES = new Set(["super_admin", "gerant_groupe", "gerant_societe", "chef_site"]);

export default async function LivraisonPage({
  params,
}: {
  params: Promise<{ missionId: string }>;
}) {
  const { missionId } = await params;
  const user = await requireUser();
  const { mission, pod } = await getMissionDelivery(missionId);

  if (!mission) notFound();

  // Le chauffeur ne peut valider que ses propres missions (sauf encadrement).
  if (mission.driver_id !== user.id && !STAFF_ROLES.has(user.role)) {
    notFound();
  }

  const deliveryLabel =
    [mission.delivery_address, mission.delivery_city].filter(Boolean).join(", ") ||
    "Adresse non renseignée";

  return (
    <div className="ch-page">
      <div className="ch-back">
        <Link href="/chauffeur">← Planning</Link>
      </div>

      <PodCapture
        missionId={mission.id}
        reference={mission.reference}
        deliveryLabel={deliveryLabel}
        initialStatus={mission.delivery_status ?? "a_traiter"}
        alreadyDelivered={!!pod}
      />
    </div>
  );
}
