/**
 * app/chauffeur/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Accueil chauffeur : son planning + suivi de position en arrière-plan.
 */

import { requireUser } from "@/lib/session";
import { getSupabaseServer } from "@/lib/supabase-server";
import { GeolocationTracker } from "@/components/chauffeur/geolocation-tracker";

export const dynamic = "force-dynamic";

type TourneeRow = {
  id: string;
  tournee_date: string | null;
  status: string | null;
  scheduled_start: string | null;
  scheduled_end: string | null;
  vehicle_id: string | null;
  notes: string | null;
};

export default async function ChauffeurHomePage() {
  const user = await requireUser();
  const supabase = await getSupabaseServer();

  // RLS : seules les tournées du chauffeur (driver_id = auth.uid()) sont retournées.
  const today = new Date().toISOString().slice(0, 10);
  const { data: tournees } = await supabase
    .from("tournees")
    .select("id, tournee_date, status, scheduled_start, scheduled_end, vehicle_id, notes")
    .gte("tournee_date", today)
    .order("tournee_date", { ascending: true })
    .order("scheduled_start", { ascending: true })
    .limit(10);

  const list = (tournees ?? []) as TourneeRow[];

  return (
    <div className="ch-page">
      <GeolocationTracker />

      <section className="ch-card ch-hero">
        <small>Bonjour</small>
        <h1>{user.full_name || "Chauffeur"}</h1>
        <p>Voici votre planning à venir.</p>
      </section>

      <section className="ch-card">
        <h2>Mes tournées</h2>
        {list.length === 0 ? (
          <p className="ch-empty">Aucune tournée planifiée à venir.</p>
        ) : (
          <ul className="ch-tournee-list">
            {list.map((t) => (
              <li key={t.id}>
                <a href={`/chauffeur/tournee/${t.id}`} className="ch-tournee ch-tournee-link">
                  <div className="ch-tournee-date">
                    <strong>{formatDate(t.tournee_date)}</strong>
                    <span className={`ch-status ch-status-${t.status ?? "unknown"}`}>
                      {labelStatus(t.status)}
                    </span>
                  </div>
                  <div className="ch-tournee-meta">
                    <span>
                      🕒 {formatTime(t.scheduled_start)} – {formatTime(t.scheduled_end)}
                    </span>
                    {t.vehicle_id && <span>🚐 {t.vehicle_id}</span>}
                  </div>
                  {t.notes && <p className="ch-tournee-notes">{t.notes}</p>}
                </a>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function formatDate(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleDateString("fr-FR", {
    weekday: "short",
    day: "numeric",
    month: "short",
  });
}

function formatTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function labelStatus(status: string | null): string {
  switch (status) {
    case "planned":
      return "Prévue";
    case "in_progress":
      return "En cours";
    case "completed":
      return "Terminée";
    case "cancelled":
      return "Annulée";
    default:
      return status ?? "—";
  }
}
