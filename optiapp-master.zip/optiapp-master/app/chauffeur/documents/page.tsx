/**
 * app/chauffeur/documents/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Documents personnels du chauffeur (RLS : il ne voit que les siens via
 * employees_read_scoped + employee_id).
 */

import { requireUser } from "@/lib/session";
import { getSupabaseServer } from "@/lib/supabase-server";

export const dynamic = "force-dynamic";

type DocRow = {
  id: string;
  name: string | null;
  type: string | null;
  expiry_date: string | null;
  created_at: string | null;
  url: string | null;
};

export default async function ChauffeurDocumentsPage() {
  const user = await requireUser();
  const supabase = await getSupabaseServer();

  let docs: DocRow[] = [];
  if (user.employee_id) {
    const { data } = await supabase
      .from("employee_documents")
      .select("id, name, type, expiry_date, created_at, url")
      .eq("employee_id", user.employee_id)
      .order("created_at", { ascending: false });
    docs = (data ?? []) as DocRow[];
  }

  return (
    <div className="ch-page">
      <section className="ch-card">
        <h2>Mes documents</h2>
        {docs.length === 0 ? (
          <p className="ch-empty">
            Aucun document n'est associé à votre profil pour le moment. Contactez votre
            exploitant pour qu'il téléverse vos pièces (permis, contrat, FIMO/FCO…).
          </p>
        ) : (
          <ul className="ch-doc-list">
            {docs.map((d) => (
              <li key={d.id} className="ch-doc">
                <div>
                  <strong>{d.name || d.type || "Document"}</strong>
                  <small>
                    {d.type && <span>{d.type}</span>}
                    {d.expiry_date && <span> · expire le {formatDate(d.expiry_date)}</span>}
                  </small>
                </div>
                {d.url && (
                  <a href={d.url} target="_blank" rel="noopener noreferrer">
                    Ouvrir
                  </a>
                )}
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}
