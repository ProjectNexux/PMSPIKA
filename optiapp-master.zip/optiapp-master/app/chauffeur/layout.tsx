/**
 * app/chauffeur/layout.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Layout mobile-first pour l'espace chauffeur (sans AppShell).
 * Le middleware garantit que seuls les rôles "chauffeur" / "client" arrivent ici.
 */

import type { Metadata, Viewport } from "next";
import Link from "next/link";
import { signOutAction } from "../login/actions";
import { requireUser } from "@/lib/session";

export const metadata: Metadata = {
  title: "PIKA TRANSPORT — Chauffeur",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Pika",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: "cover",
  themeColor: "#F59E0B",
};

export default async function ChauffeurLayout({ children }: { children: React.ReactNode }) {
  const user = await requireUser();

  return (
    <div className="ch-shell">
      <header className="ch-topbar">
        <div className="ch-topbar-left">
          <img src="/logo-icon.svg" alt="PIKA TRANSPORT" width={36} height={36} style={{ borderRadius: 8, display: "block", flexShrink: 0 }} />
          <div>
            <strong>{user.full_name || "Chauffeur"}</strong>
            <small>{user.email}</small>
          </div>
        </div>
        <form action={signOutAction}>
          <button type="submit" className="ch-signout" aria-label="Déconnexion">
            Quitter
          </button>
        </form>
      </header>

      <main className="ch-main">{children}</main>

      <nav className="ch-tabbar" aria-label="Navigation chauffeur">
        <Link href="/chauffeur" className="ch-tab">
          <span aria-hidden>🛣️</span>
          <span>Planning</span>
        </Link>
        <Link href="/chauffeur/documents" className="ch-tab">
          <span aria-hidden>📁</span>
          <span>Documents</span>
        </Link>
        <Link href="/chauffeur/profil" className="ch-tab">
          <span aria-hidden>👤</span>
          <span>Profil</span>
        </Link>
      </nav>
    </div>
  );
}
