"use server";

/**
 * app/chauffeur/tournee/actions.ts
 * Server actions pour la gestion des tournées côté chauffeur.
 */

import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { getSupabaseServer } from "@/lib/supabase-server";
import { getServerSupabase } from "@/lib/db-server";
import { requireUser } from "@/lib/session";
import { setFlash } from "@/lib/flash";
import { notifyInApp } from "@/lib/notifications";
import type { DeliveryEventType, DeliveryStatus, PodStatus } from "@/lib/pod-queries";

export type TourneeStatus = "scheduled" | "planned" | "in_progress" | "completed" | "cancelled";

/**
 * Met à jour le statut d'une tournée (le chauffeur ne peut modifier que ses propres tournées — RLS).
 */
export async function updateTourneeStatusAction(
  tourneeId: string,
  newStatus: TourneeStatus,
) {
  await requireUser();
  if (!tourneeId) return { ok: false as const, error: "ID manquant." };

  const validStatuses: TourneeStatus[] = ["scheduled", "planned", "in_progress", "completed", "cancelled"];
  if (!validStatuses.includes(newStatus)) {
    return { ok: false as const, error: "Statut invalide." };
  }

  const supabase = await getSupabaseServer();

  const update: Record<string, unknown> = { status: newStatus };
  if (newStatus === "in_progress") update.actual_start = new Date().toISOString();
  if (newStatus === "completed")   update.actual_end   = new Date().toISOString();

  const { error } = await supabase
    .from("tournees")
    .update(update)
    .eq("id", tourneeId);

  if (error) return { ok: false as const, error: error.message };

  revalidatePath("/chauffeur");
  revalidatePath(`/chauffeur/tournee/${tourneeId}`);
  return { ok: true as const };
}

/**
 * Ajoute un commentaire de fin de tournée.
 */
export async function addTourneeReportAction(
  tourneeId: string,
  report: string,
) {
  await requireUser();
  if (!tourneeId) return { ok: false as const, error: "ID manquant." };

  const text = report.trim().slice(0, 1000);
  if (!text) return { ok: false as const, error: "Rapport vide." };

  const supabase = await getSupabaseServer();
  const { error } = await supabase
    .from("tournees")
    .update({ driver_report: text })
    .eq("id", tourneeId);

  if (error) return { ok: false as const, error: error.message };

  revalidatePath(`/chauffeur/tournee/${tourneeId}`);
  return { ok: true as const };
}

/* ──────────────────────────────────────────────────────────────────────────
   POD — Preuve de livraison
   ────────────────────────────────────────────────────────────────────────── */

const STAFF_ROLES = new Set(["super_admin", "gerant_groupe", "gerant_societe", "chef_site"]);

/** Statut de livraison de mission déduit d'un type d'événement. */
function deliveryStatusFromEvent(eventType: DeliveryEventType): DeliveryStatus | null {
  switch (eventType) {
    case "enleve":       return "enleve";
    case "en_transit":   return "en_transit";
    case "en_livraison": return "en_livraison";
    case "livre":        return "livre";
    case "echec":        return "echec";
    default:             return null; // 'reserve' ne change pas le statut
  }
}

/** Notifie les responsables de la société (in-app) d'un événement de livraison. */
async function notifyCompanyManagers(
  companyId: string | null,
  title: string,
  message: string,
  link: string,
  type: "info" | "warning" | "error" | "success",
): Promise<void> {
  if (!companyId) return;
  const sb = getServerSupabase();
  const { data } = await sb
    .from("profiles")
    .select("id")
    .eq("company_id", companyId)
    .in("role", ["gerant_societe", "chef_site", "gerant_groupe"]);
  const managers = (data ?? []) as { id: string }[];
  await Promise.all(
    managers.map((m) => notifyInApp({ userId: m.id, title, message, link, type })),
  );
}

/**
 * Enregistre un événement de livraison intermédiaire (enlevé, en transit, en livraison…)
 * et met à jour le statut de la mission. Appelé depuis l'app chauffeur.
 */
export async function recordDeliveryEventAction(
  missionId: string,
  eventType: DeliveryEventType,
  opts?: { lat?: number | null; lng?: number | null; failureReason?: string | null; notes?: string | null },
) {
  const user = await requireUser();
  if (!missionId) return { ok: false as const, error: "Mission manquante." };

  const sb = getServerSupabase();
  const { data: mission } = await sb
    .from("missions")
    .select("id, company_id, driver_id")
    .eq("id", missionId)
    .maybeSingle();

  if (!mission) return { ok: false as const, error: "Mission introuvable." };
  const m = mission as { id: string; company_id: string | null; driver_id: string | null };

  const isOwner = m.driver_id === user.id;
  if (!isOwner && !STAFF_ROLES.has(user.role)) {
    return { ok: false as const, error: "Action non autorisée." };
  }

  const { error: evErr } = await sb.from("delivery_events").insert({
    company_id: m.company_id,
    mission_id: missionId,
    driver_id: user.id,
    event_type: eventType,
    failure_reason: opts?.failureReason ?? null,
    lat: opts?.lat ?? null,
    lng: opts?.lng ?? null,
    notes: opts?.notes ?? null,
  });
  if (evErr) return { ok: false as const, error: evErr.message };

  const newStatus = deliveryStatusFromEvent(eventType);
  if (newStatus) {
    await sb.from("missions").update({ delivery_status: newStatus }).eq("id", missionId);
  }

  revalidatePath("/chauffeur");
  revalidatePath(`/chauffeur/livraison/${missionId}`);
  return { ok: true as const };
}

/** Upload un blob/fichier vers le bucket privé `pod-proofs`, retourne le chemin ou null. */
async function uploadPodFile(
  file: File,
  companyId: string,
  missionId: string,
  podId: string,
  kind: string,
  index: number,
): Promise<string | null> {
  if (!file || file.size === 0) return null;
  const ext = (file.name.split(".").pop() ?? "png").toLowerCase().replace(/[^a-z0-9]/g, "") || "png";
  const path = `${companyId || "_"}/${missionId}/${podId}-${kind}-${index}.${ext}`;
  const buffer = Buffer.from(await file.arrayBuffer());
  const sb = getServerSupabase();
  const { error } = await sb.storage
    .from("pod-proofs")
    .upload(path, buffer, { contentType: file.type || "image/png", upsert: true });
  if (error) return null;
  return path;
}

/**
 * Valide une livraison : enregistre la preuve (signature + photos + scans),
 * met à jour la mission et notifie l'exploitation.
 *
 * Champs FormData attendus :
 *   mission_id, recipient_name, status ('livre'|'livre_avec_reserve'|'refuse'),
 *   reserve_text?, lat?, lng?, barcodes? (JSON string[]),
 *   signature (File png), photo (File, multiple)
 */
export async function submitPodAction(formData: FormData) {
  const user = await requireUser();

  const missionId = String(formData.get("mission_id") ?? "").trim();
  if (!missionId) {
    await setFlash({ kind: "error", message: "Mission manquante." });
    return;
  }

  const status = (String(formData.get("status") ?? "livre").trim() || "livre") as PodStatus;
  const validStatuses: PodStatus[] = ["livre", "livre_avec_reserve", "refuse"];
  if (!validStatuses.includes(status)) {
    await setFlash({ kind: "error", message: "Statut de livraison invalide." });
    return;
  }

  const sb = getServerSupabase();
  const { data: mission } = await sb
    .from("missions")
    .select("id, company_id, driver_id, reference")
    .eq("id", missionId)
    .maybeSingle();

  if (!mission) {
    await setFlash({ kind: "error", message: "Mission introuvable." });
    return;
  }
  const m = mission as { id: string; company_id: string | null; driver_id: string | null; reference: string | null };

  const isOwner = m.driver_id === user.id;
  if (!isOwner && !STAFF_ROLES.has(user.role)) {
    await setFlash({ kind: "error", message: "Action non autorisée." });
    return;
  }

  const recipientName = String(formData.get("recipient_name") ?? "").trim() || null;
  const reserveText = String(formData.get("reserve_text") ?? "").trim() || null;
  const lat = numOrNull(formData.get("lat"));
  const lng = numOrNull(formData.get("lng"));
  const companyId = m.company_id ?? "";

  const podId = randomUUID();

  // 1) Signature
  const signatureFile = formData.get("signature");
  let signaturePath: string | null = null;
  if (signatureFile instanceof File && signatureFile.size > 0) {
    signaturePath = await uploadPodFile(signatureFile, companyId, missionId, podId, "signature", 0);
  }

  // 2) Insert proof_of_delivery
  const { error: podErr } = await sb.from("proof_of_delivery").insert({
    id: podId,
    company_id: m.company_id,
    mission_id: missionId,
    driver_id: user.id,
    recipient_name: recipientName,
    status,
    reserve_text: reserveText,
    signature_path: signaturePath,
    lat,
    lng,
  });
  if (podErr) {
    await setFlash({ kind: "error", message: `Enregistrement impossible : ${podErr.message}` });
    return;
  }

  // 3) Photos
  const photos = formData.getAll("photo").filter((f): f is File => f instanceof File && f.size > 0);
  const attachments: { pod_id: string; kind: string; file_path: string; barcode: string | null }[] = [];
  for (let i = 0; i < photos.length; i++) {
    const path = await uploadPodFile(photos[i], companyId, missionId, podId, "photo", i);
    if (path) attachments.push({ pod_id: podId, kind: "photo", file_path: path, barcode: null });
  }

  // 4) Codes scannés (sans fichier)
  const barcodesRaw = String(formData.get("barcodes") ?? "").trim();
  if (barcodesRaw) {
    try {
      const codes = JSON.parse(barcodesRaw) as unknown;
      if (Array.isArray(codes)) {
        codes
          .map((c) => String(c).trim())
          .filter(Boolean)
          .forEach((code) =>
            attachments.push({ pod_id: podId, kind: "scan", file_path: `scan:${code}`, barcode: code }),
          );
      }
    } catch {
      /* barcodes mal formé : ignoré */
    }
  }

  if (attachments.length > 0) {
    await sb.from("pod_attachments").insert(attachments);
  }

  // 5) Mise à jour de la mission + événement
  const deliveryStatus: DeliveryStatus = status === "refuse" ? "echec" : "livre";
  const deliveredAt = new Date().toISOString();
  await sb
    .from("missions")
    .update({ delivery_status: deliveryStatus, delivered_at: deliveredAt, pod_id: podId })
    .eq("id", missionId);

  await sb.from("delivery_events").insert({
    company_id: m.company_id,
    mission_id: missionId,
    driver_id: user.id,
    event_type: status === "refuse" ? "echec" : "livre",
    failure_reason: status === "refuse" ? "refuse" : null,
    lat,
    lng,
    notes: reserveText,
  });

  // 6) Notification exploitation
  const ref = m.reference ?? missionId.slice(0, 8);
  await notifyCompanyManagers(
    m.company_id,
    status === "refuse" ? `Livraison en échec — ${ref}` : `Livraison validée — ${ref}`,
    status === "refuse"
      ? `La livraison ${ref} a été refusée.`
      : `La livraison ${ref} a été effectuée${recipientName ? ` (reçu par ${recipientName})` : ""}.`,
    `/missions/${missionId}/pod`,
    status === "refuse" ? "warning" : "success",
  );

  await setFlash({
    kind: "success",
    message: status === "refuse" ? "Échec de livraison enregistré." : "Preuve de livraison enregistrée.",
  });
  revalidatePath("/chauffeur");
  revalidatePath(`/chauffeur/livraison/${missionId}`);
}

function numOrNull(v: FormDataEntryValue | null): number | null {
  if (typeof v !== "string" || !v.trim()) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}
