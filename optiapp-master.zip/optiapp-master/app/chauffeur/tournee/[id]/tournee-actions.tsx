"use client";

/**
 * app/chauffeur/tournee/[id]/tournee-actions.tsx
 * Actions chauffeur : démarrer, terminer, ajouter un rapport.
 */

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { updateTourneeStatusAction, addTourneeReportAction } from "../actions";
import type { TourneeStatus } from "../actions";

interface Props {
  tourneeId: string;
  status: TourneeStatus | "draft";
  driverReport: string;
}

const STATUS_ACTIONS: Record<string, { label: string; next: TourneeStatus; color: string } | null> = {
  scheduled:   { label: "Démarrer la tournée",  next: "in_progress", color: "#10b981" },
  planned:     { label: "Démarrer la tournée",  next: "in_progress", color: "#10b981" },
  in_progress: { label: "Terminer la tournée",  next: "completed",   color: "#3b82f6" },
  completed:   null,
  cancelled:   null,
  draft:       null,
};

export function TourneeActions({ tourneeId, status, driverReport }: Props) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [report, setReport] = useState(driverReport);
  const [reportSaved, setReportSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const action = STATUS_ACTIONS[status] ?? null;

  function handleStatus() {
    if (!action) return;
    setError(null);
    startTransition(async () => {
      const res = await updateTourneeStatusAction(tourneeId, action.next);
      if (!res.ok) {
        setError(res.error ?? "Erreur inconnue.");
      } else {
        router.refresh();
      }
    });
  }

  function handleReport(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    startTransition(async () => {
      const res = await addTourneeReportAction(tourneeId, report);
      if (!res.ok) {
        setError(res.error ?? "Erreur inconnue.");
      } else {
        setReportSaved(true);
        setTimeout(() => setReportSaved(false), 3000);
      }
    });
  }

  return (
    <>
      {/* Bouton principal d'action sur le statut */}
      {action && (
        <section className="ch-card">
          {error && <p className="ch-error">{error}</p>}
          <button
            type="button"
            className="ch-action-btn"
            style={{ background: action.color }}
            onClick={handleStatus}
            disabled={isPending}
          >
            {isPending ? "…" : action.label}
          </button>
        </section>
      )}

      {/* Rapport chauffeur */}
      {(status === "in_progress" || status === "completed") && (
        <section className="ch-card">
          <h2>Compte-rendu</h2>
          <form onSubmit={handleReport} style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            <textarea
              className="ch-textarea"
              placeholder="Incidents, retards, remarques sur la tournée…"
              value={report}
              onChange={(e) => setReport(e.target.value)}
              rows={4}
              maxLength={1000}
              disabled={isPending}
            />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <small style={{ color: "var(--muted-foreground)" }}>{report.length}/1000</small>
              <button type="submit" className="ch-btn-primary" disabled={isPending || !report.trim()}>
                {reportSaved ? "✓ Enregistré" : isPending ? "…" : "Enregistrer"}
              </button>
            </div>
          </form>
        </section>
      )}
    </>
  );
}
