/**
 * app/chauffeur/tournee/[id]/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Détail d'une tournée pour le chauffeur : infos + actions (démarrer, terminer, rapport).
 */

import { notFound } from "next/navigation";
import Link from "next/link";
import { requireUser } from "@/lib/session";
import { getSupabaseServer } from "@/lib/supabase-server";
import { listTourneeDeliveries } from "@/lib/pod-queries";
import { TourneeActions } from "./tournee-actions";

export const dynamic = "force-dynamic";

type TourneeDetail = {
  id: string;
  name: string | null;
  reference: string | null;
  tournee_date: string | null;
  scheduled_date: string | null;
  scheduled_start: string | null;
  scheduled_end: string | null;
  actual_start: string | null;
  actual_end: string | null;
  status: string | null;
  vehicle_id: string | null;
  notes: string | null;
  driver_report: string | null;
};

export default async function TourneeDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const user = await requireUser();
  const supabase = await getSupabaseServer();

  const { data } = await supabase
    .from("tournees")
    .select(
      "id, name, reference, tournee_date, scheduled_date, scheduled_start, scheduled_end, actual_start, actual_end, status, vehicle_id, notes, driver_report",
    )
    .eq("id", id)
    .maybeSingle();

  const tournee = data as TourneeDetail | null;
  if (!tournee) notFound();

  const date = tournee.tournee_date ?? tournee.scheduled_date;
  const missions = await listTourneeDeliveries(id);

  return (
    <div className="ch-page">
      <div className="ch-back">
        <Link href="/chauffeur">← Planning</Link>
      </div>

      <section className="ch-card">
        <div className="ch-tournee-header">
          <div>
            <h2>{tournee.name || "Tournée"}</h2>
            {tournee.reference && (
              <span className="ch-ref">{tournee.reference}</span>
            )}
          </div>
          <span className={`ch-status ch-status-${tournee.status ?? "unknown"}`}>
            {labelStatus(tournee.status)}
          </span>
        </div>

        <dl className="ch-detail-grid">
          <div>
            <dt>Date</dt>
            <dd>{date ? formatDate(date) : "—"}</dd>
          </div>
          <div>
            <dt>Heure prévue</dt>
            <dd>
              {formatTime(tournee.scheduled_start)} – {formatTime(tournee.scheduled_end)}
            </dd>
          </div>
          {tournee.actual_start && (
            <div>
              <dt>Départ réel</dt>
              <dd>{formatDateTime(tournee.actual_start)}</dd>
            </div>
          )}
          {tournee.actual_end && (
            <div>
              <dt>Fin réelle</dt>
              <dd>{formatDateTime(tournee.actual_end)}</dd>
            </div>
          )}
          {tournee.vehicle_id && (
            <div>
              <dt>Véhicule</dt>
              <dd>🚐 {tournee.vehicle_id}</dd>
            </div>
          )}
        </dl>

        {tournee.notes && (
          <div className="ch-notes">
            <strong>Consignes</strong>
            <p>{tournee.notes}</p>
          </div>
        )}
      </section>

      {/* Missions / livraisons de la tournée */}
      {missions.length > 0 && (
        <section className="ch-card">
          <h2>Livraisons ({missions.length})</h2>
          <ul style={{ listStyle: "none", margin: "8px 0 0", padding: 0, display: "flex", flexDirection: "column", gap: 8 }}>
            {missions.map((m) => {
              const deliveredStatus = m.delivery_status ?? "a_traiter";
              const label =
                [m.delivery_address, m.delivery_city].filter(Boolean).join(", ") || "Adresse non renseignée";
              return (
                <li key={m.id}>
                  <Link
                    href={`/chauffeur/livraison/${m.id}`}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      gap: 10,
                      padding: "10px 12px",
                      border: "1px solid var(--border, #e5e7eb)",
                      borderRadius: 8,
                      textDecoration: "none",
                      color: "inherit",
                    }}
                  >
                    <span>
                      <strong>{m.reference || "Mission"}</strong>
                      <br />
                      <small style={{ color: "var(--muted-foreground)" }}>{label}</small>
                    </span>
                    <span className={`ch-status ch-status-${deliveredStatus}`}>
                      {labelDeliveryStatus(deliveredStatus)}
                    </span>
                  </Link>
                </li>
              );
            })}
          </ul>
        </section>
      )}

      {/* Actions & rapport */}
      <TourneeActions
        tourneeId={id}
        status={(tournee.status ?? "scheduled") as "draft" | "scheduled" | "in_progress" | "completed" | "cancelled"}
        driverReport={tournee.driver_report ?? ""}
      />
    </div>
  );
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

function formatTime(iso: string | null): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  return d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
}

function labelStatus(status: string | null): string {
  switch (status) {
    case "planned":
    case "scheduled": return "Prévue";
    case "in_progress": return "En cours";
    case "completed":   return "Terminée";
    case "cancelled":   return "Annulée";
    case "draft":       return "Brouillon";
    default:            return "—";
  }
}

function labelDeliveryStatus(status: string): string {
  switch (status) {
    case "a_traiter":    return "À traiter";
    case "enleve":       return "Enlevé";
    case "en_transit":   return "En transit";
    case "en_livraison": return "En livraison";
    case "livre":        return "Livré";
    case "echec":        return "Échec";
    default:             return "—";
  }
}
