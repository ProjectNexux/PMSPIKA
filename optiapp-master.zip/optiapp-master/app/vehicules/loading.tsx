import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Flotte" title="Véhicules" stats={4} rows={8} cols={7} />;
}
