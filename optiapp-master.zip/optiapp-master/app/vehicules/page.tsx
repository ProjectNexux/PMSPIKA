import { AlertTriangle, Pencil, Plus, Trash2, Wrench } from "lucide-react";
import {
  createMaintenanceRecord,
  createTmsVehicle,
  deleteTmsVehicle,
  updateTmsVehicle,
} from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import {
  getMaintenanceByCompany,
  getTmsVehiclesByCompany,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const VEHICLE_STATUS_LABELS: Record<string, string> = {
  available:      "Disponible",
  on_mission:     "En mission",
  maintenance:    "Maintenance",
  out_of_service: "Hors service",
};

const MAINTENANCE_TYPE_LABELS: Record<string, string> = {
  revision:  "Revision",
  tires:     "Pneumatiques",
  brakes:    "Freins",
  control:   "Controle tech.",
  oil_change:"Vidange",
  battery:   "Batterie",
  bodywork:  "Carrosserie",
  other:     "Autre",
};

const FUEL_LABELS: Record<string, string> = {
  diesel:   "Diesel",
  electric: "Electrique",
  hybrid:   "Hybride",
  gas:      "GPL",
};

function isExpiringSoon(dateStr: string | null, warningDays = 30): "expired" | "warning" | "ok" {
  if (!dateStr) return "ok";
  const diff = (new Date(dateStr).getTime() - Date.now()) / 86_400_000;
  if (diff < 0)            return "expired";
  if (diff < warningDays)  return "warning";
  return "ok";
}

export default async function CompanyVehiclesPage({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string; maintenance?: string }>;
}) {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const { edit, maintenance: maint } = await searchParams;
  const [fleet, maintenanceHistory] = await Promise.all([
    getTmsVehiclesByCompany(id),
    getMaintenanceByCompany(id),
  ]);

  const editingVehicle    = edit   ? fleet.find((v) => v.id === edit)   : undefined;
  const maintVehicle      = maint  ? fleet.find((v) => v.id === maint)  : undefined;
  const onMission         = fleet.filter((v) => v.status === "on_mission").length;
  const inMaintenance     = fleet.filter((v) => v.status === "maintenance").length;
  const alerts            = fleet.filter(
    (v) =>
      isExpiringSoon(v.technical_control_expiry) !== "ok" ||
      isExpiringSoon(v.insurance_expiry) !== "ok" ||
      isExpiringSoon(v.next_maintenance_date, 14) !== "ok"
  ).length;
  const redir = "/vehicules";

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Flotte & Maintenance" />

      <section className="stat-grid" aria-label="Indicateurs flotte">
        <StatCard
          label="Vehicules"
          value={formatNumber(fleet.length)}
          detail="Flotte operationnelle"
          tone="blue"
        />
        <StatCard
          label="En mission"
          value={formatNumber(onMission)}
          detail="Sur route actuellement"
          tone="green"
        />
        <StatCard
          label="Maintenance"
          value={formatNumber(inMaintenance)}
          detail="Indisponibles"
          tone="orange"
        />
        <StatCard
          label="Alertes echances"
          value={formatNumber(alerts)}
          detail="CT / assurance / entretien"
          tone="red"
        />
      </section>

      {/* ── Add / Edit vehicle form ── */}
      <div className="grid-2">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>{editingVehicle ? `Modifier — ${editingVehicle.plate_number}` : "Ajouter un vehicule"}</h2>
              <p>{editingVehicle ? "Mettre a jour les informations" : "Rattaché à PIKA TRANSPORT"}</p>
            </div>
          </div>
          {editingVehicle ? (
            <form action={updateTmsVehicle} className="form-grid">
              <input type="hidden" name="id"          value={editingVehicle.id} />
              <input type="hidden" name="redirect_to" value={redir} />
              <div className="field">
                <label>Immatriculation</label>
                <input name="plate_number" required defaultValue={editingVehicle.plate_number} />
              </div>
              <div className="field">
                <label>Marque</label>
                <input name="brand" required defaultValue={editingVehicle.brand} />
              </div>
              <div className="field">
                <label>Modele</label>
                <input name="model" required defaultValue={editingVehicle.model} />
              </div>
              <div className="field">
                <label>Annee</label>
                <input name="year" type="number" min="1990" max="2030" defaultValue={editingVehicle.year ?? ""} />
              </div>
              <div className="field">
                <label>Energie</label>
                <select name="fuel_type" defaultValue={editingVehicle.fuel_type ?? "diesel"}>
                  <option value="diesel">Diesel</option>
                  <option value="electric">Electrique</option>
                  <option value="hybrid">Hybride</option>
                  <option value="gas">GPL</option>
                </select>
              </div>
              <div className="field">
                <label>Statut</label>
                <select name="status" defaultValue={editingVehicle.status}>
                  <option value="available">Disponible</option>
                  <option value="on_mission">En mission</option>
                  <option value="maintenance">Maintenance</option>
                  <option value="out_of_service">Hors service</option>
                </select>
              </div>
              <div className="field">
                <label>Kilometrage</label>
                <input name="mileage" type="number" min="0" defaultValue={editingVehicle.mileage} />
              </div>
              <div className="field">
                <label>PTAC (kg)</label>
                <input name="max_payload_kg" type="number" min="0" defaultValue={editingVehicle.max_payload_kg ?? ""} />
              </div>
              <div className="field">
                <label>Fin assurance</label>
                <input name="insurance_expiry" type="date" defaultValue={editingVehicle.insurance_expiry ?? ""} />
              </div>
              <div className="field">
                <label>Controle tech.</label>
                <input name="technical_control_expiry" type="date" defaultValue={editingVehicle.technical_control_expiry ?? ""} />
              </div>
              <div className="field">
                <label>Prochain entretien</label>
                <input name="next_maintenance_date" type="date" defaultValue={editingVehicle.next_maintenance_date ?? ""} />
              </div>
              <div className="field">
                <label>VIN</label>
                <input name="vin" defaultValue={editingVehicle.vin ?? ""} />
              </div>
              {/* PJ Carte grise */}
              <div className="field full">
                <label>Carte grise (PDF / image)</label>
                <input type="hidden" name="registration_doc" value={editingVehicle.registration_doc ?? ""} />
                {editingVehicle.registration_doc && (
                  <div style={{ marginBottom: 6, fontSize: 12 }}>
                    <a href={editingVehicle.registration_doc} target="_blank" rel="noreferrer" className="doc-link">Voir le document actuel</a>
                  </div>
                )}
                <input name="registration_doc_file" type="file" accept=".pdf,image/*" />
              </div>
              {/* PJ Assurance flotte */}
              <div className="field full">
                <label>Assurance flotte (PDF / image)</label>
                <input type="hidden" name="insurance_doc" value={editingVehicle.insurance_doc ?? ""} />
                {editingVehicle.insurance_doc && (
                  <div style={{ marginBottom: 6, fontSize: 12 }}>
                    <a href={editingVehicle.insurance_doc} target="_blank" rel="noreferrer" className="doc-link">Voir le document actuel</a>
                  </div>
                )}
                <input name="insurance_doc_file" type="file" accept=".pdf,image/*" />
              </div>
              {/* PJ Controle technique */}
              <div className="field full">
                <label>Dernier controle technique (PDF / image)</label>
                <input type="hidden" name="inspection_doc" value={editingVehicle.inspection_doc ?? ""} />
                {editingVehicle.inspection_doc && (
                  <div style={{ marginBottom: 6, fontSize: 12 }}>
                    <a href={editingVehicle.inspection_doc} target="_blank" rel="noreferrer" className="doc-link">Voir le document actuel</a>
                  </div>
                )}
                <input name="inspection_doc_file" type="file" accept=".pdf,image/*" />
              </div>

              {/* ── Coûts d'exploitation (pour calculs de rentabilité) ── */}
              <div className="field full" style={{ marginTop: 6 }}>
                <h3 style={{ margin: "6px 0 4px", fontSize: 13, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--muted)" }}>
                  Coûts d&apos;exploitation
                </h3>
                <p style={{ margin: 0, fontSize: 11, color: "var(--muted)" }}>
                  Ces taux par défaut sont utilisés pour calculer la rentabilité des tournées. Vous pourrez les surcharger ponctuellement par tournée.
                </p>
              </div>
              <div className="field">
                <label>Conso (L / 100 km)</label>
                <input name="fuel_consumption_l_100km" type="number" step="0.1" min="0" defaultValue={editingVehicle.fuel_consumption_l_100km ?? ""} />
              </div>
              <div className="field">
                <label>Prix du carburant (€ / L)</label>
                <input name="fuel_price_per_l" type="number" step="0.01" min="0" defaultValue={editingVehicle.fuel_price_per_l ?? ""} />
              </div>
              <div className="field">
                <label>Amortissement (€ / km)</label>
                <input name="amortization_per_km" type="number" step="0.001" min="0" defaultValue={editingVehicle.amortization_per_km ?? ""} />
              </div>
              <div className="field">
                <label>Pneus (€ / km)</label>
                <input name="tire_cost_per_km" type="number" step="0.001" min="0" defaultValue={editingVehicle.tire_cost_per_km ?? ""} />
              </div>
              <div className="field">
                <label>Entretien (€ / km)</label>
                <input name="maintenance_cost_per_km" type="number" step="0.001" min="0" defaultValue={editingVehicle.maintenance_cost_per_km ?? ""} />
              </div>
              <div className="field">
                <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <input type="checkbox" name="has_cold_unit" defaultChecked={!!editingVehicle.has_cold_unit} style={{ width: "auto" }} />
                  Véhicule frigorifique
                </label>
              </div>
              <div className="field">
                <label>Groupe froid (€ / h)</label>
                <input name="cold_unit_cost_per_hour" type="number" step="0.01" min="0" defaultValue={editingVehicle.cold_unit_cost_per_hour ?? ""} />
              </div>

              <div className="full form-actions">
                <button className="button" type="submit">
                  <Pencil size={15} aria-hidden="true" />Enregistrer
                </button>
                <a href={redir} className="button secondary">Annuler</a>
              </div>
            </form>
          ) : (
            <form action={createTmsVehicle} className="form-grid">
              <input type="hidden" name="company_id"  value={id} />
              <input type="hidden" name="redirect_to" value={redir} />
              <div className="field">
                <label htmlFor="plate_number">Immatriculation</label>
                <input id="plate_number" name="plate_number" required placeholder="XX-000-XX" />
              </div>
              <div className="field">
                <label htmlFor="brand">Marque</label>
                <input id="brand" name="brand" required placeholder="Renault, Mercedes..." />
              </div>
              <div className="field">
                <label htmlFor="model">Modele</label>
                <input id="model" name="model" required placeholder="Master, Actros..." />
              </div>
              <div className="field">
                <label htmlFor="year">Annee</label>
                <input id="year" name="year" type="number" min="1990" max="2030" />
              </div>
              <div className="field">
                <label htmlFor="fuel_type">Energie</label>
                <select id="fuel_type" name="fuel_type" defaultValue="diesel">
                  <option value="diesel">Diesel</option>
                  <option value="electric">Electrique</option>
                  <option value="hybrid">Hybride</option>
                  <option value="gas">GPL</option>
                </select>
              </div>
              <div className="field">
                <label htmlFor="mileage">Kilometrage</label>
                <input id="mileage" name="mileage" type="number" min="0" defaultValue="0" />
              </div>
              <div className="field">
                <label htmlFor="max_payload_kg">PTAC (kg)</label>
                <input id="max_payload_kg" name="max_payload_kg" type="number" min="0" />
              </div>
              <div className="field">
                <label htmlFor="insurance_expiry">Fin assurance</label>
                <input id="insurance_expiry" name="insurance_expiry" type="date" />
              </div>
              <div className="field">
                <label htmlFor="technical_control_expiry">Controle tech.</label>
                <input id="technical_control_expiry" name="technical_control_expiry" type="date" />
              </div>
              <div className="field">
                <label htmlFor="next_maintenance_date">Prochain entretien</label>
                <input id="next_maintenance_date" name="next_maintenance_date" type="date" />
              </div>
              <div className="field full">
                <label htmlFor="registration_doc">Carte grise (PDF / image)</label>
                <input id="registration_doc" name="registration_doc" type="file" accept=".pdf,image/*" />
              </div>
              <div className="field full">
                <label htmlFor="insurance_doc">Assurance flotte (PDF / image)</label>
                <input id="insurance_doc" name="insurance_doc" type="file" accept=".pdf,image/*" />
              </div>
              <div className="field full">
                <label htmlFor="inspection_doc">Dernier controle technique (PDF / image)</label>
                <input id="inspection_doc" name="inspection_doc" type="file" accept=".pdf,image/*" />
              </div>

              {/* ── Coûts d'exploitation (pour calculs de rentabilité) ── */}
              <div className="field full" style={{ marginTop: 6 }}>
                <h3 style={{ margin: "6px 0 4px", fontSize: 13, textTransform: "uppercase", letterSpacing: 0.4, color: "var(--muted)" }}>
                  Coûts d&apos;exploitation
                </h3>
                <p style={{ margin: 0, fontSize: 11, color: "var(--muted)" }}>
                  Optionnel : utilisé pour calculer la rentabilité des tournées (modifiable plus tard).
                </p>
              </div>
              <div className="field">
                <label htmlFor="fuel_consumption_l_100km">Conso (L / 100 km)</label>
                <input id="fuel_consumption_l_100km" name="fuel_consumption_l_100km" type="number" step="0.1" min="0" />
              </div>
              <div className="field">
                <label htmlFor="fuel_price_per_l">Prix du carburant (€ / L)</label>
                <input id="fuel_price_per_l" name="fuel_price_per_l" type="number" step="0.01" min="0" />
              </div>
              <div className="field">
                <label htmlFor="amortization_per_km">Amortissement (€ / km)</label>
                <input id="amortization_per_km" name="amortization_per_km" type="number" step="0.001" min="0" />
              </div>
              <div className="field">
                <label htmlFor="tire_cost_per_km">Pneus (€ / km)</label>
                <input id="tire_cost_per_km" name="tire_cost_per_km" type="number" step="0.001" min="0" />
              </div>
              <div className="field">
                <label htmlFor="maintenance_cost_per_km">Entretien (€ / km)</label>
                <input id="maintenance_cost_per_km" name="maintenance_cost_per_km" type="number" step="0.001" min="0" />
              </div>
              <div className="field">
                <label style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <input type="checkbox" name="has_cold_unit" style={{ width: "auto" }} />
                  Véhicule frigorifique
                </label>
              </div>
              <div className="field">
                <label htmlFor="cold_unit_cost_per_hour">Groupe froid (€ / h)</label>
                <input id="cold_unit_cost_per_hour" name="cold_unit_cost_per_hour" type="number" step="0.01" min="0" />
              </div>

              <div className="full">
                <button className="button" type="submit">
                  <Plus size={15} aria-hidden="true" />Ajouter le vehicule
                </button>
              </div>
            </form>
          )}
        </div>

        {/* ── Add maintenance record ── */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Saisir une intervention</h2>
              <p>{maintVehicle ? `Sur ${maintVehicle.plate_number}` : "Choisir un vehicule ci-dessous"}</p>
            </div>
          </div>
          <form action={createMaintenanceRecord} className="form-grid">
            <input type="hidden" name="redirect_to" value={redir} />
            <div className="field full">
              <label htmlFor="vehicle_id">Vehicule</label>
              <select id="vehicle_id" name="vehicle_id" required defaultValue={maint ?? ""}>
                <option value="">— Choisir —</option>
                {fleet.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.plate_number} — {v.brand} {v.model}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="maintenance_type">Type</label>
              <select id="maintenance_type" name="maintenance_type" defaultValue="revision">
                {Object.entries(MAINTENANCE_TYPE_LABELS).map(([k, l]) => (
                  <option key={k} value={k}>{l}</option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="service_date">Date</label>
              <input id="service_date" name="service_date" type="date" required />
            </div>
            <div className="field">
              <label htmlFor="cost">Cout HT (€)</label>
              <input id="cost" name="cost" type="number" min="0" step="0.01" />
            </div>
            <div className="field">
              <label htmlFor="mileage_at_service">Km au service</label>
              <input id="mileage_at_service" name="mileage_at_service" type="number" min="0" />
            </div>
            <div className="field">
              <label htmlFor="provider">Prestataire</label>
              <input id="provider" name="provider" placeholder="Nom du garage..." />
            </div>
            <div className="field">
              <label htmlFor="next_service_date">Prochain service</label>
              <input id="next_service_date" name="next_service_date" type="date" />
            </div>
            <div className="field full">
              <label htmlFor="description">Description</label>
              <textarea id="description" name="description" placeholder="Details de l'intervention..." />
            </div>
            <div className="full">
              <button className="button" type="submit">
                <Wrench size={15} aria-hidden="true" />Enregistrer l&apos;intervention
              </button>
            </div>
          </form>
        </div>
      </div>

      <section className="panel">
        <div className="panel-header">
          <div>
            <h2>Vehicules de la flotte</h2>
            <p>Controle technique, assurance et prochain entretien</p>
          </div>
        </div>
        {fleet.length > 0 ? (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Immatriculation</th>
                  <th>Modele</th>
                  <th>Annee</th>
                  <th>Energie</th>
                  <th>Kilometrage</th>
                  <th>PTAC</th>
                  <th>Controle tech.</th>
                  <th>Assurance</th>
                  <th>Prochain entretien</th>
                  <th>Coûts</th>
                  <th>PJ</th>
                  <th>Etat</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {fleet.map((v) => {
                  const ctStatus  = isExpiringSoon(v.technical_control_expiry);
                  const insStatus = isExpiringSoon(v.insurance_expiry);
                  const entStatus = isExpiringSoon(v.next_maintenance_date, 14);
                  return (
                    <tr key={v.id}>
                      <td className="strong-cell fleet-plate">
                        <span className="plate-chip">{v.plate_number}</span>
                      </td>
                      <td>
                        {v.brand} {v.model}
                      </td>
                      <td className="muted">{v.year ?? "—"}</td>
                      <td className="muted">{FUEL_LABELS[v.fuel_type ?? ""] ?? v.fuel_type ?? "—"}</td>
                      <td>{formatNumber(v.mileage)} km</td>
                      <td className="muted">{v.max_payload_kg != null ? `${formatNumber(v.max_payload_kg)} kg` : "—"}</td>
                      <td>
                        <DateAlert value={v.technical_control_expiry} alertLevel={ctStatus} />
                      </td>
                      <td>
                        <DateAlert value={v.insurance_expiry} alertLevel={insStatus} />
                      </td>
                      <td>
                        <DateAlert value={v.next_maintenance_date} alertLevel={entStatus} warningLabel="Bientot" />
                      </td>
                      <td>
                        <CostSummary v={v} />
                      </td>
                      <td>
                        <span style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          {v.registration_doc && (
                            <a href={v.registration_doc} target="_blank" rel="noreferrer" className="doc-link" title="Carte grise">CG</a>
                          )}
                          {v.insurance_doc && (
                            <a href={v.insurance_doc} target="_blank" rel="noreferrer" className="doc-link" title="Assurance flotte">Ass.</a>
                          )}
                          {v.inspection_doc && (
                            <a href={v.inspection_doc} target="_blank" rel="noreferrer" className="doc-link" title="Controle technique">CT</a>
                          )}
                          {!v.registration_doc && !v.insurance_doc && !v.inspection_doc && <span className="muted">—</span>}
                        </span>
                      </td>
                      <td>
                        <StatusPill value={VEHICLE_STATUS_LABELS[v.status] ?? v.status} />
                      </td>
                      <td>
                        <div className="row-actions">
                          <a href={`?maintenance=${v.id}`} className="btn-icon" title="Saisir intervention">
                            <Wrench size={14} />
                          </a>
                          <a href={`?edit=${v.id}`} className="btn-icon" title="Modifier">
                            <Pencil size={14} />
                          </a>
                          <form action={deleteTmsVehicle}>
                            <input type="hidden" name="id"          value={v.id} />
                            <input type="hidden" name="redirect_to" value={redir} />
                            <button type="submit" className="btn-icon btn-icon-danger" title="Supprimer">
                              <Trash2 size={14} />
                            </button>
                          </form>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="muted" style={{ fontSize: 14 }}>Aucun vehicule TMS rattache a {"PIKA TRANSPORT"}.</p>
        )}
      </section>

      <section className="panel">
        <div className="panel-header">
          <div>
            <h2>Historique de maintenance</h2>
            <p>Interventions enregistrees — {"PIKA TRANSPORT"}</p>
          </div>
        </div>
        {maintenanceHistory.length > 0 ? (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Vehicule</th>
                  <th>Type</th>
                  <th>Description</th>
                  <th>Date</th>
                  <th>Prestataire</th>
                  <th>Kilometrage</th>
                  <th>Cout HT</th>
                  <th>Prochain service</th>
                </tr>
              </thead>
              <tbody>
                {maintenanceHistory.map((m) => (
                  <tr key={m.id}>
                    <td className="strong-cell">
                      <span className="plate-chip">{m.vehicle_plate}</span>
                      <span className="muted" style={{ marginLeft: 8, fontSize: 12 }}>
                        {m.vehicle_brand} {m.vehicle_model}
                      </span>
                    </td>
                    <td>
                      <span className="maintenance-type-badge">
                        {MAINTENANCE_TYPE_LABELS[m.maintenance_type] ?? m.maintenance_type}
                      </span>
                    </td>
                    <td className="muted">{m.description ?? "—"}</td>
                    <td>{formatDate(m.service_date)}</td>
                    <td className="muted">{m.provider ?? "—"}</td>
                    <td className="muted">{m.mileage_at_service != null ? `${formatNumber(m.mileage_at_service)} km` : "—"}</td>
                    <td className="strong-cell">{m.cost != null ? formatCurrency(m.cost) : "—"}</td>
                    <td className="muted">{formatDate(m.next_service_date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="muted" style={{ fontSize: 14 }}>Aucun historique de maintenance.</p>
        )}
      </section>
    </main>
  );
}

function DateAlert({
  value,
  alertLevel,
  warningLabel = "Bientot",
}: {
  value: string | null;
  alertLevel: "expired" | "warning" | "ok";
  warningLabel?: string;
}) {
  if (!value) return <span className="muted">—</span>;
  if (alertLevel === "expired") {
    return (
      <span className="date-alert date-alert-expired">
        <AlertTriangle size={13} aria-hidden="true" />
        {formatDate(value)}
      </span>
    );
  }
  if (alertLevel === "warning") {
    return (
      <span className="date-alert date-alert-warning">
        <AlertTriangle size={13} aria-hidden="true" />
        {formatDate(value)}
      </span>
    );
  }
  return <span>{formatDate(value)}</span>;
}

function CostSummary({ v }: { v: { fuel_consumption_l_100km: number | null; fuel_price_per_l: number | null; amortization_per_km: number | null; tire_cost_per_km: number | null; maintenance_cost_per_km: number | null; has_cold_unit: boolean | null; cold_unit_cost_per_hour: number | null; } }) {
  const perKm = (v.amortization_per_km ?? 0) + (v.tire_cost_per_km ?? 0) + (v.maintenance_cost_per_km ?? 0);
  const fuelPerKm = v.fuel_consumption_l_100km && v.fuel_price_per_l
    ? (v.fuel_consumption_l_100km * v.fuel_price_per_l) / 100
    : null;
  const nothing = perKm === 0 && fuelPerKm == null && !v.has_cold_unit;
  if (nothing) {
    return <span className="muted" style={{ fontSize: 12 }}>Non configuré</span>;
  }
  return (
    <div style={{ display: "flex", flexDirection: "column", fontSize: 12, lineHeight: 1.3 }}>
      {fuelPerKm != null && <span>⛽ {fuelPerKm.toFixed(2)} €/km</span>}
      {perKm > 0 && <span>🚚 {perKm.toFixed(3)} €/km</span>}
      {v.has_cold_unit && v.cold_unit_cost_per_hour != null && (
        <span>❄️ {v.cold_unit_cost_per_hour.toFixed(2)} €/h</span>
      )}
    </div>
  );
}

