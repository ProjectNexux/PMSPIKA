import Link from "next/link";
import { Plus } from "lucide-react";
import { createLedgerEntry } from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import {
  getLedgerByCompanyFull,
  getSiteOptionsByCompany,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function CompanyAccountingPage({
  searchParams,
}: {
  searchParams: Promise<{ label?: string; amount?: string; type?: string }>;
}) {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const sp = await searchParams;
  const [entries, sites] = await Promise.all([
    getLedgerByCompanyFull(id), getSiteOptionsByCompany(id),
  ]);
  const revenues = entries.filter((e) => e.type === "Recette").reduce((s, e) => s + e.amount, 0);
  const expenses = entries.filter((e) => e.type === "Depense").reduce((s, e) => s + e.amount, 0);
  const pending = entries.filter((e) => !["Pret", "Envoye comptable", "Paye"].includes(e.status)).length;
  const solde = revenues - expenses;

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Comptabilite" />

      <section className="stat-grid">
        <StatCard label="Recettes" value={formatCurrency(revenues)} tone="green" />
        <StatCard label="Depenses" value={formatCurrency(expenses)} tone="red" />
        <StatCard label="Solde" value={formatCurrency(solde)} tone="blue" />
        <StatCard label="A traiter" value={formatNumber(pending)} tone="orange" />
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Ajouter une piece</h2>
              <p>Ventilation interne — PIKA TRANSPORT</p>
            </div>
          </div>
          <form action={createLedgerEntry} className="form-grid">
            <input type="hidden" name="company_id" value={id} />
            <input type="hidden" name="redirect_to" value="/comptabilite" />
            {sp.label && (
              <div className="field full">
                <p style={{ fontSize: 12, padding: "6px 10px", background: "#eff6ff", borderRadius: 6, color: "#1d4ed8", border: "1px solid #bfdbfe" }}>
                  Pré-rempli depuis la facture{" "}
                  <Link href="/facturation" style={{ fontWeight: 700, color: "inherit" }}>
                    {sp.label}
                  </Link>
                </p>
              </div>
            )}
            <div className="field full">
              <label htmlFor="label">Libelle</label>
              <input id="label" name="label" defaultValue={sp.label ?? ""} required />
            </div>
            <div className="field">
              <label htmlFor="type">Type</label>
              <select id="type" name="type" defaultValue={sp.type ?? "Depense"}>
                <option>Depense</option>
                <option>Recette</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="amount">Montant HT</label>
              <input id="amount" name="amount" inputMode="decimal" defaultValue={sp.amount ?? ""} required />
            </div>
            <div className="field">
              <label htmlFor="tax_rate">TVA</label>
              <select id="tax_rate" name="tax_rate" defaultValue="20">
                <option value="20">20 %</option>
                <option value="10">10 %</option>
                <option value="5.5">5,5 %</option>
                <option value="0">0 %</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="period">Periode</label>
              <input id="period" name="period" defaultValue="2026-06" required />
            </div>
            <div className="field">
              <label htmlFor="site_id">Site</label>
              <select id="site_id" name="site_id" defaultValue="">
                <option value="">Societe seulement</option>
                {sites.map((site) => (
                  <option key={site.id} value={site.id}>
                    {site.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="status">Etat</label>
              <select id="status" name="status" defaultValue="A classer">
                <option>A classer</option>
                <option>A valider</option>
                <option>Pret</option>
                <option>Envoye comptable</option>
                <option>Paye</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="due_date">Echeance</label>
              <input id="due_date" name="due_date" type="date" />
            </div>
            <div className="full">
              <button className="button" type="submit">
                <Plus size={16} aria-hidden="true" />
                Ajouter
              </button>
            </div>
          </form>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Flux comptables</h2>
              <p>{entries.length} piece{entries.length > 1 ? "s" : ""} — PIKA TRANSPORT</p>
            </div>
          </div>
          {entries.length > 0 ? (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Libelle</th>
                    <th>Type</th>
                    <th>Site</th>
                    <th>Montant</th>
                    <th>Echeance</th>
                    <th>Etat</th>
                  </tr>
                </thead>
                <tbody>
                  {entries.map((entry) => (
                    <tr key={entry.id}>
                      <td className="strong-cell">{entry.label}</td>
                      <td>{entry.type}</td>
                      <td>{entry.site_name ?? "General"}</td>
                      <td>{formatCurrency(entry.amount)}</td>
                      <td>{formatDate(entry.due_date)}</td>
                      <td>
                        <StatusPill value={entry.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 14 }}>Aucune ecriture pour PIKA TRANSPORT.</p>
          )}
        </div>
      </section>
    </main>
  );
}
