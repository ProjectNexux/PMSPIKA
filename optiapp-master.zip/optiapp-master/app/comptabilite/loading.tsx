import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Comptabilité" title="Écritures" stats={4} rows={10} cols={7} />;
}
