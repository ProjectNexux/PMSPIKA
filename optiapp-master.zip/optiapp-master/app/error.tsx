"use client";

import { useEffect } from "react";
import { Button } from "@/components/ui/button";
import { WifiOff, AlertCircle } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[app] global error:", error);
  }, [error]);

  const isNetwork =
    error.message?.toLowerCase().includes("network") ||
    error.message?.toLowerCase().includes("fetch failed") ||
    error.message?.toLowerCase().includes("econnrefused");

  return (
    <div className="flex min-h-screen items-center justify-center bg-background p-6">
      <div className="w-full max-w-sm space-y-5 text-center">
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border bg-card shadow-sm">
          {isNetwork ? (
            <WifiOff className="h-6 w-6 text-muted-foreground" />
          ) : (
            <AlertCircle className="h-6 w-6 text-destructive" />
          )}
        </div>

        <div className="space-y-1.5">
          <h2 className="text-lg font-semibold tracking-tight">
            {isNetwork ? "Erreur de connexion" : "Erreur inattendue"}
          </h2>
          <p className="text-sm text-muted-foreground">
            {isNetwork
              ? "Impossible de joindre la base de données. Vérifiez votre connexion réseau et les variables d'environnement Supabase."
              : (error.message || "Une erreur est survenue.")}
          </p>
          {error.digest && (
            <p className="pt-1 font-mono text-[11px] text-muted-foreground">
              Réf : {error.digest}
            </p>
          )}
        </div>

        <div className="flex justify-center gap-2">
          <Button variant="outline" size="sm" onClick={() => window.location.reload()}>
            Recharger
          </Button>
          <Button size="sm" onClick={reset}>
            Réessayer
          </Button>
        </div>
      </div>
    </div>
  );
}
