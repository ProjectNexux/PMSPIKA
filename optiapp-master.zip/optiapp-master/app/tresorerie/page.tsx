import { BanknoteIcon, Plus, TrendingDown, TrendingUp, Wallet } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { ForecastChart } from "@/components/treasury/forecast-chart";
import { TreasuryCalendar, type CalendarEvent } from "@/components/treasury/treasury-calendar";
import { formatCurrency, formatDate } from "@/lib/format";
import {
  buildWeeklyBuckets,
  getInvoiceForecastItems,
  listCashAccounts,
  listCashTransactions,
  listForecastEntries,
  CASH_CATEGORIES_IN,
  CASH_CATEGORIES_OUT,
} from "@/lib/treasury-queries";
import { fetchQontoAccounts, fetchQontoTransactions } from "@/lib/qonto";
import { requireUser } from "@/lib/session";
import {
  addCashTransaction,
  addForecastEntry,
  createCashAccount,
  deleteCashAccount,
  deleteCashTransaction,
  deleteForecastEntry,
  realizeForecastEntry,
  syncQontoAccounts,
  updateAccountBalance,
} from "./actions";

export const dynamic = "force-dynamic";

// ── Helpers ───────────────────────────────────────────────────────────────────

const today = () => new Date().toISOString().slice(0, 10);

function monthStart() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-01`;
}

function categoryColor(category: string): "green" | "red" | "blue" | "orange" | "neutral" {
  if (["Facture client", "Subvention", "Remboursement", "Autre recette"].includes(category)) return "green";
  if (["Salaires", "Charges sociales", "TVA / URSSAF"].includes(category)) return "red";
  if (["Carburant", "Entretien véhicule", "Assurance"].includes(category)) return "orange";
  if (["Loyer", "Fournisseur"].includes(category)) return "blue";
  return "neutral";
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default async function TresoreriePage() {
  const user = await requireUser();
  const cid  = user.company_id ?? "";

  const [accounts, transactions, forecast, invoiceItems, qontoAccounts, qontoTransactions] = await Promise.all([
    listCashAccounts(cid),
    listCashTransactions(cid, 60),
    listForecastEntries(cid),
    getInvoiceForecastItems(cid),
    fetchQontoAccounts(),
    fetchQontoTransactions(undefined, 60),
  ]);

  // ── KPIs ─────────────────────────────────────────────────────────────────
  const totalBalance = accounts.reduce((s, a) => s + a.balance, 0);
  const ms = monthStart();
  const monthTx = transactions.filter((t) => t.date >= ms);
  const monthIn  = monthTx.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0);
  const monthOut = monthTx.filter((t) => t.amount < 0).reduce((s, t) => s + Math.abs(t.amount), 0);

  // Projected balance in 30 days
  const in30 = new Date(Date.now() + 30 * 86_400_000).toISOString().slice(0, 10);
  const realizedSourceIds = new Set(transactions.map((t) => t.source_id).filter(Boolean) as string[]);
  const pendingForecast30 = [
    ...forecast.filter((f) => f.expected_date <= in30),
    ...invoiceItems.filter((i) => i.expected_date <= in30 && !realizedSourceIds.has(i.source_id)),
  ];
  const projectedBalance30 = totalBalance + pendingForecast30.reduce((s, f) => s + f.amount, 0);

  // ── Chart data ────────────────────────────────────────────────────────────
  const buckets = buildWeeklyBuckets(forecast, invoiceItems, realizedSourceIds);

  // ── Forecast merged list (manual + auto, not yet realized) ────────────────
  const manualForecastIds = new Set(forecast.map((f) => f.source_id).filter(Boolean) as string[]);
  const mergedForecast = [
    ...forecast,
    ...invoiceItems.filter((i) => !realizedSourceIds.has(i.source_id) && !manualForecastIds.has(i.source_id)),
  ].sort((a, b) => a.expected_date.localeCompare(b.expected_date));

  const defaultAccountId = accounts.find((a) => a.is_default)?.id ?? accounts[0]?.id ?? "";
  const qontoBalance = qontoAccounts.reduce((sum, acc) => sum + acc.balance, 0);

  // ── Calendar events ───────────────────────────────────────────────────────
  const todayStr = today();
  const calendarMonth = todayStr.slice(0, 7);

  const calendarEvents: CalendarEvent[] = [
    ...transactions.map((t) => ({
      id: t.id,
      date: t.date,
      label: t.label,
      amount: t.amount,
      category: t.category,
      type: "realized" as const,
    })),
    ...forecast.map((f) => ({
      id: f.id,
      date: f.expected_date,
      label: f.label,
      amount: f.amount,
      category: f.category,
      type: "forecast" as const,
    })),
    ...invoiceItems
      .filter((i) => !realizedSourceIds.has(i.source_id))
      .map((i) => ({
        id: `inv-${i.id}`,
        date: i.expected_date,
        label: i.label,
        amount: i.amount,
        category: i.category,
        type: "invoice" as const,
      })),
  ];

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Trésorerie" />

      {/* ── KPI row ─────────────────────────────────────────────────────── */}
      <section className="stat-grid">
        <StatCard
          label="Solde total"
          value={formatCurrency(totalBalance)}
          tone={totalBalance >= 0 ? "green" : "red"}
          icon={<Wallet size={18} />}
          detail={`${accounts.length} compte${accounts.length > 1 ? "s" : ""}`}
        />
        <StatCard
          label="Encaissements ce mois"
          value={formatCurrency(monthIn)}
          tone="green"
          icon={<TrendingUp size={18} />}
        />
        <StatCard
          label="Décaissements ce mois"
          value={formatCurrency(monthOut)}
          tone="red"
          icon={<TrendingDown size={18} />}
        />
        <StatCard
          label="Solde prévisionnel J+30"
          value={formatCurrency(projectedBalance30)}
          tone={projectedBalance30 >= 0 ? "blue" : "orange"}
          icon={<BanknoteIcon size={18} />}
          detail={`${pendingForecast30.length} mouvement(s) attendu(s)`}
        />
      </section>

      {/* ── Calendrier de trésorerie ────────────────────────────────── */}
      <div className="panel" style={{ marginBottom: 24 }}>
        <div className="panel-header">
          <div>
            <h2>Calendrier de trésorerie</h2>
            <p>Mouvements réalisés · Prévisions · Échéances factures</p>
          </div>
        </div>
        <div style={{ padding: "0 16px 16px" }}>
          <TreasuryCalendar
            events={calendarEvents}
            initialBalance={totalBalance}
            todayStr={todayStr}
            initialMonth={calendarMonth}
          />
        </div>
      </div>

      {/* ── Forecast chart ──────────────────────────────────────────────── */}
          <div className="panel" style={{ marginBottom: 24 }}>
        <div className="panel-header">
          <div>
            <h2>Prévisionnel 13 semaines</h2>
            <p>Solde projeté à partir du solde actuel ({formatCurrency(totalBalance)})</p>
          </div>
        </div>
        <div style={{ padding: "0 16px 16px" }}>
          <ForecastChart buckets={buckets} initialBalance={totalBalance} />
        </div>
      </div>

      <div className="panel" style={{ marginBottom: 24 }}>
        <div className="panel-header" style={{ alignItems: "center", gap: 12 }}>
          <div>
            <h2>Comptes Qonto</h2>
            <p>Récupérés via l’API Qonto</p>
          </div>
          <form action={syncQontoAccounts} style={{ marginLeft: "auto" }}>
            <button type="submit" className="btn-secondary" style={{ fontSize: 12, padding: "8px 12px" }}>
              Synchroniser Qonto
            </button>
          </form>
        </div>
        <div style={{ padding: "0 16px 16px" }}>
          <div style={{ marginBottom: 12, display: "flex", justifyContent: "space-between", gap: 12 }}>
            <div style={{ fontSize: 13, color: "var(--muted-foreground)" }}>
              Total Qonto
            </div>
            <div style={{ fontWeight: 700, color: qontoBalance >= 0 ? "var(--green)" : "var(--red)" }}>
              {formatCurrency(qontoBalance)}
            </div>
          </div>
          {qontoAccounts.length === 0 ? (
            <div style={{ padding: 24, color: "var(--muted-foreground)", textAlign: "center" }}>
              Aucun compte Qonto trouvé ou la connexion Qonto n’est pas configurée.
            </div>
          ) : (
            <div style={{ display: "grid", gap: 12 }}>
              {qontoAccounts.map((acc) => (
                <div key={acc.id} style={{ padding: 16, border: "1px solid var(--border)", borderRadius: 12 }}>
                  <div style={{ fontWeight: 600, marginBottom: 6 }}>{acc.label}</div>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 16 }}>
                    <div style={{ fontSize: 13, color: "var(--muted-foreground)" }}>
                      IBAN: {acc.iban ?? "—"}
                    </div>
                    <div style={{ fontWeight: 700, color: acc.balance >= 0 ? "var(--green)" : "var(--red)" }}>
                      {formatCurrency(acc.balance)}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="panel" style={{ marginBottom: 24 }}>
        <div className="panel-header">
          <div>
            <h2>Transactions Qonto</h2>
            <p>Dernières opérations bancaires récupérées</p>
          </div>
        </div>
        <div style={{ padding: "0 16px 16px" }}>
          {qontoTransactions.length === 0 ? (
            <div style={{ padding: 24, color: "var(--muted-foreground)", textAlign: "center" }}>
              Aucun mouvement Qonto trouvé ou l’API n’est pas disponible.
            </div>
          ) : (
            <div style={{ maxHeight: 300, overflowY: "auto" }}>
              <table className="table" style={{ fontSize: 13 }}>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Libellé</th>
                    <th>Montant</th>
                    <th>Devise</th>
                  </tr>
                </thead>
                <tbody>
                  {qontoTransactions.map((tx) => (
                    <tr key={tx.id}>
                      <td style={{ whiteSpace: "nowrap" }}>{formatDate(tx.date)}</td>
                      <td style={{ maxWidth: 240, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{tx.label}</td>
                      <td style={{ textAlign: "right", fontWeight: 600, color: tx.amount >= 0 ? "var(--green)" : "var(--red)", whiteSpace: "nowrap" }}>
                        {tx.amount >= 0 ? "+" : ""}{formatCurrency(tx.amount)}
                      </td>
                      <td style={{ whiteSpace: "nowrap" }}>{tx.currency}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="grid-2">
        {/* ── Left column: comptes + transactions ─────────────────────── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>

          {/* Comptes bancaires */}
          <div className="panel">
            <div className="panel-header">
              <div>
                <h2>Comptes bancaires</h2>
                <p>{accounts.length} compte{accounts.length !== 1 ? "s" : ""}</p>
              </div>
            </div>

            {accounts.length > 0 && (
              <div style={{ borderBottom: "1px solid var(--border)" }}>
                {accounts.map((acc) => (
                  <div
                    key={acc.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: "10px 16px",
                      borderTop: "1px solid var(--border)",
                      gap: 12,
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 600, fontSize: 14 }}>
                        {acc.label}
                        {acc.is_default && (
                          <span style={{ marginLeft: 6, fontSize: 11, color: "var(--muted-foreground)", fontWeight: 400 }}>
                            (défaut)
                          </span>
                        )}
                      </div>
                      {acc.iban && (
                        <div style={{ fontSize: 12, color: "var(--muted-foreground)", marginTop: 2 }}>
                          {acc.iban}
                        </div>
                      )}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
                      <span
                        style={{
                          fontWeight: 700,
                          fontSize: 15,
                          color: acc.balance >= 0 ? "var(--green)" : "var(--red)",
                        }}
                      >
                        {formatCurrency(acc.balance)}
                      </span>
                      {/* Update balance form */}
                      <form action={updateAccountBalance} style={{ display: "flex", gap: 4 }}>
                        <input type="hidden" name="id" value={acc.id} />
                        <input
                          name="balance"
                          defaultValue={acc.balance}
                          inputMode="decimal"
                          style={{ width: 90, fontSize: 13 }}
                          className="input-sm"
                        />
                        <button type="submit" className="btn-secondary" style={{ fontSize: 12, padding: "4px 8px" }}>
                          Màj
                        </button>
                      </form>
                      <form action={deleteCashAccount}>
                        <input type="hidden" name="id" value={acc.id} />
                        <button type="submit" className="btn-ghost-danger" style={{ fontSize: 12, padding: "4px 8px" }}>
                          ×
                        </button>
                      </form>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Add account form */}
            <div style={{ padding: 16 }}>
              <p style={{ fontSize: 12, fontWeight: 600, color: "var(--muted-foreground)", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Ajouter un compte
              </p>
              <form action={createCashAccount} className="form-grid">
                <div className="field">
                  <label htmlFor="acc-label">Libellé</label>
                  <input id="acc-label" name="label" placeholder="ex: Compte courant BNP" required />
                </div>
                <div className="field">
                  <label htmlFor="acc-balance">Solde actuel (€)</label>
                  <input id="acc-balance" name="balance" inputMode="decimal" defaultValue="0" required />
                </div>
                <div className="field full">
                  <label htmlFor="acc-iban">IBAN (optionnel)</label>
                  <input id="acc-iban" name="iban" placeholder="FR76…" />
                </div>
                <div className="full">
                  <button type="submit" className="button">
                    <Plus size={14} /> Ajouter le compte
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Ajouter un mouvement réalisé */}
          <div className="panel">
            <div className="panel-header">
              <div>
                <h2>Enregistrer un mouvement</h2>
                <p>Encaissement ou décaissement réalisé</p>
              </div>
            </div>
            <div style={{ padding: 16 }}>
              <form action={addCashTransaction} className="form-grid">
                {accounts.length > 0 && (
                  <div className="field full">
                    <label htmlFor="tx-account">Compte</label>
                    <select id="tx-account" name="account_id" defaultValue={defaultAccountId}>
                      <option value="">— Sans compte —</option>
                      {accounts.map((a) => (
                        <option key={a.id} value={a.id}>{a.label}</option>
                      ))}
                    </select>
                  </div>
                )}
                <div className="field">
                  <label htmlFor="tx-date">Date</label>
                  <input id="tx-date" name="date" type="date" defaultValue={today()} required />
                </div>
                <div className="field">
                  <label htmlFor="tx-direction">Type</label>
                  <select id="tx-direction" name="direction" defaultValue="in">
                    <option value="in">Encaissement (+)</option>
                    <option value="out">Décaissement (−)</option>
                  </select>
                </div>
                <div className="field full">
                  <label htmlFor="tx-label">Libellé</label>
                  <input id="tx-label" name="label" placeholder="ex: Règlement facture EUR-2026-012" required />
                </div>
                <div className="field">
                  <label htmlFor="tx-amount">Montant (€)</label>
                  <input id="tx-amount" name="amount" inputMode="decimal" placeholder="0.00" required />
                </div>
                <div className="field">
                  <label htmlFor="tx-category">Catégorie</label>
                  <select id="tx-category" name="category" defaultValue="Autre">
                    <optgroup label="Entrées">
                      {CASH_CATEGORIES_IN.map((c) => <option key={c}>{c}</option>)}
                    </optgroup>
                    <optgroup label="Sorties">
                      {CASH_CATEGORIES_OUT.map((c) => <option key={c}>{c}</option>)}
                    </optgroup>
                  </select>
                </div>
                <div className="full">
                  <button type="submit" className="button">
                    <Plus size={14} /> Enregistrer
                  </button>
                </div>
              </form>
            </div>
          </div>

        </div>

        {/* ── Right column: mouvements récents + prévisionnel ─────────── */}
        <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>

          {/* Mouvements récents */}
          <div className="panel">
            <div className="panel-header">
              <div>
                <h2>Mouvements récents</h2>
                <p>60 derniers mouvements enregistrés</p>
              </div>
            </div>

            {transactions.length === 0 ? (
              <div style={{ padding: "32px 16px", textAlign: "center", color: "var(--muted-foreground)", fontSize: 13 }}>
                Aucun mouvement enregistré
              </div>
            ) : (
              <div style={{ maxHeight: 340, overflowY: "auto" }}>
                <table className="table" style={{ fontSize: 13 }}>
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Libellé</th>
                      <th>Catégorie</th>
                      <th style={{ textAlign: "right" }}>Montant</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((tx) => (
                      <tr key={tx.id}>
                        <td style={{ whiteSpace: "nowrap" }}>{formatDate(tx.date)}</td>
                        <td style={{ maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{tx.label}</td>
                        <td>
                          <StatusPill value={tx.category} />
                        </td>
                        <td style={{ textAlign: "right", fontWeight: 600, color: tx.amount >= 0 ? "var(--green)" : "var(--red)", whiteSpace: "nowrap" }}>
                          {tx.amount >= 0 ? "+" : ""}
                          {formatCurrency(tx.amount)}
                        </td>
                        <td>
                          <form action={deleteCashTransaction}>
                            <input type="hidden" name="id" value={tx.id} />
                            <button type="submit" className="btn-ghost-danger" style={{ fontSize: 12, padding: "2px 6px" }}>
                              ×
                            </button>
                          </form>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Prévisionnel */}
          <div className="panel">
            <div className="panel-header">
              <div>
                <h2>Prévisionnel de trésorerie</h2>
                <p>{mergedForecast.length} entrée{mergedForecast.length !== 1 ? "s" : ""} sur 90 jours</p>
              </div>
            </div>

            {/* Table of upcoming entries */}
            {mergedForecast.length > 0 && (
              <div style={{ maxHeight: 280, overflowY: "auto", borderBottom: "1px solid var(--border)" }}>
                <table className="table" style={{ fontSize: 13 }}>
                  <thead>
                    <tr>
                      <th>Échéance</th>
                      <th>Libellé</th>
                      <th>Catégorie</th>
                      <th style={{ textAlign: "right" }}>Montant</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {mergedForecast.map((entry) => {
                      const isInvoice = entry.source === "invoice";
                      return (
                        <tr key={entry.id}>
                          <td style={{ whiteSpace: "nowrap" }}>
                            <span style={{ fontWeight: 500 }}>{formatDate(entry.expected_date)}</span>
                          </td>
                          <td style={{ maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                            {entry.label}
                            {isInvoice && (
                              <span style={{ marginLeft: 4, fontSize: 10, color: "var(--muted-foreground)", background: "var(--muted)", borderRadius: 4, padding: "1px 4px" }}>
                                auto
                              </span>
                            )}
                          </td>
                          <td>
                            <StatusPill value={entry.category} />
                          </td>
                          <td style={{ textAlign: "right", fontWeight: 600, color: entry.amount >= 0 ? "var(--green)" : "var(--red)", whiteSpace: "nowrap" }}>
                            {entry.amount >= 0 ? "+" : ""}
                            {formatCurrency(entry.amount)}
                          </td>
                          <td>
                            {!isInvoice && (
                              <div style={{ display: "flex", gap: 4 }}>
                                <form action={realizeForecastEntry}>
                                  <input type="hidden" name="id" value={entry.id} />
                                  <button type="submit" className="btn-secondary" style={{ fontSize: 11, padding: "2px 6px" }} title="Marquer comme réalisé">
                                    ✓
                                  </button>
                                </form>
                                <form action={deleteForecastEntry}>
                                  <input type="hidden" name="id" value={entry.id} />
                                  <button type="submit" className="btn-ghost-danger" style={{ fontSize: 12, padding: "2px 6px" }}>
                                    ×
                                  </button>
                                </form>
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Add forecast entry form */}
            <div style={{ padding: 16 }}>
              <p style={{ fontSize: 12, fontWeight: 600, color: "var(--muted-foreground)", marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Ajouter une prévision
              </p>
              <form action={addForecastEntry} className="form-grid">
                <div className="field">
                  <label htmlFor="fc-date">Date prévue</label>
                  <input id="fc-date" name="expected_date" type="date" defaultValue={today()} required />
                </div>
                <div className="field">
                  <label htmlFor="fc-direction">Type</label>
                  <select id="fc-direction" name="direction" defaultValue="in">
                    <option value="in">Entrée prévue (+)</option>
                    <option value="out">Sortie prévue (−)</option>
                  </select>
                </div>
                <div className="field full">
                  <label htmlFor="fc-label">Libellé</label>
                  <input id="fc-label" name="label" placeholder="ex: Virement client ABC" required />
                </div>
                <div className="field">
                  <label htmlFor="fc-amount">Montant (€)</label>
                  <input id="fc-amount" name="amount" inputMode="decimal" placeholder="0.00" required />
                </div>
                <div className="field">
                  <label htmlFor="fc-category">Catégorie</label>
                  <select id="fc-category" name="category" defaultValue="Autre">
                    <optgroup label="Entrées">
                      {CASH_CATEGORIES_IN.map((c) => <option key={c}>{c}</option>)}
                    </optgroup>
                    <optgroup label="Sorties">
                      {CASH_CATEGORIES_OUT.map((c) => <option key={c}>{c}</option>)}
                    </optgroup>
                  </select>
                </div>
                <div className="field full">
                  <label htmlFor="fc-notes">Note (optionnel)</label>
                  <input id="fc-notes" name="notes" placeholder="Précision…" />
                </div>
                <div className="full">
                  <button type="submit" className="button">
                    <Plus size={14} /> Ajouter au prévisionnel
                  </button>
                </div>
              </form>
            </div>
          </div>

        </div>
      </div>
    </main>
  );
}
