"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { supabase } from "@/lib/db";
import { fetchQontoAccounts } from "@/lib/qonto";
import { requireUser } from "@/lib/session";

// ── Comptes bancaires ─────────────────────────────────────────────────────────

export async function syncQontoAccounts() {
  const user = await requireUser();
  const companyId = user.company_id;
  if (!companyId) return;

  const qontoAccounts = await fetchQontoAccounts();
  for (const qonto of qontoAccounts) {
    const baseData = {
      company_id: companyId,
      label: qonto.label,
      iban: qonto.iban,
      balance: qonto.balance,
      currency: qonto.currency,
      qonto_account_id: qonto.id,
      updated_at: new Date().toISOString(),
    };

    const { data: existingByQonto, error: qErr } = await supabase
      .from("cash_accounts")
      .select("id")
      .eq("qonto_account_id", qonto.id)
      .maybeSingle();
    if (qErr) {
      console.error("[treasury] syncQontoAccounts query by qonto_account_id:", qErr.message);
      continue;
    }

    if (existingByQonto?.id) {
      await supabase.from("cash_accounts").update(baseData).eq("id", existingByQonto.id);
      continue;
    }

    if (qonto.iban) {
      const { data: existingByIban, error: iErr } = await supabase
        .from("cash_accounts")
        .select("id")
        .eq("company_id", companyId)
        .eq("iban", qonto.iban)
        .maybeSingle();
      if (iErr) {
        console.error("[treasury] syncQontoAccounts query by iban:", iErr.message);
      } else if (existingByIban?.id) {
        await supabase.from("cash_accounts").update(baseData).eq("id", existingByIban.id);
        continue;
      }
    }

    await supabase.from("cash_accounts").insert({
      ...baseData,
      is_default: false,
      notes: "Synchronisé depuis Qonto",
      created_at: new Date().toISOString(),
    });
  }

  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

export async function createCashAccount(formData: FormData) {
  const user = await requireUser();
  const label   = String(formData.get("label") ?? "").trim();
  const iban    = String(formData.get("iban") ?? "").trim() || null;
  const balance = parseFloat(String(formData.get("balance") ?? "0")) || 0;
  const notes   = String(formData.get("notes") ?? "").trim() || null;

  if (!label) return;

  const { error } = await supabase.from("cash_accounts").insert({
    company_id: user.company_id,
    label,
    iban,
    balance,
    notes,
  });

  if (error) { console.error("[treasury] createCashAccount:", error.message); return; }
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

export async function updateAccountBalance(formData: FormData) {
  const user = await requireUser();
  const id      = String(formData.get("id") ?? "");
  const balance = parseFloat(String(formData.get("balance") ?? "0")) || 0;

  if (!id) return;

  const { error } = await supabase
    .from("cash_accounts")
    .update({ balance, updated_at: new Date().toISOString() })
    .eq("id", id)
    .eq("company_id", user.company_id);

  if (error) { console.error("[treasury] updateAccountBalance:", error.message); return; }
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

export async function deleteCashAccount(formData: FormData) {
  const user = await requireUser();
  const id = String(formData.get("id") ?? "");
  if (!id) return;

  await supabase.from("cash_accounts").delete().eq("id", id).eq("company_id", user.company_id);
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

// ── Mouvements réalisés ───────────────────────────────────────────────────────

export async function addCashTransaction(formData: FormData) {
  const user       = await requireUser();
  const account_id = String(formData.get("account_id") ?? "").trim() || null;
  const date       = String(formData.get("date") ?? "").trim();
  const label      = String(formData.get("label") ?? "").trim();
  const rawAmount  = parseFloat(String(formData.get("amount") ?? "0")) || 0;
  const direction  = String(formData.get("direction") ?? "in");
  const category   = String(formData.get("category") ?? "Autre").trim();
  const notes      = String(formData.get("notes") ?? "").trim() || null;

  if (!label || !date) return;
  const amount = direction === "out" ? -Math.abs(rawAmount) : Math.abs(rawAmount);

  const { error } = await supabase.from("cash_transactions").insert({
    company_id: user.company_id,
    account_id,
    date,
    label,
    amount,
    category,
    source: "manual",
    notes,
  });

  // Update account running balance when an account is linked
  if (!error && account_id) {
    try {
      await supabase.rpc("increment_cash_account_balance", {
        p_account_id: account_id,
        p_delta: amount,
      });
    } catch { /* best-effort; function may not exist yet */ }
  }

  if (error) { console.error("[treasury] addCashTransaction:", error.message); return; }
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

export async function deleteCashTransaction(formData: FormData) {
  const user = await requireUser();
  const id = String(formData.get("id") ?? "");
  if (!id) return;

  await supabase.from("cash_transactions").delete().eq("id", id).eq("company_id", user.company_id);
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

// ── Prévisions manuelles ──────────────────────────────────────────────────────

export async function addForecastEntry(formData: FormData) {
  const user          = await requireUser();
  const expected_date = String(formData.get("expected_date") ?? "").trim();
  const label         = String(formData.get("label") ?? "").trim();
  const rawAmount     = parseFloat(String(formData.get("amount") ?? "0")) || 0;
  const direction     = String(formData.get("direction") ?? "in");
  const category      = String(formData.get("category") ?? "Autre").trim();
  const notes         = String(formData.get("notes") ?? "").trim() || null;

  if (!label || !expected_date) return;
  const amount = direction === "out" ? -Math.abs(rawAmount) : Math.abs(rawAmount);

  const { error } = await supabase.from("cash_forecast").insert({
    company_id: user.company_id,
    expected_date,
    label,
    amount,
    category,
    source: "manual",
    notes,
  });

  if (error) { console.error("[treasury] addForecastEntry:", error.message); return; }
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

export async function realizeForecastEntry(formData: FormData) {
  const user = await requireUser();
  const id   = String(formData.get("id") ?? "");
  if (!id) return;

  await supabase
    .from("cash_forecast")
    .update({ is_realized: true, updated_at: new Date().toISOString() })
    .eq("id", id)
    .eq("company_id", user.company_id);

  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}

export async function deleteForecastEntry(formData: FormData) {
  const user = await requireUser();
  const id   = String(formData.get("id") ?? "");
  if (!id) return;

  await supabase.from("cash_forecast").delete().eq("id", id).eq("company_id", user.company_id);
  revalidatePath("/tresorerie");
  redirect("/tresorerie");
}
