import { Skeleton } from "@/components/skeleton";
import { PageHeader } from "@/components/page-header";

export default function TresorerieLoading() {
  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Trésorerie" />
      <section className="stat-grid">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} style={{ height: 90, borderRadius: "var(--radius)" }} />
        ))}
      </section>
      <Skeleton style={{ height: 220, borderRadius: "var(--radius)", marginBottom: 24 }} />
      <div className="grid-2">
        <Skeleton style={{ height: 380, borderRadius: "var(--radius)" }} />
        <Skeleton style={{ height: 380, borderRadius: "var(--radius)" }} />
      </div>
    </main>
  );
}
