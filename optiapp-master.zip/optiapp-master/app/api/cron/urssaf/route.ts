import { NextResponse } from "next/server";
import {
  currentPeriod,
  getUrssafCredentialFull,
  listAllEnabledCredentials,
  recordRunResult,
  saveAttestation,
} from "@/lib/urssaf-queries";
import { fetchUrssafAttestation } from "@/lib/urssaf-scraper";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
// Vercel : 60s sur Hobby, 300s sur Pro. Le scraping peut dépasser 60s sur N sociétés.
export const maxDuration = 300;

/**
 * Cron mensuel — déclenché par Vercel Cron (cf. vercel.json) le 1er de chaque mois.
 * Sécurisé par `CRON_SECRET` (header `Authorization: Bearer <secret>`).
 *
 * Pour tester manuellement :
 *   curl -H "Authorization: Bearer $CRON_SECRET" https://<host>/api/cron/urssaf
 */
export async function GET(req: Request) {
  const auth = req.headers.get("authorization");
  const expected = `Bearer ${process.env.CRON_SECRET ?? ""}`;
  if (!process.env.CRON_SECRET || auth !== expected) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const period = currentPeriod();
  const targets = await listAllEnabledCredentials();
  const results: Array<{ company_id: string; status: string; message?: string }> = [];

  for (const { company_id } of targets) {
    try {
      const creds = await getUrssafCredentialFull(company_id);
      if (!creds) {
        results.push({ company_id, status: "skipped", message: "no creds" });
        continue;
      }
      const result = await fetchUrssafAttestation({
        username: creds.username,
        password: creds.password,
      });
      if (!result.ok) {
        const errResult = result as { ok: false; reason: string; message: string };
        await recordRunResult(
          company_id,
          errResult.reason === "mfa_required" ? "mfa_required" : "error",
          `${errResult.reason}: ${errResult.message}`,
        );
        results.push({ company_id, status: errResult.reason, message: errResult.message });
        continue;
      }
      await saveAttestation({
        companyId: company_id,
        period,
        pdf: result.pdf,
        validFrom: result.validFrom,
        validUntil: result.validUntil,
        source: "auto",
      });
      await recordRunResult(company_id, "ok", null);
      results.push({ company_id, status: "ok" });
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      await recordRunResult(company_id, "error", message).catch(() => {});
      results.push({ company_id, status: "exception", message });
    }
  }

  return NextResponse.json({ period, processed: results.length, results });
}
