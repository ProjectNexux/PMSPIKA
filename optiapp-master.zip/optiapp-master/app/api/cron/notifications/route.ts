import { NextResponse } from "next/server";
import { getServerSupabase } from "@/lib/db-server";
import { notifyAll, type DispatchResult } from "@/lib/notifications";
import { logAudit } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * Cron quotidien — détecte les évènements à signaler aux gérants :
 *   - documents (employés ou flotte) qui expirent à J-30 ou J-7
 *   - missions non assignées pour J-1 (lendemain)
 *
 * Envoie sur les 3 canaux (in-app + email Resend si configuré + SMS Twilio si configuré).
 *
 * Sécurisé par `CRON_SECRET`. Test manuel :
 *   curl -H "Authorization: Bearer $CRON_SECRET" https://<host>/api/cron/notifications
 */
export async function GET(req: Request) {
  const auth = req.headers.get("authorization");
  const expected = `Bearer ${process.env.CRON_SECRET ?? ""}`;
  if (!process.env.CRON_SECRET || auth !== expected) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const sb = getServerSupabase();
  const summary = {
    expiring_employee_docs: 0,
    expiring_fleet_docs: 0,
    unassigned_missions: 0,
    notifications_sent: 0,
    failures: 0,
  };
  const sampleErrors: string[] = [];

  // 1. Récupère le mapping company_id → admins (gerant_societe, gerant_groupe, super_admin).
  const { data: admins } = await sb
    .from("profiles")
    .select("id, email, phone, company_id, role")
    .in("role", ["super_admin", "gerant_groupe", "gerant_societe", "chef_site"]);

  const adminsByCompany = new Map<string | null, typeof admins>();
  for (const admin of admins ?? []) {
    const key = admin.company_id;
    if (!adminsByCompany.has(key)) adminsByCompany.set(key, []);
    adminsByCompany.get(key)!.push(admin);
  }
  // Les super_admin / gerant_groupe (company_id NULL) reçoivent toutes les alertes.
  const globalAdmins = adminsByCompany.get(null) ?? [];

  const recipientsFor = (companyId: string | null) => {
    const local = (companyId ? adminsByCompany.get(companyId) ?? [] : []);
    return [...local, ...globalAdmins];
  };

  // 2. Documents (RH + flotte) expirant à J-30 ou J-7.
  const today = new Date();
  const j30 = isoDate(addDays(today, 30));
  const j7 = isoDate(addDays(today, 7));

  const { data: empDocs } = await sb
    .from("employee_documents")
    .select("id, title, category, expires_on, employee_id, employees!inner(first_name, last_name, company_id)")
    .in("expires_on", [j30, j7]);

  for (const doc of (empDocs ?? []) as unknown as ExpiringEmpDoc[]) {
    summary.expiring_employee_docs++;
    const emp = Array.isArray(doc.employees) ? doc.employees[0] : doc.employees;
    const companyId = emp?.company_id ?? null;
    const days = doc.expires_on === j7 ? 7 : 30;
    const title = `Document RH expire J-${days}`;
    const message = `${doc.title} (${doc.category}) — ${emp?.first_name ?? ""} ${emp?.last_name ?? ""} — expire le ${doc.expires_on}`;
    for (const admin of recipientsFor(companyId)) {
      const results = await notifyAll({
        userId: admin.id,
        email: admin.email,
        phone: null, // pas de SMS RH par défaut (J-30 = pas urgent)
        title,
        message,
        link: `/social`,
        type: days === 7 ? "warning" : "info",
      });
      tally(summary, sampleErrors, results);
    }
  }

  const { data: fleetDocs } = await sb
    .from("documents")
    .select("id, title, category, due_date, company_id, vehicle_id")
    .in("due_date", [j30, j7]);

  for (const doc of fleetDocs ?? []) {
    summary.expiring_fleet_docs++;
    const days = doc.due_date === j7 ? 7 : 30;
    const title = `Document expire J-${days}`;
    const message = `${doc.title} (${doc.category}) — expire le ${doc.due_date}`;
    for (const admin of recipientsFor(doc.company_id)) {
      const results = await notifyAll({
        userId: admin.id,
        email: admin.email,
        phone: days === 7 ? admin.phone : null,
        title,
        message,
        link: doc.company_id ? `/conformite-loti` : "/documents",
        type: days === 7 ? "warning" : "info",
      });
      tally(summary, sampleErrors, results);
    }
  }

  // 3. Missions non assignées pour demain.
  const tomorrow = isoDate(addDays(today, 1));
  const { data: unassigned } = await sb
    .from("missions")
    .select("id, reference, scheduled_date, pickup_city, delivery_city, company_id")
    .eq("scheduled_date", tomorrow)
    .is("driver_id", null);

  for (const mission of unassigned ?? []) {
    summary.unassigned_missions++;
    const title = "Mission non assignée demain";
    const message = `${mission.reference ?? mission.id} — ${mission.pickup_city ?? "?"} → ${mission.delivery_city ?? "?"}`;
    for (const admin of recipientsFor(mission.company_id)) {
      const results = await notifyAll({
        userId: admin.id,
        email: admin.email,
        phone: admin.phone,
        title,
        message,
        link: `/pilotage`,
        type: "warning",
      });
      tally(summary, sampleErrors, results);
    }
  }

  await logAudit({
    action: "notifications_cron",
    entity: "system",
    metadata: summary as unknown as Record<string, unknown>,
  });

  return NextResponse.json({ ok: true, summary, sample_errors: sampleErrors.slice(0, 5) });
}

type ExpiringEmpDoc = {
  id: string;
  title: string;
  category: string;
  expires_on: string;
  employee_id: string;
  employees:
    | {
        first_name: string | null;
        last_name: string | null;
        company_id: string | null;
      }
    | {
        first_name: string | null;
        last_name: string | null;
        company_id: string | null;
      }[]
    | null;
};

function addDays(d: Date, days: number): Date {
  const r = new Date(d);
  r.setUTCDate(r.getUTCDate() + days);
  return r;
}

function isoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function tally(
  summary: { notifications_sent: number; failures: number },
  errors: string[],
  results: DispatchResult[],
) {
  for (const r of results) {
    if (r.ok) summary.notifications_sent++;
    else if (!r.skipped) {
      summary.failures++;
      if (errors.length < 20 && r.error) errors.push(`${r.channel}: ${r.error}`);
    }
  }
}
