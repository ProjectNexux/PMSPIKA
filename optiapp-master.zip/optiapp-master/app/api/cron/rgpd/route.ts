import { NextResponse } from "next/server";
import { getServerSupabase } from "@/lib/db-server";
import { logAudit } from "@/lib/audit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

/**
 * Cron quotidien RGPD — purge des données personnelles selon la politique
 * de rétention (cf. ROADMAP.md Lot 2.b). Déclenché par Vercel Cron.
 *
 * Sécurisé par `CRON_SECRET` (header `Authorization: Bearer <secret>`).
 *
 * Test manuel :
 *   curl -H "Authorization: Bearer $CRON_SECRET" https://<host>/api/cron/rgpd
 */
export async function GET(req: Request) {
  const auth = req.headers.get("authorization");
  const expected = `Bearer ${process.env.CRON_SECRET ?? ""}`;
  if (!process.env.CRON_SECRET || auth !== expected) {
    return NextResponse.json({ error: "unauthorized" }, { status: 401 });
  }

  const sb = getServerSupabase();
  const { data, error } = await sb.rpc("rgpd_purge", {
    // Tunables via env si besoin (sinon DEFAULT côté SQL).
    p_driver_events_days: Number(process.env.RGPD_DRIVER_EVENTS_DAYS ?? 365),
    p_driver_hours_days: Number(process.env.RGPD_DRIVER_HOURS_DAYS ?? 1095),
    p_driver_logs_days: Number(process.env.RGPD_DRIVER_LOGS_DAYS ?? 1095),
    p_notifications_days: Number(process.env.RGPD_NOTIFICATIONS_DAYS ?? 180),
    p_audit_log_days: Number(process.env.RGPD_AUDIT_LOG_DAYS ?? 1095),
  });

  if (error) {
    await logAudit({
      action: "rgpd_purge",
      entity: "system",
      result: "error",
      message: error.message,
    });
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  await logAudit({
    action: "rgpd_purge",
    entity: "system",
    metadata: (data ?? {}) as Record<string, unknown>,
  });

  return NextResponse.json({ ok: true, purged: data });
}
