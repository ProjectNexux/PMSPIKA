import { NextResponse } from "next/server";
import { getServerSupabase } from "@/lib/db-server";
import { logAudit } from "@/lib/audit";
import { requireRole, getCurrentUser } from "@/lib/session";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Export RGPD (droit à la portabilité — art. 20 RGPD).
 * Renvoie un JSON contenant toutes les données personnelles d'un utilisateur.
 *
 * Règles d'accès :
 *   - super_admin / gerant_groupe : peuvent exporter n'importe quel user_id
 *   - tout utilisateur connecté : peut exporter ses propres données
 *
 * Endpoint : GET /api/rgpd/export?user_id=<uuid>
 *            (user_id optionnel ; par défaut = l'utilisateur courant)
 */
export async function GET(req: Request) {
  const me = await getCurrentUser();
  if (!me) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  const url = new URL(req.url);
  const targetId = url.searchParams.get("user_id") ?? me.id;

  // Si on demande quelqu'un d'autre, exige un rôle admin.
  if (targetId !== me.id) {
    try {
      await requireRole(["super_admin", "gerant_groupe"]);
    } catch {
      return NextResponse.json({ error: "forbidden" }, { status: 403 });
    }
  }

  const sb = getServerSupabase();

  // Récupère en parallèle toutes les sources de données personnelles connues.
  // `employees` n'a pas de `user_id` → lookup par email du sujet.
  const subjectEmail = targetId === me.id
    ? me.email
    : (await sb.from("profiles").select("email").eq("id", targetId).maybeSingle()).data?.email ?? null;

  const [profile, employee, employeeDocs, missions, driverEvents, auditEntries] =
    await Promise.all([
      sb.from("profiles").select("*").eq("id", targetId).maybeSingle(),
      subjectEmail
        ? sb.from("employees").select("*").eq("email", subjectEmail).maybeSingle()
        : Promise.resolve({ data: null, error: null }),
      subjectEmail
        ? sb.from("employee_documents").select("id, category, title, issued_on, expires_on, uploaded_at, employee_id")
        : Promise.resolve({ data: [], error: null }),
      sb.from("missions").select("id, reference, scheduled_date, status, pickup_city, delivery_city").eq("driver_id", targetId),
      sb.from("driver_events").select("id, mission_id, event_type, lat, lng, created_at").eq("driver_id", targetId).limit(2000),
      sb.from("audit_log").select("at, action, entity, entity_id, result, message").eq("actor_id", targetId).limit(2000),
    ]);

  const payload = {
    exported_at: new Date().toISOString(),
    exported_by: { id: me.id, email: me.email, role: me.role },
    subject_user_id: targetId,
    notice:
      "Export RGPD (droit à la portabilité — art. 20). Données conservées au titre " +
      "des obligations légales (paie, comptabilité — 10 ans Code de commerce) ne sont " +
      "PAS effacées par cet export. Pour demander l'effacement, contacter le DPO.",
    profile: profile.data,
    employee: employee.data,
    employee_documents_count: employeeDocs.data?.length ?? 0,
    employee_documents: employeeDocs.data ?? [],
    missions: missions.data ?? [],
    driver_events: driverEvents.data ?? [],
    audit_entries: auditEntries.data ?? [],
  };

  await logAudit({
    action: "rgpd_export",
    entity: "users",
    entity_id: targetId,
    metadata: {
      missions: payload.missions.length,
      driver_events: payload.driver_events.length,
      employee_documents: payload.employee_documents_count,
    },
  });

  return new NextResponse(JSON.stringify(payload, null, 2), {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "content-disposition": `attachment; filename="rgpd-export-${targetId}.json"`,
    },
  });
}
