import { NextResponse } from "next/server";
import { getMissionTrackingByToken } from "@/lib/tracking-queries";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Suivi client PUBLIC d'une mission via son token.
 * Endpoint : GET /api/suivi/<token>
 *
 * ⚠️ Public, non authentifié. Ne renvoie qu'un sous-ensemble SÛR de données
 * (statut, villes, créneau, ETA, position approximative pendant le transit).
 * Aucune donnée financière ni identité chauffeur.
 */
export async function GET(
  _req: Request,
  ctx: { params: Promise<{ token: string }> },
) {
  const { token } = await ctx.params;
  const tracking = await getMissionTrackingByToken(token);

  if (!tracking) {
    return NextResponse.json({ error: "not_found" }, { status: 404 });
  }

  return NextResponse.json(tracking, {
    headers: { "Cache-Control": "no-store" },
  });
}
