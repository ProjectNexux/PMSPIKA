"use client";

/**
 * app/admin/utilisateurs/[id]/delete-user-button.tsx
 * Bouton de suppression avec confirmation — super_admin only.
 */

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { deleteUserAction } from "../actions";

interface Props {
  userId: string;
  userName: string;
}

export function DeleteUserButton({ userId, userName }: Props) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  function handleDelete() {
    if (
      !confirm(
        `Supprimer définitivement "${userName}" ?\n\nCette action est irréversible. Le compte auth Supabase et le profil seront supprimés.`,
      )
    ) return;

    startTransition(async () => {
      const res = await deleteUserAction(userId);
      if (res.ok) {
        router.push("/admin/utilisateurs");
      } else {
        alert(`Erreur : ${res.error}`);
      }
    });
  }

  return (
    <button
      type="button"
      className="btn-destructive"
      disabled={isPending}
      onClick={handleDelete}
    >
      <Trash2 size={15} />
      {isPending ? "Suppression…" : "Supprimer"}
    </button>
  );
}
