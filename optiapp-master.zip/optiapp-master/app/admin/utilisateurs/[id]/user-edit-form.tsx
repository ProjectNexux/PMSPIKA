"use client";

/**
 * app/admin/utilisateurs/[id]/user-edit-form.tsx
 * Formulaire d'édition du profil utilisateur.
 */

import { useState, useTransition } from "react";
import { updateUserAction } from "../actions";

type Company = { id: string; name: string };
type Site    = { id: string; name: string; company_id: string | null };

interface Profile {
  id: string;
  full_name: string | null;
  role: string;
  company_id: string | null;
  site_id: string | null;
  employee_id: string | null;
  phone: string | null;
  is_active: boolean;
}

interface Props {
  profile: Profile;
  companies: Company[];
  sites: Site[];
  isSuperAdmin: boolean;
  isSelf: boolean;
}

const ALL_ROLES = [
  { value: "chauffeur",       label: "Chauffeur" },
  { value: "client",          label: "Client" },
  { value: "chef_site",       label: "Chef de site" },
  { value: "gerant_societe",  label: "Gérant société" },
  { value: "gerant_groupe",   label: "Gérant groupe" },
  { value: "super_admin",     label: "Super admin" },
] as const;

export function UserEditForm({ profile, companies, sites, isSuperAdmin, isSelf }: Props) {
  const [isPending, startTransition] = useTransition();
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [selectedCompany, setSelectedCompany] = useState(profile.company_id ?? "");

  const filteredSites = selectedCompany
    ? sites.filter((s) => s.company_id === selectedCompany)
    : sites;

  const availableRoles = isSuperAdmin
    ? ALL_ROLES
    : ALL_ROLES.filter((r) => r.value !== "super_admin" && r.value !== "gerant_groupe");

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    startTransition(async () => {
      const res = await updateUserAction(profile.id, fd);
      setMessage({
        ok: res.ok,
        text: res.ok ? "Modifications enregistrées." : (res.error ?? "Erreur inconnue."),
      });
    });
  }

  return (
    <form onSubmit={handleSubmit} className="form-grid">
      <div className="form-field">
        <label htmlFor="uf-name">Nom complet</label>
        <input
          id="uf-name"
          name="full_name"
          type="text"
          defaultValue={profile.full_name ?? ""}
          disabled={isSelf && !isSuperAdmin}
        />
      </div>

      <div className="form-field">
        <label htmlFor="uf-phone">Téléphone</label>
        <input
          id="uf-phone"
          name="phone"
          type="tel"
          defaultValue={profile.phone ?? ""}
          placeholder="+33 6 00 00 00 00"
        />
      </div>

      <div className="form-field">
        <label htmlFor="uf-role">Rôle *</label>
        <select
          id="uf-role"
          name="role"
          defaultValue={profile.role}
          disabled={isSelf}
          required
        >
          {availableRoles.map((r) => (
            <option key={r.value} value={r.value}>{r.label}</option>
          ))}
        </select>
        {isSelf && (
          <small style={{ color: "var(--muted-foreground)" }}>
            Vous ne pouvez pas modifier votre propre rôle.
          </small>
        )}
      </div>

      <div className="form-field">
        <label htmlFor="uf-company">Société</label>
        <select
          id="uf-company"
          name="company_id"
          value={selectedCompany}
          onChange={(e) => setSelectedCompany(e.target.value)}
        >
          <option value="">— Aucune —</option>
          {companies.map((c) => (
            <option key={c.id} value={c.id}>{c.name}</option>
          ))}
        </select>
      </div>

      <div className="form-field">
        <label htmlFor="uf-site">Site</label>
        <select id="uf-site" name="site_id" defaultValue={profile.site_id ?? ""}>
          <option value="">— Aucun —</option>
          {filteredSites.map((s) => (
            <option key={s.id} value={s.id}>{s.name}</option>
          ))}
        </select>
      </div>

      <div className="form-field">
        <label htmlFor="uf-employee">ID Salarié</label>
        <input
          id="uf-employee"
          name="employee_id"
          type="text"
          defaultValue={profile.employee_id ?? ""}
          placeholder="EMP-XXXXX"
        />
      </div>

      {message && (
        <div
          className={message.ok ? "alert alert-success" : "alert alert-error"}
          style={{ gridColumn: "1 / -1" }}
        >
          {message.text}
        </div>
      )}

      <div style={{ gridColumn: "1 / -1", display: "flex", justifyContent: "flex-end" }}>
        <button type="submit" className="btn-primary" disabled={isPending}>
          {isPending ? "Enregistrement…" : "Enregistrer"}
        </button>
      </div>
    </form>
  );
}
