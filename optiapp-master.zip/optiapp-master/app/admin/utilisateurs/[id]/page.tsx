/**
 * app/admin/utilisateurs/[id]/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Fiche détail d'un utilisateur — modification rôle, société, site, téléphone.
 */

import { notFound } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { requireRole } from "@/lib/session";
import { getSupabaseServer } from "@/lib/supabase-server";
import { UserEditForm } from "./user-edit-form";
import { DeleteUserButton } from "./delete-user-button";

export const dynamic = "force-dynamic";

export default async function UserDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const currentUser = await requireRole(["super_admin", "gerant_groupe"]);
  const supabase = await getSupabaseServer();

  const [{ data: profile }, { data: companies }, { data: sites }] = await Promise.all([
    supabase
      .from("profiles")
      .select("id, email, full_name, role, company_id, site_id, employee_id, phone, is_active, created_at")
      .eq("id", id)
      .maybeSingle(),
    supabase.from("companies").select("id, name").order("name"),
    supabase.from("tms_sites").select("id, name, company_id").order("name"),
  ]);

  if (!profile) notFound();

  return (
    <main className="page">
      <PageHeader
        eyebrow={
          <Link href="/admin/utilisateurs" className="back-link">
            <ArrowLeft size={14} /> Utilisateurs
          </Link>
        }
        title={profile.full_name || profile.email || "Utilisateur"}
      >
        {currentUser.is_super_admin && profile.id !== currentUser.id ? (
          <DeleteUserButton userId={profile.id} userName={profile.full_name || profile.email || "cet utilisateur"} />
        ) : null}
      </PageHeader>

      <div className="grid-2">
        {/* Formulaire d'édition */}
        <div className="panel">
          <div className="panel-header">
            <div><h2>Informations du compte</h2></div>
          </div>
          <UserEditForm
            profile={profile}
            companies={companies ?? []}
            sites={sites ?? []}
            isSuperAdmin={currentUser.is_super_admin}
            isSelf={profile.id === currentUser.id}
          />
        </div>

        {/* Métadonnées */}
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div className="panel">
            <div className="panel-header"><div><h2>Informations système</h2></div></div>
            <dl className="detail-grid">
              <div>
                <dt>ID Supabase Auth</dt>
                <dd style={{ fontFamily: "monospace", fontSize: 12 }}>{profile.id}</dd>
              </div>
              <div>
                <dt>Email</dt>
                <dd>{profile.email || "—"}</dd>
              </div>
              <div>
                <dt>Statut</dt>
                <dd>
                  {profile.is_active ? (
                    <span style={{ color: "var(--green)", fontWeight: 600 }}>Actif</span>
                  ) : (
                    <span style={{ color: "var(--red)", fontWeight: 600 }}>Désactivé</span>
                  )}
                </dd>
              </div>
              <div>
                <dt>Créé le</dt>
                <dd>
                  {profile.created_at
                    ? new Date(profile.created_at).toLocaleDateString("fr-FR", {
                        day: "2-digit", month: "long", year: "numeric",
                      })
                    : "—"}
                </dd>
              </div>
              {profile.employee_id && (
                <div>
                  <dt>Lié à salarié</dt>
                  <dd>
                    <Link href={`/social`} className="link">
                      {profile.employee_id}
                    </Link>
                  </dd>
                </div>
              )}
            </dl>
          </div>
        </div>
      </div>
    </main>
  );
}
