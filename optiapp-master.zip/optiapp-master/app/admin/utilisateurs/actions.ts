"use server";

/**
 * app/admin/utilisateurs/actions.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Server Actions pour la gestion des utilisateurs :
 *   - inviteUserAction   : invite un utilisateur par email (Supabase Auth)
 *   - updateUserAction   : modifie rôle / société / site / téléphone
 *   - toggleActiveAction : active ou désactive un compte
 *   - deleteUserAction   : supprime profil + auth user (super_admin only)
 */

import { revalidatePath } from "next/cache";
import { getSupabaseAdmin, inviteUserByEmail } from "@/lib/supabase-admin";
import { getSupabaseServer } from "@/lib/supabase-server";
import { requireRole } from "@/lib/session";
import type { AppRole } from "@/lib/session";

const ADMIN_ROLES: AppRole[] = ["super_admin", "gerant_groupe"];
const REDIRECT_TO = `${process.env.NEXT_PUBLIC_SUPABASE_URL?.replace(".supabase.co", ".supabase.co")}/auth/callback?next=/chauffeur`;

// ── Inviter un utilisateur ─────────────────────────────────────────────────
export async function inviteUserAction(formData: FormData) {
  const currentUser = await requireRole(ADMIN_ROLES);
  const supabase = await getSupabaseServer();

  const email      = String(formData.get("email") ?? "").trim().toLowerCase();
  const role       = String(formData.get("role")  ?? "chauffeur") as AppRole;
  const company_id = String(formData.get("company_id") ?? "").trim() || null;
  const site_id    = String(formData.get("site_id")    ?? "").trim() || null;
  const employee_id = String(formData.get("employee_id") ?? "").trim() || null;

  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return { ok: false as const, error: "Email invalide." };
  }

  const validRoles: AppRole[] = [
    "super_admin", "gerant_groupe", "gerant_societe",
    "chef_site", "chauffeur", "client",
  ];
  if (!validRoles.includes(role)) {
    return { ok: false as const, error: "Rôle invalide." };
  }

  // Enregistrer l'invitation en base
  const { error: dbError } = await supabase
    .from("user_invitations")
    .insert({
      email,
      role,
      company_id,
      site_id: site_id ?? null,
      employee_id,
      invited_by: currentUser.id,
    });

  if (dbError) return { ok: false as const, error: dbError.message };

  // Envoyer l'email d'invitation via Supabase Auth Admin
  try {
    const { error: inviteError } = await inviteUserByEmail(email, {
      data: { role, company_id, site_id, employee_id },
      redirectTo: REDIRECT_TO,
    });
    if (inviteError) return { ok: false as const, error: inviteError.message };
  } catch (e) {
    // Si la service_role_key n'est pas configurée, on log et on retourne
    // l'invitation en base. L'admin devra inviter manuellement via le dashboard.
    console.error("[inviteUserAction] Supabase Admin non disponible :", e);
    return {
      ok: true as const,
      warning:
        "Invitation enregistrée mais l'email n'a pas pu être envoyé (SUPABASE_SERVICE_ROLE_KEY manquant). Invitez manuellement via le dashboard Supabase.",
    };
  }

  revalidatePath("/admin/utilisateurs");
  return { ok: true as const };
}

// ── Modifier un utilisateur ────────────────────────────────────────────────
export async function updateUserAction(userId: string, formData: FormData) {
  await requireRole(ADMIN_ROLES);
  const supabase = await getSupabaseServer();

  const full_name  = String(formData.get("full_name")  ?? "").trim();
  const role       = String(formData.get("role")        ?? "") as AppRole;
  const phone      = String(formData.get("phone")       ?? "").trim() || null;
  const company_id = String(formData.get("company_id")  ?? "").trim() || null;
  const site_id    = String(formData.get("site_id")     ?? "").trim() || null;
  const employee_id = String(formData.get("employee_id") ?? "").trim() || null;

  if (!userId) return { ok: false as const, error: "ID utilisateur manquant." };

  const { error } = await supabase
    .from("profiles")
    .update({ full_name, role, phone, company_id, site_id, employee_id })
    .eq("id", userId);

  if (error) return { ok: false as const, error: error.message };

  revalidatePath("/admin/utilisateurs");
  revalidatePath(`/admin/utilisateurs/${userId}`);
  return { ok: true as const };
}

// ── Activer / désactiver un compte ─────────────────────────────────────────
export async function toggleActiveAction(userId: string, active: boolean) {
  await requireRole(ADMIN_ROLES);
  const supabase = await getSupabaseServer();

  if (!userId) return { ok: false as const, error: "ID manquant." };

  const { error } = await supabase
    .from("profiles")
    .update({ is_active: active })
    .eq("id", userId);

  if (error) return { ok: false as const, error: error.message };

  revalidatePath("/admin/utilisateurs");
  return { ok: true as const };
}

// ── Supprimer un utilisateur (super_admin seulement) ───────────────────────
export async function deleteUserAction(userId: string) {
  const currentUser = await requireRole(["super_admin"]);

  if (userId === currentUser.id) {
    return { ok: false as const, error: "Vous ne pouvez pas supprimer votre propre compte." };
  }

  // Supprimer l'auth user via admin (cascade sur profiles via trigger)
  try {
    const admin = getSupabaseAdmin();
    const { error } = await admin.auth.admin.deleteUser(userId);
    if (error) return { ok: false as const, error: error.message };
  } catch (e) {
    return { ok: false as const, error: String(e) };
  }

  revalidatePath("/admin/utilisateurs");
  return { ok: true as const };
}
