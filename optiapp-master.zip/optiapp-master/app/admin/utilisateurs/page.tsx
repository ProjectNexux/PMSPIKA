/**
 * app/admin/utilisateurs/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Liste de tous les utilisateurs de la plateforme.
 * Accessible : super_admin, gerant_groupe.
 */

import Link from "next/link";
import { UserPlus, Shield, ShieldOff } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { requireRole } from "@/lib/session";
import { getSupabaseServer } from "@/lib/supabase-server";
import { InviteModal } from "./invite-modal";
import { ToggleActiveButton } from "./toggle-active-button";

export const dynamic = "force-dynamic";

const ROLE_LABELS: Record<string, string> = {
  super_admin:    "Super admin",
  gerant_groupe:  "Gérant groupe",
  gerant_societe: "Gérant société",
  chef_site:      "Chef de site",
  chauffeur:      "Chauffeur",
  client:         "Client",
};

const ROLE_COLORS: Record<string, string> = {
  super_admin:    "var(--red)",
  gerant_groupe:  "var(--orange)",
  gerant_societe: "var(--amber)",
  chef_site:      "var(--blue)",
  chauffeur:      "var(--green)",
  client:         "var(--muted-foreground)",
};

export default async function UtilisateursPage() {
  const currentUser = await requireRole(["super_admin", "gerant_groupe"]);
  const supabase = await getSupabaseServer();

  type AdminProfile = {
    id: string;
    full_name: string | null;
    email: string | null;
    role: string;
    is_active: boolean;
    company_name: string | null;
    site_name: string | null;
    created_at: string | null;
  };

  const { data: users } = await supabase.rpc("list_profiles_for_admin");
  const { data: companies } = await supabase
    .from("companies")
    .select("id, name")
    .order("name");
  const { data: sites } = await supabase
    .from("tms_sites")
    .select("id, name, company_id")
    .order("name");

  const list = (users ?? []) as AdminProfile[];
  const active   = list.filter((u) => u.is_active).length;
  const inactive = list.filter((u) => !u.is_active).length;

  return (
    <main className="page">
      <PageHeader
        eyebrow="Administration"
        title="Utilisateurs"
      >
        <InviteModal
          companies={companies ?? []}
          sites={sites ?? []}
          isSuperAdmin={currentUser.is_super_admin}
        />
      </PageHeader>

      {/* Stats rapides */}
      <div className="grid-4" style={{ marginBottom: 16 }}>
        <div className="panel stat-mini">
          <span className="stat-mini-label">Total</span>
          <span className="stat-mini-value">{list.length}</span>
        </div>
        <div className="panel stat-mini">
          <span className="stat-mini-label">Actifs</span>
          <span className="stat-mini-value" style={{ color: "var(--green)" }}>{active}</span>
        </div>
        <div className="panel stat-mini">
          <span className="stat-mini-label">Désactivés</span>
          <span className="stat-mini-value" style={{ color: "var(--red)" }}>{inactive}</span>
        </div>
        <div className="panel stat-mini">
          <span className="stat-mini-label">Chauffeurs</span>
          <span className="stat-mini-value">
            {list.filter((u) => u.role === "chauffeur").length}
          </span>
        </div>
      </div>

      {/* Table */}
      <div className="panel" style={{ padding: 0 }}>
        <table className="data-table">
          <thead>
            <tr>
              <th>Nom</th>
              <th>Email</th>
              <th>Rôle</th>
              <th>Société</th>
              <th>Site</th>
              <th>Statut</th>
              <th>Créé le</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {list.length === 0 && (
              <tr>
                <td colSpan={8} style={{ textAlign: "center", color: "var(--muted-foreground)", padding: "32px 0" }}>
                  Aucun utilisateur trouvé.
                </td>
              </tr>
            )}
            {list.map((u) => (
              <tr key={u.id} style={{ opacity: u.is_active ? 1 : 0.5 }}>
                <td>
                  <Link href={`/admin/utilisateurs/${u.id}`} className="table-link">
                    {u.full_name || <span style={{ color: "var(--muted-foreground)" }}>—</span>}
                  </Link>
                </td>
                <td style={{ fontSize: 13, color: "var(--muted-foreground)" }}>{u.email || "—"}</td>
                <td>
                  <span
                    className="role-pill"
                    style={{ "--pill-color": ROLE_COLORS[u.role] ?? "var(--muted-foreground)" } as React.CSSProperties}
                  >
                    {ROLE_LABELS[u.role] ?? u.role}
                  </span>
                </td>
                <td style={{ fontSize: 13 }}>{u.company_name || "—"}</td>
                <td style={{ fontSize: 13 }}>{u.site_name || "—"}</td>
                <td>
                  {u.is_active ? (
                    <span style={{ color: "var(--green)", fontSize: 13, fontWeight: 500 }}>Actif</span>
                  ) : (
                    <span style={{ color: "var(--red)", fontSize: 13, fontWeight: 500 }}>Désactivé</span>
                  )}
                </td>
                <td style={{ fontSize: 12, color: "var(--muted-foreground)" }}>
                  {u.created_at
                    ? new Date(u.created_at).toLocaleDateString("fr-FR")
                    : "—"}
                </td>
                <td>
                  <ToggleActiveButton
                    userId={u.id}
                    isActive={u.is_active}
                    isSelf={u.id === currentUser.id}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
