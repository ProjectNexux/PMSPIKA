"use client";

/**
 * app/admin/utilisateurs/invite-modal.tsx
 * Formulaire d'invitation d'un nouvel utilisateur.
 */

import { useRef, useState, useTransition } from "react";
import { UserPlus, X } from "lucide-react";
import { inviteUserAction } from "./actions";

type Company = { id: string; name: string };
type Site    = { id: string; name: string; company_id: string | null };

interface Props {
  companies: Company[];
  sites: Site[];
  isSuperAdmin: boolean;
}

const ALL_ROLES = [
  { value: "chauffeur",       label: "Chauffeur" },
  { value: "client",          label: "Client" },
  { value: "chef_site",       label: "Chef de site" },
  { value: "gerant_societe",  label: "Gérant société" },
  { value: "gerant_groupe",   label: "Gérant groupe" },
  { value: "super_admin",     label: "Super admin" },
] as const;

export function InviteModal({ companies, sites, isSuperAdmin }: Props) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<{ ok: boolean; error?: string; warning?: string } | null>(null);
  const [selectedCompany, setSelectedCompany] = useState("");
  const formRef = useRef<HTMLFormElement>(null);

  const filteredSites = selectedCompany
    ? sites.filter((s) => s.company_id === selectedCompany)
    : sites;

  const availableRoles = isSuperAdmin
    ? ALL_ROLES
    : ALL_ROLES.filter((r) => r.value !== "super_admin" && r.value !== "gerant_groupe");

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    startTransition(async () => {
      const res = await inviteUserAction(fd);
      setResult(res);
      if (res.ok) {
        formRef.current?.reset();
        setSelectedCompany("");
        setTimeout(() => setOpen(false), 1800);
      }
    });
  }

  return (
    <>
      <button
        type="button"
        className="btn-primary"
        onClick={() => { setOpen(true); setResult(null); }}
      >
        <UserPlus size={15} />
        Inviter un utilisateur
      </button>

      {open && (
        <div className="modal-overlay" onClick={() => setOpen(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>Inviter un utilisateur</h2>
              <button
                type="button"
                className="modal-close"
                onClick={() => setOpen(false)}
                aria-label="Fermer"
              >
                <X size={18} />
              </button>
            </div>

            <form ref={formRef} onSubmit={handleSubmit} className="modal-body form-grid">
              <div className="form-field">
                <label htmlFor="inv-email">Email *</label>
                <input
                  id="inv-email"
                  name="email"
                  type="email"
                  required
                  placeholder="jean.dupont@exemple.fr"
                  autoComplete="off"
                />
              </div>

              <div className="form-field">
                <label htmlFor="inv-role">Rôle *</label>
                <select id="inv-role" name="role" defaultValue="chauffeur" required>
                  {availableRoles.map((r) => (
                    <option key={r.value} value={r.value}>{r.label}</option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label htmlFor="inv-company">Société</label>
                <select
                  id="inv-company"
                  name="company_id"
                  value={selectedCompany}
                  onChange={(e) => setSelectedCompany(e.target.value)}
                >
                  <option value="">— Aucune —</option>
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label htmlFor="inv-site">Site</label>
                <select id="inv-site" name="site_id">
                  <option value="">— Aucun —</option>
                  {filteredSites.map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div className="form-field">
                <label htmlFor="inv-employee">ID Salarié (optionnel)</label>
                <input
                  id="inv-employee"
                  name="employee_id"
                  type="text"
                  placeholder="EMP-XXXXX"
                />
              </div>

              {result && (
                <div
                  className={result.ok ? "alert alert-success" : "alert alert-error"}
                  style={{ gridColumn: "1 / -1" }}
                >
                  {result.ok
                    ? result.warning ?? "Invitation envoyée avec succès."
                    : result.error}
                </div>
              )}

              <div className="modal-footer" style={{ gridColumn: "1 / -1" }}>
                <button
                  type="button"
                  className="btn-ghost"
                  onClick={() => setOpen(false)}
                >
                  Annuler
                </button>
                <button type="submit" className="btn-primary" disabled={isPending}>
                  {isPending ? "Envoi…" : "Envoyer l'invitation"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </>
  );
}
