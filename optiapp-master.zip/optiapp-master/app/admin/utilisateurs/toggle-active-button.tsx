"use client";

/**
 * app/admin/utilisateurs/toggle-active-button.tsx
 * Bouton pour activer/désactiver un utilisateur.
 */

import { useTransition } from "react";
import { Shield, ShieldOff } from "lucide-react";
import { toggleActiveAction } from "./actions";

interface Props {
  userId: string;
  isActive: boolean;
  isSelf: boolean;
}

export function ToggleActiveButton({ userId, isActive, isSelf }: Props) {
  const [isPending, startTransition] = useTransition();

  if (isSelf) return null;

  return (
    <button
      type="button"
      className={isActive ? "btn-ghost btn-icon-sm text-destructive" : "btn-ghost btn-icon-sm text-success"}
      title={isActive ? "Désactiver" : "Réactiver"}
      disabled={isPending}
      onClick={() =>
        startTransition(async () => {
          await toggleActiveAction(userId, !isActive);
        })
      }
      aria-label={isActive ? "Désactiver l'utilisateur" : "Réactiver l'utilisateur"}
    >
      {isActive ? <ShieldOff size={15} /> : <Shield size={15} />}
    </button>
  );
}
