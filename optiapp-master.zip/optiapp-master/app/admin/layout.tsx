/**
 * app/admin/layout.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Layout de l'espace administration.
 * Accessible : super_admin, gerant_groupe seulement.
 */

import { requireRole } from "@/lib/session";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // Redirige vers la home si le rôle n'est pas admin
  await requireRole(["super_admin", "gerant_groupe"]);
  return <>{children}</>;
}
