import { NextResponse } from "next/server";
import { computePayroll, formatPeriod, type PayrollInputs } from "@/lib/payroll";
import { getPayrollOverview } from "@/lib/queries";

export const dynamic = "force-dynamic";

function csvCell(v: unknown): string {
  if (v == null) return "";
  const s = String(v).replace(/"/g, '""');
  return /[";\n\r]/.test(s) ? `"${s}"` : s;
}

function toFr(n: number): string {
  return (Math.round(n * 100) / 100).toString().replace(".", ",");
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const period = url.searchParams.get("period") ?? new Date().toISOString().slice(0, 7);
  const company = url.searchParams.get("company") ?? undefined;
  const rows = await getPayrollOverview(period, company);

  const headers = [
    "Periode",
    "Societe",
    "Site",
    "Matricule",
    "Nom",
    "Prenom",
    "Poste",
    "Contrat",
    "Mode paie",
    "Salaire base brut",
    "Taux horaire",
    "Heures contractuelles",
    "Heures supp",
    "Majoration HS (€)",
    "Primes",
    "Indemnite repas",
    "Frais km",
    "Retenues",
    "Heures absence non rem.",
    "Deduction absence",
    "Brut soumis",
    "Charges salariales est.",
    "Net a payer est.",
    "Charges patronales est.",
    "Cout employeur total",
    "Etat",
    "Notes",
  ];

  const lines: string[] = [headers.join(";")];

  for (const row of rows) {
    const inputs: PayrollInputs = {
      pay_mode: row.pay_mode ?? "mensualise",
      monthly_gross_salary: row.monthly_gross_salary,
      hourly_rate: row.hourly_rate,
      contract_hours: row.contract_hours,
      meal_allowance_daily: row.meal_allowance_daily ?? 0,
      overtime_hours: row.overtime_hours ?? 0,
      bonus_amount: row.bonus_amount ?? 0,
      deductions: row.deductions ?? 0,
      worked_days: row.worked_days ?? 0,
      meal_allowance_amount: row.meal_allowance_amount,
      km_allowance: row.km_allowance ?? 0,
      unpaid_absence_hours: row.unpaid_absence_hours ?? 0,
    };
    const c = computePayroll(inputs);
    lines.push(
      [
        period,
        row.company_name,
        row.site_name,
        row.employee_id,
        row.last_name,
        row.first_name,
        row.role,
        row.contract_type,
        row.pay_mode,
        toFr(c.baseSalary),
        toFr(c.baseHourlyRate),
        toFr(c.contractHours),
        toFr(row.overtime_hours ?? 0),
        toFr(c.overtimePay),
        toFr(c.bonus),
        toFr(c.mealAllowance),
        toFr(c.kmAllowance),
        toFr(c.otherDeductions),
        toFr(row.unpaid_absence_hours ?? 0),
        toFr(c.absenceDeduction),
        toFr(c.grossTaxable),
        toFr(c.employeeCharges),
        toFr(c.netPayable),
        toFr(c.employerCharges),
        toFr(c.totalEmployerCost),
        row.variable_status,
        row.notes ?? "",
      ]
        .map(csvCell)
        .join(";")
    );
  }

  // BOM UTF-8 pour Excel + delimiter ";"
  const body = "\uFEFF" + lines.join("\r\n");
  const filename = `pre-paie_${period}${company ? `_${company}` : ""}.csv`;

  return new NextResponse(body, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${filename}"`,
      "X-Period-Label": formatPeriod(period),
    },
  });
}
