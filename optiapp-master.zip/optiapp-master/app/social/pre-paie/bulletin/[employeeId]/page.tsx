import Link from "next/link";
import { notFound } from "next/navigation";
import { Printer } from "lucide-react";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import {
  PAYROLL_DEFAULTS,
  computePayroll,
  currentPeriod,
  formatPeriod,
  type PayrollInputs,
} from "@/lib/payroll";
import { getPayrollOverview } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function BulletinPage({
  params,
  searchParams,
}: {
  params: Promise<{ employeeId: string }>;
  searchParams: Promise<{ period?: string; back?: string }>;
}) {
  const { employeeId } = await params;
  const { period: periodRaw, back } = await searchParams;
  const period = periodRaw ?? currentPeriod();
  const backHref = back && back.startsWith("/") ? back : "/social";

  const rows = await getPayrollOverview(period);
  const row = rows.find((r) => r.employee_id === employeeId);
  if (!row) notFound();

  const inputs: PayrollInputs = {
    pay_mode: row.pay_mode ?? "mensualise",
    monthly_gross_salary: row.monthly_gross_salary,
    hourly_rate: row.hourly_rate,
    contract_hours: row.contract_hours,
    meal_allowance_daily: row.meal_allowance_daily ?? 0,
    overtime_hours: row.overtime_hours ?? 0,
    bonus_amount: row.bonus_amount ?? 0,
    deductions: row.deductions ?? 0,
    worked_days: row.worked_days ?? 0,
    meal_allowance_amount: row.meal_allowance_amount,
    km_allowance: row.km_allowance ?? 0,
    unpaid_absence_hours: row.unpaid_absence_hours ?? 0,
  };
  const c = computePayroll(inputs);

  return (
    <main className="bulletin-page">
      <div className="bulletin-toolbar no-print">
        <Link href={backHref} className="button secondary">← Retour</Link>
        <a
          className="button"
          href={`javascript:window.print()`}
          title="Imprimer ou sauvegarder en PDF"
        >
          <Printer size={16} /> Imprimer / PDF
        </a>
      </div>

      <article className="bulletin-doc">
        <header className="bulletin-header">
          <div>
            <h1>Bulletin de pré-paie</h1>
            <p className="muted">Document indicatif — ne remplace pas le bulletin officiel du cabinet de paie</p>
          </div>
          <div className="bulletin-employer">
            <strong>{row.company_name}</strong>
            <div className="muted">Site : {row.site_name}</div>
            <div className="muted">Période : {formatPeriod(period)}</div>
          </div>
        </header>

        <section className="bulletin-block">
          <h2>Salarié</h2>
          <div className="bulletin-id">
            <div><span>Nom prénom</span><strong>{row.last_name} {row.first_name}</strong></div>
            <div><span>Poste</span><strong>{row.role}</strong></div>
            <div><span>Contrat</span><strong>{row.contract_type}</strong></div>
            <div><span>Entrée</span><strong>{formatDate(row.hire_date)}</strong></div>
            <div><span>Matricule</span><strong>{row.employee_id}</strong></div>
            <div><span>Mode paie</span><strong>{row.pay_mode === "horaire" ? "Horaire" : "Mensualisé"}</strong></div>
          </div>
        </section>

        <section className="bulletin-block">
          <h2>Détail de paie — {formatPeriod(period)}</h2>
          <table className="bulletin-table">
            <thead>
              <tr><th>Libellé</th><th className="num">Base</th><th className="num">Taux / %</th><th className="num">Montant</th></tr>
            </thead>
            <tbody>
              <tr>
                <td>Salaire de base</td>
                <td className="num">{formatNumber(c.contractHours)} h</td>
                <td className="num">{formatCurrency(c.baseHourlyRate)}</td>
                <td className="num">{formatCurrency(c.baseSalary)}</td>
              </tr>
              {c.absenceDeduction > 0 ? (
                <tr>
                  <td>Absence non rémunérée</td>
                  <td className="num">{formatNumber(row.unpaid_absence_hours)} h</td>
                  <td className="num">{formatCurrency(c.baseHourlyRate)}</td>
                  <td className="num minus">- {formatCurrency(c.absenceDeduction)}</td>
                </tr>
              ) : null}
              {c.overtimeHours25 > 0 ? (
                <tr>
                  <td>Heures supp. +25 %</td>
                  <td className="num">{formatNumber(c.overtimeHours25)} h</td>
                  <td className="num">{formatCurrency(c.baseHourlyRate * PAYROLL_DEFAULTS.ot25Rate)}</td>
                  <td className="num">{formatCurrency(c.overtimeHours25 * c.baseHourlyRate * PAYROLL_DEFAULTS.ot25Rate)}</td>
                </tr>
              ) : null}
              {c.overtimeHours50 > 0 ? (
                <tr>
                  <td>Heures supp. +50 %</td>
                  <td className="num">{formatNumber(c.overtimeHours50)} h</td>
                  <td className="num">{formatCurrency(c.baseHourlyRate * PAYROLL_DEFAULTS.ot50Rate)}</td>
                  <td className="num">{formatCurrency(c.overtimeHours50 * c.baseHourlyRate * PAYROLL_DEFAULTS.ot50Rate)}</td>
                </tr>
              ) : null}
              {c.bonus > 0 ? (
                <tr>
                  <td>Prime</td><td className="num">—</td><td className="num">—</td>
                  <td className="num">{formatCurrency(c.bonus)}</td>
                </tr>
              ) : null}
              <tr className="total">
                <td><strong>Brut soumis à cotisations</strong></td>
                <td className="num">—</td><td className="num">—</td>
                <td className="num"><strong>{formatCurrency(c.grossTaxable)}</strong></td>
              </tr>
              <tr>
                <td>Cotisations salariales (estimation)</td>
                <td className="num">{formatCurrency(c.grossTaxable)}</td>
                <td className="num">{Math.round(PAYROLL_DEFAULTS.employeeChargesRate * 100)} %</td>
                <td className="num minus">- {formatCurrency(c.employeeCharges)}</td>
              </tr>
              <tr>
                <td>Net avant indemnités / retenues</td>
                <td className="num">—</td><td className="num">—</td>
                <td className="num">{formatCurrency(c.netBeforeIndemnities)}</td>
              </tr>
              {c.mealAllowance > 0 ? (
                <tr>
                  <td>Indemnité repas / panier</td>
                  <td className="num">{formatNumber(row.worked_days)} j</td>
                  <td className="num">{formatCurrency(row.meal_allowance_daily ?? 0)}</td>
                  <td className="num">+ {formatCurrency(c.mealAllowance)}</td>
                </tr>
              ) : null}
              {c.kmAllowance > 0 ? (
                <tr>
                  <td>Frais kilométriques</td>
                  <td className="num">—</td><td className="num">—</td>
                  <td className="num">+ {formatCurrency(c.kmAllowance)}</td>
                </tr>
              ) : null}
              {c.otherDeductions > 0 ? (
                <tr>
                  <td>Retenue (acompte / autre)</td>
                  <td className="num">—</td><td className="num">—</td>
                  <td className="num minus">- {formatCurrency(c.otherDeductions)}</td>
                </tr>
              ) : null}
              <tr className="total grand">
                <td><strong>NET À VERSER (estimation)</strong></td>
                <td className="num">—</td><td className="num">—</td>
                <td className="num"><strong>{formatCurrency(c.netPayable)}</strong></td>
              </tr>
            </tbody>
          </table>
        </section>

        <section className="bulletin-block bulletin-employer-cost">
          <h2>Coût employeur</h2>
          <div className="bulletin-id">
            <div><span>Brut soumis</span><strong>{formatCurrency(c.grossTaxable)}</strong></div>
            <div><span>Charges patronales (~{Math.round(PAYROLL_DEFAULTS.employerChargesRate * 100)} %)</span><strong>{formatCurrency(c.employerCharges)}</strong></div>
            <div><span>Indemnités</span><strong>{formatCurrency(c.mealAllowance + c.kmAllowance)}</strong></div>
            <div><span>Coût total mois</span><strong>{formatCurrency(c.totalEmployerCost)}</strong></div>
          </div>
        </section>

        {row.notes ? (
          <section className="bulletin-block">
            <h2>Notes</h2>
            <p>{row.notes}</p>
          </section>
        ) : null}

        <footer className="bulletin-footer muted">
          Édité le {new Date().toLocaleDateString("fr-FR")} — document interne, estimation indicative.
        </footer>
      </article>
    </main>
  );
}
