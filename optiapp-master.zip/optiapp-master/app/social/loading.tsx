import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Social" title="Pré-paie & employés" stats={4} rows={12} cols={8} />;
}
