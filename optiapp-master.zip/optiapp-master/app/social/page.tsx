import Link from "next/link";
import { AlertTriangle, FileText, FolderOpen, Pencil, Plus, Trash2, Upload, X } from "lucide-react";
import {
  createEmployee,
  deleteEmployee,
  deleteEmployeeDocument,
  updateEmployee,
  uploadEmployeeDocument,
} from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { PrePaieSection } from "@/components/prepaie-section";
import { SocialToolbar, type SocialView } from "@/components/social/social-toolbar";
import { SalaryCostField } from "@/components/social/salary-cost-field";
import { StatusPill } from "@/components/status-pill";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import { currentPeriod } from "@/lib/payroll";
import {
  EMPLOYEE_DOC_CATEGORIES,
  getAbsencesByCompany,
  getDriverOptions,
  getEmployeeDocuments,
  getEmployeeDossierSummaryByCompany,
  getEmployeesByCompany,
  getPayrollOverview,
  getPayrollVariablesByCompany,
  getSiteOptionsByCompany,
  type EmployeeDocumentRow,
  type EmployeeDossierSummary,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const ROLES = ["Chauffeur livreur", "Chef d'equipe", "Exploitant transport", "Assistant administratif", "Responsable site"];
const CONTRACTS = ["CDI", "CDD", "Interim", "Sous-traitance"];
const STATUTS = ["Actif", "Conge", "Arret maladie", "Fin de contrat"];

const VALID_VIEWS: SocialView[] = ["effectif", "prepaie", "absences", "historique"];

export default async function CompanySocialPage({
  searchParams,
}: {
  searchParams: Promise<{
    edit?: string;
    period?: string;
    paie?: string;
    socle?: string;
    view?: string;
    new?: string;
    tab?: string;
  }>;
}) {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const sp = await searchParams;
  const { edit, period: periodParam, paie, socle } = sp;
  const newEmployee = sp.new === "1";
  const drawerTab: "infos" | "dossier" = sp.tab === "dossier" ? "dossier" : "infos";
  const view: SocialView = VALID_VIEWS.includes(sp.view as SocialView)
    ? (sp.view as SocialView)
    : "effectif";
  const period = periodParam ?? currentPeriod();

  const [employees, absences, payroll, sites, prepaie, drivers, dossierSummary] = await Promise.all([
    getEmployeesByCompany(id),
    getAbsencesByCompany(id),
    getPayrollVariablesByCompany(id),
    getSiteOptionsByCompany(id),
    getPayrollOverview(period, id),
    getDriverOptions(),
    getEmployeeDossierSummaryByCompany(id),
  ]);

  const editingEmployee = edit ? employees.find((e) => e.id === edit) : undefined;
  const redir = "/social";
  const drawerOpen = newEmployee || !!editingEmployee;

  // Charge les documents seulement si on édite un salarié (sinon inutile)
  const employeeDocuments: EmployeeDocumentRow[] = editingEmployee
    ? await getEmployeeDocuments(editingEmployee.id)
    : [];

  // Préserver view/period dans les liens de retour des actions
  const backHref = `${redir}?view=${view}&period=${period}`;

  const prepaieReady = prepaie.filter((r) => r.variable_status === "Pret paie").length;
  const prepaieLocked = prepaie.length > 0 && prepaieReady === prepaie.length;

  return (
    <main className="page social-page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="RH & Social" />

      <SocialToolbar
        basePath={redir}
        companyId={id}
        view={view}
        period={period}
        counts={{
          effectif: employees.length,
          absences: absences.length,
          prepaie: prepaie.length,
          historique: payroll.length,
        }}
        prepaie={{ ready: prepaieReady, total: prepaie.length, locked: prepaieLocked }}
        exportPath="/social/pre-paie/export"
      />

      {view === "effectif" ? (
        <EffectifView
          companyName="PIKA TRANSPORT"
          employees={employees}
          redir={backHref}
          editId={edit}
          dossierSummary={dossierSummary}
        />
      ) : null}

      {view === "prepaie" ? (
        <PrePaieSection
          rows={prepaie}
          period={period}
          basePath={redir}
          exportPath="/social/pre-paie/export"
          bulletinPath="/social/pre-paie/bulletin"
          companyId={id}
          editEmployeeId={paie}
          editBaseId={socle}
          drivers={drivers}
          hideToolbar
          hideTitle
          extraQueryParams={{ view: "prepaie" }}
        />
      ) : null}

      {view === "absences" ? (
        <AbsencesView companyName="PIKA TRANSPORT" absences={absences} />
      ) : null}

      {view === "historique" ? (
        <HistoriqueView companyName="PIKA TRANSPORT" payroll={payroll} />
      ) : null}

      {drawerOpen ? (
        <EmployeeDrawer
          companyName="PIKA TRANSPORT"
          sites={sites}
          backHref={backHref}
          editing={editingEmployee}
          activeTab={drawerTab}
          documents={employeeDocuments}
        />
      ) : null}
    </main>
  );
}

/* ─── Vues ──────────────────────────────────────────────────────────── */

function EffectifView({
  companyName,
  employees,
  redir,
  editId,
  dossierSummary,
}: {
  companyName: string;
  employees: Awaited<ReturnType<typeof getEmployeesByCompany>>;
  redir: string;
  editId?: string;
  dossierSummary: Record<string, EmployeeDossierSummary>;
}) {
  const sep = redir.includes("?") ? "&" : "?";
  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>Salariés</h2>
          <p>Effectif {companyName}</p>
        </div>
      </div>
      {employees.length > 0 ? (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Nom</th><th>Poste</th><th>Contrat</th><th>Site</th>
                <th>Entrée</th><th>Statut</th><th>Dossier</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {employees.map((emp) => {
                const editHref = `${redir}${sep}edit=${emp.id}`;
                const dossierHref = `${redir}${sep}edit=${emp.id}&tab=dossier`;
                const summary = dossierSummary[emp.id];
                return (
                  <tr key={emp.id} className={editId === emp.id ? "row-editing" : undefined}>
                    <td className="strong-cell">{emp.first_name} {emp.last_name}</td>
                    <td>{emp.role}</td>
                    <td>{emp.contract_type}</td>
                    <td>{emp.site_name}</td>
                    <td>{formatDate(emp.hire_date)}</td>
                    <td><StatusPill value={emp.status} /></td>
                    <td><DossierBadge href={dossierHref} summary={summary} /></td>
                    <td>
                      <div className="row-actions">
                        <Link href={editHref} className="btn-icon" title="Modifier">
                          <Pencil size={14} />
                        </Link>
                        <form action={deleteEmployee}>
                          <input type="hidden" name="id"          value={emp.id} />
                          <input type="hidden" name="redirect_to" value={redir} />
                          <button type="submit" className="btn-icon btn-icon-danger" title="Supprimer">
                            <Trash2 size={14} />
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="muted" style={{ fontSize: 14 }}>Aucun salarié pour cette société.</p>
      )}
    </section>
  );
}

function DossierBadge({
  href,
  summary,
}: {
  href: string;
  summary?: EmployeeDossierSummary;
}) {
  const total = summary?.total ?? 0;
  const expired = summary?.expired ?? 0;
  const soon = summary?.expiring_soon ?? 0;
  let tone: "empty" | "ok" | "warn" | "danger" = "empty";
  let label = "—";
  if (total === 0) {
    tone = "empty";
    label = "Vide";
  } else if (expired > 0) {
    tone = "danger";
    label = `${total} · ${expired} expiré${expired > 1 ? "s" : ""}`;
  } else if (soon > 0) {
    tone = "warn";
    label = `${total} · ${soon} bientôt`;
  } else {
    tone = "ok";
    label = `${total} OK`;
  }
  return (
    <Link href={href} className={`dossier-badge ${tone}`} title="Ouvrir le dossier">
      {tone === "danger" || tone === "warn" ? (
        <AlertTriangle size={12} aria-hidden />
      ) : (
        <FolderOpen size={12} aria-hidden />
      )}
      <span>{label}</span>
    </Link>
  );
}

function AbsencesView({
  companyName,
  absences,
}: {
  companyName: string;
  absences: Awaited<ReturnType<typeof getAbsencesByCompany>>;
}) {
  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>Absences</h2>
          <p>Congés et arrêts — {companyName}</p>
        </div>
      </div>
      {absences.length > 0 ? (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Salarié</th><th>Site</th><th>Période</th><th>État</th>
              </tr>
            </thead>
            <tbody>
              {absences.map((absence) => (
                <tr key={absence.id}>
                  <td className="strong-cell">{absence.employee_name}</td>
                  <td>{absence.site_name}</td>
                  <td>{formatDate(absence.start_date)} → {formatDate(absence.end_date)}</td>
                  <td><StatusPill value={absence.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="muted" style={{ fontSize: 14 }}>Aucune absence enregistrée.</p>
      )}
    </section>
  );
}

function HistoriqueView({
  companyName,
  payroll,
}: {
  companyName: string;
  payroll: Awaited<ReturnType<typeof getPayrollVariablesByCompany>>;
}) {
  return (
    <section className="panel">
      <div className="panel-header">
        <div>
          <h2>Variables sociales — historique</h2>
          <p>Vue brute multi-périodes — {companyName}</p>
        </div>
      </div>
      {payroll.length > 0 ? (
        <div className="table-wrap">
          <table className="data-table">
            <thead>
              <tr>
                <th>Salarié</th><th>Site</th><th>Période</th>
                <th>Heures supp.</th><th>Prime</th><th>Retenue</th><th>État</th>
              </tr>
            </thead>
            <tbody>
              {payroll.map((line) => (
                <tr key={line.id}>
                  <td className="strong-cell">{line.employee_name}</td>
                  <td>{line.site_name}</td>
                  <td>{line.period}</td>
                  <td>{formatNumber(line.overtime_hours)}</td>
                  <td>{formatCurrency(line.bonus_amount)}</td>
                  <td>{formatCurrency(line.deductions)}</td>
                  <td><StatusPill value={line.status} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="muted" style={{ fontSize: 14 }}>Aucune variable à transmettre.</p>
      )}
    </section>
  );
}

/* ─── Drawer "Ajouter / Modifier un salarié" ───────────────────────── */

function EmployeeDrawer({
  companyName,
  sites,
  backHref,
  editing,
  activeTab,
  documents,
}: {
  companyName: string;
  sites: Awaited<ReturnType<typeof getSiteOptionsByCompany>>;
  backHref: string;
  editing?: Awaited<ReturnType<typeof getEmployeesByCompany>>[number];
  activeTab: "infos" | "dossier";
  documents: EmployeeDocumentRow[];
}) {
  const title = editing
    ? `${editing.first_name} ${editing.last_name}`
    : "Ajouter un salarié";
  const subtitle = editing
    ? editing.role
    : `Rattaché à ${companyName}`;

  // L'onglet Dossier n'a de sens que pour un salarié existant
  const showTabs = !!editing;
  const tab: "infos" | "dossier" = showTabs ? activeTab : "infos";

  const sep = backHref.includes("?") ? "&" : "?";
  const infosHref = editing ? `${backHref}${sep}edit=${editing.id}` : backHref;
  const dossierHref = editing ? `${backHref}${sep}edit=${editing.id}&tab=dossier` : backHref;
  const dossierRedir = dossierHref;

  return (
    <>
      <Link href={backHref} className="drawer-backdrop" aria-label="Fermer le panneau" />
      <aside className="drawer drawer-wide" role="dialog" aria-modal="true" aria-label={title}>
        <header className="drawer-header">
          <div>
            <h2>{title}</h2>
            <p className="muted">{subtitle}</p>
          </div>
          <Link href={backHref} className="btn-icon" aria-label="Fermer">
            <X size={16} />
          </Link>
        </header>

        {showTabs ? (
          <nav className="drawer-tabs" aria-label="Sections du salarié">
            <Link
              href={infosHref}
              className={tab === "infos" ? "drawer-tab active" : "drawer-tab"}
              aria-current={tab === "infos" ? "page" : undefined}
            >
              <Pencil size={13} /> Infos
            </Link>
            <Link
              href={dossierHref}
              className={tab === "dossier" ? "drawer-tab active" : "drawer-tab"}
              aria-current={tab === "dossier" ? "page" : undefined}
            >
              <FolderOpen size={13} /> Dossier
              <span className="drawer-tab-count">{documents.length}</span>
            </Link>
          </nav>
        ) : null}

        <div className="drawer-body">
          {tab === "infos" ? (
            editing ? (
              <EditEmployeeForm editing={editing} sites={sites} backHref={infosHref} />
            ) : (
              <CreateEmployeeForm sites={sites} backHref={backHref} />
            )
          ) : null}

          {tab === "dossier" && editing ? (
            <DossierPanel
              employeeId={editing.id}
              documents={documents}
              backHref={dossierRedir}
            />
          ) : null}
        </div>
      </aside>
    </>
  );
}

function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <>
      <div
        className="full"
        style={{
          marginTop: 4,
          paddingTop: 8,
          borderTop: "1px solid var(--border)",
          fontSize: 11,
          letterSpacing: 0.6,
          textTransform: "uppercase",
          fontWeight: 800,
          color: "var(--muted)",
        }}
      >
        {title}
      </div>
      {children}
    </>
  );
}

function EditEmployeeForm({
  editing,
  sites,
  backHref,
}: {
  editing: NonNullable<Awaited<ReturnType<typeof getEmployeesByCompany>>[number]>;
  sites: Awaited<ReturnType<typeof getSiteOptionsByCompany>>;
  backHref: string;
}) {
  return (
    <form action={updateEmployee} className="form-grid">
      <input type="hidden" name="id"          value={editing.id} />
      <input type="hidden" name="redirect_to" value={backHref} />

      <FormSection title="Identité">
        <div className="field">
          <label>Prénom</label>
          <input name="first_name" defaultValue={editing.first_name} required />
        </div>
        <div className="field">
          <label>Nom</label>
          <input name="last_name" defaultValue={editing.last_name} required />
        </div>
        <div className="field">
          <label>Date de naissance</label>
          <input name="birth_date" type="date" defaultValue={editing.birth_date ?? ""} />
        </div>
        <div className="field">
          <label>Lieu de naissance</label>
          <input name="birth_place" defaultValue={editing.birth_place ?? ""} placeholder="Ville, pays" />
        </div>
        <div className="field">
          <label>Nationalité</label>
          <input name="nationality" defaultValue={editing.nationality ?? ""} placeholder="Ex. Française" />
        </div>
        <div className="field">
          <label>Titre de séjour — expiration</label>
          <input
            name="residence_permit_expiry"
            type="date"
            defaultValue={editing.residence_permit_expiry ?? ""}
          />
        </div>
        <div className="field full">
          <label>Numéro de sécurité sociale</label>
          <input
            name="social_security_number"
            defaultValue={editing.social_security_number ?? ""}
            placeholder="1 99 12 75 123 456 78"
            inputMode="numeric"
            pattern="[0-9 ]{13,21}"
          />
        </div>
      </FormSection>

      <FormSection title="Coordonnées">
        <div className="field full">
          <label>Adresse postale</label>
          <input name="address" defaultValue={editing.address ?? ""} placeholder="N°, rue, code postal, ville" />
        </div>
        <div className="field">
          <label>Email</label>
          <input name="email" type="email" defaultValue={editing.email ?? ""} />
        </div>
        <div className="field">
          <label>Téléphone</label>
          <input name="phone" defaultValue={editing.phone ?? ""} />
        </div>
      </FormSection>

      <FormSection title="Contrat">
        <div className="field">
          <label>Poste</label>
          <select name="role" defaultValue={editing.role}>
            {ROLES.map((r) => <option key={r}>{r}</option>)}
          </select>
        </div>
        <div className="field">
          <label>Contrat</label>
          <select name="contract_type" defaultValue={editing.contract_type}>
            {CONTRACTS.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="field">
          <label>Statut</label>
          <select name="status" defaultValue={editing.status}>
            {STATUTS.map((s) => <option key={s}>{s}</option>)}
          </select>
        </div>
        <div className="field">
          <label>Site</label>
          <select name="site_id" defaultValue={editing.site_id ?? ""}>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
        </div>
      </FormSection>

      <FormSection title="Rémunération">
        <SalaryCostField defaultValue={editing.monthly_gross_salary ?? null} />
      </FormSection>

      <div className="full form-actions">
        <button className="button" type="submit">
          <Pencil size={15} aria-hidden="true" />
          Enregistrer
        </button>
        <Link href={backHref} className="button secondary">Annuler</Link>
      </div>
    </form>
  );
}

function CreateEmployeeForm({
  sites,
  backHref,
}: {
  sites: Awaited<ReturnType<typeof getSiteOptionsByCompany>>;
  backHref: string;
}) {
  return (
    <form action={createEmployee} className="form-grid">
      <input type="hidden" name="redirect_to" value={backHref} />

      <FormSection title="Identité">
        <div className="field">
          <label htmlFor="first_name">Prénom</label>
          <input id="first_name" name="first_name" required />
        </div>
        <div className="field">
          <label htmlFor="last_name">Nom</label>
          <input id="last_name" name="last_name" required />
        </div>
        <div className="field">
          <label htmlFor="birth_date">Date de naissance</label>
          <input id="birth_date" name="birth_date" type="date" />
        </div>
        <div className="field">
          <label htmlFor="birth_place">Lieu de naissance</label>
          <input id="birth_place" name="birth_place" placeholder="Ville, pays" />
        </div>
        <div className="field">
          <label htmlFor="nationality">Nationalité</label>
          <input id="nationality" name="nationality" placeholder="Ex. Française" defaultValue="Française" />
        </div>
        <div className="field">
          <label htmlFor="residence_permit_expiry">Titre de séjour — expiration</label>
          <input id="residence_permit_expiry" name="residence_permit_expiry" type="date" />
        </div>
        <div className="field full">
          <label htmlFor="social_security_number">Numéro de sécurité sociale</label>
          <input
            id="social_security_number"
            name="social_security_number"
            placeholder="1 99 12 75 123 456 78"
            inputMode="numeric"
            pattern="[0-9 ]{13,21}"
          />
        </div>
      </FormSection>

      <FormSection title="Coordonnées">
        <div className="field full">
          <label htmlFor="address">Adresse postale</label>
          <input id="address" name="address" placeholder="N°, rue, code postal, ville" />
        </div>
        <div className="field">
          <label htmlFor="email">Email</label>
          <input id="email" name="email" type="email" />
        </div>
        <div className="field">
          <label htmlFor="phone">Téléphone</label>
          <input id="phone" name="phone" />
        </div>
      </FormSection>

      <FormSection title="Contrat">
        <div className="field">
          <label htmlFor="role">Poste</label>
          <select id="role" name="role" defaultValue="Chauffeur livreur">
            {ROLES.map((r) => <option key={r}>{r}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="contract_type">Contrat</label>
          <select id="contract_type" name="contract_type" defaultValue="CDI">
            {CONTRACTS.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="site_id">Site</label>
          <select id="site_id" name="site_id" required>
            {sites.map((s) => (
              <option key={s.id} value={s.id}>{s.label}</option>
            ))}
          </select>
        </div>
        <div className="field">
          <label htmlFor="hire_date">Date d&apos;entrée</label>
          <input id="hire_date" name="hire_date" type="date" required />
        </div>
      </FormSection>

      <FormSection title="Rémunération">
        <SalaryCostField defaultValue={null} />
      </FormSection>

      <div className="full form-actions">
        <button className="button" type="submit">
          <Plus size={16} aria-hidden="true" />
          Ajouter
        </button>
        <Link href={backHref} className="button secondary">Annuler</Link>
      </div>
    </form>
  );
}

function DossierPanel({
  employeeId,
  documents,
  backHref,
}: {
  employeeId: string;
  documents: EmployeeDocumentRow[];
  backHref: string;
}) {
  const today = new Date();
  const horizon = new Date();
  horizon.setDate(horizon.getDate() + 30);

  return (
    <div className="dossier">
      {/* Liste des documents existants */}
      {documents.length > 0 ? (
        <ul className="dossier-list">
          {documents.map((d) => {
            const expired = d.expires_on ? new Date(d.expires_on) < today : false;
            const soon = !expired && d.expires_on ? new Date(d.expires_on) <= horizon : false;
            const tone = expired ? "danger" : soon ? "warn" : "ok";
            return (
              <li key={d.id} className={`dossier-item ${tone}`}>
                <div className="dossier-item-main">
                  <div className="dossier-item-head">
                    <strong>{d.category}</strong>
                    {d.title ? <span className="muted"> — {d.title}</span> : null}
                  </div>
                  <div className="dossier-item-meta">
                    {d.issued_on ? <span>Émis : {formatDate(d.issued_on)}</span> : null}
                    {d.expires_on ? (
                      <span className={tone === "danger" ? "txt-danger" : tone === "warn" ? "txt-warn" : ""}>
                        Expire : {formatDate(d.expires_on)}
                        {expired ? " (expiré)" : soon ? " (bientôt)" : ""}
                      </span>
                    ) : null}
                    {d.file_size ? <span>{formatFileSize(d.file_size)}</span> : null}
                  </div>
                  {d.notes ? <p className="muted dossier-item-notes">{d.notes}</p> : null}
                </div>
                <div className="dossier-item-actions">
                  {d.file_url ? (
                    <a className="btn-icon" href={d.file_url} target="_blank" rel="noopener noreferrer" title="Ouvrir le fichier">
                      <FileText size={14} />
                    </a>
                  ) : null}
                  <form action={deleteEmployeeDocument}>
                    <input type="hidden" name="id" value={d.id} />
                    <input type="hidden" name="redirect_to" value={backHref} />
                    <button type="submit" className="btn-icon btn-icon-danger" title="Supprimer le document">
                      <Trash2 size={14} />
                    </button>
                  </form>
                </div>
              </li>
            );
          })}
        </ul>
      ) : (
        <p className="muted" style={{ fontSize: 13 }}>Aucun document dans le dossier.</p>
      )}

      {/* Formulaire d'ajout */}
      <form action={uploadEmployeeDocument} className="form-grid dossier-form" encType="multipart/form-data">
        <input type="hidden" name="employee_id" value={employeeId} />
        <input type="hidden" name="redirect_to" value={backHref} />

        <div className="field">
          <label htmlFor="doc-category">Type de document</label>
          <select id="doc-category" name="category" defaultValue="CNI / Passeport">
            {EMPLOYEE_DOC_CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="field">
          <label htmlFor="doc-title">Libellé (optionnel)</label>
          <input id="doc-title" name="title" placeholder="ex : Renouvellement 2026" />
        </div>
        <div className="field">
          <label htmlFor="doc-issued">Date d&apos;émission</label>
          <input id="doc-issued" name="issued_on" type="date" />
        </div>
        <div className="field">
          <label htmlFor="doc-expires">Date d&apos;expiration</label>
          <input id="doc-expires" name="expires_on" type="date" />
        </div>
        <div className="field full">
          <label htmlFor="doc-file">Fichier (PDF, JPG, PNG…)</label>
          <input id="doc-file" name="file" type="file" accept=".pdf,.jpg,.jpeg,.png,.webp,.heic" />
        </div>
        <div className="field full">
          <label htmlFor="doc-notes">Notes (optionnel)</label>
          <textarea id="doc-notes" name="notes" rows={2} />
        </div>
        <div className="full form-actions">
          <button className="button" type="submit">
            <Upload size={15} aria-hidden="true" />
            Ajouter au dossier
          </button>
        </div>
      </form>
    </div>
  );
}

function formatFileSize(bytes: number) {
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} Mo`;
}
