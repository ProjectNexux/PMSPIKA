/**
 * app/missions/[id]/pod/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Vue exploitation d'une preuve de livraison (POD) — imprimable (Ctrl+P → PDF).
 */

import { notFound } from "next/navigation";
import Link from "next/link";
import { requireRole } from "@/lib/session";
import { formatDate } from "@/lib/format";
import {
  getMissionDelivery,
  getPodSignedUrl,
  type DeliveryEvent,
} from "@/lib/pod-queries";

export const dynamic = "force-dynamic";

const POD_STATUS_LABEL: Record<string, string> = {
  livre: "Livré",
  livre_avec_reserve: "Livré avec réserve",
  refuse: "Refusé / échec",
};

const EVENT_LABEL: Record<string, string> = {
  enleve: "Enlevé",
  en_transit: "En transit",
  en_livraison: "En cours de livraison",
  livre: "Livré",
  echec: "Échec",
  reserve: "Réserve",
};

export default async function PodViewPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  await requireRole(["super_admin", "gerant_groupe", "gerant_societe", "chef_site"]);

  const { mission, events, pod, attachments } = await getMissionDelivery(id);
  if (!mission) notFound();

  const signatureUrl = pod ? await getPodSignedUrl(pod.signature_path) : null;
  const photos = attachments.filter((a) => a.kind === "photo");
  const scans = attachments.filter((a) => a.kind === "scan");
  const photoUrls = await Promise.all(photos.map((p) => getPodSignedUrl(p.file_path)));

  const pickup = [mission.pickup_address, mission.pickup_city].filter(Boolean).join(", ") || "—";
  const delivery = [mission.delivery_address, mission.delivery_city].filter(Boolean).join(", ") || "—";

  return (
    <div style={{ maxWidth: 820, margin: "0 auto", padding: 24 }}>
      <div className="no-print" style={{ marginBottom: 16, display: "flex", justifyContent: "space-between" }}>
        <Link href="/missions">← Missions</Link>
        <span style={{ color: "#6b7280", fontSize: 13 }}>Imprimez cette page (Ctrl+P) pour générer le PDF.</span>
      </div>

      <h1 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>
        Preuve de livraison
      </h1>
      <p style={{ color: "#6b7280", marginBottom: 24 }}>
        Mission {mission.reference || mission.id.slice(0, 8)}
      </p>

      <section style={cardStyle}>
        <Row label="Statut" value={pod ? POD_STATUS_LABEL[pod.status] ?? pod.status : "Non livré"} />
        <Row label="Date prévue" value={formatDate(mission.scheduled_date)} />
        {pod && <Row label="Signé le" value={formatDateTime(pod.signed_at)} />}
        {pod?.recipient_name && <Row label="Réceptionnaire" value={pod.recipient_name} />}
        <Row label="Enlèvement" value={pickup} />
        <Row label="Livraison" value={delivery} />
        {mission.cargo_description && <Row label="Marchandise" value={mission.cargo_description} />}
        {pod?.reserve_text && <Row label="Réserves" value={pod.reserve_text} />}
        {pod && (pod.lat != null && pod.lng != null) && (
          <Row label="Position" value={`${pod.lat.toFixed(5)}, ${pod.lng.toFixed(5)}`} />
        )}
      </section>

      {/* Signature */}
      {signatureUrl && (
        <section style={cardStyle}>
          <h2 style={h2Style}>Signature</h2>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={signatureUrl} alt="Signature" style={{ maxWidth: 320, border: "1px solid #e5e7eb", borderRadius: 8 }} />
        </section>
      )}

      {/* Photos */}
      {photoUrls.filter(Boolean).length > 0 && (
        <section style={cardStyle}>
          <h2 style={h2Style}>Photos</h2>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
            {photoUrls.filter(Boolean).map((url, i) => (
              // eslint-disable-next-line @next/next/no-img-element
              <img key={i} src={url as string} alt={`Photo ${i + 1}`} style={{ width: 180, height: 180, objectFit: "cover", borderRadius: 8 }} />
            ))}
          </div>
        </section>
      )}

      {/* Codes scannés */}
      {scans.length > 0 && (
        <section style={cardStyle}>
          <h2 style={h2Style}>Codes-barres</h2>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {scans.map((s) => (
              <li key={s.id}>{s.barcode}</li>
            ))}
          </ul>
        </section>
      )}

      {/* Timeline des événements */}
      {events.length > 0 && (
        <section style={cardStyle}>
          <h2 style={h2Style}>Suivi</h2>
          <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
            {events.map((e: DeliveryEvent) => (
              <li key={e.id} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: "1px solid #f3f4f6" }}>
                <span>{EVENT_LABEL[e.event_type] ?? e.event_type}{e.failure_reason ? ` (${e.failure_reason})` : ""}</span>
                <span style={{ color: "#6b7280" }}>{formatDateTime(e.occurred_at)}</span>
              </li>
            ))}
          </ul>
        </section>
      )}

      {!pod && (
        <p style={{ color: "#b45309" }}>Aucune preuve de livraison n&apos;a encore été enregistrée pour cette mission.</p>
      )}
    </div>
  );
}

const cardStyle: React.CSSProperties = {
  border: "1px solid #e5e7eb",
  borderRadius: 10,
  padding: 16,
  marginBottom: 16,
};

const h2Style: React.CSSProperties = { fontSize: 15, fontWeight: 600, marginBottom: 10 };

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div style={{ display: "flex", justifyContent: "space-between", padding: "5px 0", borderBottom: "1px solid #f3f4f6" }}>
      <span style={{ color: "#6b7280" }}>{label}</span>
      <span style={{ fontWeight: 500, textAlign: "right" }}>{value}</span>
    </div>
  );
}

function formatDateTime(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "—";
  return d.toLocaleString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}
