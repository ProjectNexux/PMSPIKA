import Link from "next/link";
import { FileText, Plus, Trash2 } from "lucide-react";
import { createMission, deleteMission, updateMissionStatus } from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import {
  getClientOptions,
  getDriverOptions,
  getMissionsByCompany,
  getMissionsStatsByCompany,
  getTmsVehicleOptionsByCompany,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const STATUS_LABELS: Record<string, string> = {
  completed:   "Livree",
  in_progress: "En cours",
  assigned:    "Assignee",
  draft:       "Brouillon",
  cancelled:   "Annulee",
};

export default async function MissionsPage() {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const [missions, stats, drivers, vehicles, clients] = await Promise.all([
    getMissionsByCompany(id),
    getMissionsStatsByCompany(id),
    getDriverOptions(),
    getTmsVehicleOptionsByCompany(id),
    getClientOptions(),
  ]);

  const active = missions.filter((m) => ["in_progress", "assigned"].includes(m.status));
  const drafts = missions.filter((m) => m.status === "draft");
  const closed = missions.filter((m) => ["completed", "cancelled"].includes(m.status));
  const redir  = "/missions";

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Ordres de transport" />

      <section className="stat-grid" aria-label="Indicateurs missions">
        <StatCard label="Missions totales"       value={formatNumber(stats?.total ?? 0)}   detail={`${formatNumber(stats?.total_distance ?? 0)} km`} tone="blue" />
        <StatCard label="En cours / Assignees"   value={formatNumber((stats?.in_progress ?? 0) + (stats?.assigned ?? 0))} detail="Missions actives" tone="orange" />
        <StatCard label="Terminees"              value={formatNumber(stats?.completed ?? 0)} detail={`CA: ${formatCurrency(stats?.total_revenue ?? 0)}`} tone="green" />
        <StatCard label="Brouillons"             value={formatNumber(stats?.draft ?? 0)}    detail="A affecter" tone="red" />
      </section>

      {/* ── Create mission form ── */}
      <div className="panel">
        <div className="panel-header">
          <div><h2>Nouvel ordre de transport</h2><p>Rattaché à PIKA TRANSPORT</p></div>
        </div>
        <form action={createMission} className="form-grid">
          <input type="hidden" name="company_id"  value={id} />
          <input type="hidden" name="redirect_to" value={redir} />
          <div className="field">
            <label htmlFor="m_client">Client</label>
            <select id="m_client" name="client_id" required>
              <option value="">— Choisir —</option>
              {clients.map((c) => (
                <option key={c.id} value={c.id}>{c.company_name}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="m_date">Date</label>
            <input id="m_date" name="scheduled_date" type="date" required />
          </div>
          <div className="field">
            <label htmlFor="m_time">Heure depart</label>
            <input id="m_time" name="scheduled_time" type="time" />
          </div>
          <div className="field">
            <label htmlFor="m_priority">Priorite</label>
            <select id="m_priority" name="priority" defaultValue="normal">
              <option value="urgent">Urgent</option>
              <option value="high">Haute</option>
              <option value="normal">Normale</option>
              <option value="low">Basse</option>
            </select>
          </div>
          <div className="field">
            <label htmlFor="m_pickup_city">Ville depart</label>
            <input id="m_pickup_city" name="pickup_city" required placeholder="Paris" />
          </div>
          <div className="field">
            <label htmlFor="m_pickup_addr">Adresse depart</label>
            <input id="m_pickup_addr" name="pickup_address" required placeholder="12 Rue du Commerce" />
          </div>
          <div className="field">
            <label htmlFor="m_delivery_city">Ville arrivee</label>
            <input id="m_delivery_city" name="delivery_city" required placeholder="Lyon" />
          </div>
          <div className="field">
            <label htmlFor="m_delivery_addr">Adresse arrivee</label>
            <input id="m_delivery_addr" name="delivery_address" required placeholder="8 Av. du Marche" />
          </div>
          <div className="field">
            <label htmlFor="m_cargo">Marchandise</label>
            <input id="m_cargo" name="cargo_description" placeholder="Palettes alimentaires, ADR..." />
          </div>
          <div className="field">
            <label htmlFor="m_dist">Distance (km)</label>
            <input id="m_dist" name="distance_km" type="number" min="0" />
          </div>
          <div className="field">
            <label htmlFor="m_price">Prix HT (€)</label>
            <input id="m_price" name="price" type="number" min="0" step="0.01" />
          </div>
          <div className="field">
            <label htmlFor="m_driver">Chauffeur</label>
            <select id="m_driver" name="driver_id">
              <option value="">— Non affecte —</option>
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>{d.full_name}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="m_vehicle">Vehicule</label>
            <select id="m_vehicle" name="vehicle_id">
              <option value="">— Non affecte —</option>
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>{v.plate_number} — {v.brand} {v.model}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <input name="requires_adr" type="checkbox" style={{ width: "auto" }} />
              Marchandises ADR
            </label>
          </div>
          <div className="full">
            <button className="button" type="submit">
              <Plus size={15} aria-hidden="true" />Creer l&apos;ordre
            </button>
          </div>
        </form>
      </div>

      {active.length > 0 && (
        <section className="panel">
          <div className="panel-header">
            <div><h2>Missions actives</h2><p>{active.length} ordre{active.length > 1 ? "s" : ""} en cours</p></div>
          </div>
          <MissionsTable missions={active} redir={redir} drivers={drivers} vehicles={vehicles} />
        </section>
      )}

      {drafts.length > 0 && (
        <section className="panel">
          <div className="panel-header">
            <div><h2>A affecter</h2><p>Brouillons en attente</p></div>
          </div>
          <MissionsTable missions={drafts} redir={redir} drivers={drivers} vehicles={vehicles} />
        </section>
      )}

      {closed.length > 0 && (
        <section className="panel">
          <div className="panel-header">
            <div><h2>Historique</h2><p>Missions terminees et annulees</p></div>
          </div>
          <MissionsTable missions={closed} redir={redir} drivers={drivers} vehicles={vehicles} />
        </section>
      )}

      {missions.length === 0 && (
        <div className="panel">
          <p className="muted" style={{ fontSize: 14 }}>Aucune mission enregistree pour cette societe.</p>
        </div>
      )}
    </main>
  );
}

type MissionRow = Awaited<ReturnType<typeof getMissionsByCompany>>[number];
type DriverOpt  = Awaited<ReturnType<typeof getDriverOptions>>[number];
type VehicleOpt = Awaited<ReturnType<typeof getTmsVehicleOptionsByCompany>>[number];

function MissionsTable({
  missions,
  redir,
  drivers,
  vehicles,
}: {
  missions: MissionRow[];
  redir: string;
  drivers: DriverOpt[];
  vehicles: VehicleOpt[];
}) {
  return (
    <div className="table-wrap">
      <table className="data-table">
        <thead>
          <tr>
            <th>Ref</th><th>Date</th><th>Depart</th><th>Arrivee</th>
            <th>Marchandise</th><th>Chauffeur</th><th>Vehicule</th>
            <th>Client</th><th>Distance</th><th>Prix</th><th>Statut</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {missions.map((m) => (
            <tr key={m.id}>
              <td className="strong-cell tms-ref">{m.reference}</td>
              <td>{formatDate(m.scheduled_date)}</td>
              <td>{m.pickup_city}</td>
              <td>{m.delivery_city}</td>
              <td className="muted mission-cargo">
                {m.requires_adr && <span className="adr-badge">ADR</span>}
                {m.cargo_description ?? "—"}
              </td>

              {/* Assign driver */}
              <td>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {m.driver_name && (
                    <Link
                      href="/social?view=effectif"
                      style={{ fontSize: 11, color: "var(--primary)", fontWeight: 600, textDecoration: "none" }}
                      title="Voir dans Social"
                    >
                      {m.driver_name}
                    </Link>
                  )}
                  <form action={updateMissionStatus} className="inline-form">
                    <input type="hidden" name="id"          value={m.id} />
                    <input type="hidden" name="redirect_to" value={redir} />
                    <input type="hidden" name="status"      value={m.status} />
                    <select name="driver_id" className="inline-select">
                      <option value="">— Non —</option>
                      {drivers.map((d) => (
                        <option key={d.id} value={d.id}>{d.full_name}</option>
                      ))}
                    </select>
                    <button type="submit" className="compact-button">OK</button>
                  </form>
                </div>
              </td>

              {/* Assign vehicle */}
              <td>
                <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                  {m.vehicle_plate && (
                    <Link
                      href="/vehicules"
                      style={{ fontSize: 11, color: "var(--primary)", fontWeight: 600, textDecoration: "none", fontFamily: "ui-monospace, monospace" }}
                      title="Voir dans Véhicules"
                    >
                      {m.vehicle_plate}
                    </Link>
                  )}
                  <form action={updateMissionStatus} className="inline-form">
                    <input type="hidden" name="id"          value={m.id} />
                    <input type="hidden" name="redirect_to" value={redir} />
                    <input type="hidden" name="status"      value={m.status} />
                    <select name="vehicle_id" className="inline-select">
                      <option value="">— Non —</option>
                      {vehicles.map((v) => (
                        <option key={v.id} value={v.id}>{v.plate_number}</option>
                      ))}
                    </select>
                    <button type="submit" className="compact-button">OK</button>
                  </form>
                </div>
              </td>

              <td className="muted">{m.client_name ?? "—"}</td>
              <td className="muted">{m.distance_km != null ? `${formatNumber(m.distance_km)} km` : "—"}</td>
              <td className="strong-cell">{m.price != null ? formatCurrency(m.price) : "—"}</td>

              {/* Status */}
              <td>
                <form action={updateMissionStatus} className="inline-form">
                  <input type="hidden" name="id"          value={m.id} />
                  <input type="hidden" name="redirect_to" value={redir} />
                  <select name="status" defaultValue={m.status} className="inline-select">
                    <option value="draft">Brouillon</option>
                    <option value="assigned">Assignee</option>
                    <option value="in_progress">En cours</option>
                    <option value="completed">Livree</option>
                    <option value="cancelled">Annulee</option>
                  </select>
                  <button type="submit" className="compact-button">OK</button>
                </form>
              </td>

              <td>
                <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
                  {m.status === "completed" && m.billing_status !== "billed" && (
                    <Link
                      href={`/facturation/nouvelle?${new URLSearchParams({
                        ref: m.reference,
                        ...(m.driver_name   ? { driver:  m.driver_name }             : {}),
                        ...(m.vehicle_plate ? { vehicle: m.vehicle_plate }           : {}),
                        ...(m.scheduled_date ? { date:   m.scheduled_date }          : {}),
                        ...(m.price != null  ? { price:  String(m.price) }           : {}),
                        ...(m.client_name    ? { client: m.client_name }             : {}),
                        ...(m.pickup_city    ? { origin: m.pickup_city }             : {}),
                        ...(m.delivery_city  ? { dest:   m.delivery_city }           : {}),
                      }).toString()}`}
                      className="compact-button"
                      title="Créer une facture depuis cette mission"
                      style={{ display: "inline-flex", alignItems: "center", gap: 4, color: "#2563eb", background: "#eff6ff", borderColor: "#bfdbfe" }}
                    >
                      <FileText size={13} />
                      Facturer
                    </Link>
                  )}
                  <form action={deleteMission}>
                    <input type="hidden" name="id"          value={m.id} />
                    <input type="hidden" name="redirect_to" value={redir} />
                    <button type="submit" className="btn-icon btn-icon-danger" title="Supprimer">
                      <Trash2 size={14} />
                    </button>
                  </form>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

