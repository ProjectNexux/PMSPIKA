import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Sous-traitance" title="Contractants Rungis" stats={4} rows={10} cols={6} />;
}
