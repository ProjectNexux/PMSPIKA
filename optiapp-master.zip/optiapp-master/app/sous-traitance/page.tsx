import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatNumber, pct } from "@/lib/format";
import {
  getContractorsByCompany,
  getDocumentsByCompanyFull,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function CompanySubcontractingPage() {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const [contractors, allDocs] = await Promise.all([
    getContractorsByCompany(id), getDocumentsByCompanyFull(id),
  ]);
  const documents = allDocs.filter((d) => d.category === "Sous-traitance");
  const routes = contractors.reduce((sum, c) => sum + c.monthly_routes, 0);
  const vehicles = contractors.reduce((sum, c) => sum + c.vehicles, 0);
  const employees = contractors.reduce((sum, c) => sum + c.employees, 0);

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Sous-traitance" />

      <section className="stat-grid">
        <StatCard label="Sous-traitants" value={formatNumber(contractors.length)} tone="blue" />
        <StatCard label="Tournees / mois" value={formatNumber(routes)} tone="green" />
        <StatCard label="Vehicules" value={formatNumber(vehicles)} tone="orange" />
        <StatCard label="Salaries" value={formatNumber(employees)} tone="red" />
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Partenaires</h2>
              <p>Sous-traitants — PIKA TRANSPORT</p>
            </div>
          </div>
          {contractors.length > 0 ? (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Partenaire</th>
                    <th>Site</th>
                    <th>Tournees</th>
                    <th>Realisees</th>
                    <th>Vehicules</th>
                    <th>Salaries</th>
                    <th>Incidents</th>
                    <th>Ponctualite</th>
                    <th>Etat</th>
                  </tr>
                </thead>
                <tbody>
                  {contractors.map((contractor) => (
                    <tr key={contractor.id}>
                      <td className="strong-cell">{contractor.name}</td>
                      <td>{contractor.site_name}</td>
                      <td>{formatNumber(contractor.monthly_routes)}</td>
                      <td>{formatNumber(contractor.completed_routes)}</td>
                      <td>{formatNumber(contractor.vehicles)}</td>
                      <td>{formatNumber(contractor.employees)}</td>
                      <td>{formatNumber(contractor.incidents)}</td>
                      <td>{pct(contractor.on_time_rate)}</td>
                      <td>
                        <StatusPill value={contractor.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 14 }}>Aucun sous-traitant pour PIKA TRANSPORT.</p>
          )}
        </div>

        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Pieces sous-traitants</h2>
              <p>Attestations et conformite — PIKA TRANSPORT</p>
            </div>
          </div>
          {documents.length > 0 ? (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Document</th>
                    <th>Responsable</th>
                    <th>Etat</th>
                  </tr>
                </thead>
                <tbody>
                  {documents.map((document) => (
                    <tr key={document.id}>
                      <td className="strong-cell">{document.title}</td>
                      <td>{document.owner_name}</td>
                      <td>
                        <StatusPill value={document.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 14 }}>Aucune piece sous-traitant a suivre.</p>
          )}
        </div>
      </section>
    </main>
  );
}
