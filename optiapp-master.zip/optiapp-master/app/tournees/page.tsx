import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { TourneePlanning } from "@/components/planning/tournee-planning";
import { addDays, getMapData, getPlanning, startOfWeek, toIsoDate } from "@/lib/planning";
import { formatCurrency, formatNumber } from "@/lib/format";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function TourneesPage() {
  const user = await requireUser();
  const id = user.company_id ?? "";

  // On charge ±28 jours autour de la semaine en cours pour couvrir toutes les vues
  const today = new Date();
  const start = toIsoDate(addDays(startOfWeek(today), -7));
  const end   = toIsoDate(addDays(startOfWeek(today), 27));

  const [payload, mapData] = await Promise.all([
    getPlanning(id, start, end),
    getMapData(id, start, end),
  ]);
  const redir = "/tournees";

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Planning & Tournées" />

      <section className="stat-grid" aria-label="Indicateurs planning">
        <StatCard
          label="Tournées"
          value={formatNumber(payload.stats.total)}
          detail={`${formatNumber(Math.round(payload.stats.total_distance))} km cumulés`}
          tone="blue"
        />
        <StatCard
          label="En cours"
          value={formatNumber(payload.stats.in_progress)}
          detail={`${formatNumber(payload.stats.scheduled)} planifiées`}
          tone="orange"
        />
        <StatCard
          label="Chiffre d'affaires"
          value={formatCurrency(payload.stats.total_revenue)}
          detail={`Coût ${formatCurrency(payload.stats.total_cost)}`}
          tone="blue"
        />
        <StatCard
          label="Marge période"
          value={formatCurrency(payload.stats.total_margin)}
          detail={
            payload.stats.margin_pct == null
              ? "—"
              : `${payload.stats.margin_pct.toFixed(1)}% • ${payload.looseMissions.length} mission(s) à rattacher`
          }
          tone={
            payload.stats.margin_pct == null ? "orange"
            : payload.stats.margin_pct >= 15 ? "green"
            : payload.stats.margin_pct >= 5 ? "orange" : "red"
          }
        />
      </section>

      <TourneePlanning companyId={id} payload={payload} mapData={mapData} redir={redir} />
    </main>
  );
}
