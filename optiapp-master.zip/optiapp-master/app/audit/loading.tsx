import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Sécurité" title="Audit log" stats={0} rows={12} cols={7} />;
}
