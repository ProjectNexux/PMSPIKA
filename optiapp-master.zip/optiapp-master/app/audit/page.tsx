import { ScrollText } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { StatusPill } from "@/components/status-pill";
import { requireRole } from "@/lib/session";
import { getAuditLog } from "@/lib/queries";

export const dynamic = "force-dynamic";

function formatDateTime(iso: string) {
  try {
    return new Date(iso).toLocaleString("fr-FR", {
      dateStyle: "short",
      timeStyle: "medium",
    });
  } catch {
    return iso;
  }
}

function entryStatus(result: "ok" | "error"): string {
  return result === "ok" ? "Valide" : "A revoir";
}

export default async function AuditPage({
  searchParams,
}: {
  searchParams: Promise<{ company?: string }>;
}) {
  await requireRole(["super_admin", "gerant_groupe"]);
  const { company } = await searchParams;
  const rows = await getAuditLog(300, company);

  return (
    <main className="page">
      <PageHeader eyebrow="Sécurité" title="Audit log" />
      <p className="muted" style={{ fontSize: 13, marginTop: -8, marginBottom: 12 }}>
        <ScrollText size={14} aria-hidden style={{ verticalAlign: -2, marginRight: 4 }} />
        Trace des actions sensibles (créations, suppressions, opérations URSSAF, bascules de période…).
        Lecture réservée aux administrateurs.
      </p>

      <div className="panel">
        <div className="panel-header">
          <div>
            <h2>{rows.length} dernière(s) action(s)</h2>
            <p>
              {company
                ? `Filtré sur la société ${company}`
                : "Toutes sociétés confondues"}
            </p>
          </div>
        </div>

        {rows.length === 0 ? (
          <p className="muted" style={{ fontSize: 14 }}>
            Aucune entrée d'audit pour le moment.
          </p>
        ) : (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Utilisateur</th>
                  <th>Société</th>
                  <th>Action</th>
                  <th>Entité</th>
                  <th>État</th>
                  <th>Message / metadata</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td className="strong-cell" style={{ whiteSpace: "nowrap" }}>
                      {formatDateTime(r.at)}
                    </td>
                    <td>
                      {r.actor_name}
                      {r.actor_role ? (
                        <span className="muted" style={{ fontSize: 12, marginLeft: 6 }}>
                          ({r.actor_role})
                        </span>
                      ) : null}
                    </td>
                    <td>{r.company_name ?? <span className="muted">—</span>}</td>
                    <td>
                      <code style={{ fontSize: 12 }}>{r.action}</code>
                    </td>
                    <td>
                      <code style={{ fontSize: 12 }}>{r.entity}</code>
                      {r.entity_id ? (
                        <div className="muted" style={{ fontSize: 11 }}>
                          {r.entity_id.slice(0, 8)}…
                        </div>
                      ) : null}
                    </td>
                    <td>
                      <StatusPill value={entryStatus(r.result)} />
                    </td>
                    <td style={{ maxWidth: 360 }}>
                      {r.message ? (
                        <span style={{ color: r.result === "error" ? "var(--red)" : undefined }}>
                          {r.message}
                        </span>
                      ) : r.metadata ? (
                        <code
                          style={{
                            fontSize: 11,
                            display: "block",
                            whiteSpace: "pre-wrap",
                            wordBreak: "break-word",
                          }}
                        >
                          {JSON.stringify(r.metadata)}
                        </code>
                      ) : (
                        <span className="muted">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </main>
  );
}
