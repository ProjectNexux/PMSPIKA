/**
 * app/auth/reset-password/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Page d'atterrissage du lien "Reset password" envoyé par Supabase.
 *
 * Flux Supabase :
 *   1) L'email contient un lien vers `${SITE_URL}/auth/reset-password?code=...`
 *      (ou `?token_hash=...&type=recovery` selon le template).
 *   2) On échange ce code/token contre une session.
 *   3) On affiche un formulaire pour saisir le nouveau mot de passe.
 *   4) Le formulaire appelle l'action `updatePasswordAction`.
 *
 * Sécurité : la page est listée dans `PUBLIC_PATHS` du middleware pour que
 * l'utilisateur (non encore connecté) puisse y accéder via le lien email.
 */

import { redirect } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase-server";
import { updatePasswordAction } from "./actions";

export const dynamic = "force-dynamic";

type SearchParams = {
  code?: string;
  token_hash?: string;
  type?: string;
  error?: string;
  status?: string;
};

export default async function ResetPasswordPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const params = await searchParams;
  const supabase = await getSupabaseServer();

  // ── 1) Si on arrive avec un `code` (flux PKCE), on l'échange ──────────────
  if (params.code) {
    const { error } = await supabase.auth.exchangeCodeForSession(params.code);
    if (error) {
      redirect("/auth/reset-password?error=invalid_link");
    }
    // Redirige vers la même page sans le code dans l'URL
    redirect("/auth/reset-password");
  }

  // ── 2) Si on arrive avec token_hash+type (flux ancien), on vérifie l'OTP ─
  if (params.token_hash && params.type === "recovery") {
    const { error } = await supabase.auth.verifyOtp({
      type: "recovery",
      token_hash: params.token_hash,
    });
    if (error) {
      redirect("/auth/reset-password?error=invalid_link");
    }
    redirect("/auth/reset-password");
  }

  // ── 3) Vérifie que l'utilisateur est bien authentifié (session recovery) ─
  const { data: { user } } = await supabase.auth.getUser();
  if (!user && !params.error && !params.status) {
    // Pas de session et pas de code → lien invalide ou expiré
    redirect("/login?error=invalid");
  }

  const errorMessage =
    params.error === "invalid_link"
      ? "Le lien de réinitialisation est invalide ou a expiré. Demandez un nouveau lien."
      : params.error === "weak"
        ? "Le mot de passe doit faire au moins 8 caractères."
        : params.error === "mismatch"
          ? "Les deux mots de passe ne correspondent pas."
          : params.error === "update_failed"
            ? "Impossible de mettre à jour le mot de passe. Réessayez."
            : null;

  const isDone = params.status === "ok";

  return (
    <div className="login-shell">
      <div className="login-card">
        <div className="login-brand">
          <span className="login-mark">JT</span>
          <div>
            <strong>PIKA TRANSPORT</strong>
            <small>Nouveau mot de passe</small>
          </div>
        </div>

        {isDone ? (
          <>
            <div
              className="login-error"
              style={{ background: "#dcfce7", color: "#166534" }}
            >
              Mot de passe mis à jour. Vous êtes connecté.
            </div>
            <a href="/" className="login-submit" style={{ display: "block", textAlign: "center", textDecoration: "none" }}>
              Accéder à mon espace
            </a>
          </>
        ) : (
          <>
            {errorMessage && <div className="login-error">{errorMessage}</div>}

            <form action={updatePasswordAction} className="login-form">
              <label>
                <span>Nouveau mot de passe</span>
                <input
                  type="password"
                  name="password"
                  required
                  minLength={8}
                  autoComplete="new-password"
                  placeholder="Au moins 8 caractères"
                />
              </label>
              <label>
                <span>Confirmer le mot de passe</span>
                <input
                  type="password"
                  name="confirm"
                  required
                  minLength={8}
                  autoComplete="new-password"
                  placeholder="Retapez le mot de passe"
                />
              </label>
              <button type="submit" className="login-submit">
                Mettre à jour
              </button>
            </form>
          </>
        )}
      </div>
    </div>
  );
}
