"use server";

/**
 * Action serveur appelée par le formulaire /auth/reset-password.
 * Exige une session active (créée par l'échange du code dans la page).
 */

import { redirect } from "next/navigation";
import { getSupabaseServer } from "@/lib/supabase-server";

export async function updatePasswordAction(formData: FormData) {
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");

  if (password.length < 8) {
    redirect("/auth/reset-password?error=weak");
  }
  if (password !== confirm) {
    redirect("/auth/reset-password?error=mismatch");
  }

  const supabase = await getSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    redirect("/auth/reset-password?error=invalid_link");
  }

  const { error } = await supabase.auth.updateUser({ password });
  if (error) {
    redirect("/auth/reset-password?error=update_failed");
  }

  redirect("/auth/reset-password?status=ok");
}
