import { notFound } from "next/navigation";
import { getMissionTrackingByToken } from "@/lib/tracking-queries";
import { TrackingLive } from "./tracking-live";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Suivi de livraison",
  robots: { index: false, follow: false },
};

export default async function SuiviPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const tracking = await getMissionTrackingByToken(token);
  if (!tracking) notFound();

  return (
    <main className="suivi-page">
      <TrackingLive token={token} initial={tracking} />
    </main>
  );
}
