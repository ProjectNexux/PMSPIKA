"use client";

import { useEffect, useState } from "react";
import type { PublicTracking } from "@/lib/tracking-queries";

const POLL_MS = 30_000;

/** Étapes affichées dans la barre de progression (ordre = avancement). */
const STEPS: { key: string; label: string }[] = [
  { key: "a_traiter", label: "Pris en charge" },
  { key: "enleve", label: "Enlevé" },
  { key: "en_transit", label: "En transit" },
  { key: "en_livraison", label: "En livraison" },
  { key: "livre", label: "Livré" },
];

function stepIndex(status: string): number {
  const i = STEPS.findIndex((s) => s.key === status);
  return i === -1 ? 0 : i;
}

function statusLabel(status: string): string {
  if (status === "echec") return "Livraison non aboutie";
  const step = STEPS.find((s) => s.key === status);
  return step ? step.label : "En cours de traitement";
}

function fmtTime(iso: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleTimeString("fr-FR", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtWindow(start: string | null, end: string | null): string {
  if (!start && !end) return "—";
  if (start && end) return `${fmtTime(start)} – ${fmtTime(end)}`;
  return fmtTime(start ?? end);
}

function osmEmbed(lat: number, lng: number): string {
  // Petite bbox autour de la position du chauffeur.
  const d = 0.05;
  const bbox = [lng - d, lat - d, lng + d, lat + d].join(",");
  return `https://www.openstreetmap.org/export/embed.html?bbox=${encodeURIComponent(
    bbox,
  )}&layer=mapnik&marker=${lat},${lng}`;
}

export function TrackingLive({
  token,
  initial,
}: {
  token: string;
  initial: PublicTracking;
}) {
  const [data, setData] = useState<PublicTracking>(initial);

  useEffect(() => {
    const done = initial.delivery_status === "livre" || initial.delivery_status === "echec";
    if (done) return;
    let active = true;
    const tick = async () => {
      try {
        const res = await fetch(`/api/suivi/${token}`, { cache: "no-store" });
        if (!res.ok) return;
        const json = (await res.json()) as PublicTracking;
        if (active) setData(json);
        if (json.delivery_status === "livre" || json.delivery_status === "echec") {
          clearInterval(id);
        }
      } catch {
        /* on retentera au prochain tick */
      }
    };
    const id = setInterval(tick, POLL_MS);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [token, initial.delivery_status]);

  const idx = stepIndex(data.delivery_status);
  const failed = data.delivery_status === "echec";
  const delivered = data.delivery_status === "livre";
  const hasMap = data.driver_lat != null && data.driver_lng != null;

  return (
    <div className="suivi-card">
      <header className="suivi-head">
        <p className="suivi-eyebrow">Suivi de livraison</p>
        <h1 className="suivi-ref">{data.reference ?? "Votre colis"}</h1>
        <p className={`suivi-status ${failed ? "is-failed" : delivered ? "is-done" : ""}`}>
          {statusLabel(data.delivery_status)}
        </p>
      </header>

      {!failed && (
        <ol className="suivi-steps" aria-label="Progression">
          {STEPS.map((s, i) => (
            <li
              key={s.key}
              className={`suivi-step ${i < idx ? "done" : ""} ${i === idx ? "current" : ""}`}
            >
              <span className="suivi-dot" />
              <span className="suivi-step-label">{s.label}</span>
            </li>
          ))}
        </ol>
      )}

      <dl className="suivi-info">
        <div>
          <dt>Départ</dt>
          <dd>{data.pickup_city ?? "—"}</dd>
        </div>
        <div>
          <dt>Destination</dt>
          <dd>{data.delivery_city ?? "—"}</dd>
        </div>
        <div>
          <dt>Créneau de livraison</dt>
          <dd>{fmtWindow(data.window_start, data.window_end)}</dd>
        </div>
        <div>
          <dt>Arrivée estimée</dt>
          <dd>{data.eta ? fmtTime(data.eta) : "—"}</dd>
        </div>
      </dl>

      {hasMap && (
        <div className="suivi-map">
          <iframe
            title="Position du véhicule"
            src={osmEmbed(data.driver_lat!, data.driver_lng!)}
            loading="lazy"
          />
          <p className="suivi-map-note">
            Position mise à jour à {fmtTime(data.driver_updated_at)}
          </p>
        </div>
      )}

      <footer className="suivi-foot">
        {delivered
          ? "Votre livraison a été effectuée. Merci !"
          : failed
            ? "Un incident est survenu. Notre équipe revient vers vous."
            : "Cette page se met à jour automatiquement."}
      </footer>
    </div>
  );
}
