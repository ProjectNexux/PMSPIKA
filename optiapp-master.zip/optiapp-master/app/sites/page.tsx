import { Pencil, Plus, Trash2 } from "lucide-react";
import { createSite, deleteSite, updateSite } from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatNumber, pct } from "@/lib/format";
import { getSitesByCompany } from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const MODES = ["Propre", "Sous-traitance pilotee", "Mixte"];

export default async function CompanySitesPage({
  searchParams,
}: {
  searchParams: Promise<{ edit?: string }>;
}) {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const { edit } = await searchParams;
  const sites = await getSitesByCompany(id);

  const editingSite = edit ? sites.find((s) => s.id === edit) : undefined;
  const redir = "/sites";

  const totalRoutes    = sites.reduce((s, x) => s + (x.monthly_routes  ?? 0), 0);
  const totalVehicles  = sites.reduce((s, x) => s + (x.actual_vehicles  ?? 0), 0);
  const totalEmployees = sites.reduce((s, x) => s + (x.actual_employees ?? 0), 0);
  const totalIncidents = sites.reduce((s, x) => s + (x.incidents        ?? 0), 0);

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Sites operationnels" />

      <section className="stat-grid">
        <StatCard label="Sites"             value={formatNumber(sites.length)}        tone="blue" />
        <StatCard label="Tournees / mois"   value={formatNumber(totalRoutes)}         tone="green" />
        <StatCard label="Vehicules actifs"  value={formatNumber(totalVehicles)}       tone="orange" />
        <StatCard label="Incidents (M)"     value={formatNumber(totalIncidents)}      tone="red" />
      </section>

      <div className="grid-2">
        {/* ── Create / Edit form ── */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>{editingSite ? `Modifier — ${editingSite.name}` : "Ajouter un site"}</h2>
              <p>{editingSite ? "Modifier les informations du site" : "Rattaché à PIKA TRANSPORT"}</p>
            </div>
          </div>
          {editingSite ? (
            <form action={updateSite} className="form-grid">
              <input type="hidden" name="id"          value={editingSite.id} />
              <input type="hidden" name="redirect_to" value={redir} />
              <div className="field full">
                <label htmlFor="name">Nom du site</label>
                <input id="name" name="name" required defaultValue={editingSite.name} />
              </div>
              <div className="field">
                <label htmlFor="region">Region</label>
                <input id="region" name="region" required defaultValue={editingSite.region} />
              </div>
              <div className="field">
                <label htmlFor="mode">Mode</label>
                <select id="mode" name="mode" defaultValue={editingSite.mode}>
                  {MODES.map((m) => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div className="field">
                <label htmlFor="monthly_routes">Tournees / mois</label>
                <input id="monthly_routes" name="monthly_routes" type="number" min="0" defaultValue={editingSite.monthly_routes} />
              </div>
              <div className="field">
                <label htmlFor="vehicles_target">Objectif vehicules</label>
                <input id="vehicles_target" name="vehicles_target" type="number" min="0" defaultValue={editingSite.vehicles_target} />
              </div>
              <div className="field">
                <label htmlFor="employees_target">Objectif salaries</label>
                <input id="employees_target" name="employees_target" type="number" min="0" defaultValue={editingSite.employees_target} />
              </div>
              <div className="field full">
                <label htmlFor="observations">Observations</label>
                <textarea id="observations" name="observations" defaultValue={editingSite.observations ?? ""} />
              </div>
              <div className="full form-actions">
                <button className="button" type="submit">
                  <Pencil size={15} aria-hidden="true" />
                  Enregistrer
                </button>
                <a href={redir} className="button secondary">Annuler</a>
              </div>
            </form>
          ) : (
            <form action={createSite} className="form-grid">
              <input type="hidden" name="company_id"  value={id} />
              <input type="hidden" name="redirect_to" value={redir} />
              <div className="field full">
                <label htmlFor="name">Nom du site</label>
                <input id="name" name="name" required placeholder="Ex. Rungis — Plateforme A" />
              </div>
              <div className="field">
                <label htmlFor="region">Region</label>
                <input id="region" name="region" required placeholder="Ex. Ile-de-France" />
              </div>
              <div className="field">
                <label htmlFor="mode">Mode</label>
                <select id="mode" name="mode" defaultValue="Propre">
                  {MODES.map((m) => <option key={m}>{m}</option>)}
                </select>
              </div>
              <div className="field">
                <label htmlFor="monthly_routes">Tournees / mois</label>
                <input id="monthly_routes" name="monthly_routes" type="number" min="0" defaultValue="0" />
              </div>
              <div className="field">
                <label htmlFor="vehicles_target">Objectif vehicules</label>
                <input id="vehicles_target" name="vehicles_target" type="number" min="0" defaultValue="0" />
              </div>
              <div className="field">
                <label htmlFor="employees_target">Objectif salaries</label>
                <input id="employees_target" name="employees_target" type="number" min="0" defaultValue="0" />
              </div>
              <div className="field full">
                <label htmlFor="observations">Observations</label>
                <textarea id="observations" name="observations" placeholder="Notes ou contexte..." />
              </div>
              <div className="full">
                <button className="button" type="submit">
                  <Plus size={15} aria-hidden="true" />
                  Ajouter le site
                </button>
              </div>
            </form>
          )}
        </div>

        {/* ── Stats totals ── */}
        <div className="panel">
          <div className="panel-header">
            <div><h2>Recapitulatif</h2><p>Consolide {sites.length} site{sites.length > 1 ? "s" : ""}</p></div>
          </div>
          <div className="metric-list">
            <div className="metric-row"><span>Salaries total</span><strong>{formatNumber(totalEmployees)}</strong></div>
            <div className="metric-row"><span>Vehicules total</span><strong>{formatNumber(totalVehicles)}</strong></div>
            <div className="metric-row"><span>Tournees / mois</span><strong>{formatNumber(totalRoutes)}</strong></div>
            <div className="metric-row"><span>Incidents (mois)</span><strong>{formatNumber(totalIncidents)}</strong></div>
          </div>
        </div>
      </div>

      {/* ── Data table ── */}
      <section className="panel">
        <div className="panel-header">
          <div>
            <h2>Repartition operationnelle</h2>
            <p>{sites.length} site{sites.length > 1 ? "s" : ""} pour PIKA TRANSPORT</p>
          </div>
        </div>
        {sites.length > 0 ? (
          <div className="table-wrap">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Site</th>
                  <th>Region</th>
                  <th>Mode</th>
                  <th>Tournees</th>
                  <th>Vehicules</th>
                  <th>Salaries</th>
                  <th>Ponctualite</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {sites.map((site) => (
                  <tr key={site.id} className={edit === site.id ? "row-editing" : undefined}>
                    <td className="strong-cell">{site.name}</td>
                    <td>{site.region}</td>
                    <td><StatusPill value={site.mode === "Sous-traitance pilotee" ? "A revoir" : "Actif"} /></td>
                    <td>{formatNumber(site.monthly_routes)}</td>
                    <td>{formatNumber(site.actual_vehicles)}</td>
                    <td>{formatNumber(site.actual_employees)}</td>
                    <td>{pct(site.on_time_rate)}</td>
                    <td>
                      <div className="row-actions">
                        <a href={`?edit=${site.id}`} className="btn-icon" title="Modifier">
                          <Pencil size={14} />
                        </a>
                        <form action={deleteSite}>
                          <input type="hidden" name="id"          value={site.id} />
                          <input type="hidden" name="redirect_to" value={redir} />
                          <button type="submit" className="btn-icon btn-icon-danger" title="Supprimer">
                            <Trash2 size={14} />
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="muted" style={{ fontSize: 14 }}>Aucun site rattache a PIKA TRANSPORT.</p>
        )}
      </section>
    </main>
  );
}
