import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Exploitation" title="Sites" stats={4} rows={8} cols={7} />;
}
