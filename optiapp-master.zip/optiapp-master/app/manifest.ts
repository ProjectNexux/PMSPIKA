import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "PIKA TRANSPORT",
    short_name: "Pika",
    description: "Espace chauffeur — tournées, documents, géolocalisation",
    start_url: "/chauffeur",
    display: "standalone",
    background_color: "#f8fafc",
    theme_color: "#F59E0B",
    orientation: "portrait",
    icons: [
      {
        src: "/logo-icon.svg",
        sizes: "any",
        type: "image/svg+xml",
        purpose: "maskable",
      },
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
      },
    ],
  };
}
