/**
 * app/login/page.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Page de connexion (email + mot de passe Supabase Auth).
 * Pas d'AppShell (layout dédié plus bas).
 */

import { redirect } from "next/navigation";
import { signInAction } from "./actions";
import { getCurrentUser, homeForRole } from "@/lib/session";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { AlertCircle } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string }>;
}) {
  const params = await searchParams;
  const user = await getCurrentUser();
  if (user) redirect(params.next || homeForRole(user.role));

  const errorMessage =
    params.error === "no_profile"
      ? "Votre compte n'a pas de profil applicatif. Contactez un administrateur."
      : params.error === "invalid"
        ? "Email ou mot de passe incorrect."
        : null;

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 px-4 py-12">
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="space-y-4 text-center">
          <div className="space-y-1.5">
            <img src="/pika-logo.svg" alt="Pika Transport" width={200} height={65} style={{ display: "block", margin: "0 auto" }} />
            <CardDescription>Espace administrateur</CardDescription>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {errorMessage && (
            <div
              role="alert"
              className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive"
            >
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          <form action={signInAction} className="space-y-4">
            <input type="hidden" name="next" value={params.next ?? ""} />

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                name="email"
                required
                autoComplete="email"
                placeholder="vous@exemple.com"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe</Label>
              <Input
                id="password"
                type="password"
                name="password"
                required
                autoComplete="current-password"
                placeholder="••••••••"
              />
            </div>

            <Button type="submit" className="w-full">
              Se connecter
            </Button>
          </form>
        </CardContent>
        <CardFooter>
          <p className="w-full text-center text-xs text-muted-foreground">
            Mot de passe oublié ? Contactez votre administrateur.
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
