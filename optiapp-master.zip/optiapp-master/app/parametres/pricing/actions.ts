"use server";
import { getServerSupabase } from "@/lib/db-server";
import { requireRole } from "@/lib/session";
import { randomUUID } from "node:crypto";

const supabase = getServerSupabase();

export async function createPricingProfile(formData: FormData) {
  await requireRole(["super_admin", "gerant_groupe", "gerant_societe"]);
  const company_id = formData.get("company_id") as string | null;
  const name = (formData.get("name") as string) || "Profil";
  const base_fee = Number(formData.get("base_fee") || 0);
  const per_km = Number(formData.get("per_km") || 0);
  const per_kg = Number(formData.get("per_kg") || 0);
  const cold_unit_fee = Number(formData.get("cold_unit_fee") || 0);
  const adr_fee = Number(formData.get("adr_fee") || 0);
  const priority_multiplier = Number(formData.get("priority_multiplier") || 1);

  await supabase.from("pricing_profiles").insert({
    id: randomUUID(),
    company_id,
    name,
    base_fee,
    per_km,
    per_kg,
    cold_unit_fee,
    adr_fee,
    priority_multiplier,
  });
}

export async function createFuelRate(formData: FormData) {
  await requireRole(["super_admin", "gerant_groupe", "gerant_societe"]);
  const company_id = formData.get("company_id") as string | null;
  const price_per_l = Number(formData.get("price_per_l") || 0);
  if (!price_per_l || price_per_l <= 0) return;
  await supabase.from("fuel_price_rates").insert({ company_id: company_id || null, price_per_l });
}

export async function deactivateFuelRate(id: string) {
  await requireRole(["super_admin", "gerant_groupe", "gerant_societe"]);
  await supabase.from("fuel_price_rates").update({ active: false }).eq("id", id);
}
