import { requireRole } from "@/lib/session";
import { getServerSupabase } from "@/lib/db-server";
import { createPricingProfile, createFuelRate } from "./actions";

export const dynamic = "force-dynamic";

export default async function PricingPage() {
  await requireRole(["super_admin", "gerant_groupe", "gerant_societe"]);
  const supabase = getServerSupabase();

  const [{ data: profiles }, { data: rates }] = await Promise.all([
    supabase.from("pricing_profiles").select("*").order("created_at", { ascending: false }),
    supabase.from("fuel_price_rates").select("*").order("effective_at", { ascending: false }),
  ]);

  return (
    <main className="page">
      <h1>Tarification</h1>

      <section style={{ marginBottom: 24 }}>
        <h2>Profils de tarification</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Nom</th>
              <th>Company</th>
              <th>Base</th>
              <th>€/km</th>
              <th>€/kg</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {(profiles ?? []).map((p: any) => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.company_id ?? "—"}</td>
                <td>{p.base_fee}</td>
                <td>{p.per_km}</td>
                <td>{p.per_kg}</td>
                <td>—</td>
              </tr>
            ))}
          </tbody>
        </table>

        <form action={createPricingProfile} style={{ marginTop: 12 }}>
          <input name="company_id" placeholder="company_id (vide = global)" />
          <input name="name" placeholder="Nom du profil" />
          <input name="base_fee" placeholder="Frais fixe" type="number" step="0.01" />
          <input name="per_km" placeholder="€/km" type="number" step="0.01" />
          <input name="per_kg" placeholder="€/kg" type="number" step="0.01" />
          <input name="cold_unit_fee" placeholder="Frigo €/h" type="number" step="0.01" />
          <input name="adr_fee" placeholder="ADR €" type="number" step="0.01" />
          <input name="priority_multiplier" placeholder="Multiplicateur priorité" type="number" step="0.01" defaultValue={1} />
          <button type="submit">Créer</button>
        </form>
      </section>

      <section>
        <h2>Prix du carburant</h2>
        <table className="table">
          <thead>
            <tr>
              <th>Prix</th>
              <th>Company</th>
              <th>Effective</th>
              <th>Actif</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {(rates ?? []).map((r: any) => (
              <tr key={r.id}>
                <td>{r.price_per_l}</td>
                <td>{r.company_id ?? "—"}</td>
                <td>{new Date(r.effective_at).toLocaleString()}</td>
                <td>{r.active ? "oui" : "non"}</td>
                <td>
                  {r.active && (
                    <form action={async (fd: FormData) => { await fetch(`/api/internal/deactivate-fuel/${r.id}`, { method: "POST" }); }}>
                      <button type="submit">Désactiver</button>
                    </form>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <form action={createFuelRate} style={{ marginTop: 12 }}>
          <input name="company_id" placeholder="company_id (vide = global)" />
          <input name="price_per_l" placeholder="€/L" type="number" step="0.001" />
          <button type="submit">Ajouter</button>
        </form>
      </section>
    </main>
  );
}
