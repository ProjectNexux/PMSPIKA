"use client";

import { useState, useTransition } from "react";
import { Download } from "lucide-react";
import { getAttestationDownloadUrl } from "@/app/actions-urssaf";

export function AttestationDownloadButton({ storagePath }: { storagePath: string }) {
  const [pending, startTransition] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const onClick = () => {
    setError(null);
    startTransition(async () => {
      try {
        const fd = new FormData();
        fd.set("storage_path", storagePath);
        const url = await getAttestationDownloadUrl(fd);
        window.open(url, "_blank", "noopener,noreferrer");
      } catch (err) {
        setError(err instanceof Error ? err.message : "Erreur");
      }
    });
  };

  return (
    <>
      <button
        type="button"
        className="button secondary"
        onClick={onClick}
        disabled={pending}
        title="Télécharger le PDF"
      >
        <Download size={14} aria-hidden /> {pending ? "…" : "PDF"}
      </button>
      {error ? <div style={{ color: "var(--red)", fontSize: 12 }}>{error}</div> : null}
    </>
  );
}
