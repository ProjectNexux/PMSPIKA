import Link from "next/link";
import { AlertTriangle, CheckCircle2, RefreshCw, ShieldCheck, Trash2 } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { StatusPill } from "@/components/status-pill";
import { getAttestations, getUrssafCredentialPublic } from "@/lib/urssaf-queries";
import {
  removeUrssafCredentials,
  runUrssafFetchNow,
  saveUrssafCredentials,
} from "@/app/actions-urssaf";
import { AttestationDownloadButton } from "./download-button";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

function formatDateTime(iso: string | null | undefined) {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("fr-FR", {
      dateStyle: "short",
      timeStyle: "short",
    });
  } catch {
    return iso;
  }
}

function formatBytes(n: number | null) {
  if (!n) return "—";
  if (n < 1024) return `${n} o`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} Ko`;
  return `${(n / 1024 / 1024).toFixed(2)} Mo`;
}

export default async function CompanyParametresPage() {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const [creds, attestations] = await Promise.all([
    getUrssafCredentialPublic(id),
    getAttestations(id),
  ]);

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Paramètres" />
      <p className="muted" style={{ fontSize: 13, marginTop: -8, marginBottom: 12 }}>
        Intégrations &amp; accès tiers
      </p>

      <section className="grid-2">
        {/* ---------- URSSAF CREDENTIALS ---------- */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>
                <ShieldCheck size={18} aria-hidden /> Identifiants URSSAF / Net-Entreprises
              </h2>
              <p>
                Le mot de passe est chiffré AES-256-GCM avant stockage (clé hors-base).
                Utilisé uniquement par la tâche planifiée mensuelle.
              </p>
            </div>
          </div>

          {creds ? (
            <div style={{ display: "grid", gap: 12, marginBottom: 12 }}>
              <div className="muted" style={{ fontSize: 13 }}>
                <strong>Identifiant :</strong> {creds.username}
                <br />
                <strong>Portail :</strong> {creds.portal}
                <br />
                <strong>Dernier run :</strong> {formatDateTime(creds.last_run_at)}{" "}
                {creds.last_run_status && (
                  <span style={{ marginLeft: 6 }}>
                    <StatusPill value={creds.last_run_status === "ok" ? "Valide" : "A revoir"} />
                  </span>
                )}
                {creds.last_run_error ? (
                  <>
                    <br />
                    <span style={{ color: "var(--red)", display: "inline-flex", alignItems: "center", gap: 6 }}>
                      <AlertTriangle size={14} /> {creds.last_run_error}
                    </span>
                  </>
                ) : null}
              </div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <form action={runUrssafFetchNow}>
                  <input type="hidden" name="company_id" value={id} />
                  <button type="submit" className="button">
                    <RefreshCw size={16} aria-hidden /> Lancer maintenant
                  </button>
                </form>
                <form action={removeUrssafCredentials}>
                  <input type="hidden" name="company_id" value={id} />
                  <button type="submit" className="button secondary" style={{ color: "var(--red)" }}>
                    <Trash2 size={16} aria-hidden /> Supprimer
                  </button>
                </form>
              </div>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 13, marginBottom: 12 }}>
              Aucun identifiant enregistré pour PIKA TRANSPORT.
            </p>
          )}

          <form action={saveUrssafCredentials} className="form-grid">
            <input type="hidden" name="company_id" value={id} />
            <div className="field full">
              <label htmlFor="username">Identifiant Net-Entreprises</label>
              <input
                id="username"
                name="username"
                required
                autoComplete="off"
                defaultValue={creds?.username ?? ""}
              />
            </div>
            <div className="field full">
              <label htmlFor="password">
                Mot de passe {creds ? "(laisser vide pour conserver — non, ressaisir requis)" : ""}
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                autoComplete="new-password"
              />
            </div>
            <div className="field">
              <label htmlFor="portal">Portail</label>
              <select id="portal" name="portal" defaultValue={creds?.portal ?? "net-entreprises"}>
                <option value="net-entreprises">net-entreprises.fr</option>
                <option value="urssaf-direct">urssaf.fr (direct)</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="mfa_method">MFA</label>
              <select id="mfa_method" name="mfa_method" defaultValue={creds?.mfa_method ?? "none"}>
                <option value="none">Aucun</option>
                <option value="email">Email</option>
                <option value="sms">SMS</option>
                <option value="app">Application</option>
              </select>
            </div>
            <div className="field full">
              <label htmlFor="contact_email">Email d'alerte (échec / MFA)</label>
              <input
                id="contact_email"
                name="contact_email"
                type="email"
                defaultValue={creds?.contact_email ?? ""}
              />
            </div>
            <div className="field full">
              <label style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <input
                  type="checkbox"
                  name="enabled"
                  defaultChecked={creds?.enabled ?? true}
                />
                Activer le téléchargement automatique mensuel
              </label>
            </div>
            <div className="full" style={{ display: "flex", gap: 8 }}>
              <button type="submit" className="button">
                <CheckCircle2 size={16} aria-hidden /> Enregistrer
              </button>
              <Link href="/" className="button secondary">
                Annuler
              </Link>
            </div>
          </form>

          <p className="muted" style={{ fontSize: 12, marginTop: 12 }}>
            En activant cette fonction vous attestez disposer du droit d'utiliser ces
            identifiants pour le compte de la société PIKA TRANSPORT. L'usage automatisé
            relève de votre responsabilité vis-à-vis des CGU du portail.
          </p>
        </div>

        {/* ---------- ATTESTATIONS HISTORIQUE ---------- */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Attestations téléchargées</h2>
              <p>Historique mensuel — {attestations.length} document(s)</p>
            </div>
          </div>
          {attestations.length > 0 ? (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Période</th>
                    <th>Téléchargée</th>
                    <th>Valable jusqu'au</th>
                    <th>Taille</th>
                    <th>Source</th>
                    <th>Etat</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody>
                  {attestations.map((a) => (
                    <tr key={a.id}>
                      <td className="strong-cell">{a.period}</td>
                      <td>{formatDateTime(a.downloaded_at)}</td>
                      <td>{a.valid_until ?? "—"}</td>
                      <td>{formatBytes(a.file_size)}</td>
                      <td>{a.source}</td>
                      <td><StatusPill value={a.status} /></td>
                      <td>
                        <AttestationDownloadButton storagePath={a.storage_path} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 13 }}>
              Aucune attestation téléchargée pour le moment.
              {creds?.enabled
                ? " La prochaine collecte automatique aura lieu le 1er du mois prochain."
                : " Activez le téléchargement automatique ou cliquez sur « Lancer maintenant »."}
            </p>
          )}
        </div>
      </section>
    </main>
  );
}
