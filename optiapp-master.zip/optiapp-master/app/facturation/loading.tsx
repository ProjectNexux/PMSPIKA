export default function Loading() {
  return (
    <main className="page">
      <div className="page-header skeleton-block" style={{ height: 56, borderRadius: 10, marginBottom: 24 }} />
      <div className="stat-grid" style={{ marginBottom: 24 }}>
        {[...Array(4)].map((_, i) => (
          <div key={i} className="skeleton-block" style={{ height: 80, borderRadius: 10 }} />
        ))}
      </div>
      <div className="panel">
        <div className="skeleton-block" style={{ height: 320, borderRadius: 10 }} />
      </div>
    </main>
  );
}
