import Link from "next/link";
import { Plus, Settings, Users, TrendingUp, Clock, CheckCircle, FileText, Receipt } from "lucide-react";
import type { ReactNode } from "react";
import { PageHeader } from "@/components/page-header";
import { formatCurrency } from "@/lib/format";
import { listInvoices } from "@/lib/invoice-queries";
import { requireUser } from "@/lib/session";
import { InvoiceList } from "./invoice-list";

export const dynamic = "force-dynamic";

export default async function FacturationPage() {
  await requireUser();
  const invoices = await listInvoices();

  const totalTTC       = invoices.reduce((s, i) => s + i.total_ttc, 0);
  const totalPayees    = invoices.filter((i) => i.status === "Payée").reduce((s, i) => s + i.total_ttc, 0);
  const totalEnAttente = invoices.filter((i) => i.status === "Envoyée").reduce((s, i) => s + i.total_ttc, 0);
  const nbBrouillons   = invoices.filter((i) => i.status === "Brouillon").length;

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Facturation">
        <div style={{ display: "flex", gap: 8 }}>
          <Link href="/facturation/parametres" className="btn-secondary" style={{ gap: 6 }}>
            <Settings size={14} /> Paramètres
          </Link>
          <Link href="/facturation/clients" className="btn-secondary" style={{ gap: 6 }}>
            <Users size={14} /> Clients
          </Link>
          <Link href="/facturation/prefacturation" className="btn-secondary" style={{ gap: 6 }}>
            <Receipt size={14} /> Pré-facturation
          </Link>
          <Link href="/facturation/nouvelle" className="btn-primary" style={{ gap: 6 }}>
            <Plus size={15} /> Nouvelle facture
          </Link>
        </div>
      </PageHeader>

      {/* ── KPIs ── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0,1fr))", gap: 12 }}>
        <KpiCard icon={<TrendingUp size={18} />} label="CA TTC total"
          value={formatCurrency(totalTTC)}
          sub={`${invoices.length} facture${invoices.length > 1 ? "s" : ""}`}
          accent="#3b82f6" />
        <KpiCard icon={<CheckCircle size={18} />} label="Encaissé"
          value={formatCurrency(totalPayees)}
          sub={`${invoices.filter((i) => i.status === "Payée").length} payée${invoices.filter((i) => i.status === "Payée").length > 1 ? "s" : ""}`}
          accent="#22c55e" />
        <KpiCard icon={<Clock size={18} />} label="En attente"
          value={formatCurrency(totalEnAttente)}
          sub={`${invoices.filter((i) => i.status === "Envoyée").length} envoyée${invoices.filter((i) => i.status === "Envoyée").length > 1 ? "s" : ""}`}
          accent="#f59e0b" />
        <KpiCard icon={<FileText size={18} />} label="Brouillons"
          value={String(nbBrouillons)}
          sub="à finaliser"
          accent="#94a3b8" />
      </div>

      {/* ── Liste ── */}
      <div className="panel" style={{ overflow: "hidden" }}>
        <InvoiceList invoices={invoices} />
      </div>
    </main>
  );
}

function KpiCard({ icon, label, value, sub, accent }: {
  icon: ReactNode; label: string; value: string; sub: string; accent: string;
}) {
  return (
    <div style={{
      background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12,
      padding: "18px 20px", display: "flex", flexDirection: "column", gap: 10,
      boxShadow: "0 1px 3px oklch(0 0 0/.04)",
    }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <span style={{ fontSize: 11.5, fontWeight: 600, color: "var(--muted-foreground)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
          {label}
        </span>
        <span style={{
          display: "inline-flex", alignItems: "center", justifyContent: "center",
          width: 32, height: 32, borderRadius: 8, background: accent + "18", color: accent,
        }}>
          {icon}
        </span>
      </div>
      <div>
        <div style={{ fontSize: 24, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1 }}>{value}</div>
        <div style={{ fontSize: 12, color: "var(--muted-foreground)", marginTop: 4 }}>{sub}</div>
      </div>
    </div>
  );
}
