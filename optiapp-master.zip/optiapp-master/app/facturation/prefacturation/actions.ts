"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { supabase } from "@/lib/db";
import { setFlash } from "@/lib/flash";
import {
  getInvoiceClientById,
  getTourneesAFacturer,
} from "@/lib/prefacturation-queries";
import { getNextInvoiceNumber } from "@/lib/invoice-queries";

// ─── Associer un client à une tournée ────────────────────────────────────────

export async function assignClientToTournee(formData: FormData) {
  const tourneeId = formData.get("tournee_id") as string | null;
  const clientId  = formData.get("client_id")  as string | null;
  if (!tourneeId) return;

  const { error } = await supabase
    .from("tournees")
    .update({ client_id: clientId || null })
    .eq("id", tourneeId);

  if (error) {
    await setFlash({ kind: "error", message: `Erreur: ${error.message}` });
  }
  revalidatePath("/facturation/prefacturation");
}

// ─── Générer une facture brouillon depuis des tournées ────────────────────────

export async function genererFactureDepuisTournees(formData: FormData) {
  const clientId  = formData.get("client_id")  as string | null;
  const periode   = formData.get("periode")    as string | null;
  const tvaRateRaw = formData.get("tva_rate")  as string | null;
  const tvaRate   = tvaRateRaw ? parseFloat(tvaRateRaw) : 20;

  // Les IDs de tournées sélectionnées
  const tourneeIds = formData.getAll("tournee_ids") as string[];

  if (!clientId || tourneeIds.length === 0) {
    await setFlash({ kind: "error", message: "Client et tournées requis" });
    revalidatePath("/facturation/prefacturation");
    return;
  }

  // 1. Récupérer le client
  const client = await getInvoiceClientById(clientId);
  if (!client) {
    await setFlash({ kind: "error", message: "Client introuvable" });
    return;
  }

  // 2. Récupérer les paramètres vendeur
  const { data: settings } = await supabase
    .from("invoice_settings")
    .select("*")
    .limit(1)
    .single();

  type TourneeFacturable = {
    id: string;
    reference: string | null;
    name: string | null;
    scheduled_date: string | null;
    flat_rate_revenue: number | null;
    surcharge_fuel: number | null;
    surcharge_adr: number | null;
    surcharge_wait: number | null;
    surcharge_other: number | null;
    other_revenue: number | null;
  };

  // 3. Récupérer les tournées sélectionnées
  const { data: tourneesRaw, error: tErr } = await supabase
    .from("tournees")
    .select(
      "id, reference, name, scheduled_date, " +
      "flat_rate_revenue, surcharge_fuel, surcharge_adr, surcharge_wait, surcharge_other, other_revenue",
    )
    .in("id", tourneeIds)
    .is("billed_invoice_id", null)
    .returns<TourneeFacturable[]>();

  if (tErr || !tourneesRaw || tourneesRaw.length === 0) {
    await setFlash({ kind: "error", message: "Aucune tournée à facturer" });
    return;
  }

  // 4. Numéro de facture auto
  const invoiceNumber = await getNextInvoiceNumber();

  // 5. Créer la facture brouillon
  const { data: inv, error: invErr } = await supabase
    .from("invoices")
    .insert({
      invoice_number:     invoiceNumber,
      issue_date:         new Date().toISOString().split("T")[0],
      period:             periode,
      invoice_type:       "transport",
      status:             "Brouillon",

      client_id:           client.id,
      client_name:         client.name,
      client_address:      client.address,
      client_postal_code:  client.postal_code,
      client_city:         client.city,
      client_email:        client.email,
      client_phone:        client.phone,
      client_rcs:          client.rcs,
      client_code_ape:     client.code_ape,
      client_id_tva:       client.id_tva,
      client_legal_form:   client.legal_form,
      client_capital:      client.capital,

      seller_name:        settings?.seller_name        ?? null,
      seller_address:     settings?.seller_address     ?? null,
      seller_postal_code: settings?.seller_postal_code ?? null,
      seller_city:        settings?.seller_city        ?? null,
      seller_email:       settings?.seller_email       ?? null,
      seller_phone:       settings?.seller_phone       ?? null,
      seller_rcs:         settings?.seller_rcs         ?? null,
      seller_code_naf:    settings?.seller_code_naf    ?? null,
      seller_tva:         settings?.seller_tva         ?? null,
      seller_legal_form:  settings?.seller_legal_form  ?? null,
      seller_capital:     settings?.seller_capital     ?? null,

      tva_rate:            tvaRate,
      payment_beneficiary: settings?.payment_beneficiary ?? null,
      payment_bic:         settings?.payment_bic         ?? null,
      payment_iban:        settings?.payment_iban        ?? null,
      compte:              settings?.compte_template     ?? null,
    })
    .select("id")
    .single();

  if (invErr || !inv) {
    await setFlash({ kind: "error", message: `Erreur création facture: ${invErr?.message}` });
    return;
  }

  // 6. Créer une ligne par tournée
  const lines = tourneesRaw.map((t, i) => {
    const flat   = t.flat_rate_revenue ?? 0;
    const sFuel  = t.surcharge_fuel    ?? 0;
    const sAdr   = t.surcharge_adr     ?? 0;
    const sWait  = t.surcharge_wait    ?? 0;
    const sOther = t.surcharge_other   ?? 0;
    const other  = t.other_revenue     ?? 0;
    const total  = flat + sFuel + sAdr + sWait + sOther + other;

    return {
      invoice_id:   inv.id,
      sort_order:   i,
      line_date:    t.scheduled_date,
      ref:          t.reference,
      exp_address:  t.name,
      dest_address: null as string | null,
      poids_kg:     null as number | null,
      qty_trips:    1,
      qty_taxable:  null as number | null,
      total_ht:     total,
      ecotaxe:      0,
    };
  });

  if (lines.length > 0) {
    const { error: lErr } = await supabase.from("invoice_lines").insert(lines);
    if (lErr) {
      await setFlash({ kind: "error", message: `Erreur lignes: ${lErr.message}` });
      // On supprime la facture vide créée
      await supabase.from("invoices").delete().eq("id", inv.id);
      return;
    }
  }

  // 7. Marquer les tournées comme facturées
  await supabase
    .from("tournees")
    .update({ billed_invoice_id: inv.id })
    .in("id", tourneeIds);

  await setFlash({ kind: "success", message: `Facture ${invoiceNumber} créée en brouillon` });
  revalidatePath("/facturation");
  revalidatePath("/facturation/prefacturation");
  redirect(`/facturation/${inv.id}`);
}

// ─── Dé-facturer (retirer le lien facture d'une tournée) ──────────────────────

export async function defacturerTournee(formData: FormData) {
  const tourneeId = formData.get("tournee_id") as string | null;
  if (!tourneeId) return;

  await supabase
    .from("tournees")
    .update({ billed_invoice_id: null })
    .eq("id", tourneeId);

  revalidatePath("/facturation/prefacturation");
}
