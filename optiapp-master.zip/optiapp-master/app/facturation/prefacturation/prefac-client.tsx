"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import {
  FileText, Loader2, ChevronDown, ChevronRight,
  CheckSquare, Square, AlertCircle, Receipt,
} from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/format";
import type { GroupeClient, TourneeAFacturer } from "@/lib/prefacturation-queries";
import { genererFactureDepuisTournees } from "./actions";

// ─── Sélecteur de période ─────────────────────────────────────────────────────

const MOIS = [
  "Janvier","Février","Mars","Avril","Mai","Juin",
  "Juillet","Août","Septembre","Octobre","Novembre","Décembre",
];

export function PeriodePicker({
  annee, mois, onChange,
}: {
  annee: number; mois: number; onChange: (a: number, m: number) => void;
}) {
  const now = new Date();
  const annees = Array.from({ length: 3 }, (_, i) => now.getFullYear() - i);

  return (
    <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <select
        value={mois}
        onChange={(e) => onChange(annee, Number(e.target.value))}
        style={{
          padding: "7px 12px", borderRadius: 8, border: "1px solid var(--border)",
          background: "var(--card)", color: "var(--foreground)", fontSize: 13,
          cursor: "pointer",
        }}
      >
        {MOIS.map((m, i) => (
          <option key={i} value={i + 1}>{m}</option>
        ))}
      </select>
      <select
        value={annee}
        onChange={(e) => onChange(Number(e.target.value), mois)}
        style={{
          padding: "7px 12px", borderRadius: 8, border: "1px solid var(--border)",
          background: "var(--card)", color: "var(--foreground)", fontSize: 13,
          cursor: "pointer",
        }}
      >
        {annees.map((a) => (
          <option key={a} value={a}>{a}</option>
        ))}
      </select>
    </div>
  );
}

// ─── Badge statut tournée ─────────────────────────────────────────────────────

const STATUT_STYLE: Record<string, { bg: string; color: string }> = {
  completed:   { bg: "#f0fdf4", color: "#16a34a" },
  in_progress: { bg: "#eff6ff", color: "#2563eb" },
  scheduled:   { bg: "#fefce8", color: "#ca8a04" },
  draft:       { bg: "#f8fafc", color: "#64748b" },
  cancelled:   { bg: "#fef2f2", color: "#dc2626" },
};

const STATUT_LABEL: Record<string, string> = {
  completed:   "Terminée",
  in_progress: "En cours",
  scheduled:   "Planifiée",
  draft:       "Brouillon",
  cancelled:   "Annulée",
};

function StatutBadge({ status }: { status: string }) {
  const s = STATUT_STYLE[status] ?? { bg: "#f8fafc", color: "#64748b" };
  return (
    <span style={{
      padding: "2px 8px", borderRadius: 12, fontSize: 11, fontWeight: 600,
      background: s.bg, color: s.color,
    }}>
      {STATUT_LABEL[status] ?? status}
    </span>
  );
}

// ─── Groupe client ─────────────────────────────────────────────────────────────

function GroupeClientRow({
  groupe,
  tvaRate,
  periode,
}: {
  groupe: GroupeClient;
  tvaRate: number;
  periode: string;
}) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [pending, startTransition] = useTransition();

  const billables = groupe.tournees.filter((t) => t.revenue_ht > 0 && !t.billed_invoice_id);
  const alreadyBilled = groupe.tournees.filter((t) => t.billed_invoice_id);

  const toggleAll = () => {
    if (selected.size === billables.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(billables.map((t) => t.id)));
    }
  };

  const toggle = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const totalSelected = billables
    .filter((t) => selected.has(t.id))
    .reduce((s, t) => s + t.revenue_ht, 0);

  const handleGenerer = () => {
    if (selected.size === 0) return;
    startTransition(async () => {
      const fd = new FormData();
      fd.append("client_id", groupe.client_id);
      fd.append("periode", periode);
      fd.append("tva_rate", String(tvaRate));
      for (const id of selected) fd.append("tournee_ids", id);
      await genererFactureDepuisTournees(fd);
    });
  };

  return (
    <div style={{
      background: "var(--card)", border: "1px solid var(--border)",
      borderRadius: 12, overflow: "hidden",
    }}>
      {/* En-tête client */}
      <div
        style={{
          display: "flex", alignItems: "center", gap: 12, padding: "14px 18px",
          cursor: "pointer", userSelect: "none",
        }}
        onClick={() => setOpen((v) => !v)}
      >
        <span style={{ color: "var(--muted-foreground)", flexShrink: 0 }}>
          {open ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
        </span>

        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{groupe.client_name}</div>
          <div style={{ fontSize: 12, color: "var(--muted-foreground)", marginTop: 2 }}>
            {groupe.nb_tournees} tournée{groupe.nb_tournees > 1 ? "s" : ""}
            {alreadyBilled.length > 0 && (
              <span style={{ marginLeft: 8, color: "#22c55e" }}>
                · {alreadyBilled.length} déjà facturée{alreadyBilled.length > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>

        <div style={{ textAlign: "right", flexShrink: 0 }}>
          <div style={{ fontWeight: 700, fontSize: 15, color: "var(--foreground)" }}>
            {formatCurrency(groupe.total_ht)}
          </div>
          <div style={{ fontSize: 11, color: "var(--muted-foreground)" }}>HT · total période</div>
        </div>
      </div>

      {/* Détail tournées */}
      {open && (
        <div style={{ borderTop: "1px solid var(--border)" }}>
          {/* Barre d'actions */}
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            padding: "10px 18px", background: "var(--muted)",
            gap: 12, flexWrap: "wrap",
          }}>
            <button
              type="button"
              onClick={toggleAll}
              style={{
                display: "flex", alignItems: "center", gap: 6,
                background: "none", border: "none", cursor: "pointer",
                color: "var(--foreground)", fontSize: 12, fontWeight: 500,
              }}
            >
              {selected.size === billables.length && billables.length > 0
                ? <CheckSquare size={15} />
                : <Square size={15} />}
              {selected.size === billables.length && billables.length > 0
                ? "Tout désélectionner"
                : "Tout sélectionner"}
            </button>

            {selected.size > 0 && (
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 12, color: "var(--muted-foreground)" }}>
                  {selected.size} sélectionnée{selected.size > 1 ? "s" : ""} · {formatCurrency(totalSelected)} HT
                </span>
                <button
                  type="button"
                  onClick={handleGenerer}
                  disabled={pending}
                  style={{
                    display: "flex", alignItems: "center", gap: 6,
                    padding: "6px 14px", borderRadius: 8, border: "none",
                    background: "var(--primary)", color: "var(--primary-foreground)",
                    fontWeight: 600, fontSize: 12, cursor: pending ? "not-allowed" : "pointer",
                    opacity: pending ? 0.7 : 1,
                  }}
                >
                  {pending ? <Loader2 size={13} className="animate-spin" /> : <Receipt size={13} />}
                  Générer facture
                </button>
              </div>
            )}
          </div>

          {/* Tableau des tournées */}
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr style={{ background: "var(--muted)" }}>
                  <th style={{ width: 36, padding: "8px 12px" }} />
                  <th style={{ padding: "8px 12px", textAlign: "left", fontWeight: 600, color: "var(--muted-foreground)", fontSize: 11 }}>DATE</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", fontWeight: 600, color: "var(--muted-foreground)", fontSize: 11 }}>RÉFÉRENCE</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", fontWeight: 600, color: "var(--muted-foreground)", fontSize: 11 }}>NOM</th>
                  <th style={{ padding: "8px 12px", textAlign: "left", fontWeight: 600, color: "var(--muted-foreground)", fontSize: 11 }}>STATUT</th>
                  <th style={{ padding: "8px 12px", textAlign: "right", fontWeight: 600, color: "var(--muted-foreground)", fontSize: 11 }}>MONTANT HT</th>
                  <th style={{ padding: "8px 12px", textAlign: "center", fontWeight: 600, color: "var(--muted-foreground)", fontSize: 11 }}>FACTURE</th>
                </tr>
              </thead>
              <tbody>
                {groupe.tournees.map((t) => (
                  <TourneeRow
                    key={t.id}
                    tournee={t}
                    checked={selected.has(t.id)}
                    onToggle={() => toggle(t.id)}
                    disabled={!!t.billed_invoice_id || t.revenue_ht === 0}
                  />
                ))}
              </tbody>
            </table>
          </div>

          {billables.length === 0 && alreadyBilled.length === 0 && (
            <div style={{
              padding: "16px 18px", color: "var(--muted-foreground)", fontSize: 13,
              display: "flex", alignItems: "center", gap: 8,
            }}>
              <AlertCircle size={14} />
              Aucune tournée avec montant renseigné pour cette période.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function TourneeRow({
  tournee, checked, onToggle, disabled,
}: {
  tournee: TourneeAFacturer;
  checked: boolean;
  onToggle: () => void;
  disabled: boolean;
}) {
  return (
    <tr
      style={{
        borderTop: "1px solid var(--border)",
        background: checked ? "oklch(0.97 0.01 250 / 0.5)" : "transparent",
        opacity: disabled && !tournee.billed_invoice_id ? 0.5 : 1,
      }}
    >
      <td style={{ padding: "9px 12px", textAlign: "center" }}>
        {!tournee.billed_invoice_id && (
          <button
            type="button"
            onClick={onToggle}
            disabled={disabled}
            style={{
              background: "none", border: "none", cursor: disabled ? "default" : "pointer",
              color: checked ? "var(--primary)" : "var(--muted-foreground)",
              display: "inline-flex", alignItems: "center",
            }}
          >
            {checked ? <CheckSquare size={15} /> : <Square size={15} />}
          </button>
        )}
      </td>
      <td style={{ padding: "9px 12px", color: "var(--muted-foreground)" }}>
        {formatDate(tournee.scheduled_date)}
      </td>
      <td style={{ padding: "9px 12px", fontFamily: "monospace", fontSize: 12 }}>
        {tournee.reference}
      </td>
      <td style={{ padding: "9px 12px" }}>{tournee.name}</td>
      <td style={{ padding: "9px 12px" }}>
        <StatutBadge status={tournee.status} />
      </td>
      <td style={{ padding: "9px 12px", textAlign: "right", fontWeight: 600 }}>
        {tournee.revenue_ht > 0 ? formatCurrency(tournee.revenue_ht) : (
          <span style={{ color: "var(--muted-foreground)", fontWeight: 400, fontSize: 12 }}>
            Non renseigné
          </span>
        )}
      </td>
      <td style={{ padding: "9px 12px", textAlign: "center" }}>
        {tournee.billed_invoice_id ? (
          <Link
            href={`/facturation/${tournee.billed_invoice_id}`}
            style={{
              display: "inline-flex", alignItems: "center", gap: 4,
              fontSize: 11, color: "#16a34a", fontWeight: 600,
              textDecoration: "none",
            }}
          >
            <FileText size={13} /> Voir
          </Link>
        ) : (
          <span style={{ fontSize: 11, color: "var(--muted-foreground)" }}>—</span>
        )}
      </td>
    </tr>
  );
}

// ─── Composant principal ───────────────────────────────────────────────────────

export function PrefacClient({
  groupes,
  totalHT,
  nbClients,
  nbTournees,
  tvaRate,
  anneeInit,
  moisInit,
}: {
  groupes: GroupeClient[];
  totalHT: number;
  nbClients: number;
  nbTournees: number;
  tvaRate: number;
  anneeInit: number;
  moisInit: number;
}) {
  const [annee, setAnnee] = useState(anneeInit);
  const [mois, setMois] = useState(moisInit);
  const [afficherFacturees, setAfficherFacturees] = useState(false);
  const [pending, startTransition] = useTransition();

  const handlePeriodeChange = (a: number, m: number) => {
    startTransition(() => {
      setAnnee(a);
      setMois(m);
      // Rechargement côté serveur via URL
      window.location.href =
        `/facturation/prefacturation?annee=${a}&mois=${m}&facturees=${afficherFacturees ? "1" : "0"}`;
    });
  };

  const toggleFacturees = () => {
    const next = !afficherFacturees;
    setAfficherFacturees(next);
    window.location.href =
      `/facturation/prefacturation?annee=${annee}&mois=${mois}&facturees=${next ? "1" : "0"}`;
  };

  const moisLabel = new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric" })
    .format(new Date(annee, mois - 1));

  const periode = `${annee}-${String(mois).padStart(2, "0")}`;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Contrôles période */}
      <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
        <PeriodePicker annee={annee} mois={mois} onChange={handlePeriodeChange} />
        <label style={{
          display: "flex", alignItems: "center", gap: 6,
          fontSize: 13, color: "var(--muted-foreground)", cursor: "pointer",
        }}>
          <input
            type="checkbox"
            checked={afficherFacturees}
            onChange={toggleFacturees}
            style={{ cursor: "pointer" }}
          />
          Afficher les tournées déjà facturées
        </label>
        {pending && <Loader2 size={14} className="animate-spin" style={{ color: "var(--muted-foreground)" }} />}
      </div>

      {/* KPIs */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0,1fr))", gap: 12 }}>
        <KpiMini
          label="À facturer (HT)"
          value={formatCurrency(totalHT)}
          sub={`${MOIS[mois - 1]} ${annee}`}
          accent="#3b82f6"
        />
        <KpiMini
          label="Clients concernés"
          value={String(nbClients)}
          sub="avec tournées non facturées"
          accent="#8b5cf6"
        />
        <KpiMini
          label="Tournées"
          value={String(nbTournees)}
          sub="à inclure dans factures"
          accent="#f59e0b"
        />
      </div>

      {/* Groupes clients */}
      {groupes.length === 0 ? (
        <div style={{
          background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12,
          padding: "40px 24px", textAlign: "center",
          color: "var(--muted-foreground)", fontSize: 14,
        }}>
          <AlertCircle size={28} style={{ marginBottom: 12, opacity: 0.5 }} />
          <div style={{ fontWeight: 600, marginBottom: 6 }}>
            Aucune tournée à pré-facturer pour {moisLabel}
          </div>
          <div style={{ fontSize: 12 }}>
            Associez des clients aux tournées depuis le planning, puis définissez leurs tarifs.
          </div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {groupes.map((g) => (
            <GroupeClientRow
              key={g.client_id}
              groupe={g}
              tvaRate={tvaRate}
              periode={periode}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function KpiMini({ label, value, sub, accent }: {
  label: string; value: string; sub: string; accent: string;
}) {
  return (
    <div style={{
      background: "var(--card)", border: "1px solid var(--border)", borderRadius: 12,
      padding: "16px 18px", display: "flex", flexDirection: "column", gap: 6,
    }}>
      <span style={{ fontSize: 11, fontWeight: 600, color: "var(--muted-foreground)", textTransform: "uppercase", letterSpacing: "0.06em" }}>
        {label}
      </span>
      <span style={{ fontSize: 22, fontWeight: 700, color: accent }}>{value}</span>
      <span style={{ fontSize: 11, color: "var(--muted-foreground)" }}>{sub}</span>
    </div>
  );
}
