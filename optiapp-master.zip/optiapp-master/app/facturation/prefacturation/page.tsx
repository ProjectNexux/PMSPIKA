import Link from "next/link";
import { ArrowLeft, Receipt } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { requireUser } from "@/lib/session";
import {
  getTourneesAFacturer,
  grouperParClient,
  computePrefacKpis,
} from "@/lib/prefacturation-queries";
import { PrefacClient } from "./prefac-client";
import { supabase } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function PrefactuationPage({
  searchParams,
}: {
  searchParams: Promise<{ annee?: string; mois?: string; facturees?: string }>;
}) {
  await requireUser();

  const params = await searchParams;
  const now = new Date();
  const annee = params.annee ? parseInt(params.annee, 10) : now.getFullYear();
  const mois  = params.mois  ? parseInt(params.mois,  10) : now.getMonth() + 1;
  const afficherFacturees = params.facturees === "1";

  // Plage de dates du mois sélectionné
  const dateDebut = `${annee}-${String(mois).padStart(2, "0")}-01`;
  const dernierJour = new Date(annee, mois, 0).getDate();
  const dateFin   = `${annee}-${String(mois).padStart(2, "0")}-${String(dernierJour).padStart(2, "0")}`;

  // Récupérer les tournées à facturer
  const tournees = await getTourneesAFacturer(dateDebut, dateFin, !afficherFacturees);
  const groupes  = grouperParClient(tournees);
  const { totalHT, nbClients, nbTournees } = computePrefacKpis(groupes);

  // Taux TVA depuis les paramètres
  const { data: settings } = await supabase
    .from("invoice_settings")
    .select("tva_rate")
    .limit(1)
    .single();
  const tvaRate = settings?.tva_rate ?? 20;

  return (
    <main className="page">
      <PageHeader eyebrow="FACTURATION" title="Pré-facturation">
        <Link href="/facturation" className="btn-secondary" style={{ gap: 6 }}>
          <ArrowLeft size={14} /> Retour
        </Link>
        <div style={{
          display: "flex", alignItems: "center", gap: 6,
          padding: "6px 14px", borderRadius: 8, background: "var(--muted)",
          fontSize: 12, color: "var(--muted-foreground)",
        }}>
          <Receipt size={14} />
          Sélectionnez les tournées et générez les factures brouillon en un clic
        </div>
      </PageHeader>

      <PrefacClient
        groupes={groupes}
        totalHT={totalHT}
        nbClients={nbClients}
        nbTournees={nbTournees}
        tvaRate={tvaRate}
        anneeInit={annee}
        moisInit={mois}
      />
    </main>
  );
}
