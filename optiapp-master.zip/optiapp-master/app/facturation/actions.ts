"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";
import { supabase } from "@/lib/db";
import { parseFormData, zNonEmpty, zOptional } from "@/lib/validation";
import { setFlash } from "@/lib/flash";

// ─── Helpers ────────────────────────────────────────────────────────────────

function str(formData: FormData, key: string) {
  const v = formData.get(key);
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

function num(formData: FormData, key: string) {
  const v = str(formData, key);
  if (!v) return null;
  const n = parseFloat(v.replace(",", "."));
  return isNaN(n) ? null : n;
}

function numDef(formData: FormData, key: string, def: number) {
  return num(formData, key) ?? def;
}

// ─── Schémas ────────────────────────────────────────────────────────────────

// ─── SIRET lookup (API Recherche Entreprises — data.gouv.fr) ─────────────────

export type SiretLookupResult =
  | {
      ok: true;
      data: {
        name: string;
        address: string;
        postal_code: string;
        city: string;
        code_ape: string;
        legal_form: string;
        id_tva: string;
        rcs: string;
        siren: string;
      };
    }
  | { ok: false; error: string };

export async function lookupSiret(siret: string): Promise<SiretLookupResult> {
  const clean = siret.replace(/[\s.]/g, "");
  if (!/^\d{14}$/.test(clean)) {
    return { ok: false, error: "Le SIRET doit contenir 14 chiffres" };
  }

  try {
    const res = await fetch(
      `https://recherche-entreprises.api.gouv.fr/search?q=${clean}&per_page=1`,
      { next: { revalidate: 3600 } },
    );
    if (!res.ok) return { ok: false, error: "Service gouvernemental indisponible" };

    const json = await res.json() as {
      results?: Array<{
        nom_complet?: string;
        siren?: string;
        categorie_juridique_libelle?: string;
        siege?: {
          siret?: string;
          adresse?: string;
          code_postal?: string;
          commune?: string;
          activite_principale?: string;
        };
      }>;
    };

    const result = json.results?.[0];
    if (!result) return { ok: false, error: "SIRET introuvable" };

    const siege = result.siege ?? {};
    const siren = result.siren ?? clean.slice(0, 9);

    // Clé TVA intracommunautaire : (12 + 3 × (SIREN % 97)) % 97
    const sirenNum = parseInt(siren, 10);
    const tvaKey = ((12 + 3 * (sirenNum % 97)) % 97).toString().padStart(2, "0");
    const idTva = `FR${tvaKey}${siren}`;

    return {
      ok: true,
      data: {
        name:        result.nom_complet ?? "",
        address:     siege.adresse ?? "",
        postal_code: siege.code_postal ?? "",
        city:        siege.commune ?? "",
        code_ape:    siege.activite_principale ?? "",
        legal_form:  result.categorie_juridique_libelle ?? "",
        id_tva:      idTva,
        rcs:         siren,
        siren,
      },
    };
  } catch {
    return { ok: false, error: "Erreur réseau" };
  }
}

const ClientSchema = z.object({
  name:       zNonEmpty,
  address:    zOptional,
  postal_code: zOptional,
  city:       zOptional,
  email:      zOptional,
  phone:      zOptional,
  rcs:        zOptional,
  code_ape:   zOptional,
  id_tva:     zOptional,
  legal_form: zOptional,
  iban:       zOptional,
  bic:        zOptional,
  notes:      zOptional,
});

// ─── Actions clients ─────────────────────────────────────────────────────────

export async function createInvoiceClient(formData: FormData) {
  const parsed = parseFormData(ClientSchema, formData);
  if (!parsed.ok) {
    await setFlash({ kind: "error", message: parsed.ok === false ? parsed.error : "Erreur" });
    revalidatePath("/facturation/clients");
    return;
  }

  const capital = num(formData, "capital");
  const { error } = await supabase.from("invoice_clients").insert({
    ...parsed.data,
    capital: capital ?? null,
  });

  if (error) {
    await setFlash({ kind: "error", message: `Erreur: ${error.message}` });
  } else {
    await setFlash({ kind: "success", message: "Client enregistré" });
  }
  revalidatePath("/facturation/clients");
  redirect("/facturation/clients");
}

export async function updateInvoiceClient(formData: FormData) {
  const id = str(formData, "id");
  if (!id) { await setFlash({ kind: "error", message: "ID manquant" }); return; }

  const parsed = parseFormData(ClientSchema, formData);
  if (!parsed.ok) { await setFlash({ kind: "error", message: parsed.ok === false ? parsed.error : "Erreur" }); return; }

  const capital = num(formData, "capital");
  const { error } = await supabase.from("invoice_clients").update({
    ...parsed.data,
    capital: capital ?? null,
  }).eq("id", id);

  if (error) {
    await setFlash({ kind: "error", message: `Erreur: ${error.message}` });
  } else {
    await setFlash({ kind: "success", message: "Client mis à jour" });
  }
  revalidatePath("/facturation/clients");
  redirect("/facturation/clients");
}

export async function deleteInvoiceClient(formData: FormData) {
  const id = str(formData, "id");
  if (!id) return;
  await supabase.from("invoice_clients").delete().eq("id", id);
  await setFlash({ kind: "success", message: "Client supprimé" });
  revalidatePath("/facturation/clients");
}

// ─── Actions factures ────────────────────────────────────────────────────────

export async function createInvoice(formData: FormData) {
  // 1. Infos de base
  const invoiceNumber = str(formData, "invoice_number");
  const clientName = str(formData, "client_name");
  if (!invoiceNumber || !clientName) {
    await setFlash({ kind: "error", message: "Numéro de facture et client obligatoires" });
    redirect("/facturation/nouvelle");
  }

  const invoiceData = {
    invoice_number:     invoiceNumber,
    issue_date:         str(formData, "issue_date") ?? new Date().toISOString().split("T")[0],
    period:             str(formData, "period"),
    driver_name:        str(formData, "driver_name"),
    vehicle_plate:      str(formData, "vehicle_plate"),

    client_id:          str(formData, "client_id"),
    client_name:        clientName!,
    client_address:     str(formData, "client_address"),
    client_postal_code: str(formData, "client_postal_code"),
    client_city:        str(formData, "client_city"),
    client_email:       str(formData, "client_email"),
    client_phone:       str(formData, "client_phone"),
    client_rcs:         str(formData, "client_rcs"),
    client_code_ape:    str(formData, "client_code_ape"),
    client_id_tva:      str(formData, "client_id_tva"),
    client_legal_form:  str(formData, "client_legal_form"),
    client_capital:     num(formData, "client_capital"),

    seller_name:        str(formData, "seller_name"),
    seller_address:     str(formData, "seller_address"),
    seller_postal_code: str(formData, "seller_postal_code"),
    seller_city:        str(formData, "seller_city"),
    seller_email:       str(formData, "seller_email"),
    seller_phone:       str(formData, "seller_phone"),
    seller_rcs:         str(formData, "seller_rcs"),
    seller_code_naf:    str(formData, "seller_code_naf"),
    seller_tva:         str(formData, "seller_tva"),
    seller_legal_form:  str(formData, "seller_legal_form"),
    seller_capital:     num(formData, "seller_capital"),

    compte:             str(formData, "compte"),
    tva_rate:           numDef(formData, "tva_rate", 20),
    image_rights_rate:  numDef(formData, "image_rights_rate", 1),
    invoice_type:       str(formData, "invoice_type") ?? "transport",

    payment_beneficiary: str(formData, "payment_beneficiary"),
    payment_bic:         str(formData, "payment_bic"),
    payment_iban:        str(formData, "payment_iban"),

    status: "Brouillon",
    notes:  str(formData, "notes"),
  };

  const { data: inv, error: invError } = await supabase
    .from("invoices")
    .insert(invoiceData)
    .select("id")
    .single();

  if (invError || !inv) {
    await setFlash({ kind: "error", message: `Erreur création: ${invError?.message}` });
    redirect("/facturation");
  }

  // 2. Lignes
  const linesRaw = formData.getAll("lines");
  if (linesRaw.length > 0) {
    type LineInput = {
      line_date: string | null;
      ref: string | null;
      exp_address: string | null;
      dest_address: string | null;
      poids_kg: number | null;
      qty_trips: number | null;
      qty_taxable: number | null;
      total_ht: number;
      ecotaxe: number;
      // Location fields
      rental_start_date?: string | null;
      rental_end_date?: string | null;
      qty_days?: number | null;
      unit_price?: number | null;
    };
    const linesToInsert: (LineInput & { invoice_id: string; sort_order: number })[] = [];

    // Les lignes arrivent encodées en JSON dans un seul champ "lines"
    try {
      const parsed = JSON.parse(linesRaw[0] as string) as LineInput[];
      parsed.forEach((l, i) => {
        linesToInsert.push({ ...l, invoice_id: inv!.id, sort_order: i });
      });
    } catch {
      // Format fallback : champs individuels line_0_ref, line_0_total_ht, etc.
      let i = 0;
      while (formData.has(`line_${i}_total_ht`)) {
        linesToInsert.push({
          invoice_id:   inv!.id,
          sort_order:   i,
          line_date:    str(formData, `line_${i}_date`),
          ref:          str(formData, `line_${i}_ref`),
          exp_address:  str(formData, `line_${i}_exp`),
          dest_address: str(formData, `line_${i}_dest`),
          poids_kg:     num(formData, `line_${i}_poids`),
          qty_trips:    num(formData, `line_${i}_qty_trips`),
          qty_taxable:  num(formData, `line_${i}_qty_taxable`),
          total_ht:     numDef(formData, `line_${i}_total_ht`, 0),
          ecotaxe:      numDef(formData, `line_${i}_ecotaxe`, 0),
        });
        i++;
      }
    }

    if (linesToInsert.length > 0) {
      await supabase.from("invoice_lines").insert(linesToInsert);
    }
  }

  await setFlash({ kind: "success", message: `Facture ${invoiceNumber} créée` });
  revalidatePath("/facturation");
  redirect(`/facturation/${inv!.id}`);
}

export async function updateInvoiceStatus(formData: FormData) {
  const id = str(formData, "id");
  const status = str(formData, "status");
  if (!id || !status) return;

  const { error } = await supabase.from("invoices").update({ status }).eq("id", id);
  if (error) {
    await setFlash({ kind: "error", message: `Erreur: ${error.message}` });
  } else {
    await setFlash({ kind: "success", message: `Statut mis à jour: ${status}` });
  }
  revalidatePath("/facturation");
  revalidatePath(`/facturation/${id}`);
}

export async function deleteInvoice(formData: FormData) {
  const id = str(formData, "id");
  if (!id) return;
  await supabase.from("invoices").delete().eq("id", id);
  await setFlash({ kind: "success", message: "Facture supprimée" });
  revalidatePath("/facturation");
  redirect("/facturation");
}

export async function duplicateInvoice(formData: FormData) {
  const id = str(formData, "id");
  const newNumber = str(formData, "new_number");
  if (!id || !newNumber) { await setFlash({ kind: "error", message: "ID ou numéro manquant" }); return; }

  const { data: src, error: srcErr } = await supabase
    .from("invoices")
    .select("*, invoice_lines(*)")
    .eq("id", id)
    .single();

  if (srcErr || !src) { await setFlash({ kind: "error", message: "Facture introuvable" }); return; }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { id: _id, created_at, updated_at, invoice_lines, ...rest } = src as Record<string, unknown> & {
    id: string; created_at: string; updated_at: string;
    invoice_lines: Array<Record<string, unknown> & { id: string; invoice_id: string; created_at: string }>;
  };

  const { data: newInv, error: newErr } = await supabase
    .from("invoices")
    .insert({ ...rest, invoice_number: newNumber, status: "Brouillon" })
    .select("id")
    .single();

  if (newErr || !newInv) { await setFlash({ kind: "error", message: "Erreur duplication" }); return; }

  const newLines = (invoice_lines ?? []).map(
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    ({ id: _lid, invoice_id: _iid, created_at: _ca, ...l }) => ({
      ...l,
      invoice_id: newInv.id,
    }),
  );
  if (newLines.length > 0) await supabase.from("invoice_lines").insert(newLines);

  await setFlash({ kind: "success", message: `Facture ${newNumber} créée` });
  revalidatePath("/facturation");
  redirect(`/facturation/${newInv.id}`);
}

// ─── Paramètres de facturation ───────────────────────────────────────────────

export async function saveInvoiceSettings(formData: FormData) {
  const settings = {
    seller_name:         str(formData, "seller_name")         ?? "",
    seller_address:      str(formData, "seller_address")      ?? "",
    seller_postal_code:  str(formData, "seller_postal_code")  ?? "",
    seller_city:         str(formData, "seller_city")         ?? "",
    seller_email:        str(formData, "seller_email")        ?? "",
    seller_phone:        str(formData, "seller_phone")        ?? "",
    seller_rcs:          str(formData, "seller_rcs")          ?? "",
    seller_code_naf:     str(formData, "seller_code_naf")     ?? "",
    seller_tva:          str(formData, "seller_tva")          ?? "",
    seller_legal_form:   str(formData, "seller_legal_form")   ?? "",
    seller_capital:      num(formData, "seller_capital"),
    invoice_prefix:      str(formData, "invoice_prefix")      ?? "EUR",
    tva_rate:            numDef(formData, "tva_rate", 20),
    payment_beneficiary: str(formData, "payment_beneficiary") ?? "",
    payment_bic:         str(formData, "payment_bic")         ?? "",
    payment_iban:        str(formData, "payment_iban")        ?? "",
    compte_template:     str(formData, "compte_template")     ?? "",
  };

  // Upsert : une seule ligne dans invoice_settings
  const existingId = str(formData, "settings_id");

  if (existingId) {
    const { error } = await supabase.from("invoice_settings").update(settings).eq("id", existingId);
    if (error) { await setFlash({ kind: "error", message: `Erreur: ${error.message}` }); }
    else { await setFlash({ kind: "success", message: "Paramètres enregistrés" }); }
  } else {
    const { error } = await supabase.from("invoice_settings").insert(settings);
    if (error) { await setFlash({ kind: "error", message: `Erreur: ${error.message}` }); }
    else { await setFlash({ kind: "success", message: "Paramètres enregistrés" }); }
  }

  revalidatePath("/facturation/parametres");
  revalidatePath("/facturation/nouvelle");
  redirect("/facturation/parametres");
}
