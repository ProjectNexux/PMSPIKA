import { PageHeader } from "@/components/page-header";
import { listInvoiceClients, getNextInvoiceNumber, getInvoiceSettings } from "@/lib/invoice-queries";
import { getDriverOptions, getTmsVehicleOptionsByCompany } from "@/lib/queries";
import { requireUser } from "@/lib/session";
import { createInvoice } from "@/app/facturation/actions";
import { InvoiceForm } from "./invoice-form";

export const dynamic = "force-dynamic";

export default async function NouvelleFacturePage({
  searchParams,
}: {
  searchParams: Promise<{
    ref?: string;
    driver?: string;
    vehicle?: string;
    date?: string;
    price?: string;
    client?: string;
    origin?: string;
    dest?: string;
  }>;
}) {
  const user = await requireUser();
  const cid = user.company_id ?? "";
  const sp = await searchParams;

  const [clients, nextNumber, settings, drivers, vehicles] = await Promise.all([
    listInvoiceClients(),
    getNextInvoiceNumber(),
    getInvoiceSettings(),
    getDriverOptions(),
    getTmsVehicleOptionsByCompany(cid),
  ]);

  const fromMission = (sp.ref || sp.driver || sp.vehicle || sp.date || sp.price || sp.client || sp.origin || sp.dest)
    ? {
        ref:     sp.ref,
        driver:  sp.driver,
        vehicle: sp.vehicle,
        date:    sp.date,
        price:   sp.price,
        client:  sp.client,
        origin:  sp.origin,
        dest:    sp.dest,
      }
    : undefined;

  return (
    <main className="page">
      <PageHeader eyebrow="Facturation" title="Nouvelle facture" />
      <InvoiceForm
        clients={clients}
        nextNumber={nextNumber}
        settings={settings}
        createAction={createInvoice}
        drivers={drivers}
        vehicles={vehicles}
        fromMission={fromMission}
      />
    </main>
  );
}
