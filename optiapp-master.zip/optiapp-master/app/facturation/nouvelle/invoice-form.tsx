"use client";

import { useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Plus, Trash2, Search, Loader2, Truck, Car, ChevronDown, ChevronUp, FileText } from "lucide-react";
import type { InvoiceClient, InvoiceSettings } from "@/lib/invoice-queries";
import { computeInvoiceTotals } from "@/lib/invoice-queries";
import { lookupSiret } from "@/app/facturation/actions";

// ─── Types ────────────────────────────────────────────────────────────────────

type Line = {
  id: string;
  line_date: string;
  ref: string;
  exp_address: string;
  dest_address: string;
  poids_kg: string;
  qty_trips: string;
  qty_taxable: string;
  total_ht: string;
  ecotaxe: string;
};

type RentalLine = {
  id: string;
  ref: string;              // immatriculation + description
  rental_start_date: string;
  rental_end_date: string;
  qty_days: string;
  unit_price: string;       // prix/jour
  total_ht: string;
};

type SellerInfo = {
  name: string;
  address: string;
  postal_code: string;
  city: string;
  email: string;
  phone: string;
  rcs: string;
  code_naf: string;
  tva: string;
  legal_form: string;
  capital: string;
};

function makeId() {
  return Math.random().toString(36).slice(2);
}

function emptyLine(): Line {
  return {
    id: makeId(),
    line_date: new Date().toISOString().split("T")[0],
    ref: "",
    exp_address: "",
    dest_address: "",
    poids_kg: "",
    qty_trips: "",
    qty_taxable: "",
    total_ht: "",
    ecotaxe: "0",
  };
}

function emptyRentalLine(): RentalLine {
  const today = new Date().toISOString().split("T")[0];
  return {
    id: makeId(),
    ref: "",
    rental_start_date: today,
    rental_end_date: today,
    qty_days: "1",
    unit_price: "",
    total_ht: "0",
  };
}

// ─── Props ────────────────────────────────────────────────────────────────────

type DriverOpt  = { id: string; full_name: string };
type VehicleOpt = { id: string; plate_number: string; brand: string; model: string };

type FromMission = {
  ref?: string;
  driver?: string;
  vehicle?: string;
  date?: string;
  price?: string;
  client?: string;
  origin?: string;
  dest?: string;
};

type Props = {
  clients: InvoiceClient[];
  nextNumber: string;
  settings: InvoiceSettings;
  createAction: (formData: FormData) => Promise<void>;
  drivers?: DriverOpt[];
  vehicles?: VehicleOpt[];
  fromMission?: FromMission;
};

// ─── Composant ────────────────────────────────────────────────────────────────

export function InvoiceForm({ clients, nextNumber, settings, createAction, drivers, vehicles, fromMission }: Props) {
  const router = useRouter();

  // En-tête
  const [invoiceType, setInvoiceType] = useState<"transport" | "location">("transport");
  const [invoiceNumber, setInvoiceNumber] = useState(nextNumber);
  const [issueDate, setIssueDate] = useState(fromMission?.date ?? new Date().toISOString().split("T")[0]);
  const [period, setPeriod] = useState("");
  const [driverName, setDriverName] = useState(fromMission?.driver ?? "");
  const [vehiclePlate, setVehiclePlate] = useState(fromMission?.vehicle ?? "");

  // Seller (pré-rempli depuis les paramètres)
  const [seller, setSeller] = useState<SellerInfo>({
    name:       settings.seller_name,
    address:    settings.seller_address,
    postal_code: settings.seller_postal_code,
    city:       settings.seller_city,
    email:      settings.seller_email,
    phone:      settings.seller_phone,
    rcs:        settings.seller_rcs,
    code_naf:   settings.seller_code_naf,
    tva:        settings.seller_tva,
    legal_form: settings.seller_legal_form,
    capital:    settings.seller_capital?.toString() ?? "",
  });
  const [sellerExpanded, setSellerExpanded] = useState(false);

  // Client — pré-rempli depuis la mission si disponible
  const [selectedClientId, setSelectedClientId] = useState<string>(() => {
    if (!fromMission?.client) return "";
    const found = clients.find((c) => c.name.toLowerCase() === fromMission.client!.toLowerCase());
    return found?.id ?? "";
  });
  const [client, setClient] = useState(() => {
    if (!fromMission?.client) return { name: "", address: "", postal_code: "", city: "", email: "", phone: "", rcs: "", code_ape: "", id_tva: "", legal_form: "", capital: "" };
    const found = clients.find((c) => c.name.toLowerCase() === fromMission.client!.toLowerCase());
    if (found) return {
      name: found.name, address: found.address ?? "", postal_code: found.postal_code ?? "",
      city: found.city ?? "", email: found.email ?? "", phone: found.phone ?? "",
      rcs: found.rcs ?? "", code_ape: found.code_ape ?? "", id_tva: found.id_tva ?? "",
      legal_form: found.legal_form ?? "", capital: found.capital?.toString() ?? "",
    };
    return { name: fromMission.client, address: "", postal_code: "", city: "", email: "", phone: "", rcs: "", code_ape: "", id_tva: "", legal_form: "", capital: "" };
  });

  // SIRET lookup
  const [siretInput, setSiretInput] = useState("");
  const [siretLoading, setSiretLoading] = useState(false);
  const [siretError, setSiretError] = useState("");

  const handleSiretLookup = useCallback(async () => {
    const raw = siretInput.replace(/[\s.]/g, "");
    if (!raw) return;
    setSiretLoading(true);
    setSiretError("");
    const result = await lookupSiret(raw);
    setSiretLoading(false);
    if (result.ok === false) {
      setSiretError(result.error);
      return;
    }
    const d = result.data;
    setClient((c) => ({
      ...c,
      name:        d.name        || c.name,
      address:     d.address     || c.address,
      postal_code: d.postal_code || c.postal_code,
      city:        d.city        || c.city,
      code_ape:    d.code_ape    || c.code_ape,
      legal_form:  d.legal_form  || c.legal_form,
      id_tva:      d.id_tva      || c.id_tva,
      rcs:         d.siren       || c.rcs,
    }));
    setSiretError("");
  }, [siretInput]);

  // Lignes — pré-rempli depuis la mission si disponible
  const [lines, setLines] = useState<Line[]>(() => [{
    ...emptyLine(),
    exp_address:  fromMission?.origin  ?? "",
    dest_address: fromMission?.dest    ?? "",
    total_ht:     fromMission?.price   ?? "",
  }]);
  const [rentalLines, setRentalLines] = useState<RentalLine[]>([emptyRentalLine()]);

  // Finance
  const [tvaRate, setTvaRate] = useState(settings.tva_rate);
  const [compte, setCompte] = useState(settings.compte_template);
  const [payBeneficiary, setPayBeneficiary] = useState(settings.payment_beneficiary);
  const [payBic, setPayBic] = useState(settings.payment_bic);
  const [payIban, setPayIban] = useState(settings.payment_iban);
  const [notes, setNotes] = useState("");

  const [pending, setPending] = useState(false);

  // Remplir client depuis la liste
  const handleClientSelect = useCallback(
    (clientId: string) => {
      setSelectedClientId(clientId);
      const found = clients.find((c) => c.id === clientId);
      if (found) {
        setClient({
          name: found.name,
          address: found.address ?? "",
          postal_code: found.postal_code ?? "",
          city: found.city ?? "",
          email: found.email ?? "",
          phone: found.phone ?? "",
          rcs: found.rcs ?? "",
          code_ape: found.code_ape ?? "",
          id_tva: found.id_tva ?? "",
          legal_form: found.legal_form ?? "",
          capital: found.capital?.toString() ?? "",
        });
      }
    },
    [clients],
  );

  // Gestion lignes transport
  const addLine = () => setLines((prev) => [...prev, emptyLine()]);
  const removeLine = (id: string) => setLines((prev) => prev.filter((l) => l.id !== id));
  const updateLine = (id: string, field: keyof Line, value: string) => {
    setLines((prev) => prev.map((l) => (l.id === id ? { ...l, [field]: value } : l)));
  };

  // Gestion lignes location
  const addRentalLine = () => setRentalLines((prev) => [...prev, emptyRentalLine()]);
  const removeRentalLine = (id: string) => setRentalLines((prev) => prev.filter((l) => l.id !== id));
  const updateRentalLine = (id: string, field: keyof RentalLine, value: string) => {
    setRentalLines((prev) =>
      prev.map((l) => {
        if (l.id !== id) return l;
        const updated = { ...l, [field]: value };
        // Recalcul automatique du total selon les jours/prix
        if (field === "qty_days" || field === "unit_price") {
          const days = parseFloat(field === "qty_days" ? value : updated.qty_days) || 0;
          const price = parseFloat(field === "unit_price" ? value : updated.unit_price) || 0;
          updated.total_ht = (days * price).toFixed(2);
        }
        // Recalcul des jours depuis les dates
        if (field === "rental_start_date" || field === "rental_end_date") {
          const start = new Date(field === "rental_start_date" ? value : updated.rental_start_date);
          const end = new Date(field === "rental_end_date" ? value : updated.rental_end_date);
          const days = Math.max(1, Math.ceil((end.getTime() - start.getTime()) / 86_400_000) + 1);
          updated.qty_days = String(days);
          const price = parseFloat(updated.unit_price) || 0;
          updated.total_ht = (days * price).toFixed(2);
        }
        return updated;
      }),
    );
  };

  // Totaux live
  const parsedLines = (invoiceType === "transport" ? lines : rentalLines).map((l) => ({
    total_ht: parseFloat(l.total_ht) || 0,
    ecotaxe:  invoiceType === "transport" ? parseFloat((l as Line).ecotaxe) || 0 : 0,
  }));
  const { montantHT, ecotaxeTotal, tva, montantTTC } = computeInvoiceTotals(
    parsedLines, tvaRate,
  );

  // Soumission
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setPending(true);
    const fd = new FormData();

    // Header
    fd.set("invoice_number",  invoiceNumber);
    fd.set("invoice_type",    invoiceType);
    fd.set("issue_date",      issueDate);
    fd.set("period",          period);
    fd.set("driver_name",     driverName);
    fd.set("vehicle_plate",   vehiclePlate);

    // Seller
    fd.set("seller_name",        seller.name);
    fd.set("seller_address",     seller.address);
    fd.set("seller_postal_code", seller.postal_code);
    fd.set("seller_city",        seller.city);
    fd.set("seller_email",       seller.email);
    fd.set("seller_phone",       seller.phone);
    fd.set("seller_rcs",         seller.rcs);
    fd.set("seller_code_naf",    seller.code_naf);
    fd.set("seller_tva",         seller.tva);
    fd.set("seller_legal_form",  seller.legal_form);
    fd.set("seller_capital",     seller.capital);

    // Client
    if (selectedClientId) fd.set("client_id", selectedClientId);
    fd.set("client_name",         client.name);
    fd.set("client_address",      client.address);
    fd.set("client_postal_code",  client.postal_code);
    fd.set("client_city",         client.city);
    fd.set("client_email",        client.email);
    fd.set("client_phone",        client.phone);
    fd.set("client_rcs",          client.rcs);
    fd.set("client_code_ape",     client.code_ape);
    fd.set("client_id_tva",       client.id_tva);
    fd.set("client_legal_form",   client.legal_form);
    fd.set("client_capital",      client.capital);

    // Finance
    fd.set("compte",             compte);
    fd.set("tva_rate",           String(tvaRate));
    fd.set("payment_beneficiary", payBeneficiary);
    fd.set("payment_bic",        payBic);
    fd.set("payment_iban",       payIban);
    fd.set("notes",              notes);

    // Lignes (transport ou location)
    if (invoiceType === "transport") {
      const linesPayload = lines.map((l) => ({
        line_date:    l.line_date || null,
        ref:          l.ref || null,
        exp_address:  l.exp_address || null,
        dest_address: l.dest_address || null,
        poids_kg:     parseFloat(l.poids_kg) || null,
        qty_trips:    parseFloat(l.qty_trips) || null,
        qty_taxable:  parseFloat(l.qty_taxable) || null,
        total_ht:     parseFloat(l.total_ht) || 0,
        ecotaxe:      parseFloat(l.ecotaxe) || 0,
      }));
      fd.set("lines", JSON.stringify(linesPayload));
    } else {
      const linesPayload = rentalLines.map((l) => ({
        line_date:          null,
        ref:                l.ref || null,
        rental_start_date:  l.rental_start_date || null,
        rental_end_date:    l.rental_end_date || null,
        qty_days:           parseFloat(l.qty_days) || null,
        unit_price:         parseFloat(l.unit_price) || null,
        total_ht:           parseFloat(l.total_ht) || 0,
        ecotaxe:            0,
        exp_address:        null,
        dest_address:       null,
        poids_kg:           null,
        qty_trips:          null,
        qty_taxable:        null,
      }));
      fd.set("lines", JSON.stringify(linesPayload));
    }

    try {
      await createAction(fd);
    } finally {
      setPending(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* ── Bandeau mission ──────────────────────────────────────── */}
      {fromMission && (
        <div style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "10px 16px", borderRadius: 10,
          background: "#eff6ff", border: "1px solid #bfdbfe", color: "#1d4ed8",
          fontSize: 13, fontWeight: 500,
        }}>
          <FileText size={15} strokeWidth={2} />
          Pré-rempli depuis la mission
          {fromMission.ref && <strong style={{ marginLeft: 2 }}>{fromMission.ref}</strong>}
          {fromMission.origin && fromMission.dest && (
            <span style={{ marginLeft: 4, opacity: 0.8 }}>
              — {fromMission.origin} → {fromMission.dest}
            </span>
          )}
        </div>
      )}

      {/* ── En-tête ──────────────────────────────────────────────── */}
      <div className="panel">
        <div className="panel-header"><h2>Informations générales</h2></div>

        {/* ── Sélecteur de type — card style ── */}
        <div style={{ display: "flex", gap: 12, marginBottom: 20, paddingBottom: 20, borderBottom: "1px solid var(--border)" }}>
          {(["transport", "location"] as const).map((t) => {
            const active = invoiceType === t;
            const Icon = t === "transport" ? Truck : Car;
            return (
              <button
                key={t}
                type="button"
                onClick={() => setInvoiceType(t)}
                style={{
                  display: "flex", alignItems: "center", gap: 10,
                  padding: "12px 20px", borderRadius: 10,
                  border: `2px solid ${active ? "var(--primary)" : "var(--border)"}`,
                  background: active ? "color-mix(in oklch, var(--primary) 10%, transparent)" : "var(--card)",
                  color: active ? "var(--primary)" : "var(--foreground)",
                  fontWeight: active ? 700 : 500,
                  cursor: "pointer", fontSize: 13,
                  transition: "all 140ms",
                }}
              >
                <Icon size={16} strokeWidth={active ? 2.2 : 1.8} />
                {t === "transport" ? "Facture transport" : "Location sans chauffeur"}
              </button>
            );
          })}
        </div>

        <div className="form-grid">
          <div className="field">
            <label>Numéro de facture *</label>
            <input value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} required />
          </div>
          <div className="field">
            <label>Date d&apos;émission *</label>
            <input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} required />
          </div>
          <div className="field">
            <label>Période (ex: 2026/04)</label>
            <input value={period} onChange={(e) => setPeriod(e.target.value)} placeholder="2026/04" />
          </div>
          <div className="field">
            <label>Chauffeur</label>
            {drivers && drivers.length > 0 && (
              <select
                style={{ marginBottom: 4 }}
                value={drivers.find((d) => d.full_name === driverName)?.id ?? ""}
                onChange={(e) => {
                  const d = drivers.find((d) => d.id === e.target.value);
                  setDriverName(d ? d.full_name : "");
                }}
                aria-label="Sélectionner depuis Social"
              >
                <option value="">— Depuis Social —</option>
                {drivers.map((d) => (
                  <option key={d.id} value={d.id}>{d.full_name}</option>
                ))}
              </select>
            )}
            <input value={driverName} onChange={(e) => setDriverName(e.target.value)} placeholder="ILYAS" />
          </div>
          <div className="field">
            <label>Immatriculation véhicule</label>
            {vehicles && vehicles.length > 0 && (
              <select
                style={{ marginBottom: 4 }}
                value={vehicles.find((v) => v.plate_number === vehiclePlate)?.id ?? ""}
                onChange={(e) => {
                  const v = vehicles.find((v) => v.id === e.target.value);
                  setVehiclePlate(v ? v.plate_number : "");
                }}
                aria-label="Sélectionner depuis Véhicules"
              >
                <option value="">— Depuis Véhicules —</option>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>{v.plate_number} — {v.brand} {v.model}</option>
                ))}
              </select>
            )}
            <input value={vehiclePlate} onChange={(e) => setVehiclePlate(e.target.value)} placeholder="EY-901-VG" />
          </div>
          <div className="field">
            <label>Compte</label>
            <input value={compte} onChange={(e) => setCompte(e.target.value)} placeholder="PIKATRANSPORT/401..." />
          </div>
        </div>
      </div>

      {/* ── Émetteur / Client ─────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* Émetteur — collapsible */}
        <div className="panel">
          <button
            type="button"
            onClick={() => setSellerExpanded((v) => !v)}
            style={{
              display: "flex", alignItems: "center", justifyContent: "space-between",
              width: "100%", background: "none", border: "none", cursor: "pointer",
              padding: "0 0 12px 0",
              borderBottom: sellerExpanded ? "1px solid var(--border)" : "none",
            }}
          >
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 1 }}>
              <span style={{ fontWeight: 700, fontSize: 14 }}>Émetteur</span>
              {!sellerExpanded && (
                <span style={{ fontSize: 12, color: "var(--muted-foreground)" }}>
                  {seller.name}{seller.city ? ` — ${seller.city}` : ""}
                </span>
              )}
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "var(--muted-foreground)" }}>
              {sellerExpanded ? <><ChevronUp size={14} /> Réduire</> : <><ChevronDown size={14} /> Modifier</>}
            </div>
          </button>

          {sellerExpanded && (
            <div className="form-grid" style={{ marginTop: 14 }}>
              {(
                [
                  ["name",       "Nom société *",    "PIKA TRANSPORT"],
                  ["address",    "Adresse",           "8 AVENUE HENRI BARBUSSE"],
                  ["postal_code","Code postal",       "93000"],
                  ["city",       "Ville",             "BOBIGNY"],
                  ["email",      "Email",             "pikatransports@gmail.com"],
                  ["phone",      "Téléphone",         "06 80 80 72 05"],
                  ["rcs",        "RCS",               "93399600100014"],
                  ["code_naf",   "Code NAF",          "4941B"],
                  ["tva",        "N° TVA",            "FR37933996001"],
                  ["legal_form", "Forme juridique",   "SAS"],
                  ["capital",    "Capital (€)",       "50000"],
                ] as [keyof SellerInfo, string, string][]
              ).map(([field, label, placeholder]) => (
                <div className="field" key={field}>
                  <label>{label}</label>
                  <input
                    value={seller[field]}
                    onChange={(e) => setSeller((s) => ({ ...s, [field]: e.target.value }))}
                    placeholder={placeholder}
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Client */}
        <div className="panel">
          <div className="panel-header">
            <h2>Client</h2>
            {clients.length > 0 && (
              <select
                className="select-sm"
                value={selectedClientId}
                onChange={(e) => handleClientSelect(e.target.value)}
              >
                <option value="">— Choisir un client enregistré —</option>
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            )}
          </div>

          {/* ── Recherche SIRET ── */}
          <div style={{ marginBottom: 16, paddingBottom: 16, borderBottom: "1px solid var(--border)" }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: "var(--muted-foreground)", textTransform: "uppercase", letterSpacing: "0.06em", display: "block", marginBottom: 6 }}>
              Remplir depuis le SIRET
            </label>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <input
                type="text"
                value={siretInput}
                onChange={(e) => { setSiretInput(e.target.value); setSiretError(""); }}
                onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), handleSiretLookup())}
                placeholder="Ex : 91439900100041"
                maxLength={17}
                style={{ flex: 1, fontFamily: "monospace", letterSpacing: "0.05em" }}
              />
              <button
                type="button"
                className="btn-secondary"
                onClick={handleSiretLookup}
                disabled={siretLoading || !siretInput.trim()}
                style={{ whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: 6 }}
              >
                {siretLoading
                  ? <Loader2 size={14} className="animate-spin" />
                  : <Search size={14} />}
                Rechercher
              </button>
            </div>
            {siretError && (
              <p style={{ marginTop: 6, fontSize: 12, color: "var(--destructive)" }}>{siretError}</p>
            )}
          </div>

          <div className="form-grid">
            {(
              [
                ["name",        "Nom société *",   "EUROMAT DISTRIBUTION"],
                ["address",     "Adresse",         "5 RUE DE LA STRENE"],
                ["postal_code", "Code postal",     "91200"],
                ["city",        "Ville",           "ATHIS-MONS"],
                ["email",       "Email",           "contact@groupe-euromat.fr"],
                ["phone",       "Téléphone",       "01 48 52 61 68"],
                ["rcs",         "RCS",             "91345480700011"],
                ["code_ape",    "Code APE",        "4941A"],
                ["id_tva",      "ID TVA",          "FR709134543807"],
                ["legal_form",  "Forme juridique", "SA"],
                ["capital",     "Capital (€)",     "70000"],
              ] as [keyof typeof client, string, string][]
            ).map(([field, label, placeholder]) => (
              <div className="field" key={field}>
                <label>{label}</label>
                <input
                  value={client[field]}
                  onChange={(e) => setClient((c) => ({ ...c, [field]: e.target.value }))}
                  placeholder={placeholder}
                  required={field === "name"}
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Lignes de prestation ──────────────────────────────────── */}
      <div className="panel">
        <div className="panel-header">
          <h2>{invoiceType === "location" ? "Véhicules loués" : "Lignes de prestation"}</h2>
          <button type="button" className="btn-secondary" onClick={invoiceType === "location" ? addRentalLine : addLine}>
            <Plus size={14} /> Ajouter une ligne
          </button>
        </div>

        <div style={{ overflowX: "auto" }}>
          {invoiceType === "transport" ? (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Référence</th>
                  <th>Expéditeur</th>
                  <th>Destinataire</th>
                  <th style={{ textAlign: "right" }}>Poids kg</th>
                  <th style={{ textAlign: "right" }}>Qté trs</th>
                  <th style={{ textAlign: "right" }}>Qté tax</th>
                  <th style={{ textAlign: "right" }}>Total HT (€)</th>
                  <th style={{ textAlign: "right" }}>Écotaxe</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {lines.map((line) => (
                  <tr key={line.id}>
                    <td>
                      <input
                        type="date"
                        value={line.line_date}
                        onChange={(e) => updateLine(line.id, "line_date", e.target.value)}
                        style={{ width: 130 }}
                      />
                    </td>
                    <td>
                      <input
                        value={line.ref}
                        onChange={(e) => updateLine(line.id, "ref", e.target.value)}
                        placeholder="183 083"
                        style={{ width: 90 }}
                      />
                    </td>
                    <td>
                      <input
                        value={line.exp_address}
                        onChange={(e) => updateLine(line.id, "exp_address", e.target.value)}
                        placeholder="77100 MEAUX"
                        style={{ width: 130 }}
                      />
                    </td>
                    <td>
                      <input
                        value={line.dest_address}
                        onChange={(e) => updateLine(line.id, "dest_address", e.target.value)}
                        placeholder="77100 MEAUX"
                        style={{ width: 130 }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        value={line.poids_kg}
                        onChange={(e) => updateLine(line.id, "poids_kg", e.target.value)}
                        placeholder="8000"
                        style={{ width: 80, textAlign: "right" }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        step="0.01"
                        value={line.qty_trips}
                        onChange={(e) => updateLine(line.id, "qty_trips", e.target.value)}
                        placeholder="8"
                        style={{ width: 70, textAlign: "right" }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        step="0.01"
                        value={line.qty_taxable}
                        onChange={(e) => updateLine(line.id, "qty_taxable", e.target.value)}
                        placeholder="8"
                        style={{ width: 70, textAlign: "right" }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        step="0.01"
                        value={line.total_ht}
                        onChange={(e) => updateLine(line.id, "total_ht", e.target.value)}
                        placeholder="370.00"
                        required
                        style={{ width: 90, textAlign: "right", fontWeight: 600 }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        step="0.01"
                        value={line.ecotaxe}
                        onChange={(e) => updateLine(line.id, "ecotaxe", e.target.value)}
                        style={{ width: 70, textAlign: "right" }}
                      />
                    </td>
                    <td>
                      {lines.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeLine(line.id)}
                          style={{ background: "none", border: "none", cursor: "pointer", color: "var(--destructive)", padding: 4 }}
                        >
                          <Trash2 size={15} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            /* ── Table location ── */
            <table className="data-table">
              <thead>
                <tr>
                  <th>Véhicule / Description</th>
                  <th>Début location</th>
                  <th>Fin location</th>
                  <th style={{ textAlign: "right" }}>Nb jours</th>
                  <th style={{ textAlign: "right" }}>Prix/jour (€)</th>
                  <th style={{ textAlign: "right" }}>Total HT (€)</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {rentalLines.map((line) => (
                  <tr key={line.id}>
                    <td>
                      <input
                        value={line.ref}
                        onChange={(e) => updateRentalLine(line.id, "ref", e.target.value)}
                        placeholder="EY-901-VG – RENAULT MASTER"
                        style={{ width: 220 }}
                      />
                    </td>
                    <td>
                      <input
                        type="date"
                        value={line.rental_start_date}
                        onChange={(e) => updateRentalLine(line.id, "rental_start_date", e.target.value)}
                        style={{ width: 140 }}
                      />
                    </td>
                    <td>
                      <input
                        type="date"
                        value={line.rental_end_date}
                        onChange={(e) => updateRentalLine(line.id, "rental_end_date", e.target.value)}
                        style={{ width: 140 }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        min="1"
                        value={line.qty_days}
                        onChange={(e) => updateRentalLine(line.id, "qty_days", e.target.value)}
                        style={{ width: 70, textAlign: "right" }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        step="0.01"
                        value={line.unit_price}
                        onChange={(e) => updateRentalLine(line.id, "unit_price", e.target.value)}
                        placeholder="50.00"
                        style={{ width: 90, textAlign: "right" }}
                      />
                    </td>
                    <td>
                      <input
                        type="number"
                        step="0.01"
                        value={line.total_ht}
                        onChange={(e) => updateRentalLine(line.id, "total_ht", e.target.value)}
                        required
                        style={{ width: 100, textAlign: "right", fontWeight: 600 }}
                      />
                    </td>
                    <td>
                      {rentalLines.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeRentalLine(line.id)}
                          style={{ background: "none", border: "none", cursor: "pointer", color: "var(--destructive)", padding: 4 }}
                        >
                          <Trash2 size={15} />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>

        {/* ── Totaux live ── */}
        <div style={{ display: "flex", justifyContent: "flex-end", marginTop: 20 }}>
          <div style={{
            background: "var(--muted)", borderRadius: 12, padding: "16px 24px",
            minWidth: 300, display: "flex", flexDirection: "column", gap: 8,
          }}>
            <TotalRow label="Montant HT"       value={montantHT}    />
            {ecotaxeTotal > 0 && <TotalRow label="Écotaxe" value={ecotaxeTotal} small />}
            <TotalRow label={`TVA ${tvaRate} %`}  value={tva}          small />
            <div style={{ borderTop: "2px solid var(--border)", paddingTop: 10, marginTop: 2 }}>
              <TotalRow label="Total TTC" value={montantTTC} bold />
            </div>
          </div>
        </div>
      </div>

      {/* ── Paramètres financiers & paiement ─────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div className="panel">
          <div className="panel-header"><h2>Paramètre TVA</h2></div>
          <div className="form-grid">
            <div className="field full">
              <label>Taux TVA (%)</label>
              <input type="number" step="0.1" value={tvaRate} onChange={(e) => setTvaRate(Number(e.target.value))} />
            </div>
          </div>
        </div>

        <div className="panel">
          <div className="panel-header"><h2>Coordonnées de paiement</h2></div>
          <div className="form-grid">
            <div className="field full">
              <label>Bénéficiaire</label>
              <input value={payBeneficiary} onChange={(e) => setPayBeneficiary(e.target.value)} />
            </div>
            <div className="field">
              <label>BIC</label>
              <input value={payBic} onChange={(e) => setPayBic(e.target.value)} placeholder="QNTOFRP1XXX" />
            </div>
            <div className="field">
              <label>IBAN</label>
              <input value={payIban} onChange={(e) => setPayIban(e.target.value)} placeholder="FR76…" />
            </div>
          </div>
        </div>
      </div>

      {/* Notes */}
      <div className="panel">
        <div className="panel-header"><h2>Notes internes</h2></div>
        <div className="form-grid">
          <div className="field full">
            <textarea
              rows={3}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Remarques, conditions de paiement…"
              style={{ resize: "vertical" }}
            />
          </div>
        </div>
      </div>

      {/* Actions */}
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
        <button type="button" className="btn-secondary" onClick={() => router.back()}>
          Annuler
        </button>
        <button type="submit" className="btn-primary" disabled={pending}>
          {pending ? "Création…" : "Créer la facture"}
        </button>
      </div>
    </form>
  );
}

function TotalRow({
  label, value, small, bold,
}: {
  label: string; value: number; small?: boolean; bold?: boolean;
}) {
  return (
    <div style={{
      display: "flex", justifyContent: "space-between", alignItems: "center",
      fontSize: small ? 13 : 14,
      color: small ? "var(--muted-foreground)" : "var(--foreground)",
      fontWeight: bold ? 700 : small ? 400 : 500,
    }}>
      <span>{label}</span>
      <span style={{ fontFeatureSettings: '"tnum"' }}>
        {value.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
      </span>
    </div>
  );
}
