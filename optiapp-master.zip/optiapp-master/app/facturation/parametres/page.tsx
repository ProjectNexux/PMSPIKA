import Link from "next/link";
import { Settings } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { getInvoiceSettings } from "@/lib/invoice-queries";
import { requireUser } from "@/lib/session";
import { saveInvoiceSettings } from "@/app/facturation/actions";

export const dynamic = "force-dynamic";

export default async function FacturationParametresPage() {
  await requireUser();
  const s = await getInvoiceSettings();

  return (
    <main className="page">
      <PageHeader eyebrow="Facturation" title="Paramètres">
        <Link href="/facturation" className="btn-secondary">
          ← Retour aux factures
        </Link>
      </PageHeader>

      <form action={saveInvoiceSettings} style={{ display: "flex", flexDirection: "column", gap: 20 }}>
        <input type="hidden" name="settings_id" value={s.id} />

        {/* ── Émetteur ── */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Informations émetteur</h2>
              <p>Pré-remplissent chaque nouvelle facture</p>
            </div>
          </div>
          <div className="form-grid" style={{ padding: "20px 24px" }}>
            <div className="field full">
              <label htmlFor="seller_name">Nom de la société *</label>
              <input id="seller_name" name="seller_name" defaultValue={s.seller_name} required />
            </div>
            <div className="field">
              <label htmlFor="seller_address">Adresse</label>
              <input id="seller_address" name="seller_address" defaultValue={s.seller_address} />
            </div>
            <div className="field">
              <label htmlFor="seller_postal_code">Code postal</label>
              <input id="seller_postal_code" name="seller_postal_code" defaultValue={s.seller_postal_code} />
            </div>
            <div className="field">
              <label htmlFor="seller_city">Ville</label>
              <input id="seller_city" name="seller_city" defaultValue={s.seller_city} />
            </div>
            <div className="field">
              <label htmlFor="seller_email">Email</label>
              <input id="seller_email" name="seller_email" type="email" defaultValue={s.seller_email} />
            </div>
            <div className="field">
              <label htmlFor="seller_phone">Téléphone</label>
              <input id="seller_phone" name="seller_phone" defaultValue={s.seller_phone} />
            </div>
            <div className="field">
              <label htmlFor="seller_rcs">RCS</label>
              <input id="seller_rcs" name="seller_rcs" defaultValue={s.seller_rcs} />
            </div>
            <div className="field">
              <label htmlFor="seller_code_naf">Code NAF</label>
              <input id="seller_code_naf" name="seller_code_naf" defaultValue={s.seller_code_naf} />
            </div>
            <div className="field">
              <label htmlFor="seller_tva">N° TVA intracommunautaire</label>
              <input id="seller_tva" name="seller_tva" defaultValue={s.seller_tva} />
            </div>
            <div className="field">
              <label htmlFor="seller_legal_form">Forme juridique</label>
              <input id="seller_legal_form" name="seller_legal_form" defaultValue={s.seller_legal_form} placeholder="SAS, SA, SARL…" />
            </div>
            <div className="field">
              <label htmlFor="seller_capital">Capital social (€)</label>
              <input id="seller_capital" name="seller_capital" type="number" defaultValue={s.seller_capital ?? ""} />
            </div>
          </div>
        </div>

        {/* ── Facturation ── */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Paramètres de facturation</h2>
              <p>Numérotation et TVA appliquées par défaut</p>
            </div>
          </div>
          <div className="form-grid" style={{ padding: "20px 24px" }}>
            <div className="field">
              <label htmlFor="invoice_prefix">
                Préfixe des numéros de facture
              </label>
              <input
                id="invoice_prefix"
                name="invoice_prefix"
                defaultValue={s.invoice_prefix}
                placeholder="EUR"
              />
              <span style={{ fontSize: 11, color: "var(--muted-foreground)" }}>
                Exemple : <code>EUR</code> → EUR-2026-001
              </span>
            </div>
            <div className="field">
              <label htmlFor="tva_rate">Taux TVA par défaut (%)</label>
              <input
                id="tva_rate"
                name="tva_rate"
                type="number"
                step="0.1"
                defaultValue={s.tva_rate}
              />
            </div>
            <div className="field full">
              <label htmlFor="compte_template">Référence compte (modèle)</label>
              <input
                id="compte_template"
                name="compte_template"
                defaultValue={s.compte_template}
                placeholder="PIKATRANSPORT/401PIKATR"
              />
            </div>
          </div>
        </div>

        {/* ── Paiement ── */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Coordonnées de paiement</h2>
              <p>Figurent en bas de chaque facture</p>
            </div>
          </div>
          <div className="form-grid" style={{ padding: "20px 24px" }}>
            <div className="field full">
              <label htmlFor="payment_beneficiary">Bénéficiaire</label>
              <input id="payment_beneficiary" name="payment_beneficiary" defaultValue={s.payment_beneficiary} />
            </div>
            <div className="field">
              <label htmlFor="payment_bic">BIC</label>
              <input id="payment_bic" name="payment_bic" defaultValue={s.payment_bic} placeholder="QNTOFRP1XXX" />
            </div>
            <div className="field">
              <label htmlFor="payment_iban">IBAN</label>
              <input id="payment_iban" name="payment_iban" defaultValue={s.payment_iban} placeholder="FR76…" />
            </div>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: 12 }}>
          <Link href="/facturation" className="btn-secondary">Annuler</Link>
          <button type="submit" className="btn-primary">
            <Settings size={14} /> Enregistrer les paramètres
          </button>
        </div>
      </form>
    </main>
  );
}
