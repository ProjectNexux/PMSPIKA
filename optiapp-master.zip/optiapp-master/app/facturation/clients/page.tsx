import Link from "next/link";
import { Plus, Pencil } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { listInvoiceClients } from "@/lib/invoice-queries";
import { requireUser } from "@/lib/session";
import { createInvoiceClient, deleteInvoiceClient } from "@/app/facturation/actions";

export const dynamic = "force-dynamic";

export default async function InvoiceClientsPage() {
  await requireUser();
  const clients = await listInvoiceClients();

  return (
    <main className="page">
      <PageHeader eyebrow="Facturation" title="Clients" />

      <div className="grid-2">
        {/* Formulaire nouveau client */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Ajouter un client</h2>
              <p>Enregistrez les infos pour les réutiliser rapidement</p>
            </div>
          </div>
          <form action={createInvoiceClient} className="form-grid">
            <div className="field full">
              <label htmlFor="c-name">Nom société *</label>
              <input id="c-name" name="name" required placeholder="EUROMAT DISTRIBUTION" />
            </div>
            <div className="field">
              <label htmlFor="c-address">Adresse</label>
              <input id="c-address" name="address" placeholder="5 RUE DE LA STRENE" />
            </div>
            <div className="field">
              <label htmlFor="c-postal">Code postal</label>
              <input id="c-postal" name="postal_code" placeholder="91200" />
            </div>
            <div className="field">
              <label htmlFor="c-city">Ville</label>
              <input id="c-city" name="city" placeholder="ATHIS-MONS" />
            </div>
            <div className="field">
              <label htmlFor="c-email">Email</label>
              <input id="c-email" name="email" type="email" placeholder="contact@exemple.fr" />
            </div>
            <div className="field">
              <label htmlFor="c-phone">Téléphone</label>
              <input id="c-phone" name="phone" placeholder="01 48 52 61 68" />
            </div>
            <div className="field">
              <label htmlFor="c-rcs">RCS</label>
              <input id="c-rcs" name="rcs" placeholder="91345480700011" />
            </div>
            <div className="field">
              <label htmlFor="c-ape">Code APE</label>
              <input id="c-ape" name="code_ape" placeholder="4941A" />
            </div>
            <div className="field">
              <label htmlFor="c-tva">ID TVA</label>
              <input id="c-tva" name="id_tva" placeholder="FR709134543807" />
            </div>
            <div className="field">
              <label htmlFor="c-legal">Forme juridique</label>
              <input id="c-legal" name="legal_form" placeholder="SA" />
            </div>
            <div className="field">
              <label htmlFor="c-capital">Capital (€)</label>
              <input id="c-capital" name="capital" type="number" placeholder="70000" />
            </div>
            <div className="field">
              <label htmlFor="c-iban">IBAN</label>
              <input id="c-iban" name="iban" placeholder="FR76…" />
            </div>
            <div className="field">
              <label htmlFor="c-bic">BIC</label>
              <input id="c-bic" name="bic" placeholder="QNTOFRP1XXX" />
            </div>
            <div className="field full">
              <label htmlFor="c-notes">Notes</label>
              <textarea id="c-notes" name="notes" rows={2} />
            </div>
            <div className="field full" style={{ paddingTop: 4 }}>
              <button type="submit" className="btn-primary">
                <Plus size={14} /> Enregistrer le client
              </button>
            </div>
          </form>
        </div>

        {/* Liste clients */}
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Clients enregistrés</h2>
              <p>{clients.length} client{clients.length > 1 ? "s" : ""}</p>
            </div>
          </div>

          {clients.length === 0 ? (
            <p style={{ color: "var(--muted-foreground)", padding: "24px 0", textAlign: "center", fontSize: 14 }}>
              Aucun client enregistré
            </p>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {clients.map((c) => (
                <div key={c.id} style={{
                  border: "1px solid var(--border)",
                  borderRadius: "var(--radius-md)",
                  padding: "12px 16px",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                  gap: 12,
                }}>
                  <div>
                    <strong style={{ fontSize: 14 }}>{c.name}</strong>
                    {(c.postal_code || c.city) && (
                      <p style={{ margin: "2px 0 0", fontSize: 12, color: "var(--muted-foreground)" }}>
                        {[c.postal_code, c.city].filter(Boolean).join(" ")}
                      </p>
                    )}
                    {c.rcs && (
                      <p style={{ margin: 0, fontSize: 11, color: "var(--muted-foreground)" }}>
                        RCS {c.rcs}
                      </p>
                    )}
                    {c.id_tva && (
                      <p style={{ margin: 0, fontSize: 11, color: "var(--muted-foreground)" }}>
                        TVA {c.id_tva}
                      </p>
                    )}
                  </div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <Link
                      href={`/facturation/clients/${c.id}`}
                      className="btn-secondary"
                      style={{ padding: "4px 10px", fontSize: 12 }}
                    >
                      <Pencil size={12} /> Modifier
                    </Link>
                    <form action={deleteInvoiceClient}>
                      <input type="hidden" name="id" value={c.id} />
                      <button
                        type="submit"
                        className="btn-secondary"
                        style={{ padding: "4px 10px", fontSize: 12, color: "var(--destructive)" }}
                        onClick={(e) => {
                          if (!confirm(`Supprimer le client "${c.name}" ?`)) e.preventDefault();
                        }}
                      >
                        Supprimer
                      </button>
                    </form>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
