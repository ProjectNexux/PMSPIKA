"use client";

import Link from "next/link";
import { useState } from "react";
import { Plus, FileText, Users, Settings, ChevronRight, Wallet, BookOpen } from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/format";
import type { InvoiceListRow } from "@/lib/invoice-queries";

const STATUSES = ["Tous", "Brouillon", "Envoyée", "Payée", "Annulée"] as const;

const STATUS_STYLE: Record<string, { bg: string; color: string; dot: string }> = {
  Brouillon: { bg: "#f1f5f9", color: "#64748b", dot: "#94a3b8" },
  Envoyée:   { bg: "#eff6ff", color: "#2563eb", dot: "#3b82f6" },
  Payée:     { bg: "#f0fdf4", color: "#16a34a", dot: "#22c55e" },
  Annulée:   { bg: "#fef2f2", color: "#dc2626", dot: "#ef4444" },
};

function StatusBadge({ status }: { status: string }) {
  const s = STATUS_STYLE[status] ?? { bg: "#f8fafc", color: "#64748b", dot: "#94a3b8" };
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 9px", borderRadius: 20,
      background: s.bg, color: s.color,
      fontSize: 11.5, fontWeight: 600,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: s.dot, flexShrink: 0 }} />
      {status}
    </span>
  );
}

export function InvoiceList({ invoices }: { invoices: InvoiceListRow[] }) {
  const [filter, setFilter] = useState<string>("Tous");

  const counts = STATUSES.reduce((acc, s) => {
    acc[s] = s === "Tous" ? invoices.length : invoices.filter((i) => i.status === s).length;
    return acc;
  }, {} as Record<string, number>);

  const visible = filter === "Tous" ? invoices : invoices.filter((i) => i.status === filter);

  const totalHT  = visible.reduce((s, i) => s + i.total_ht, 0);
  const totalTTC = visible.reduce((s, i) => s + i.total_ttc, 0);

  return (
    <>
      {/* ── Filtres statut ── */}
      <div style={{
        display: "flex", gap: 4, flexWrap: "wrap",
        background: "var(--muted)", padding: 4, borderRadius: 10,
        marginBottom: 0,
      }}>
        {STATUSES.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setFilter(s)}
            style={{
              display: "flex", alignItems: "center", gap: 6,
              padding: "6px 14px", borderRadius: 8, border: "none", cursor: "pointer",
              background: filter === s ? "var(--card)" : "transparent",
              color: filter === s ? "var(--foreground)" : "var(--muted-foreground)",
              fontWeight: filter === s ? 600 : 400,
              fontSize: 13,
              boxShadow: filter === s ? "0 1px 3px oklch(0 0 0 / .06)" : "none",
              transition: "all 100ms ease",
            }}
          >
            {s}
            {counts[s] > 0 && (
              <span style={{
                minWidth: 18, height: 18, borderRadius: 9,
                background: filter === s ? "var(--primary)" : "var(--border)",
                color: filter === s ? "var(--primary-foreground)" : "var(--muted-foreground)",
                fontSize: 10, fontWeight: 700,
                display: "inline-flex", alignItems: "center", justifyContent: "center",
                padding: "0 4px",
              }}>
                {counts[s]}
              </span>
            )}
          </button>
        ))}

        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", alignItems: "center", gap: 4, padding: "0 8px", fontSize: 12, color: "var(--muted-foreground)" }}>
          <span>{formatCurrency(totalHT)} HT</span>
          <span style={{ opacity: 0.4 }}>·</span>
          <strong style={{ color: "var(--foreground)" }}>{formatCurrency(totalTTC)} TTC</strong>
        </div>
      </div>

      {/* ── Table ── */}
      {visible.length === 0 ? (
        <div style={{ padding: "56px 0", textAlign: "center", color: "var(--muted-foreground)" }}>
          <FileText size={40} strokeWidth={1.2} style={{ margin: "0 auto 14px", opacity: 0.3 }} />
          <p style={{ fontWeight: 600, marginBottom: 4 }}>Aucune facture{filter !== "Tous" ? ` "${filter}"` : ""}</p>
          {filter === "Tous" && (
            <Link href="/facturation/nouvelle" className="btn-primary" style={{ marginTop: 16, display: "inline-flex" }}>
              <Plus size={14} /> Créer une facture
            </Link>
          )}
        </div>
      ) : (
        <table className="data-table" style={{ tableLayout: "auto" }}>
          <thead>
            <tr>
              <th>N° facture</th>
              <th>Date</th>
              <th>Période</th>
              <th>Client</th>
              <th>Chauffeur / Véhicule</th>
              <th style={{ textAlign: "right" }}>HT</th>
              <th style={{ textAlign: "right" }}>TTC</th>
              <th>Statut</th>
              <th style={{ width: 32 }} />
            </tr>
          </thead>
          <tbody>
            {visible.map((inv) => (
              <tr
                key={inv.id}
                style={{ cursor: "pointer" }}
                onClick={() => window.location.href = `/facturation/${inv.id}`}
              >
                <td>
                  <span style={{
                    fontWeight: 700, fontSize: 13,
                    color: "var(--foreground)",
                    fontFamily: "ui-monospace, monospace",
                    letterSpacing: "0.02em",
                  }}>
                    {inv.invoice_number}
                  </span>
                </td>
                <td style={{ color: "var(--muted-foreground)", fontSize: 13 }}>
                  {formatDate(inv.issue_date)}
                </td>
                <td style={{ color: "var(--muted-foreground)", fontSize: 13 }}>
                  {inv.period ?? "—"}
                </td>
                <td style={{ fontWeight: 500 }}>{inv.client_name}</td>
                <td style={{ color: "var(--muted-foreground)", fontSize: 12 }}>
                  {[inv.driver_name, inv.vehicle_plate].filter(Boolean).join(" / ") || "—"}
                </td>
                <td style={{ textAlign: "right", fontVariantNumeric: "tabular-nums", fontSize: 13 }}>
                  {formatCurrency(inv.total_ht)}
                </td>
                <td style={{ textAlign: "right", fontWeight: 700, fontVariantNumeric: "tabular-nums" }}>
                  {formatCurrency(inv.total_ttc)}
                </td>
                <td><StatusBadge status={inv.status} /></td>
                <td>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    {inv.status === "Payée" && (
                      <>
                        <Link
                          href="/tresorerie"
                          title="Voir en trésorerie"
                          onClick={(e) => e.stopPropagation()}
                          style={{
                            display: "inline-flex", alignItems: "center", gap: 4,
                            padding: "3px 8px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                            background: "#f0fdf4", color: "#15803d", border: "1px solid #bbf7d0",
                            textDecoration: "none",
                          }}
                        >
                          <Wallet size={11} /> Tréso
                        </Link>
                        <Link
                          href={`/comptabilite?label=${encodeURIComponent(inv.invoice_number)}&amount=${encodeURIComponent(inv.total_ht)}&type=Recette`}
                          title="Créer une entrée comptable"
                          onClick={(e) => e.stopPropagation()}
                          style={{
                            display: "inline-flex", alignItems: "center", gap: 4,
                            padding: "3px 8px", borderRadius: 6, fontSize: 11, fontWeight: 600,
                            background: "#eff6ff", color: "#1d4ed8", border: "1px solid #bfdbfe",
                            textDecoration: "none",
                          }}
                        >
                          <BookOpen size={11} /> Compta
                        </Link>
                      </>
                    )}
                    <ChevronRight size={15} style={{ color: "var(--muted-foreground)", opacity: 0.5 }} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
