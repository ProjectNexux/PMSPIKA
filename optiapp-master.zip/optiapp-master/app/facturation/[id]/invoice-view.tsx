"use client";

import { useRef } from "react";
import { Printer, ArrowLeft, CheckCircle2, Send, XCircle, Copy } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import type { Invoice } from "@/lib/invoice-queries";
import { computeInvoiceTotals } from "@/lib/invoice-queries";
import { updateInvoiceStatus, deleteInvoice, duplicateInvoice } from "@/app/facturation/actions";

const STATUS_COLOR: Record<string, string> = {
  Brouillon: "#94a3b8",
  Envoyée:   "#3b82f6",
  Payée:     "#22c55e",
  Annulée:   "#ef4444",
};

function fmt(n: number) {
  return n.toLocaleString("fr-FR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function fmtDate(d: string | null) {
  if (!d) return "";
  return new Intl.DateTimeFormat("fr-FR").format(new Date(`${d}T00:00:00`));
}

export function InvoiceView({ invoice }: { invoice: Invoice }) {
  const printRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  const lines = invoice.lines ?? [];
  const { montantHT, ecotaxeTotal, tva, montantTTC } = computeInvoiceTotals(
    lines, invoice.tva_rate,
  );

  const handlePrint = () => {
    window.print();
  };

  const handleStatusUpdate = async (status: string) => {
    const fd = new FormData();
    fd.set("id", invoice.id);
    fd.set("status", status);
    await updateInvoiceStatus(fd);
    router.refresh();
  };

  const handleDelete = async () => {
    if (!confirm(`Supprimer la facture ${invoice.invoice_number} ?`)) return;
    const fd = new FormData();
    fd.set("id", invoice.id);
    await deleteInvoice(fd);
  };

  const handleDuplicate = async () => {
    const newNum = prompt("Numéro de la nouvelle facture :", invoice.invoice_number.replace(
      /(\d+)$/, (_, n) => String(parseInt(n) + 1).padStart(n.length, "0"),
    ));
    if (!newNum) return;
    const fd = new FormData();
    fd.set("id", invoice.id);
    fd.set("new_number", newNum);
    await duplicateInvoice(fd);
  };

  return (
    <>
      {/* ── Barre d'actions ─────────────────────────────────────────── */}
      <div className="no-print" style={{
        display: "flex", alignItems: "center", gap: 10, marginBottom: 20,
        flexWrap: "wrap",
      }}>
        {/* Retour */}
        <Link href="/facturation" style={{
          display: "flex", alignItems: "center", gap: 5,
          color: "var(--muted-foreground)", fontSize: 13, fontWeight: 500,
          padding: "6px 10px", borderRadius: 8,
          transition: "background 120ms",
        }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "var(--muted)")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "transparent")}
        >
          <ArrowLeft size={14} /> Factures
        </Link>

        {/* Workflow steps */}
        <div style={{
          display: "flex", alignItems: "center", gap: 0,
          background: "var(--muted)", borderRadius: 10, padding: 3,
          marginLeft: 4,
        }}>
          {(["Brouillon", "Envoyée", "Payée"] as const).map((step, i) => {
            const isActive = invoice.status === step;
            const isDone = (
              (step === "Brouillon" && ["Envoyée", "Payée"].includes(invoice.status)) ||
              (step === "Envoyée" && invoice.status === "Payée")
            );
            const stepColor = { Brouillon: "#94a3b8", Envoyée: "#3b82f6", Payée: "#22c55e" }[step];
            return (
              <span key={step} style={{ display: "flex", alignItems: "center" }}>
                {i > 0 && (
                  <span style={{ width: 16, height: 1, background: isDone ? stepColor : "var(--border)", margin: "0 2px" }} />
                )}
                <span style={{
                  padding: "5px 12px", borderRadius: 8, fontSize: 12, fontWeight: 600,
                  background: isActive ? "var(--card)" : "transparent",
                  color: isActive ? stepColor : isDone ? stepColor : "var(--muted-foreground)",
                  opacity: isDone ? 0.7 : 1,
                  boxShadow: isActive ? "0 1px 3px oklch(0 0 0/.08)" : "none",
                  transition: "all 120ms",
                }}>
                  {isDone ? "✓ " : ""}{step}
                </span>
              </span>
            );
          })}
          {invoice.status === "Annulée" && (
            <span style={{ padding: "5px 12px", borderRadius: 8, fontSize: 12, fontWeight: 600, color: "#dc2626", background: "#fef2f2" }}>
              ✕ Annulée
            </span>
          )}
        </div>

        <div style={{ flex: 1 }} />

        {/* Actions secondaires */}
        <div style={{ display: "flex", gap: 6 }}>
          {invoice.status === "Brouillon" && (
            <button className="btn-secondary" onClick={() => handleStatusUpdate("Envoyée")} style={{ gap: 6 }}>
              <Send size={13} /> Envoyer
            </button>
          )}
          {invoice.status === "Envoyée" && (
            <button className="btn-secondary" onClick={() => handleStatusUpdate("Payée")} style={{ gap: 6 }}>
              <CheckCircle2 size={13} /> Marquer payée
            </button>
          )}
          {invoice.status !== "Annulée" && invoice.status !== "Payée" && (
            <button className="btn-secondary" style={{ color: "var(--destructive)", gap: 6 }} onClick={() => handleStatusUpdate("Annulée")}>
              <XCircle size={13} /> Annuler
            </button>
          )}
          <button className="btn-secondary" onClick={handleDuplicate} style={{ gap: 6 }}>
            <Copy size={13} /> Dupliquer
          </button>
          <button className="btn-secondary" style={{ color: "var(--destructive)", gap: 6 }} onClick={handleDelete}>
            Supprimer
          </button>
          <button className="btn-primary" onClick={handlePrint} style={{ gap: 7 }}>
            <Printer size={14} /> Imprimer / PDF
          </button>
        </div>
      </div>

      {/* ── Document facture ──────────────────────────────────────── */}
      <div ref={printRef} className="invoice-doc">

        {/* ── Header ── */}
        <div className="invoice-header">
          <div className="invoice-logo">
            <div className="invoice-logo-mark">PT</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
              <strong style={{ fontSize: 20, letterSpacing: -0.5, lineHeight: 1 }}>
                {invoice.seller_name ?? "PIKA TRANSPORT"}
              </strong>
              {(invoice.seller_postal_code || invoice.seller_city) && (
                <span style={{ fontSize: 12, color: "#666" }}>
                  {[invoice.seller_postal_code, invoice.seller_city].filter(Boolean).join(" ")}
                </span>
              )}
            </div>
          </div>
          <div style={{ textAlign: "right" }}>
            <h1 className="invoice-title">
              {invoice.invoice_type === "location" ? "CONTRAT DE LOCATION" : "FACTURE"}
            </h1>
            <div style={{
              display: "inline-block", marginTop: 6,
              padding: "3px 10px", borderRadius: 12,
              background: (STATUS_COLOR[invoice.status] ?? "#94a3b8") + "18",
              color: STATUS_COLOR[invoice.status] ?? "#94a3b8",
              fontSize: 11, fontWeight: 700, letterSpacing: "0.04em",
            }} className="no-print">
              {invoice.status}
            </div>
          </div>
        </div>

        {/* ── Référence & dates ── */}
        <div className="invoice-meta">
          <div>
            <p><strong>N° facture :</strong> {invoice.invoice_number}</p>
            <p><strong>Émission :</strong> {fmtDate(invoice.issue_date)}</p>
          </div>
          {(invoice.period || invoice.driver_name || invoice.vehicle_plate) && (
            <div style={{ textAlign: "right" }}>
              {invoice.period && <p><strong>Période :</strong> {invoice.period}</p>}
              {(invoice.driver_name || invoice.vehicle_plate) && (
                <p><strong>{invoice.driver_name}{invoice.driver_name && invoice.vehicle_plate ? " / " : ""}{invoice.vehicle_plate}</strong></p>
              )}
            </div>
          )}
        </div>

        {/* ── Parties ── */}
        <div className="invoice-parties">
          {/* Émetteur */}
          <div className="invoice-party">
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", color: "#888", textTransform: "uppercase", marginBottom: 6 }}>
              Émetteur
            </div>
            <strong style={{ fontSize: 13 }}>{invoice.seller_name}</strong>
            {invoice.seller_address && <span>{invoice.seller_address}</span>}
            {(invoice.seller_postal_code || invoice.seller_city) && (
              <span>{[invoice.seller_postal_code, invoice.seller_city].filter(Boolean).join(" ")}</span>
            )}
            {invoice.seller_email && <span>Email : {invoice.seller_email}</span>}
            {invoice.seller_phone && <span>Tél : {invoice.seller_phone}</span>}
            <div className="invoice-party-meta">
              {invoice.seller_rcs      && <span>RCS : {invoice.seller_rcs}</span>}
              {invoice.seller_code_naf && <span>NAF : {invoice.seller_code_naf}</span>}
              {invoice.seller_tva      && <span>TVA : {invoice.seller_tva}</span>}
              {invoice.seller_legal_form && invoice.seller_capital && (
                <span>{invoice.seller_legal_form} — capital {Number(invoice.seller_capital).toLocaleString("fr-FR")} €</span>
              )}
            </div>
          </div>

          {/* Client */}
          <div className="invoice-party" style={{ background: "#fafafa", borderRadius: 8, padding: "14px 16px" }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", color: "#888", textTransform: "uppercase", marginBottom: 6 }}>
              Facturé à
            </div>
            <strong style={{ fontSize: 13 }}>{invoice.client_name}</strong>
            {invoice.client_address && <span>{invoice.client_address}</span>}
            {(invoice.client_postal_code || invoice.client_city) && (
              <span>{[invoice.client_postal_code, invoice.client_city].filter(Boolean).join(" ")}</span>
            )}
            {invoice.client_email && <span>Email : {invoice.client_email}</span>}
            {invoice.client_phone && <span>Tél : {invoice.client_phone}</span>}
            <div className="invoice-party-meta">
              {invoice.client_rcs      && <span>RCS : {invoice.client_rcs}</span>}
              {invoice.client_code_ape && <span>APE : {invoice.client_code_ape}</span>}
              {invoice.client_id_tva   && <span>TVA : {invoice.client_id_tva}</span>}
              {invoice.client_legal_form && invoice.client_capital && (
                <span>{invoice.client_legal_form} — capital {Number(invoice.client_capital).toLocaleString("fr-FR")} €</span>
              )}
            </div>
          </div>
        </div>

        {/* ── Compte / Référence ── */}
        {invoice.compte && (
          <div style={{ fontSize: 11, marginBottom: 16, padding: "6px 10px", background: "#f8fafc", borderRadius: 6, color: "#555", border: "1px solid #e8ecf0" }}>
            <strong>Compte :</strong> {invoice.compte}
          </div>
        )}

        {/* Tableau lignes */}
        {invoice.invoice_type === "location" ? (
          /* ── Table location sans chauffeur ── */
          <table className="invoice-table">
            <thead>
              <tr>
                <th>Véhicule</th>
                <th>Période de location</th>
                <th style={{ textAlign: "right" }}>Nb jours</th>
                <th style={{ textAlign: "right" }}>Prix/jour</th>
                <th style={{ textAlign: "right" }}>Total HT</th>
              </tr>
            </thead>
            <tbody>
              {lines.map((line) => (
                <tr key={line.id}>
                  <td><strong>{line.ref ?? "—"}</strong></td>
                  <td style={{ whiteSpace: "nowrap" }}>
                    {line.rental_start_date && line.rental_end_date
                      ? `${fmtDate(line.rental_start_date)} → ${fmtDate(line.rental_end_date)}`
                      : line.rental_start_date
                      ? `À partir du ${fmtDate(line.rental_start_date)}`
                      : "—"}
                  </td>
                  <td style={{ textAlign: "right" }}>
                    {line.qty_days != null ? fmt(line.qty_days) : "—"}
                  </td>
                  <td style={{ textAlign: "right" }}>
                    {line.unit_price != null ? `${fmt(line.unit_price)} €` : "—"}
                  </td>
                  <td style={{ textAlign: "right", fontWeight: 600 }}>{fmt(line.total_ht)} €</td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          /* ── Table transport (existante) ── */
          <table className="invoice-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th style={{ textAlign: "right" }}>Poids kg</th>
                <th style={{ textAlign: "right" }}>Qté trs</th>
                <th style={{ textAlign: "right" }}>Qté tax</th>
                <th style={{ textAlign: "right" }}>Total HT</th>
              </tr>
            </thead>
            <tbody>
              {lines.map((line) => (
                <tr key={line.id}>
                  <td style={{ whiteSpace: "nowrap" }}>{fmtDate(line.line_date)}</td>
                  <td>
                    {line.ref && <div><strong>Ref : {line.ref}</strong></div>}
                    {line.exp_address  && <div>Exp : {line.exp_address}</div>}
                    {line.dest_address && <div>Dest : {line.dest_address}</div>}
                  </td>
                  <td style={{ textAlign: "right" }}>{line.poids_kg != null ? fmt(line.poids_kg) : ""}</td>
                  <td style={{ textAlign: "right" }}>{line.qty_trips   != null ? fmt(line.qty_trips) : ""}</td>
                  <td style={{ textAlign: "right" }}>{line.qty_taxable != null ? fmt(line.qty_taxable) : ""}</td>
                  <td style={{ textAlign: "right", fontWeight: 600 }}>{fmt(line.total_ht)} €</td>
                </tr>
              ))}
              {/* Ligne écotaxe si > 0 */}
              {ecotaxeTotal > 0 && (
                <tr>
                  <td colSpan={5} style={{ textAlign: "right", fontSize: 11, color: "#666" }}>
                    Total Majoration Écotaxe
                  </td>
                  <td style={{ textAlign: "right" }}>{fmt(ecotaxeTotal)} €</td>
                </tr>
              )}
            </tbody>
          </table>
        )}

        {/* ── Totaux ── */}
        <div className="invoice-totals">
          <div className="invoice-total-row">
            <span>Montant HT</span>
            <span>{fmt(montantHT)} €</span>
          </div>
          {ecotaxeTotal > 0 && (
            <div className="invoice-total-row">
              <span>Majoration écotaxe</span>
              <span>{fmt(ecotaxeTotal)} €</span>
            </div>
          )}
          <div className="invoice-total-row">
            <span>TVA {invoice.tva_rate} %</span>
            <span>{fmt(tva)} €</span>
          </div>
          <div className="invoice-total-row invoice-total-ttc">
            <span>Total TTC</span>
            <span>{fmt(montantTTC)} €</span>
          </div>
        </div>

        {/* ── Paiement ── */}
        {(invoice.payment_beneficiary || invoice.payment_iban || invoice.payment_bic) && (
          <div className="invoice-payment">
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: "0.08em", color: "#888", textTransform: "uppercase", marginBottom: 8 }}>
              Coordonnées bancaires
            </div>
            <table>
              <tbody>
                {invoice.payment_beneficiary && (
                  <tr><td>Bénéficiaire</td><td><strong>{invoice.payment_beneficiary}</strong></td></tr>
                )}
                {invoice.payment_bic && (
                  <tr><td>BIC</td><td>{invoice.payment_bic}</td></tr>
                )}
                {invoice.payment_iban && (
                  <tr><td>IBAN</td><td style={{ letterSpacing: "0.05em", fontFamily: "monospace" }}>{invoice.payment_iban}</td></tr>
                )}
              </tbody>
            </table>
          </div>
        )}

        {/* ── Notes ── */}
        {invoice.notes && (
          <div className="invoice-notes">
            <p>{invoice.notes}</p>
          </div>
        )}
      </div>
    </>
  );
}
