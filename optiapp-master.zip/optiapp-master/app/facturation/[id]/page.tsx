import { notFound } from "next/navigation";
import { getInvoiceById } from "@/lib/invoice-queries";
import { requireUser } from "@/lib/session";
import { InvoiceView } from "./invoice-view";

export const dynamic = "force-dynamic";

export default async function InvoicePage({ params }: { params: Promise<{ id: string }> }) {
  await requireUser();
  const { id } = await params;
  const invoice = await getInvoiceById(id);
  if (!invoice) notFound();

  return (
    <main className="page invoice-page">
      <InvoiceView invoice={invoice} />
    </main>
  );
}
