"use server";

import { revalidatePath } from "next/cache";
import { logAudit } from "@/lib/audit";
import {
  currentPeriod,
  deleteUrssafCredential,
  getUrssafCredentialFull,
  recordRunResult,
  saveAttestation,
  signedAttestationUrl,
  upsertUrssafCredential,
} from "@/lib/urssaf-queries";
import { fetchUrssafAttestation } from "@/lib/urssaf-scraper";

function s(formData: FormData, key: string): string | null {
  const v = formData.get(key);
  return typeof v === "string" && v.trim() ? v.trim() : null;
}

export async function saveUrssafCredentials(formData: FormData) {
  const companyId = s(formData, "company_id");
  const username = s(formData, "username");
  const password = s(formData, "password");
  if (!companyId || !username || !password) {
    throw new Error("company_id, username et password sont requis");
  }
  await upsertUrssafCredential({
    companyId,
    username,
    password,
    portal: (s(formData, "portal") as "net-entreprises" | "urssaf-direct") ?? "net-entreprises",
    mfaMethod: s(formData, "mfa_method"),
    contactEmail: s(formData, "contact_email"),
    enabled: formData.get("enabled") !== null,
  });
  await logAudit({
    action: "save_urssaf_credentials",
    entity: "urssaf_credentials",
    entity_id: companyId,
    company_id: companyId,
    metadata: { username, portal: s(formData, "portal") },
  });
  revalidatePath(`/parametres`);
}

export async function removeUrssafCredentials(formData: FormData) {
  const companyId = s(formData, "company_id");
  if (!companyId) throw new Error("company_id requis");
  await deleteUrssafCredential(companyId);
  await logAudit({
    action: "delete_urssaf_credentials",
    entity: "urssaf_credentials",
    entity_id: companyId,
    company_id: companyId,
  });
  revalidatePath(`/parametres`);
}

/** Lance le téléchargement maintenant pour une société donnée. */
export async function runUrssafFetchNow(formData: FormData) {
  const companyId = s(formData, "company_id");
  if (!companyId) throw new Error("company_id requis");
  const creds = await getUrssafCredentialFull(companyId);
  if (!creds) throw new Error("Aucun identifiant URSSAF enregistré");

  const result = await fetchUrssafAttestation({
    username: creds.username,
    password: creds.password,
  });

  if (!result.ok) {
    const errResult = result as { ok: false; reason: string; message: string };
    await recordRunResult(
      companyId,
      errResult.reason === "mfa_required" ? "mfa_required" : "error",
      `${errResult.reason}: ${errResult.message}`,
    );
    await logAudit({
      action: "run_urssaf_fetch",
      entity: "urssaf_attestations",
      company_id: companyId,
      result: "error",
      message: `${errResult.reason}: ${errResult.message}`,
    });
    revalidatePath(`/parametres`);
    return;
  }

  await saveAttestation({
    companyId,
    period: currentPeriod(),
    pdf: result.pdf,
    validFrom: result.validFrom,
    validUntil: result.validUntil,
    source: "auto",
  });
  await recordRunResult(companyId, "ok", null);
  await logAudit({
    action: "run_urssaf_fetch",
    entity: "urssaf_attestations",
    company_id: companyId,
    metadata: { period: currentPeriod(), valid_until: result.validUntil },
  });
  revalidatePath(`/parametres`);
}

/** Génère une URL signée temporaire pour télécharger l'attestation. */
export async function getAttestationDownloadUrl(formData: FormData): Promise<string> {
  const storagePath = s(formData, "storage_path");
  if (!storagePath) throw new Error("storage_path requis");
  return signedAttestationUrl(storagePath, 300);
}
