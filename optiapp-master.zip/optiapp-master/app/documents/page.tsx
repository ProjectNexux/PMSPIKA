import { Plus } from "lucide-react";
import { createDocument } from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatDate, formatNumber } from "@/lib/format";
import {
  getDocumentsByCompanyFull,
  getSiteOptionsByCompany,
  getTmsVehicleOptionsByCompany,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function CompanyDocumentsPage() {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const [documents, sites, vehicles] = await Promise.all([
    getDocumentsByCompanyFull(id),
    getSiteOptionsByCompany(id),
    getTmsVehicleOptionsByCompany(id),
  ]);
  const missing = documents.filter((d) => d.status === "Manquant").length;
  const expiring = documents.filter((d) => d.status === "Expire bientot").length;
  const valid = documents.filter((d) => d.status === "Valide").length;

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Documents" />

      <section className="stat-grid">
        <StatCard label="Documents" value={formatNumber(documents.length)} tone="blue" />
        <StatCard label="Valides" value={formatNumber(valid)} tone="green" />
        <StatCard label="A echeance" value={formatNumber(expiring)} tone="orange" />
        <StatCard label="Manquants" value={formatNumber(missing)} tone="red" />
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Ajouter un document</h2>
              <p>Rattaché automatiquement à PIKA TRANSPORT</p>
            </div>
          </div>
          <form action={createDocument} className="form-grid">
            <input type="hidden" name="company_id" value={id} />
            <input type="hidden" name="redirect_to" value="/documents" />
            <div className="field full">
              <label htmlFor="title">Document</label>
              <input id="title" name="title" required />
            </div>
            <div className="field">
              <label htmlFor="category">Categorie</label>
              <select id="category" name="category" defaultValue="Administratif">
                <option>Administratif</option>
                <option>Social</option>
                <option>Comptabilite</option>
                <option>Vehicule</option>
                <option>Sous-traitance</option>
                <option>Operations</option>
                <optgroup label="LOTI / capacité transport">
                  <option>Licence transport marchandises</option>
                  <option>LCI</option>
                  <option>Copie conforme</option>
                  <option>Attestation capacité</option>
                  <option>Inscription registre</option>
                </optgroup>
              </select>
            </div>
            <div className="field">
              <label htmlFor="status">Etat</label>
              <select id="status" name="status" defaultValue="A classer">
                <option>A classer</option>
                <option>A revoir</option>
                <option>Expire bientot</option>
                <option>Manquant</option>
                <option>Valide</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="site_id">Site</label>
              <select id="site_id" name="site_id" defaultValue="">
                <option value="">Tous sites</option>
                {sites.map((site) => (
                  <option key={site.id} value={site.id}>
                    {site.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="owner_type">Perimetre</label>
              <select id="owner_type" name="owner_type" defaultValue="Site">
                <option>Societe</option>
                <option>Site</option>
                <option>Salarie</option>
                <option>Vehicule</option>
                <option>Sous-traitant</option>
                <option>Groupe</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="owner_name">Responsable</label>
              <input id="owner_name" name="owner_name" required />
            </div>
            <div className="field">
              <label htmlFor="vehicle_id">Véhicule lié (LOTI)</label>
              <select id="vehicle_id" name="vehicle_id" defaultValue="">
                <option value="">— Aucun —</option>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.plate_number} — {v.brand} {v.model}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="due_date">Echeance</label>
              <input id="due_date" name="due_date" type="date" />
            </div>
            <div className="field">
              <label htmlFor="notes">Note</label>
              <input id="notes" name="notes" />
            </div>
            <div className="full">
              <button className="button" type="submit">
                <Plus size={16} aria-hidden="true" />
                Ajouter
              </button>
            </div>
          </form>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Suivi documentaire</h2>
              <p>Pieces prioritaires en haut — PIKA TRANSPORT</p>
            </div>
          </div>
          {documents.length > 0 ? (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Document</th>
                    <th>Categorie</th>
                    <th>Responsable</th>
                    <th>Site</th>
                    <th>Echeance</th>
                    <th>Etat</th>
                  </tr>
                </thead>
                <tbody>
                  {documents.map((document) => (
                    <tr key={document.id}>
                      <td className="strong-cell">{document.title}</td>
                      <td>{document.category}</td>
                      <td>{document.owner_name}</td>
                      <td>{document.site_name ?? "Tous"}</td>
                      <td>{formatDate(document.due_date)}</td>
                      <td>
                        <StatusPill value={document.status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 14 }}>Aucun document pour PIKA TRANSPORT.</p>
          )}
        </div>
      </section>
    </main>
  );
}
