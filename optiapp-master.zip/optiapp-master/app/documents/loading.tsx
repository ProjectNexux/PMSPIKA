import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Administratif" title="Documents" stats={4} rows={10} cols={6} />;
}
