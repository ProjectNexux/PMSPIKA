import Link from "next/link";
import { DashboardClient } from "@/components/dashboard/dashboard-client";
import {
  getDashboardCompanyFleetAlerts,
  getDashboardCompanyIncidents,
  getDashboardCompanyOverdueInvoices,
  getDashboardCompanyOverview,
  getDashboardCompanyTournees,
  getDashboardFinanceTrend,
  getDocumentsByCompanyFull,
  getEmployeesByCompany,
  getVehiclesByCompany,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

export default async function Home() {
  const user = await requireUser();
  const id = user.company_id ?? "";

  const [
    overview,
    financeTrend,
    tournees,
    fleetAlerts,
    invoices,
    incidents,
    documents,
    vehicles,
    employees,
  ] = await Promise.all([
    getDashboardCompanyOverview(id),
    getDashboardFinanceTrend(id),
    getDashboardCompanyTournees(id, 400),
    getDashboardCompanyFleetAlerts(id, 60, 10),
    getDashboardCompanyOverdueInvoices(id, 10),
    getDashboardCompanyIncidents(id, 10),
    getDocumentsByCompanyFull(id),
    getVehiclesByCompany(id, 200),
    getEmployeesByCompany(id, 200),
  ]);

  return (
    <>
      <div className="flex items-center justify-between gap-4 px-6 pt-5 pb-0">
        <span className="text-sm font-semibold text-foreground">PIKA TRANSPORT</span>
        <div className="flex items-center gap-2">
          <Link
            href="/pilotage"
            className="inline-flex h-8 items-center gap-1.5 rounded-md border bg-background px-3 text-xs font-medium text-foreground shadow-sm hover:bg-muted"
          >
            Pilotage
          </Link>
          <Link
            href="/tournees"
            className="inline-flex h-8 items-center gap-1.5 rounded-md bg-primary px-3 text-xs font-medium text-primary-foreground shadow-sm hover:bg-primary/90"
          >
            Tournees
          </Link>
        </div>
      </div>
      <DashboardClient
        overview={overview ?? null}
        financeTrend={financeTrend ?? null}
        tournees={tournees}
        fleetAlerts={fleetAlerts}
        invoices={invoices}
        incidents={incidents}
        documents={documents}
        vehicles={vehicles}
        employees={employees}
        companyName="PIKA TRANSPORT"
        companyId={id}
      />
    </>
  );
}
