import Link from "next/link";
import { Plus } from "lucide-react";
import { createTask, updateTaskStatus } from "@/app/actions";
import { PageHeader } from "@/components/page-header";
import { StatCard } from "@/components/stat-card";
import { StatusPill } from "@/components/status-pill";
import { formatDate, formatNumber } from "@/lib/format";
import {
  getSiteOptionsByCompany,
  getTasksByCompany,
} from "@/lib/queries";
import { requireUser } from "@/lib/session";

export const dynamic = "force-dynamic";

const DOMAIN_ROUTES: Record<string, string> = {
  Administratif:    "/documents",
  Comptabilite:     "/comptabilite",
  Social:           "/social",
  Operations:       "/missions",
  "Sous-traitance": "/sous-traitance",
  Facturation:      "/facturation",
  Tresorerie:       "/tresorerie",
  Vehicules:        "/vehicules",
  Sites:            "/sites",
};

export default async function CompanySteeringPage() {
  const user = await requireUser();
  const id = user.company_id ?? "";
  const [tasks, sites] = await Promise.all([
    getTasksByCompany(id), getSiteOptionsByCompany(id),
  ]);
  const open = tasks.filter((t) => t.status !== "Termine").length;
  const critical = tasks.filter((t) => t.priority === "Critique").length;
  const blocked = tasks.filter((t) => t.status === "Bloque").length;
  const done = tasks.filter((t) => t.status === "Termine").length;

  return (
    <main className="page">
      <PageHeader eyebrow="PIKA TRANSPORT" title="Pilotage" />

      <section className="stat-grid">
        <StatCard label="Ouvertes" value={formatNumber(open)} tone="blue" />
        <StatCard label="Critiques" value={formatNumber(critical)} tone="red" />
        <StatCard label="Bloquees" value={formatNumber(blocked)} tone="orange" />
        <StatCard label="Terminees" value={formatNumber(done)} tone="green" />
      </section>

      <section className="grid-2">
        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Ajouter une tache</h2>
              <p>Affectée à PIKA TRANSPORT</p>
            </div>
          </div>
          <form action={createTask} className="form-grid">
            <input type="hidden" name="company_id" value={id} />
            <input type="hidden" name="redirect_to" value="/pilotage" />
            <div className="field full">
              <label htmlFor="title">Tache</label>
              <input id="title" name="title" required />
            </div>
            <div className="field">
              <label htmlFor="domain">Domaine</label>
              <select id="domain" name="domain" defaultValue="Operations">
                <option>Administratif</option>
                <option>Comptabilite</option>
                <option>Social</option>
                <option>Operations</option>
                <option>Sous-traitance</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="priority">Priorite</label>
              <select id="priority" name="priority" defaultValue="Moyenne">
                <option>Basse</option>
                <option>Moyenne</option>
                <option>Haute</option>
                <option>Critique</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="owner">Responsable</label>
              <input id="owner" name="owner" required />
            </div>
            <div className="field">
              <label htmlFor="due_date">Echeance</label>
              <input id="due_date" name="due_date" type="date" />
            </div>
            <div className="field full">
              <label htmlFor="site_id">Site</label>
              <select id="site_id" name="site_id" defaultValue="">
                <option value="">Tous sites</option>
                {sites.map((site) => (
                  <option key={site.id} value={site.id}>
                    {site.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="field full">
              <label htmlFor="notes">Note</label>
              <textarea id="notes" name="notes" />
            </div>
            <div className="full">
              <button className="button" type="submit">
                <Plus size={16} aria-hidden="true" />
                Ajouter
              </button>
            </div>
          </form>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div>
              <h2>Suivi</h2>
              <p>{tasks.length} tache{tasks.length > 1 ? "s" : ""} — PIKA TRANSPORT</p>
            </div>
          </div>
          {tasks.length > 0 ? (
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Tache</th>
                    <th>Domaine</th>
                    <th>Responsable</th>
                    <th>Site</th>
                    <th>Echeance</th>
                    <th>Priorite</th>
                    <th>Etat</th>
                    <th>MAJ</th>
                  </tr>
                </thead>
                <tbody>
                  {tasks.map((task) => (
                    <tr key={task.id}>
                      <td className="strong-cell">{task.title}</td>
                      <td>
                        <Link
                          href={DOMAIN_ROUTES[task.domain] ?? "#"}
                          style={{
                            display: "inline-flex", alignItems: "center", gap: 4,
                            padding: "2px 8px", borderRadius: 20, fontSize: 11.5, fontWeight: 600,
                            background: "var(--muted)", color: "var(--foreground)",
                            textDecoration: "none",
                          }}
                        >
                          {task.domain}
                        </Link>
                      </td>
                      <td>{task.owner}</td>
                      <td>{task.site_name ?? "Tous"}</td>
                      <td>{formatDate(task.due_date)}</td>
                      <td>
                        <StatusPill value={task.priority} />
                      </td>
                      <td>
                        <StatusPill value={task.status} />
                      </td>
                      <td>
                        <form action={updateTaskStatus} className="inline-form">
                          <input type="hidden" name="id" value={task.id} />
                          <input type="hidden" name="redirect_to" value="/pilotage" />
                          <select name="status" defaultValue={task.status} aria-label={`Etat ${task.title}`}>
                            <option>A faire</option>
                            <option>En cours</option>
                            <option>Bloque</option>
                            <option>Termine</option>
                          </select>
                          <button className="compact-button" type="submit">
                            OK
                          </button>
                        </form>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ fontSize: 14 }}>Aucune tache pour PIKA TRANSPORT.</p>
          )}
        </div>
      </section>
    </main>
  );
}
