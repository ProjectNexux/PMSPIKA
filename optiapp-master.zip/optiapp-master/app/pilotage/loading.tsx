import { SkeletonListPage } from "@/components/skeleton";

export default function Loading() {
  return <SkeletonListPage eyebrow="Pilotage" title="Tâches" stats={4} rows={10} cols={6} />;
}
