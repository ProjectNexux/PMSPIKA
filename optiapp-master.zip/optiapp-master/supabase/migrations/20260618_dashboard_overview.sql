-- Dashboard rich overview functions
-- Provides real, aggregated operational data for the homepage.

-- 1) Aggregated snapshot (one row)
create or replace function public.get_dashboard_overview()
returns table (
  -- Operations
  tournees_today               int,
  tournees_in_progress         int,
  tournees_scheduled_week      int,
  tournees_completed_week      int,
  missions_in_progress         int,
  missions_assigned            int,
  missions_today               int,
  missions_completed_30d       int,
  -- Fleet (operational table)
  fleet_total                  int,
  fleet_active                 int,
  fleet_maintenance            int,
  -- Fleet (TMS live status)
  tms_fleet_total              int,
  tms_fleet_available          int,
  tms_fleet_on_mission         int,
  tms_fleet_maintenance        int,
  -- HR
  employees_active             int,
  drivers_active               int,
  absences_active              int,
  -- Alerts
  documents_critical           int,
  documents_expiring_30d       int,
  vehicles_ct_30d              int,
  vehicles_ct_60d              int,
  vehicles_ins_30d             int,
  vehicles_ins_60d             int,
  incidents_open               int,
  tasks_open_high              int,
  -- Finance (current month)
  period                       text,
  revenue_period               numeric,
  expenses_period              numeric,
  margin_period                numeric,
  invoices_overdue_count       int,
  invoices_overdue_amount      numeric,
  invoices_outstanding_count   int,
  invoices_outstanding_amount  numeric
)
language sql
stable
security definer
set search_path = public
as $$
  with curr as (select to_char(current_date, 'YYYY-MM') as p)
  select
    (select count(*) from tournees where scheduled_date = current_date)::int,
    (select count(*) from tournees where status = 'in_progress')::int,
    (select count(*) from tournees where scheduled_date between current_date and current_date + interval '7 days')::int,
    (select count(*) from tournees where status = 'completed' and scheduled_date >= current_date - interval '7 days')::int,
    (select count(*) from missions where status = 'in_progress')::int,
    (select count(*) from missions where status = 'assigned')::int,
    (select count(*) from missions where scheduled_date = current_date)::int,
    (select count(*) from missions where status = 'completed' and scheduled_date >= current_date - interval '30 days')::int,
    (select count(*) from vehicles)::int,
    (select count(*) from vehicles where status = 'Actif')::int,
    (select count(*) from vehicles where status = 'Maintenance')::int,
    (select count(*) from tms_vehicles)::int,
    (select count(*) from tms_vehicles where status = 'available')::int,
    (select count(*) from tms_vehicles where status = 'on_mission')::int,
    (select count(*) from tms_vehicles where status = 'maintenance')::int,
    (select count(*) from employees where status = 'Actif')::int,
    (select count(*) from employees where status = 'Actif' and role ilike '%chauffeur%')::int,
    (select count(*) from absences where status = 'En cours')::int,
    (select count(*) from documents where status in ('Manquant','Expire bientot','A revoir'))::int,
    (select count(*) from documents
       where due_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
         and due_date::date <= current_date + interval '30 days'
         and (status is null or status not in ('Valide','Pret','Envoye comptable')))::int,
    (select count(*) from vehicles
       where next_inspection ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
         and next_inspection::date <= current_date + interval '30 days')::int,
    (select count(*) from vehicles
       where next_inspection ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
         and next_inspection::date between current_date + interval '31 days' and current_date + interval '60 days')::int,
    (select count(*) from vehicles
       where insurance_due_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
         and insurance_due_date::date <= current_date + interval '30 days')::int,
    (select count(*) from vehicles
       where insurance_due_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
         and insurance_due_date::date between current_date + interval '31 days' and current_date + interval '60 days')::int,
    (select count(*) from incidents where status = 'open')::int,
    (select count(*) from tasks where priority in ('Haute','Critique') and status <> 'Termine')::int,
    (select p from curr),
    coalesce((select sum(le.amount::numeric) from ledger_entries le, curr c where le.type = 'Recette' and le.period = c.p), 0)::numeric,
    coalesce((select sum(le.amount::numeric) from ledger_entries le, curr c where le.type = 'Depense' and le.period = c.p), 0)::numeric,
    coalesce((select sum(case when le.type = 'Recette' then le.amount::numeric else -le.amount::numeric end) from ledger_entries le, curr c where le.period = c.p), 0)::numeric,
    (select count(*) from invoices where status = 'overdue')::int,
    coalesce((select sum(total_amount::numeric) from invoices where status = 'overdue'), 0)::numeric,
    (select count(*) from invoices where status in ('sent','overdue'))::int,
    coalesce((select sum(total_amount::numeric) from invoices where status in ('sent','overdue')), 0)::numeric;
$$;

grant execute on function public.get_dashboard_overview() to anon, authenticated, service_role;


-- 2) Fleet alerts: vehicles with CT or insurance expiring within p_days
create or replace function public.get_dashboard_fleet_alerts(p_days int default 60, p_limit int default 8)
returns table (
  id              text,
  plate           text,
  brand           text,
  model           text,
  company_name    text,
  site_name       text,
  ct_due          date,
  ins_due         date,
  earliest_due    date,
  alert_kind      text   -- 'CT' / 'ASSURANCE' / 'CT+ASSURANCE'
)
language sql
stable
security definer
set search_path = public
as $$
  with v as (
    select
      v.id, v.plate, v.brand, v.model,
      c.name as company_name,
      s.name as site_name,
      case when v.next_inspection ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
           then v.next_inspection::date end as ct_due,
      case when v.insurance_due_date ~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}$'
           then v.insurance_due_date::date end as ins_due
    from vehicles v
    left join companies c on c.id = v.company_id
    left join sites s on s.id = v.site_id
  )
  select
    v.id, v.plate, v.brand, v.model, v.company_name, v.site_name,
    v.ct_due, v.ins_due,
    least(coalesce(v.ct_due, date '9999-12-31'), coalesce(v.ins_due, date '9999-12-31')) as earliest_due,
    case
      when v.ct_due is not null and v.ct_due <= current_date + (p_days || ' days')::interval
       and v.ins_due is not null and v.ins_due <= current_date + (p_days || ' days')::interval then 'CT+ASSURANCE'
      when v.ct_due is not null and v.ct_due <= current_date + (p_days || ' days')::interval then 'CT'
      when v.ins_due is not null and v.ins_due <= current_date + (p_days || ' days')::interval then 'ASSURANCE'
      else null
    end as alert_kind
  from v
  where (v.ct_due is not null and v.ct_due <= current_date + (p_days || ' days')::interval)
     or (v.ins_due is not null and v.ins_due <= current_date + (p_days || ' days')::interval)
  order by earliest_due asc
  limit p_limit;
$$;

grant execute on function public.get_dashboard_fleet_alerts(int, int) to anon, authenticated, service_role;


-- 3) Recent / upcoming tournées (planning feed)
create or replace function public.get_dashboard_tournees(p_limit int default 8)
returns table (
  id                uuid,
  reference         text,
  name              text,
  status            text,
  scheduled_date    date,
  total_distance_km numeric,
  driver_name       text,
  vehicle_plate     text,
  company_name      text,
  missions_count    int
)
language sql
stable
security definer
set search_path = public
as $$
  select
    t.id,
    t.reference,
    t.name,
    t.status,
    t.scheduled_date,
    t.total_distance_km::numeric,
    p.full_name as driver_name,
    v.plate_number as vehicle_plate,
    c.name as company_name,
    (select count(*) from tournee_missions tm where tm.tournee_id = t.id)::int as missions_count
  from tournees t
  left join profiles p on p.id = t.driver_id
  left join tms_vehicles v on v.id = t.vehicle_id
  left join companies c on c.id = t.company_id
  order by
    case t.status
      when 'in_progress' then 0
      when 'scheduled'   then 1
      when 'draft'       then 2
      when 'completed'   then 3
      else 4
    end,
    case when t.scheduled_date >= current_date then t.scheduled_date end nulls last,
    t.scheduled_date desc
  limit p_limit;
$$;

grant execute on function public.get_dashboard_tournees(int) to anon, authenticated, service_role;


-- 4) Top overdue / pending invoices
create or replace function public.get_dashboard_overdue_invoices(p_limit int default 6)
returns table (
  id             uuid,
  invoice_number text,
  total_amount   numeric,
  status         text,
  issued_at      date,
  due_at         date,
  days_overdue   int,
  client_name    text,
  mission_ref    text
)
language sql
stable
security definer
set search_path = public
as $$
  select
    i.id,
    i.invoice_number,
    i.total_amount::numeric,
    i.status,
    i.issued_at,
    i.due_at,
    greatest((current_date - i.due_at)::int, 0) as days_overdue,
    cl.company_name as client_name,
    m.reference as mission_ref
  from invoices i
  left join clients cl on cl.id = i.client_id
  left join missions m on m.id = i.mission_id
  where i.status in ('overdue','sent')
  order by
    case i.status when 'overdue' then 0 else 1 end,
    i.due_at asc nulls last
  limit p_limit;
$$;

grant execute on function public.get_dashboard_overdue_invoices(int) to anon, authenticated, service_role;


-- 5) Open / recent incidents
create or replace function public.get_dashboard_incidents(p_limit int default 5)
returns table (
  id             uuid,
  title          text,
  incident_type  text,
  severity       text,
  status         text,
  created_at     timestamptz,
  estimated_cost numeric,
  mission_ref    text,
  driver_name    text
)
language sql
stable
security definer
set search_path = public
as $$
  select
    i.id,
    i.title,
    i.incident_type,
    i.severity,
    i.status,
    i.created_at,
    i.estimated_cost::numeric,
    m.reference as mission_ref,
    p.full_name as driver_name
  from incidents i
  left join missions m on m.id = i.mission_id
  left join profiles p on p.id = i.reported_by
  order by
    case i.status when 'open' then 0 when 'investigating' then 1 else 2 end,
    case i.severity when 'high' then 0 when 'medium' then 1 else 2 end,
    i.created_at desc
  limit p_limit;
$$;

grant execute on function public.get_dashboard_incidents(int) to anon, authenticated, service_role;
