-- Paramètres de facturation (une ligne, mise à jour en place)
CREATE TABLE IF NOT EXISTS public.invoice_settings (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_name         text NOT NULL DEFAULT '',
  seller_address      text NOT NULL DEFAULT '',
  seller_postal_code  text NOT NULL DEFAULT '',
  seller_city         text NOT NULL DEFAULT '',
  seller_email        text NOT NULL DEFAULT '',
  seller_phone        text NOT NULL DEFAULT '',
  seller_rcs          text NOT NULL DEFAULT '',
  seller_code_naf     text NOT NULL DEFAULT '',
  seller_tva          text NOT NULL DEFAULT '',
  seller_legal_form   text NOT NULL DEFAULT '',
  seller_capital      numeric,
  invoice_prefix      text NOT NULL DEFAULT 'EUR',
  tva_rate            numeric NOT NULL DEFAULT 20,
  payment_beneficiary text NOT NULL DEFAULT '',
  payment_bic         text NOT NULL DEFAULT '',
  payment_iban        text NOT NULL DEFAULT '',
  compte_template     text NOT NULL DEFAULT '',
  updated_at          timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.invoice_settings (
  seller_name, seller_address, seller_postal_code, seller_city,
  seller_email, seller_phone, seller_rcs, seller_code_naf, seller_tva,
  seller_legal_form, seller_capital, invoice_prefix, tva_rate,
  payment_beneficiary, payment_bic, payment_iban
) VALUES (
  'PIKA TRANSPORT', '8 AVENUE HENRI BARBUSSE', '93000', 'BOBIGNY',
  'pikatransports@gmail.com', '06 80 80 72 05', '93399600100014', '4941B', 'FR37933996001',
  'SAS', 50000, 'EUR', 20,
  'PIKATRANSPORT', 'QNTOFRP1XXX', 'FR7616958000013673454356051'
) ON CONFLICT DO NOTHING;

ALTER TABLE public.invoice_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "anon_all_invoice_settings" ON public.invoice_settings FOR ALL TO anon USING (true) WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.update_invoice_settings_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
DROP TRIGGER IF EXISTS trg_invoice_settings_updated_at ON public.invoice_settings;
CREATE TRIGGER trg_invoice_settings_updated_at
  BEFORE UPDATE ON public.invoice_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_invoice_settings_updated_at();
