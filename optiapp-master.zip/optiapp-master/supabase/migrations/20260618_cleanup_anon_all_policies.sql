-- Lot 2.f — Suppression des policies `anon_all_*`.
-- Cf. ROADMAP.md.

DROP POLICY IF EXISTS anon_all_clients          ON public.clients;
DROP POLICY IF EXISTS anon_all_missions         ON public.missions;
DROP POLICY IF EXISTS anon_all_profiles         ON public.profiles;
DROP POLICY IF EXISTS anon_all_tms_sites        ON public.tms_sites;
DROP POLICY IF EXISTS anon_all_tms_vehicles     ON public.tms_vehicles;
DROP POLICY IF EXISTS anon_all_tournee_missions ON public.tournee_missions;
DROP POLICY IF EXISTS anon_all_tournee_tolls    ON public.tournee_tolls;
DROP POLICY IF EXISTS anon_all_tournees         ON public.tournees;

CREATE POLICY anon_read_clients          ON public.clients          FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_missions         ON public.missions         FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_profiles         ON public.profiles         FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_tms_sites        ON public.tms_sites        FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_tms_vehicles     ON public.tms_vehicles     FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_tournee_missions ON public.tournee_missions FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_tournee_tolls    ON public.tournee_tolls    FOR SELECT TO anon USING (true);
CREATE POLICY anon_read_tournees         ON public.tournees         FOR SELECT TO anon USING (true);

CREATE POLICY auth_all_clients          ON public.clients          FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_missions         ON public.missions         FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_profiles         ON public.profiles         FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_tms_sites        ON public.tms_sites        FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_tms_vehicles     ON public.tms_vehicles     FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_tournee_missions ON public.tournee_missions FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_tournee_tolls    ON public.tournee_tolls    FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_tournees         ON public.tournees         FOR ALL TO authenticated USING (true) WITH CHECK (true);
