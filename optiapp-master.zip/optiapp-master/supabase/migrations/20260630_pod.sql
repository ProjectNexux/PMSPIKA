-- ────────────────────────────────────────────────────────────────────────────
-- MODULE 1 — POD : Preuve de livraison mobile
-- Tables : delivery_events, proof_of_delivery, pod_attachments
-- + colonnes de suivi sur missions + bucket Storage privé 'pod-proofs'
-- ────────────────────────────────────────────────────────────────────────────

-- ── Bucket privé pour signatures / photos / scans ──────────────────────────
INSERT INTO storage.buckets (id, name, public)
VALUES ('pod-proofs', 'pod-proofs', false)
ON CONFLICT (id) DO NOTHING;

-- Lecture/écriture réservées aux utilisateurs authentifiés (les URLs publiques
-- sont désactivées : on sert des URLs signées via le service role).
DROP POLICY IF EXISTS pod_authenticated_read  ON storage.objects;
DROP POLICY IF EXISTS pod_authenticated_write ON storage.objects;
CREATE POLICY pod_authenticated_read  ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'pod-proofs');
CREATE POLICY pod_authenticated_write ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'pod-proofs');

-- ── Événements de livraison (machine à états + horodatage + géoloc) ─────────
CREATE TABLE IF NOT EXISTS public.delivery_events (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id     uuid,
  mission_id     uuid NOT NULL REFERENCES public.missions(id) ON DELETE CASCADE,
  driver_id      uuid,
  event_type     text NOT NULL,   -- 'enleve'|'en_transit'|'en_livraison'|'livre'|'echec'|'reserve'
  failure_reason text,            -- si event_type='echec' : 'absent'|'refuse'|'adresse_introuvable'|'autre'
  lat            numeric,
  lng            numeric,
  occurred_at    timestamptz NOT NULL DEFAULT now(),
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now()
);

-- ── En-tête de preuve de livraison (1 POD = 1 livraison validée) ────────────
CREATE TABLE IF NOT EXISTS public.proof_of_delivery (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id     uuid,
  mission_id     uuid NOT NULL REFERENCES public.missions(id) ON DELETE CASCADE,
  driver_id      uuid,
  recipient_name text,
  status         text NOT NULL DEFAULT 'livre', -- 'livre'|'livre_avec_reserve'|'refuse'
  reserve_text   text,
  signature_path text,
  lat            numeric,
  lng            numeric,
  signed_at      timestamptz NOT NULL DEFAULT now(),
  created_at     timestamptz NOT NULL DEFAULT now(),
  UNIQUE (mission_id)
);

-- ── Pièces jointes d'une preuve (photos, scans) ─────────────────────────────
CREATE TABLE IF NOT EXISTS public.pod_attachments (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pod_id     uuid NOT NULL REFERENCES public.proof_of_delivery(id) ON DELETE CASCADE,
  kind       text NOT NULL DEFAULT 'photo', -- 'photo'|'scan'
  file_path  text NOT NULL,
  barcode    text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- ── Indexes ─────────────────────────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_delivery_events_mission ON public.delivery_events(mission_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_pod_mission             ON public.proof_of_delivery(mission_id);
CREATE INDEX IF NOT EXISTS idx_pod_attachments_pod     ON public.pod_attachments(pod_id);

-- ── Suivi rapide de livraison sur la mission ────────────────────────────────
ALTER TABLE public.missions
  ADD COLUMN IF NOT EXISTS delivery_status text DEFAULT 'a_traiter', -- 'a_traiter'|'enleve'|'en_transit'|'en_livraison'|'livre'|'echec'
  ADD COLUMN IF NOT EXISTS delivered_at    timestamptz,
  ADD COLUMN IF NOT EXISTS pod_id          uuid REFERENCES public.proof_of_delivery(id) ON DELETE SET NULL;

-- ── RLS ─────────────────────────────────────────────────────────────────────
ALTER TABLE public.delivery_events   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proof_of_delivery ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pod_attachments   ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS auth_all_delivery_events   ON public.delivery_events;
DROP POLICY IF EXISTS auth_all_proof_of_delivery ON public.proof_of_delivery;
DROP POLICY IF EXISTS auth_all_pod_attachments   ON public.pod_attachments;

CREATE POLICY auth_all_delivery_events   ON public.delivery_events   FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_proof_of_delivery ON public.proof_of_delivery FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_pod_attachments   ON public.pod_attachments   FOR ALL TO authenticated USING (true) WITH CHECK (true);
