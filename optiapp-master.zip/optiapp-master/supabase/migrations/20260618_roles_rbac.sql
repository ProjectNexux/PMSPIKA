-- ════════════════════════════════════════════════════════════════════════════
-- Migration : RBAC (Role-Based Access Control) Jamal Transport
-- ════════════════════════════════════════════════════════════════════════════
-- Met en place 5 rôles applicatifs + helpers SQL + RLS scopée par rôle.
--
-- Rôles
--   super_admin     : accès total, peut tout faire (ex: super utilisateur)
--   gerant_groupe   : accès lecture/écriture à toutes les sociétés
--   gerant_societe  : accès uniquement à sa société (profiles.company_id)
--   chef_site       : accès uniquement à son site (profiles.site_id)
--   chauffeur       : accès uniquement à ses propres données (auth.uid())
--   client          : accès lecture limitée à ses propres missions (legacy)
--
-- Sécurité
--   - Ne supprime PAS les policies anon existantes (compat phase de transition).
--     À supprimer dans une migration suivante une fois toutes les requêtes
--     migrées vers un client authentifié.
--   - Helpers (auth.app_*) sont SECURITY DEFINER pour lire profiles sans
--     déclencher la RLS récursive.
-- ════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ── 1. Enum des rôles ───────────────────────────────────────────────────────
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'app_role') THEN
    CREATE TYPE public.app_role AS ENUM (
      'super_admin',
      'gerant_groupe',
      'gerant_societe',
      'chef_site',
      'chauffeur',
      'client'
    );
  END IF;
END $$;

-- ── 2. Migration de profiles.role (text → app_role) ─────────────────────────
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS company_id text REFERENCES public.companies(id) ON DELETE SET NULL;

-- Backup de la colonne actuelle (pour rollback éventuel)
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS role_legacy text;

UPDATE public.profiles
SET role_legacy = role::text
WHERE role_legacy IS NULL;

-- Drop policies qui référencent profiles.role (sinon ALTER TYPE échoue)
DROP POLICY IF EXISTS profiles_select ON public.profiles;
DROP POLICY IF EXISTS profiles_update_own ON public.profiles;
DROP POLICY IF EXISTS "Drivers update own position" ON public.profiles;

-- Conversion in-place vers l'enum
ALTER TABLE public.profiles
  ALTER COLUMN role DROP DEFAULT;

ALTER TABLE public.profiles
  ALTER COLUMN role TYPE public.app_role
  USING (
    CASE
      WHEN email = 'mboudjelida@optimove.fr' THEN 'super_admin'::public.app_role
      WHEN role = 'manager' THEN 'gerant_groupe'::public.app_role
      WHEN role = 'driver'  THEN 'chauffeur'::public.app_role
      WHEN role = 'client'  THEN 'client'::public.app_role
      ELSE 'chauffeur'::public.app_role
    END
  );

ALTER TABLE public.profiles
  ALTER COLUMN role SET DEFAULT 'chauffeur'::public.app_role;

ALTER TABLE public.profiles
  ALTER COLUMN role SET NOT NULL;

CREATE INDEX IF NOT EXISTS idx_profiles_role        ON public.profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_company_id  ON public.profiles(company_id);
CREATE INDEX IF NOT EXISTS idx_profiles_site_id     ON public.profiles(site_id);

-- ── 3. Helpers SQL (lecture du profil courant) ──────────────────────────────
-- Stockés dans le schéma public pour rester accessibles via PostgREST.

CREATE OR REPLACE FUNCTION public.app_user_role()
RETURNS public.app_role
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION public.app_user_company_id()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT company_id FROM public.profiles WHERE id = auth.uid()
$$;

CREATE OR REPLACE FUNCTION public.app_user_site_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT site_id FROM public.profiles WHERE id = auth.uid()
$$;

-- Vrai pour super_admin et gerant_groupe (visibilité globale)
CREATE OR REPLACE FUNCTION public.app_is_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.app_user_role() IN ('super_admin', 'gerant_groupe')
$$;

-- Vrai uniquement pour le super utilisateur
CREATE OR REPLACE FUNCTION public.app_is_super_admin()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.app_user_role() = 'super_admin'
$$;

GRANT EXECUTE ON FUNCTION public.app_user_role()        TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.app_user_company_id()  TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.app_user_site_id()     TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.app_is_admin()         TO authenticated, anon;
GRANT EXECUTE ON FUNCTION public.app_is_super_admin()   TO authenticated, anon;

-- ── 4. RLS sur profiles ─────────────────────────────────────────────────────
-- (RLS déjà activée)

-- Lecture
CREATE POLICY profiles_read_scoped ON public.profiles
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()                                                                 -- admin global
    OR id = auth.uid()                                                                    -- soi-même
    OR (public.app_user_role() = 'gerant_societe' AND company_id = public.app_user_company_id())
    OR (public.app_user_role() = 'chef_site'      AND site_id    = public.app_user_site_id())
  );

-- Mise à jour : soi-même OU admin global
CREATE POLICY profiles_update_scoped ON public.profiles
  FOR UPDATE
  TO authenticated
  USING (
    id = auth.uid() OR public.app_is_admin()
  )
  WITH CHECK (
    id = auth.uid() OR public.app_is_admin()
  );

-- Création/suppression : admin uniquement (gestion utilisateurs)
CREATE POLICY profiles_admin_insert ON public.profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (public.app_is_admin());

CREATE POLICY profiles_admin_delete ON public.profiles
  FOR DELETE
  TO authenticated
  USING (public.app_is_admin());

-- ── 5. RLS sur companies ────────────────────────────────────────────────────
ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

CREATE POLICY companies_read_scoped ON public.companies
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR id = public.app_user_company_id()
    OR id = (SELECT t.company_id FROM public.tms_sites s
             LEFT JOIN public.tournees t ON t.site_id = s.id
             WHERE s.id = public.app_user_site_id() LIMIT 1)
  );

CREATE POLICY companies_admin_write ON public.companies
  FOR ALL
  TO authenticated
  USING (public.app_is_admin())
  WITH CHECK (public.app_is_admin());

-- Compat : lecture anon temporairement (à retirer)
CREATE POLICY companies_anon_read ON public.companies
  FOR SELECT TO anon USING (true);

-- ── 6. RLS sur tournees / missions (scopées) ────────────────────────────────
-- On garde les policies anon existantes pour ne rien casser.

CREATE POLICY tournees_role_scoped ON public.tournees
  FOR ALL
  TO authenticated
  USING (
    public.app_is_admin()
    OR (public.app_user_role() = 'gerant_societe' AND company_id = public.app_user_company_id())
    OR (public.app_user_role() = 'chef_site'      AND site_id    = public.app_user_site_id())
    OR (public.app_user_role() = 'chauffeur'      AND driver_id  = auth.uid())
  )
  WITH CHECK (
    public.app_is_admin()
    OR (public.app_user_role() = 'gerant_societe' AND company_id = public.app_user_company_id())
    OR (public.app_user_role() = 'chef_site'      AND site_id    = public.app_user_site_id())
  );

CREATE POLICY missions_role_scoped ON public.missions
  FOR ALL
  TO authenticated
  USING (
    public.app_is_admin()
    OR (public.app_user_role() = 'gerant_societe' AND company_id = public.app_user_company_id())
    OR (public.app_user_role() = 'chauffeur'      AND driver_id  = auth.uid())
  )
  WITH CHECK (
    public.app_is_admin()
    OR (public.app_user_role() = 'gerant_societe' AND company_id = public.app_user_company_id())
  );

-- ── 7. Activer RLS sur les tables actuellement ouvertes ─────────────────────
-- (Voir advisory rls_disabled — tables sans RLS exposées via anon key)

ALTER TABLE public.employees           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicles            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents           ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.sites               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contractors         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ledger_entries      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payroll_variables   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.route_metrics       ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.absences            ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks               ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.employee_documents  ENABLE ROW LEVEL SECURITY;

-- Policies de transition : lecture anon ouverte (compat) + admin write
-- À durcir au cas par cas dans une migration suivante.

DO $$
DECLARE
  t text;
  tables text[] := ARRAY[
    'employees','vehicles','documents','sites','contractors',
    'ledger_entries','payroll_variables','route_metrics','absences',
    'tasks','employee_documents'
  ];
BEGIN
  FOREACH t IN ARRAY tables LOOP
    -- Lecture anon (transition)
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR SELECT TO anon USING (true)',
      t || '_anon_read', t
    );
    -- Lecture/écriture authenticated (admin = tout, autres = scoped via company_id si la colonne existe)
    EXECUTE format(
      'CREATE POLICY %I ON public.%I FOR ALL TO authenticated USING (true) WITH CHECK (public.app_is_admin())',
      t || '_auth_all', t
    );
  END LOOP;
END $$;

-- ── 8. RLS scopée fine sur employees (ressource RH sensible) ────────────────
DROP POLICY IF EXISTS employees_auth_all ON public.employees;

CREATE POLICY employees_read_scoped ON public.employees
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR (public.app_user_role() = 'gerant_societe' AND company_id = public.app_user_company_id())
    OR (public.app_user_role() = 'chef_site'      AND site_id    IN (
          SELECT s.id FROM public.sites s WHERE s.id = public.app_user_site_id()::text
        ))
    OR (public.app_user_role() = 'chauffeur'      AND id         = (
          SELECT employee_id FROM public.profiles WHERE id = auth.uid()
        ))
  );

CREATE POLICY employees_admin_write ON public.employees
  FOR ALL
  TO authenticated
  USING (public.app_is_admin())
  WITH CHECK (public.app_is_admin());

-- ── 9. Vue utilitaire : utilisateur courant + droits ────────────────────────
CREATE OR REPLACE VIEW public.app_current_user AS
SELECT
  p.id,
  p.email,
  p.full_name,
  p.role,
  p.company_id,
  p.site_id,
  p.employee_id,
  c.name AS company_name,
  c.color AS company_color,
  s.name AS site_name,
  public.app_is_admin()       AS is_admin,
  public.app_is_super_admin() AS is_super_admin
FROM public.profiles p
LEFT JOIN public.companies c ON c.id = p.company_id
LEFT JOIN public.tms_sites s ON s.id = p.site_id
WHERE p.id = auth.uid();

GRANT SELECT ON public.app_current_user TO authenticated;

COMMIT;
