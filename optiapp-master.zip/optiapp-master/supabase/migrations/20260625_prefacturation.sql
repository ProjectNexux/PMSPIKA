-- ─────────────────────────────────────────────────────────────────
-- Pré-facturation : lien client + suivi facturation sur les tournées
-- ─────────────────────────────────────────────────────────────────

-- Lier une tournée à un client facturable
ALTER TABLE public.tournees
  ADD COLUMN IF NOT EXISTS client_id uuid REFERENCES public.invoice_clients(id) ON DELETE SET NULL;

-- Tracker quelle facture a couvert cette tournée
ALTER TABLE public.tournees
  ADD COLUMN IF NOT EXISTS billed_invoice_id uuid REFERENCES public.invoices(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_tournees_client_id      ON public.tournees(client_id);
CREATE INDEX IF NOT EXISTS idx_tournees_billed_invoice ON public.tournees(billed_invoice_id);
CREATE INDEX IF NOT EXISTS idx_tournees_sched_date     ON public.tournees(scheduled_date);
