-- RGPD : politique de rétention + helpers anonymisation.
-- cf. ROADMAP.md (Lot 2.b) pour la procédure d'arbitrage des durées.

CREATE OR REPLACE FUNCTION public.rgpd_purge(
  p_driver_events_days  int DEFAULT 365,
  p_driver_hours_days   int DEFAULT 1095,
  p_driver_logs_days    int DEFAULT 1095,
  p_notifications_days  int DEFAULT 180,
  p_audit_log_days      int DEFAULT 1095
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  n_events int := 0;
  n_hours  int := 0;
  n_logs   int := 0;
  n_notifs int := 0;
  n_audit  int := 0;
BEGIN
  DELETE FROM public.driver_events
   WHERE created_at < now() - (p_driver_events_days * INTERVAL '1 day');
  GET DIAGNOSTICS n_events = ROW_COUNT;

  IF to_regclass('public.driver_hours_log') IS NOT NULL THEN
    EXECUTE format(
      'DELETE FROM public.driver_hours_log WHERE created_at < now() - (%L * INTERVAL ''1 day'')',
      p_driver_hours_days
    );
    GET DIAGNOSTICS n_hours = ROW_COUNT;
  END IF;

  IF to_regclass('public.driver_logs') IS NOT NULL THEN
    EXECUTE format(
      'DELETE FROM public.driver_logs WHERE created_at < now() - (%L * INTERVAL ''1 day'')',
      p_driver_logs_days
    );
    GET DIAGNOSTICS n_logs = ROW_COUNT;
  END IF;

  IF to_regclass('public.notifications') IS NOT NULL THEN
    EXECUTE format(
      'DELETE FROM public.notifications WHERE created_at < now() - (%L * INTERVAL ''1 day'') AND read = true',
      p_notifications_days
    );
    GET DIAGNOSTICS n_notifs = ROW_COUNT;
  END IF;

  DELETE FROM public.audit_log
   WHERE at < now() - (p_audit_log_days * INTERVAL '1 day');
  GET DIAGNOSTICS n_audit = ROW_COUNT;

  RETURN jsonb_build_object(
    'at', now(),
    'driver_events', n_events,
    'driver_hours_log', n_hours,
    'driver_logs', n_logs,
    'notifications', n_notifs,
    'audit_log', n_audit
  );
END;
$$;

REVOKE ALL ON FUNCTION public.rgpd_purge(int,int,int,int,int) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.rgpd_purge(int,int,int,int,int) TO service_role;

CREATE OR REPLACE FUNCTION public.rgpd_anonymize_user(p_user_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_hash text := encode(digest(p_user_id::text || now()::text, 'sha256'), 'hex');
BEGIN
  UPDATE public.profiles
     SET full_name        = 'Utilisateur anonymisé ' || left(v_hash, 8),
         email            = 'deleted+' || left(v_hash, 12) || '@anonymized.local',
         phone            = NULL,
         avatar_url       = NULL,
         last_lat         = NULL,
         last_lng         = NULL,
         last_position_at = NULL,
         license_number   = NULL,
         updated_at       = now()
   WHERE id = p_user_id;

  DELETE FROM public.driver_events WHERE driver_id = p_user_id;

  RETURN jsonb_build_object('user_id', p_user_id, 'hash', v_hash, 'at', now());
END;
$$;

REVOKE ALL ON FUNCTION public.rgpd_anonymize_user(uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.rgpd_anonymize_user(uuid) TO service_role;
