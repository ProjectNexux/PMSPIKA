-- ────────────────────────────────────────────────────────────────────────────
-- MODULE 2 — Suivi temps réel + tracking client public
-- Table driver_positions (historique) + token public & ETA sur missions
-- ────────────────────────────────────────────────────────────────────────────

-- ── Historique des positions chauffeur (au lieu d'écraser profiles.last_*) ──
CREATE TABLE IF NOT EXISTS public.driver_positions (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  driver_id   uuid NOT NULL,
  company_id  uuid,
  lat         numeric NOT NULL,
  lng         numeric NOT NULL,
  speed_kmh   numeric,
  heading     numeric,
  recorded_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_driver_positions_driver ON public.driver_positions(driver_id, recorded_at DESC);

-- ── Token public de suivi par mission + ETA ─────────────────────────────────
ALTER TABLE public.missions
  ADD COLUMN IF NOT EXISTS tracking_token text UNIQUE DEFAULT encode(gen_random_bytes(12), 'hex'),
  ADD COLUMN IF NOT EXISTS eta            timestamptz;

-- Backfill des tokens pour les missions existantes (sans token)
UPDATE public.missions
SET tracking_token = encode(gen_random_bytes(12), 'hex')
WHERE tracking_token IS NULL;

CREATE INDEX IF NOT EXISTS idx_missions_tracking_token ON public.missions(tracking_token);

-- ── RLS ─────────────────────────────────────────────────────────────────────
-- driver_positions : accès réservé aux authentifiés. Le suivi public passe par
-- un Route Handler service-role filtré par token (jamais d'accès anon direct).
ALTER TABLE public.driver_positions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS auth_all_driver_positions ON public.driver_positions;
CREATE POLICY auth_all_driver_positions ON public.driver_positions
  FOR ALL TO authenticated USING (true) WITH CHECK (true);
