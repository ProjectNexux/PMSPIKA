-- Add missing planning volume column used by site create/update server actions.
ALTER TABLE public.sites
  ADD COLUMN IF NOT EXISTS monthly_routes integer NOT NULL DEFAULT 0;
