-- ════════════════════════════════════════════════════════════════════════════
-- Migration: FIX RLS POLICIES - Security Hardening
-- ════════════════════════════════════════════════════════════════════════════
-- Remplace les policies dangereux "USING (true)" par des policies scoped
-- par company_id selon le système RBAC existant.
--
-- BEFORE: auth_all_clients USING (true) → n'importe quel user accède tout
-- AFTER: Scoped par company_id pour les gerant_societe/gerant_groupe
-- ════════════════════════════════════════════════════════════════════════════

BEGIN;

-- ── 1. CLIENTS - Company scoping ────────────────────────────────────────────
DROP POLICY IF EXISTS auth_all_clients ON public.clients;

CREATE POLICY auth_clients_scoped ON public.clients
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_clients_insert ON public.clients
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_clients_update ON public.clients
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  )
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_clients_delete ON public.clients
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

-- ── 2. MISSIONS - Company scoping ───────────────────────────────────────────
DROP POLICY IF EXISTS auth_all_missions ON public.missions;

CREATE POLICY auth_missions_scoped ON public.missions
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
    OR assigned_to = auth.uid()  -- Chauffeurs voient leurs missions
  );

CREATE POLICY auth_missions_insert ON public.missions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_missions_update ON public.missions
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
    OR assigned_to = auth.uid()  -- Chauffeurs peuvent updater leurs missions
  )
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_missions_delete ON public.missions
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

-- ── 3. TMSITESS - Company scoping ───────────────────────────────────────────
DROP POLICY IF EXISTS auth_all_tms_sites ON public.tms_sites;

CREATE POLICY auth_tms_sites_scoped ON public.tms_sites
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
    OR id = public.app_user_site_id()
  );

CREATE POLICY auth_tms_sites_insert ON public.tms_sites
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_tms_sites_update ON public.tms_sites
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
    OR id = public.app_user_site_id()
  )
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_tms_sites_delete ON public.tms_sites
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

-- ── 4. TMS_VEHICLES - Company scoping ───────────────────────────────────────
DROP POLICY IF EXISTS auth_all_tms_vehicles ON public.tms_vehicles;

CREATE POLICY auth_tms_vehicles_scoped ON public.tms_vehicles
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
    OR id IN (
      SELECT vehicle_id FROM public.missions
      WHERE assigned_to = auth.uid()
    )
  );

CREATE POLICY auth_tms_vehicles_insert ON public.tms_vehicles
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_tms_vehicles_update ON public.tms_vehicles
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  )
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_tms_vehicles_delete ON public.tms_vehicles
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

-- ── 5. TOURNEES - Company scoping ───────────────────────────────────────────
DROP POLICY IF EXISTS auth_all_tournees ON public.tournees;

CREATE POLICY auth_tournees_scoped ON public.tournees
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
    OR id IN (
      SELECT tournee_id FROM public.tournee_missions tm
      JOIN public.missions m ON tm.mission_id = m.id
      WHERE m.assigned_to = auth.uid()
    )
  );

CREATE POLICY auth_tournees_insert ON public.tournees
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_tournees_update ON public.tournees
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  )
  WITH CHECK (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

CREATE POLICY auth_tournees_delete ON public.tournees
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR company_id = public.app_user_company_id()
  );

-- ── 6. TOURNEE_MISSIONS - Operation scoping ────────────────────────────────
DROP POLICY IF EXISTS auth_all_tournee_missions ON public.tournee_missions;

CREATE POLICY auth_tournee_missions_scoped ON public.tournee_missions
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR mission_id IN (
      SELECT id FROM public.missions
      WHERE company_id = public.app_user_company_id() OR assigned_to = auth.uid()
    )
  );

CREATE POLICY auth_tournee_missions_insert ON public.tournee_missions
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR mission_id IN (
      SELECT id FROM public.missions
      WHERE company_id = public.app_user_company_id()
    )
  );

CREATE POLICY auth_tournee_missions_update ON public.tournee_missions
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR mission_id IN (
      SELECT id FROM public.missions
      WHERE company_id = public.app_user_company_id() OR assigned_to = auth.uid()
    )
  )
  WITH CHECK (
    public.app_is_admin()
    OR mission_id IN (
      SELECT id FROM public.missions
      WHERE company_id = public.app_user_company_id()
    )
  );

CREATE POLICY auth_tournee_missions_delete ON public.tournee_missions
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR mission_id IN (
      SELECT id FROM public.missions
      WHERE company_id = public.app_user_company_id()
    )
  );

-- ── 7. TOURNEE_TOLLS - Operation scoping ────────────────────────────────────
DROP POLICY IF EXISTS auth_all_tournee_tolls ON public.tournee_tolls;

CREATE POLICY auth_tournee_tolls_scoped ON public.tournee_tolls
  FOR SELECT
  TO authenticated
  USING (
    public.app_is_admin()
    OR tournee_id IN (
      SELECT id FROM public.tournees
      WHERE company_id = public.app_user_company_id()
    )
    OR tournee_id IN (
      SELECT t.id FROM public.tournees t
      JOIN public.tournee_missions tm ON tm.tournee_id = t.id
      JOIN public.missions m ON tm.mission_id = m.id
      WHERE m.assigned_to = auth.uid()
    )
  );

CREATE POLICY auth_tournee_tolls_insert ON public.tournee_tolls
  FOR INSERT
  TO authenticated
  WITH CHECK (
    public.app_is_admin()
    OR tournee_id IN (
      SELECT id FROM public.tournees
      WHERE company_id = public.app_user_company_id()
    )
  );

CREATE POLICY auth_tournee_tolls_update ON public.tournee_tolls
  FOR UPDATE
  TO authenticated
  USING (
    public.app_is_admin()
    OR tournee_id IN (
      SELECT id FROM public.tournees
      WHERE company_id = public.app_user_company_id()
    )
  )
  WITH CHECK (
    public.app_is_admin()
    OR tournee_id IN (
      SELECT id FROM public.tournees
      WHERE company_id = public.app_user_company_id()
    )
  );

CREATE POLICY auth_tournee_tolls_delete ON public.tournee_tolls
  FOR DELETE
  TO authenticated
  USING (
    public.app_is_admin()
    OR tournee_id IN (
      SELECT id FROM public.tournees
      WHERE company_id = public.app_user_company_id()
    )
  );

-- ── 8. ANONYMOUS policies - Restrict to public data only ─────────────────────
-- Keep anon read-only on non-sensitive data

DROP POLICY IF EXISTS anon_read_clients ON public.clients;
DROP POLICY IF EXISTS anon_read_missions ON public.missions;
DROP POLICY IF EXISTS anon_read_tms_sites ON public.tms_sites;
DROP POLICY IF EXISTS anon_read_tms_vehicles ON public.tms_vehicles;
DROP POLICY IF EXISTS anon_read_tournees ON public.tournees;

-- Anonymous users cannot access sensitive data
-- If needed, create explicit public views instead of direct table access

-- ── 9. Audit & logging ──────────────────────────────────────────────────────
-- Log this security change
INSERT INTO public.audit_log (
  table_name,
  operation,
  user_id,
  changes
) VALUES (
  'rls_policies',
  'HARDENED',
  NULL,
  jsonb_build_object(
    'reason', 'Fixed overly permissive USING (true) policies',
    'migration', 'fix_rls_policies_security',
    'timestamp', NOW()
  )
);

COMMIT;
