-- ─────────────────────────────────────────────────────────────────
-- Système de facturation PIKA TRANSPORT
-- Standalone: pas de FK sur companies (table peut ne pas exister)
-- ─────────────────────────────────────────────────────────────────

-- Clients facturables (répertoire)
CREATE TABLE IF NOT EXISTS public.invoice_clients (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  name        text NOT NULL,
  address     text,
  postal_code text,
  city        text,
  email       text,
  phone       text,
  rcs         text,
  code_ape    text,
  id_tva      text,
  legal_form  text,
  capital     numeric,
  iban        text,
  bic         text,
  notes       text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Factures
CREATE TABLE IF NOT EXISTS public.invoices (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid,
  invoice_number  text NOT NULL,
  issue_date      date NOT NULL DEFAULT current_date,
  period          text,
  driver_name     text,
  vehicle_plate   text,

  client_id           uuid REFERENCES public.invoice_clients(id) ON DELETE SET NULL,
  client_name         text NOT NULL,
  client_address      text,
  client_postal_code  text,
  client_city         text,
  client_email        text,
  client_phone        text,
  client_rcs          text,
  client_code_ape     text,
  client_id_tva       text,
  client_legal_form   text,
  client_capital      numeric,

  seller_name         text,
  seller_address      text,
  seller_postal_code  text,
  seller_city         text,
  seller_email        text,
  seller_phone        text,
  seller_rcs          text,
  seller_code_naf     text,
  seller_tva          text,
  seller_legal_form   text,
  seller_capital      numeric,

  compte              text,
  tva_rate            numeric NOT NULL DEFAULT 20,
  image_rights_rate   numeric NOT NULL DEFAULT 1,

  payment_beneficiary text,
  payment_bic         text,
  payment_iban        text,

  status      text NOT NULL DEFAULT 'Brouillon',
  notes       text,

  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Lignes de facture
CREATE TABLE IF NOT EXISTS public.invoice_lines (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id   uuid NOT NULL REFERENCES public.invoices(id) ON DELETE CASCADE,
  sort_order   int NOT NULL DEFAULT 0,
  line_date    date,
  ref          text,
  exp_address  text,
  dest_address text,
  poids_kg     numeric,
  qty_trips    numeric,
  qty_taxable  numeric,
  total_ht     numeric NOT NULL DEFAULT 0,
  ecotaxe      numeric NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_invoices_company     ON public.invoices(company_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status      ON public.invoices(status);
CREATE INDEX IF NOT EXISTS idx_invoice_lines_inv    ON public.invoice_lines(invoice_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_invoice_clients_cmp  ON public.invoice_clients(company_id);

CREATE OR REPLACE FUNCTION public.update_invoices_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_invoices_updated_at ON public.invoices;
CREATE TRIGGER trg_invoices_updated_at
  BEFORE UPDATE ON public.invoices
  FOR EACH ROW EXECUTE FUNCTION public.update_invoices_updated_at();

ALTER TABLE public.invoice_clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices        ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoice_lines   ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anon_all_invoice_clients" ON public.invoice_clients FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_invoices"        ON public.invoices        FOR ALL TO anon USING (true) WITH CHECK (true);
CREATE POLICY "anon_all_invoice_lines"   ON public.invoice_lines   FOR ALL TO anon USING (true) WITH CHECK (true);
