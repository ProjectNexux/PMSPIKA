-- Recherche globale ⌘K (UNION sociétés / employés / véhicules / missions / sites).
-- Cf. ROADMAP.md (Lot 2.d).

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;
CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;

CREATE OR REPLACE FUNCTION public.global_search(p_q text, p_limit int DEFAULT 20)
RETURNS TABLE (
  kind text,
  id text,
  title text,
  subtitle text,
  href text,
  rank real
)
LANGUAGE sql
STABLE
SECURITY INVOKER
AS $$
  WITH q AS (
    SELECT lower(unaccent(coalesce(trim(p_q), ''))) AS norm
  )
  SELECT * FROM (
    SELECT
      'company'::text AS kind,
      c.id::text AS id,
      c.name AS title,
      coalesce(c.legal_name, '') AS subtitle,
      '/societes/' || c.id::text AS href,
      similarity(lower(unaccent(c.name)), (SELECT norm FROM q)) AS rank
    FROM public.companies c, q
    WHERE length(q.norm) >= 2
      AND (lower(unaccent(c.name)) LIKE '%' || q.norm || '%'
        OR lower(unaccent(coalesce(c.legal_name, ''))) LIKE '%' || q.norm || '%')
    UNION ALL
    SELECT
      'employee'::text, e.id::text,
      coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, ''),
      coalesce(e.role, '') || coalesce(' · ' || nullif(e.email,''), ''),
      '/societes/' || coalesce(e.company_id::text, '') || '/social',
      similarity(
        lower(unaccent(coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, ''))),
        (SELECT norm FROM q)
      )
    FROM public.employees e, q
    WHERE length(q.norm) >= 2
      AND (lower(unaccent(coalesce(e.first_name, '') || ' ' || coalesce(e.last_name, ''))) LIKE '%' || q.norm || '%'
        OR lower(unaccent(coalesce(e.email, ''))) LIKE '%' || q.norm || '%')
    UNION ALL
    SELECT
      'vehicle'::text, v.id::text, v.plate_number,
      coalesce(v.brand, '') || ' ' || coalesce(v.model, ''),
      '/societes/' || coalesce(v.company_id::text, '') || '/vehicules',
      similarity(lower(unaccent(v.plate_number)), (SELECT norm FROM q))
    FROM public.tms_vehicles v, q
    WHERE length(q.norm) >= 2
      AND lower(unaccent(v.plate_number)) LIKE '%' || q.norm || '%'
    UNION ALL
    SELECT
      'mission'::text, m.id::text, coalesce(m.reference, m.id::text),
      coalesce(m.pickup_city, '') || ' → ' || coalesce(m.delivery_city, ''),
      '/pilotage',
      similarity(lower(unaccent(coalesce(m.reference, ''))), (SELECT norm FROM q))
    FROM public.missions m, q
    WHERE length(q.norm) >= 2
      AND m.reference IS NOT NULL
      AND lower(unaccent(m.reference)) LIKE '%' || q.norm || '%'
    UNION ALL
    SELECT
      'site'::text, s.id::text, s.name, coalesce(s.region, ''),
      '/societes/' || coalesce(s.company_id::text, '') || '/sites',
      similarity(lower(unaccent(s.name)), (SELECT norm FROM q))
    FROM public.sites s, q
    WHERE length(q.norm) >= 2
      AND lower(unaccent(s.name)) LIKE '%' || q.norm || '%'
  ) results
  ORDER BY rank DESC NULLS LAST, title
  LIMIT p_limit;
$$;

GRANT EXECUTE ON FUNCTION public.global_search(text, int) TO authenticated, anon;
