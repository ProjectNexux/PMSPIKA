-- ── Company-scoped dashboard RPCs ────────────────────────────────────────────
-- p_company_id is text (matches profiles.company_id / employees.company_id).
-- Tables with uuid company_id get an explicit ::uuid cast.
-- Tables not yet in schema (tournees, vehicles, incidents, documents) return
-- zeros or empty result sets.

-- 1) Aggregated snapshot per company (one row)
create or replace function public.get_dashboard_company_overview(p_company_id text)
returns table (
  tournees_today               int,
  tournees_in_progress         int,
  tournees_scheduled_week      int,
  tournees_completed_week      int,
  missions_in_progress         int,
  missions_assigned            int,
  missions_today               int,
  missions_completed_30d       int,
  fleet_total                  int,
  fleet_active                 int,
  fleet_maintenance            int,
  tms_fleet_total              int,
  tms_fleet_available          int,
  tms_fleet_on_mission         int,
  tms_fleet_maintenance        int,
  employees_active             int,
  drivers_active               int,
  absences_active              int,
  documents_critical           int,
  documents_expiring_30d       int,
  vehicles_ct_30d              int,
  vehicles_ct_60d              int,
  vehicles_ins_30d             int,
  vehicles_ins_60d             int,
  incidents_open               int,
  tasks_open_high              int,
  period                       text,
  revenue_period               numeric,
  expenses_period              numeric,
  margin_period                numeric,
  invoices_overdue_count       int,
  invoices_overdue_amount      numeric,
  invoices_outstanding_count   int,
  invoices_outstanding_amount  numeric
)
language sql
stable
security definer
set search_path = public
as $$
  with
    curr_period as (
      select to_char(current_date, 'YYYY-MM') as p
    ),
    cid_uuid as (
      select p_company_id::uuid as v
    ),
    inv_totals as (
      select
        i.id,
        i.status,
        coalesce(sum((il.total_ht + coalesce(il.ecotaxe, 0)) * (1 + coalesce(i.tva_rate, 0) / 100)), 0) as total_ttc
      from invoices i
      left join invoice_lines il on il.invoice_id = i.id
      where i.company_id = (select v from cid_uuid)
      group by i.id, i.status
    ),
    cash as (
      select
        coalesce(sum(case when ct.amount > 0 then ct.amount else 0 end), 0) as revenue,
        coalesce(sum(case when ct.amount < 0 then abs(ct.amount) else 0 end), 0) as expenses
      from cash_transactions ct
      where ct.company_id = (select v from cid_uuid)
        and to_char(ct.date, 'YYYY-MM') = (select p from curr_period)
    )
  select
    0::int, 0::int, 0::int, 0::int,
    0::int, 0::int, 0::int, 0::int,
    0::int, 0::int, 0::int,
    0::int, 0::int, 0::int, 0::int,
    (select count(*) from employees e where e.company_id = p_company_id and e.status = 'Actif')::int,
    (select count(*) from employees e where e.company_id = p_company_id and e.status = 'Actif' and e.role ilike '%chauffeur%')::int,
    0::int,
    0::int, 0::int, 0::int, 0::int, 0::int, 0::int, 0::int, 0::int,
    (select p from curr_period),
    (select revenue  from cash)::numeric,
    (select expenses from cash)::numeric,
    (select revenue - expenses from cash)::numeric,
    (select count(*) from inv_totals where status = 'overdue')::int,
    coalesce((select sum(total_ttc) from inv_totals where status = 'overdue'), 0)::numeric,
    (select count(*) from inv_totals where status in ('sent','overdue'))::int,
    coalesce((select sum(total_ttc) from inv_totals where status in ('sent','overdue')), 0)::numeric;
$$;

grant execute on function public.get_dashboard_company_overview(text) to anon, authenticated, service_role;


-- 2) Tournées per company (table not yet in schema → always empty)
create or replace function public.get_dashboard_company_tournees(
  p_company_id text,
  p_limit      int default 8
)
returns table (
  id                uuid,
  reference         text,
  name              text,
  status            text,
  scheduled_date    date,
  total_distance_km numeric,
  driver_name       text,
  vehicle_plate     text,
  company_name      text,
  missions_count    int
)
language sql
stable
security definer
set search_path = public
as $$
  select null::uuid, null::text, null::text, null::text,
         null::date, null::numeric, null::text, null::text, null::text, 0::int
  where false;
$$;

grant execute on function public.get_dashboard_company_tournees(text, int) to anon, authenticated, service_role;


-- 3) Fleet alerts per company (table not yet in schema → always empty)
create or replace function public.get_dashboard_company_fleet_alerts(
  p_company_id text,
  p_days       int default 60,
  p_limit      int default 8
)
returns table (
  id           text,
  plate        text,
  brand        text,
  model        text,
  company_name text,
  site_name    text,
  ct_due       date,
  ins_due      date,
  earliest_due date,
  alert_kind   text
)
language sql
stable
security definer
set search_path = public
as $$
  select null::text, null::text, null::text, null::text,
         null::text, null::text, null::date, null::date, null::date, null::text
  where false;
$$;

grant execute on function public.get_dashboard_company_fleet_alerts(text, int, int) to anon, authenticated, service_role;


-- 4) Overdue / outstanding invoices per company
create or replace function public.get_dashboard_company_overdue_invoices(
  p_company_id text,
  p_limit      int default 6
)
returns table (
  id             uuid,
  invoice_number text,
  total_amount   numeric,
  status         text,
  issued_at      date,
  due_at         date,
  days_overdue   int,
  client_name    text,
  mission_ref    text
)
language sql
stable
security definer
set search_path = public
as $$
  with inv_totals as (
    select
      i.id,
      i.invoice_number,
      i.status,
      i.issue_date,
      (i.issue_date + interval '30 days')::date as due_date,
      i.client_name,
      coalesce(sum((il.total_ht + coalesce(il.ecotaxe, 0)) * (1 + coalesce(i.tva_rate, 0) / 100)), 0) as total_ttc
    from invoices i
    left join invoice_lines il on il.invoice_id = i.id
    where i.company_id = p_company_id::uuid
      and i.status in ('sent', 'overdue')
    group by i.id, i.invoice_number, i.status, i.issue_date, i.client_name
  )
  select
    t.id,
    t.invoice_number,
    t.total_ttc,
    t.status,
    t.issue_date,
    t.due_date,
    greatest((current_date - t.due_date)::int, 0),
    t.client_name,
    null::text
  from inv_totals t
  order by
    case t.status when 'overdue' then 0 else 1 end,
    t.due_date asc nulls last
  limit p_limit;
$$;

grant execute on function public.get_dashboard_company_overdue_invoices(text, int) to anon, authenticated, service_role;


-- 5) Open incidents per company (table not yet in schema → always empty)
create or replace function public.get_dashboard_company_incidents(
  p_company_id text,
  p_limit      int default 5
)
returns table (
  id             uuid,
  title          text,
  incident_type  text,
  severity       text,
  status         text,
  created_at     timestamptz,
  estimated_cost numeric,
  mission_ref    text,
  driver_name    text
)
language sql
stable
security definer
set search_path = public
as $$
  select null::uuid, null::text, null::text, null::text, null::text,
         null::timestamptz, null::numeric, null::text, null::text
  where false;
$$;

grant execute on function public.get_dashboard_company_incidents(text, int) to anon, authenticated, service_role;


-- 6) Finance trend: current month vs previous month
create or replace function public.get_dashboard_finance_trend(
  p_company_id text default null
)
returns table (
  period          text,
  prev_period     text,
  revenue_period  numeric,
  revenue_prev    numeric,
  expenses_period numeric,
  expenses_prev   numeric,
  margin_period   numeric,
  margin_prev     numeric
)
language sql
stable
security definer
set search_path = public
as $$
  with
    periods as (
      select
        to_char(current_date, 'YYYY-MM')                       as curr,
        to_char(current_date - interval '1 month', 'YYYY-MM')  as prev
    ),
    cid_uuid as (
      select case when p_company_id is not null then p_company_id::uuid end as v
    ),
    txns as (
      select
        to_char(ct.date, 'YYYY-MM') as mo,
        ct.amount
      from cash_transactions ct
      where (p_company_id is null or ct.company_id = (select v from cid_uuid))
        and to_char(ct.date, 'YYYY-MM') in (
          (select curr from periods),
          (select prev from periods)
        )
    ),
    agg as (
      select
        mo,
        coalesce(sum(case when amount > 0 then amount else 0 end), 0) as revenue,
        coalesce(sum(case when amount < 0 then abs(amount) else 0 end), 0) as expenses
      from txns
      group by mo
    )
  select
    (select curr from periods),
    (select prev from periods),
    coalesce((select revenue  from agg where mo = (select curr from periods)), 0)::numeric,
    coalesce((select revenue  from agg where mo = (select prev from periods)), 0)::numeric,
    coalesce((select expenses from agg where mo = (select curr from periods)), 0)::numeric,
    coalesce((select expenses from agg where mo = (select prev from periods)), 0)::numeric,
    coalesce((select revenue - expenses from agg where mo = (select curr from periods)), 0)::numeric,
    coalesce((select revenue - expenses from agg where mo = (select prev from periods)), 0)::numeric;
$$;

grant execute on function public.get_dashboard_finance_trend(text) to anon, authenticated, service_role;


-- 7) Document alerts per company (table not yet in schema → always empty)
create or replace function public.get_dashboard_documents_alerts(
  p_company_id text default null,
  p_limit      int  default 5
)
returns table (
  id           text,
  title        text,
  status       text,
  due_date     text,
  category     text,
  company_name text,
  days_left    int
)
language sql
stable
security definer
set search_path = public
as $$
  select null::text, null::text, null::text, null::text,
         null::text, null::text, null::int
  where false;
$$;

grant execute on function public.get_dashboard_documents_alerts(text, int) to anon, authenticated, service_role;
