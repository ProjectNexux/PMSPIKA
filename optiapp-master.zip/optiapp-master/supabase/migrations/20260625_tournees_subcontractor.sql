-- Rattachement d'un sous-traitant à une tournée
ALTER TABLE public.tournees
  ADD COLUMN IF NOT EXISTS subcontractor_id uuid REFERENCES public.contractors(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_tournees_subcontractor_id ON public.tournees(subcontractor_id);
