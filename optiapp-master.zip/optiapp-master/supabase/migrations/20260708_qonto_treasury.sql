-- ─────────────────────────────────────────────────────────────────
-- Qonto integration for treasury
-- Adds qonto_account_id mapping to cash_accounts
-- ─────────────────────────────────────────────────────────────────

ALTER TABLE IF EXISTS public.cash_accounts
  ADD COLUMN IF NOT EXISTS qonto_account_id text;

CREATE INDEX IF NOT EXISTS cash_accounts_qonto_account_id_idx
  ON public.cash_accounts (qonto_account_id);
