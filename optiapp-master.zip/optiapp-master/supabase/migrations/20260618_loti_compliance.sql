-- LOTI / capacité transport : fonctions de synthèse de conformité par société.
-- Convention sur `documents.category` :
--   'Licence transport marchandises' / 'LCI' / 'Inscription registre'  : société
--   'Copie conforme'                                                    : véhicule
--   'Attestation capacité'                                              : société
-- Le statut est dérivé de `due_date` (J-30).

CREATE OR REPLACE FUNCTION public.get_loti_compliance(p_company_id text)
RETURNS TABLE (
  licence_id            text,
  licence_title         text,
  licence_due_date      text,
  licence_status        text,
  licence_days_left     int,
  vehicles_total        int,
  vehicles_with_copy    int,
  vehicles_missing_copy int,
  vehicles_expiring     int,
  vehicles_expired      int
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
AS $$
DECLARE
  v_licence record;
  v_total int;
  v_with int;
  v_missing int;
  v_expiring int;
  v_expired int;
BEGIN
  SELECT d.id, d.title, d.due_date,
         CASE
           WHEN d.due_date IS NULL THEN 'A revoir'
           WHEN d.due_date::date < CURRENT_DATE THEN 'Expiré'
           WHEN d.due_date::date < CURRENT_DATE + INTERVAL '30 days' THEN 'Expire bientot'
           ELSE 'Valide'
         END AS status,
         CASE
           WHEN d.due_date IS NULL THEN NULL
           ELSE (d.due_date::date - CURRENT_DATE)
         END AS days_left
    INTO v_licence
  FROM documents d
  WHERE d.company_id = p_company_id
    AND d.category IN ('Licence transport marchandises', 'LCI', 'Inscription registre')
  ORDER BY (d.due_date IS NULL), d.due_date DESC
  LIMIT 1;

  SELECT COUNT(*) INTO v_total
  FROM tms_vehicles v
  WHERE v.company_id = p_company_id
    AND v.status <> 'retired';

  SELECT COUNT(DISTINCT v.id) INTO v_with
  FROM tms_vehicles v
  JOIN documents d
    ON d.vehicle_id = v.id::text
   AND d.category = 'Copie conforme'
   AND d.status <> 'Manquant'
  WHERE v.company_id = p_company_id
    AND v.status <> 'retired';

  v_missing := GREATEST(v_total - v_with, 0);

  SELECT COUNT(DISTINCT v.id) INTO v_expiring
  FROM tms_vehicles v
  JOIN documents d
    ON d.vehicle_id = v.id::text
   AND d.category = 'Copie conforme'
  WHERE v.company_id = p_company_id
    AND v.status <> 'retired'
    AND d.due_date IS NOT NULL
    AND d.due_date::date >= CURRENT_DATE
    AND d.due_date::date < CURRENT_DATE + INTERVAL '30 days';

  SELECT COUNT(DISTINCT v.id) INTO v_expired
  FROM tms_vehicles v
  JOIN documents d
    ON d.vehicle_id = v.id::text
   AND d.category = 'Copie conforme'
  WHERE v.company_id = p_company_id
    AND v.status <> 'retired'
    AND d.due_date IS NOT NULL
    AND d.due_date::date < CURRENT_DATE;

  RETURN QUERY SELECT
    v_licence.id,
    v_licence.title,
    v_licence.due_date,
    v_licence.status,
    v_licence.days_left,
    v_total,
    v_with,
    v_missing,
    v_expiring,
    v_expired;
END;
$$;

GRANT EXECUTE ON FUNCTION public.get_loti_compliance(text) TO anon, authenticated, service_role;

CREATE OR REPLACE FUNCTION public.get_loti_vehicles(p_company_id text)
RETURNS TABLE (
  vehicle_id      text,
  plate_number    text,
  brand           text,
  model           text,
  max_payload_kg  numeric,
  vehicle_status  text,
  copy_doc_id     text,
  copy_title      text,
  copy_due_date   text,
  copy_status     text,
  days_left       int
)
LANGUAGE sql
STABLE SECURITY DEFINER
AS $$
  SELECT
    v.id::text,
    v.plate_number,
    v.brand,
    v.model,
    v.max_payload_kg,
    v.status,
    d.id,
    d.title,
    d.due_date,
    CASE
      WHEN d.id IS NULL THEN 'Manquant'
      WHEN d.due_date IS NULL THEN d.status
      WHEN d.due_date::date < CURRENT_DATE THEN 'Expiré'
      WHEN d.due_date::date < CURRENT_DATE + INTERVAL '30 days' THEN 'Expire bientot'
      ELSE COALESCE(d.status, 'Valide')
    END AS copy_status,
    CASE WHEN d.due_date IS NULL THEN NULL ELSE (d.due_date::date - CURRENT_DATE) END
  FROM tms_vehicles v
  LEFT JOIN LATERAL (
    SELECT id, title, due_date, status
    FROM documents
    WHERE vehicle_id = v.id::text
      AND category = 'Copie conforme'
    ORDER BY (due_date IS NULL), due_date DESC NULLS LAST
    LIMIT 1
  ) d ON TRUE
  WHERE v.company_id = p_company_id
    AND v.status <> 'retired'
  ORDER BY
    CASE
      WHEN d.id IS NULL THEN 0
      WHEN d.due_date::date < CURRENT_DATE THEN 1
      WHEN d.due_date::date < CURRENT_DATE + INTERVAL '30 days' THEN 2
      ELSE 3
    END,
    v.plate_number;
$$;

GRANT EXECUTE ON FUNCTION public.get_loti_vehicles(text) TO anon, authenticated, service_role;
