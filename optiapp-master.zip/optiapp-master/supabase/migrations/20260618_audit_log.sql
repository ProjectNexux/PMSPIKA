-- Audit log applicatif : trace toutes les actions sensibles utilisateur.
-- Écrit via la service role depuis le wrapper `withAudit()` (lib/audit.ts).
-- Indexé pour : recherche par société, par utilisateur, par entité.

CREATE TABLE IF NOT EXISTS public.audit_log (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  at          timestamptz NOT NULL DEFAULT now(),
  actor_id    uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  actor_email text,
  actor_role  text,
  company_id  text,
  action      text NOT NULL,
  entity      text NOT NULL,
  entity_id   text,
  result      text NOT NULL DEFAULT 'ok' CHECK (result IN ('ok','error')),
  message     text,
  metadata    jsonb
);

CREATE INDEX IF NOT EXISTS audit_log_at_idx          ON public.audit_log (at DESC);
CREATE INDEX IF NOT EXISTS audit_log_actor_idx       ON public.audit_log (actor_id, at DESC);
CREATE INDEX IF NOT EXISTS audit_log_company_idx     ON public.audit_log (company_id, at DESC);
CREATE INDEX IF NOT EXISTS audit_log_entity_idx      ON public.audit_log (entity, entity_id, at DESC);
CREATE INDEX IF NOT EXISTS audit_log_action_idx      ON public.audit_log (action, at DESC);

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS audit_log_read_admin ON public.audit_log;
CREATE POLICY audit_log_read_admin ON public.audit_log
  FOR SELECT
  TO authenticated
  USING (public.app_is_admin());

CREATE OR REPLACE VIEW public.audit_log_listing AS
SELECT
  a.id,
  a.at,
  a.actor_id,
  COALESCE(p.full_name, a.actor_email, 'Système') AS actor_name,
  a.actor_email,
  a.actor_role,
  a.company_id,
  c.name AS company_name,
  a.action,
  a.entity,
  a.entity_id,
  a.result,
  a.message,
  a.metadata
FROM public.audit_log a
LEFT JOIN public.profiles p   ON p.id = a.actor_id
LEFT JOIN public.companies c  ON c.id = a.company_id;

GRANT SELECT ON public.audit_log_listing TO authenticated;
