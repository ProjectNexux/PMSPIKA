-- MODULE 3 — Tarification automatique + surcharge carburant

-- Profil de tarification par société
CREATE TABLE IF NOT EXISTS public.pricing_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL,
  name text NOT NULL,
  base_fee numeric NOT NULL DEFAULT 0,          -- frais fixes par mission
  per_km numeric NOT NULL DEFAULT 1.0,          -- tarif au km
  per_kg numeric NOT NULL DEFAULT 0.0,          -- tarif au kg (si applicable)
  cold_unit_fee numeric NOT NULL DEFAULT 0.0,   -- supplément pour frigo par heure
  adr_fee numeric NOT NULL DEFAULT 0.0,         -- supplément pour ADR
  priority_multiplier numeric NOT NULL DEFAULT 1.0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pricing_profiles_company ON public.pricing_profiles(company_id);

-- Historique du prix du litre et règles de surcharge
CREATE TABLE IF NOT EXISTS public.fuel_price_rates (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  company_id uuid,
  price_per_l numeric NOT NULL,
  effective_at timestamptz NOT NULL DEFAULT now(),
  active boolean NOT NULL DEFAULT true
);
CREATE INDEX IF NOT EXISTS idx_fuel_price_company ON public.fuel_price_rates(company_id, effective_at DESC);

-- Colonnes de support dans missions
ALTER TABLE public.missions
  ADD COLUMN IF NOT EXISTS price_computed numeric,
  ADD COLUMN IF NOT EXISTS price_breakdown jsonb,
  ADD COLUMN IF NOT EXISTS fuel_price_used numeric,
  ADD COLUMN IF NOT EXISTS fuel_surcharge_percent numeric;

-- Backfill: leave existing missions NULL

-- RLS: profiles already in place; pricing tables readable by authenticated/service role only
ALTER TABLE public.pricing_profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS auth_all_pricing_profiles ON public.pricing_profiles;
CREATE POLICY auth_all_pricing_profiles ON public.pricing_profiles FOR ALL TO authenticated USING (true) WITH CHECK (true);

ALTER TABLE public.fuel_price_rates ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS auth_all_fuel_price_rates ON public.fuel_price_rates;
CREATE POLICY auth_all_fuel_price_rates ON public.fuel_price_rates FOR ALL TO authenticated USING (true) WITH CHECK (true);
