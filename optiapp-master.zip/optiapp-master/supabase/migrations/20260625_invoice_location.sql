-- Add invoice type (transport vs location sans chauffeur)
ALTER TABLE public.invoices
  ADD COLUMN IF NOT EXISTS invoice_type text NOT NULL DEFAULT 'transport';

-- Add rental-specific columns to invoice_lines
ALTER TABLE public.invoice_lines
  ADD COLUMN IF NOT EXISTS rental_start_date date,
  ADD COLUMN IF NOT EXISTS rental_end_date   date,
  ADD COLUMN IF NOT EXISTS qty_days          numeric,
  ADD COLUMN IF NOT EXISTS unit_price        numeric;
