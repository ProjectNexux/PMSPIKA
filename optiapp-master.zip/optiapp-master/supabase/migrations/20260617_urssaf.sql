-- ============================================================================
-- URSSAF : credentials chiffrés + attestations téléchargées automatiquement
-- ============================================================================
-- À appliquer via : supabase db push  (ou SQL editor)
-- Suppose que la table `companies(id uuid PK)` existe déjà.
-- ============================================================================

-- 1. Identifiants Net-Entreprises / URSSAF, un jeu par société.
--    Le mot de passe est stocké chiffré AES-256-GCM (clé hors-base : URSSAF_ENC_KEY).
--    On NE stocke JAMAIS de mot de passe en clair côté DB.
create table if not exists public.urssaf_credentials (
  company_id            uuid primary key references public.companies(id) on delete cascade,
  username              text not null,
  password_ciphertext   text not null,   -- base64
  password_iv           text not null,   -- base64 (12 bytes)
  password_tag          text not null,   -- base64 (16 bytes)
  portal                text not null default 'net-entreprises' check (portal in ('net-entreprises','urssaf-direct')),
  mfa_method            text,            -- 'none' | 'email' | 'sms' | 'app'  (libre pour V1)
  contact_email         text,            -- où envoyer les alertes (échec, MFA)
  enabled               boolean not null default true,
  last_run_at           timestamptz,
  last_run_status       text check (last_run_status in ('ok','error','skipped','mfa_required')),
  last_run_error        text,
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create index if not exists idx_urssaf_credentials_enabled
  on public.urssaf_credentials(enabled) where enabled = true;

-- 2. Attestations téléchargées, historiques par société + mois.
create table if not exists public.urssaf_attestations (
  id            uuid primary key default gen_random_uuid(),
  company_id    uuid not null references public.companies(id) on delete cascade,
  period        text not null,                 -- 'YYYY-MM'
  storage_path  text not null,                 -- ex: urssaf/<company_id>/2026-06.pdf
  file_size     integer,
  valid_from    date,
  valid_until   date,
  status        text not null default 'Valide' check (status in ('Valide','Expire bientot','Expiree','Erreur')),
  source        text not null default 'auto' check (source in ('auto','manuel')),
  downloaded_at timestamptz not null default now(),
  created_at    timestamptz not null default now(),
  unique (company_id, period)
);

create index if not exists idx_urssaf_attestations_company
  on public.urssaf_attestations(company_id, period desc);

-- 3. Trigger updated_at
create or replace function public.tg_urssaf_credentials_touch()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end$$;

drop trigger if exists trg_urssaf_credentials_touch on public.urssaf_credentials;
create trigger trg_urssaf_credentials_touch
  before update on public.urssaf_credentials
  for each row execute function public.tg_urssaf_credentials_touch();

-- 4. RLS
-- ATTENTION SÉCURITÉ : l'app prototype tourne avec la clé anon (cf. memory).
-- Tant qu'il n'y a pas d'auth, la table `urssaf_credentials` doit rester
-- INACCESSIBLE au rôle anon (même chiffrée, on ne donne pas l'IV/tag/ciphertext).
-- Tous les accès doivent passer par le code serveur (server actions / route cron)
-- qui doit utiliser la SERVICE ROLE KEY (jamais exposée côté client).
alter table public.urssaf_credentials enable row level security;
alter table public.urssaf_attestations enable row level security;

-- Policies : seul service_role (bypass automatique) et authenticated peuvent lire.
-- Pas de policy pour anon → 0 ligne renvoyée si quelqu'un essaie avec la clé publique.
drop policy if exists "urssaf_credentials_auth_all" on public.urssaf_credentials;
create policy "urssaf_credentials_auth_all"
  on public.urssaf_credentials for all
  to authenticated
  using (true) with check (true);

drop policy if exists "urssaf_attestations_auth_all" on public.urssaf_attestations;
create policy "urssaf_attestations_auth_all"
  on public.urssaf_attestations for all
  to authenticated
  using (true) with check (true);

-- Lecture seule côté anon UNIQUEMENT pour la liste des attestations (PDFs sont
-- déjà dans un bucket privé, donc on ne fuite que les métadonnées).
-- À durcir dès que l'auth est branchée.
drop policy if exists "urssaf_attestations_anon_read" on public.urssaf_attestations;
create policy "urssaf_attestations_anon_read"
  on public.urssaf_attestations for select
  to anon
  using (true);

-- 5. Bucket de stockage privé (à créer aussi via UI Supabase si la cmd échoue)
insert into storage.buckets (id, name, public)
values ('urssaf-attestations', 'urssaf-attestations', false)
on conflict (id) do nothing;

-- Policies storage : lecture/écriture pour authenticated uniquement.
drop policy if exists "urssaf_storage_auth_read" on storage.objects;
create policy "urssaf_storage_auth_read"
  on storage.objects for select
  to authenticated
  using (bucket_id = 'urssaf-attestations');

drop policy if exists "urssaf_storage_auth_write" on storage.objects;
create policy "urssaf_storage_auth_write"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'urssaf-attestations');
