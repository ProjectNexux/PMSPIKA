-- ─────────────────────────────────────────────────────────────────
-- Module Trésorerie PIKA TRANSPORT
-- Tables: cash_accounts, cash_transactions, cash_forecast
-- ─────────────────────────────────────────────────────────────────

-- Comptes bancaires / de paiement
CREATE TABLE IF NOT EXISTS public.cash_accounts (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  label       text        NOT NULL,
  iban        text,
  balance     numeric     NOT NULL DEFAULT 0,
  currency    text        NOT NULL DEFAULT 'EUR',
  is_default  boolean     NOT NULL DEFAULT false,
  notes       text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Mouvements de trésorerie réalisés (historique)
-- amount > 0 = encaissement  |  amount < 0 = décaissement
CREATE TABLE IF NOT EXISTS public.cash_transactions (
  id          uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  account_id  uuid        REFERENCES public.cash_accounts(id) ON DELETE SET NULL,
  date        date        NOT NULL DEFAULT current_date,
  label       text        NOT NULL,
  amount      numeric     NOT NULL,
  category    text        NOT NULL DEFAULT 'Autre',
  source      text        NOT NULL DEFAULT 'manual',   -- 'manual' | 'invoice' | 'payroll' | 'ledger'
  source_id   uuid,
  reconciled  boolean     NOT NULL DEFAULT false,
  notes       text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Prévisions de trésorerie (entrées/sorties attendues)
-- amount > 0 = entrée prévue  |  amount < 0 = sortie prévue
CREATE TABLE IF NOT EXISTS public.cash_forecast (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id     uuid,
  expected_date  date        NOT NULL,
  label          text        NOT NULL,
  amount         numeric     NOT NULL,
  category       text        NOT NULL DEFAULT 'Autre',
  source         text        NOT NULL DEFAULT 'manual',
  source_id      uuid,
  is_realized    boolean     NOT NULL DEFAULT false,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS cash_transactions_company_date_idx ON public.cash_transactions (company_id, date DESC);
CREATE INDEX IF NOT EXISTS cash_forecast_company_date_idx     ON public.cash_forecast     (company_id, expected_date);
CREATE INDEX IF NOT EXISTS cash_forecast_source_id_idx        ON public.cash_forecast     (source_id);

-- RLS
ALTER TABLE public.cash_accounts     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cash_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cash_forecast     ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'cash_accounts' AND policyname = 'auth_users_cash_accounts'
  ) THEN
    CREATE POLICY auth_users_cash_accounts ON public.cash_accounts
      FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'cash_transactions' AND policyname = 'auth_users_cash_transactions'
  ) THEN
    CREATE POLICY auth_users_cash_transactions ON public.cash_transactions
      FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE tablename = 'cash_forecast' AND policyname = 'auth_users_cash_forecast'
  ) THEN
    CREATE POLICY auth_users_cash_forecast ON public.cash_forecast
      FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;
