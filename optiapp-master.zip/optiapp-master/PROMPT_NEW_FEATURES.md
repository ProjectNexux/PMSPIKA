# Prompt — Nouvelles fonctionnalités TMS

> **Contexte** : Extension fonctionnelle du TMS (Next.js 15 + Supabase). Ce document spécifie
> 5 nouveaux modules à développer, dans l'ordre de priorité. Même stack et mêmes conventions
> que `PROMPT_MIGRATION_FEATURES.md`.
>
> **Ordre de priorité** :
> 1. POD — Preuve de livraison mobile (signature + photo + scan)
> 2. Suivi temps réel + tracking client public
> 3. Tarification automatique + surcharge gazole indexée
> 4. Gestion de flotte (maintenance préventive + documents réglementaires)
> 5. Temps de conduite / repos (réglementation sociale européenne — RSE)

---

## Conventions du projet (rappel — à respecter)

### Clients Supabase
| Fichier | Export | Usage | RLS |
|---------|--------|-------|-----|
| `lib/db.ts` | `supabase`, `rpc()`, `rpcOne()` | Client anon léger + helper RPC (timeout 8 s) | ✅ |
| `lib/db-server.ts` | `getServerSupabase()` | **Service role** — Server Actions / Route Handlers uniquement | ❌ bypass |
| `lib/supabase-server.ts` | `getSupabaseServer()` (async) | Lecture RLS dans Server Components / Actions (JWT cookie) | ✅ |
| `lib/supabase-browser.ts` | `getSupabaseBrowser()` | Client Components (realtime, lectures) | ✅ |
| `lib/supabase-admin.ts` | `getSupabaseAdmin()`, `inviteUserByEmail()` | Opérations admin auth | ❌ bypass |

### Server Actions — pattern obligatoire
```typescript
"use server";
import { requireUser, requireRole } from "@/lib/session";
import { parseFormData, zNonEmpty, zUuid, zNumberOpt } from "@/lib/validation";
import { setFlash } from "@/lib/flash";
import { getServerSupabase } from "@/lib/db-server";
import { revalidatePath } from "next/cache";

export async function myAction(formData: FormData) {
  const user = await requireUser();                    // garde-fou auth
  const parsed = parseFormData(MySchema, formData);    // validation zod
  if (!parsed.ok) { await setFlash({ kind: "error", message: parsed.error }); return; }

  const sb = getServerSupabase();
  // ⚠️ TOUJOURS scoper par user.company_id (la RLS n'isole pas encore)
  const { error } = await sb.from("...").insert({ ...parsed.data, company_id: user.company_id });
  if (error) { await setFlash({ kind: "error", message: error.message }); return; }

  await setFlash({ kind: "success", message: "Opération réussie" });
  revalidatePath("/ma-page");
}
```

### Helpers disponibles
- **Validation** (`lib/validation.ts`) : `parseFormData`, `zNonEmpty`, `zOptional`, `zUuid`, `zId`, `zDateOpt`, `zNumber`, `zNumberOpt`, `zEmailOpt`, `zCheckbox`
- **Flash/Toast** (`lib/flash.ts`) : `setFlash({ kind, message })`, `flashSuccess/Error/Info/Warning`, `consumeFlash`
- **Format** (`lib/format.ts`) : `formatNumber`, `formatCurrency`, `formatDate`, `pct`
- **Session** (`lib/session.ts`) : `requireUser`, `requireRole(roles[])`, `getCurrentUser`, `canAccessCompany`, `canAccessSite`. Rôles : `super_admin | gerant_groupe | gerant_societe | chef_site | chauffeur | client`
- **Notifications** (`lib/notifications.ts`) : `notifyInApp`, `sendEmail` (Resend), `sendSms` (Twilio), `notifyAll`
- **RPC** (`lib/db.ts`) : `rpc<T>(fn, params)`, `rpcOne<T>(fn, params)`

### Storage — pattern existant
Buckets déjà utilisés : `employee-docs`, `vehicle-docs`. Pattern de chemin `{entityId}/{field}.{ext}`,
upload via service role, on stocke l'URL publique en colonne. **Les nouveaux buckets POD doivent être PRIVÉS**
(données clients) → utiliser des URLs signées, pas publiques.

### Realtime — pattern existant
Voir `components/notification-bell.tsx` : `getSupabaseBrowser().channel(...).on("postgres_changes", { event, schema:"public", table, filter:"col=eq.x" }, cb).subscribe()`.

---

## MODULE 1 — POD : Preuve de livraison mobile

> **But** : le chauffeur valide chaque livraison depuis son téléphone avec signature manuscrite,
> photos et/ou scan de code-barres. Génère une preuve horodatée et géolocalisée, consultable
> par l'exploitation et le client.

### 1.0 Préparation Storage (à faire une fois)

```sql
-- Bucket privé pour les preuves de livraison
insert into storage.buckets (id, name, public)
values ('pod-proofs', 'pod-proofs', false)
on conflict (id) do nothing;

-- Policies storage : un chauffeur écrit dans son périmètre, l'exploitation lit le sien.
-- (À affiner avec la stratégie RLS company_id ; en attendant, restreindre à 'authenticated'.)
create policy "pod_authenticated_read"  on storage.objects for select to authenticated using (bucket_id = 'pod-proofs');
create policy "pod_authenticated_write" on storage.objects for insert to authenticated with check (bucket_id = 'pod-proofs');
```

> Chemin de fichier : `{company_id}/{mission_id}/{podId}-{kind}.{ext}` (kind = `signature` | `photo` | `scan`).

### 1.1 Schéma SQL

```sql
-- Événements de livraison (machine à états + horodatage + géoloc)
CREATE TABLE IF NOT EXISTS public.delivery_events (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid,
  mission_id    uuid NOT NULL REFERENCES public.missions(id) ON DELETE CASCADE,
  driver_id     uuid,                       -- profiles.id
  event_type    text NOT NULL,              -- 'enleve'|'en_transit'|'en_livraison'|'livre'|'echec'|'reserve'
  failure_reason text,                       -- si event_type='echec' : 'absent'|'refuse'|'adresse_introuvable'|'autre'
  lat           numeric, lng numeric,
  occurred_at   timestamptz NOT NULL DEFAULT now(),
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- En-tête de preuve de livraison (1 POD = 1 livraison validée)
CREATE TABLE IF NOT EXISTS public.proof_of_delivery (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid,
  mission_id      uuid NOT NULL REFERENCES public.missions(id) ON DELETE CASCADE,
  driver_id       uuid,
  recipient_name  text,                      -- nom du réceptionnaire
  status          text NOT NULL DEFAULT 'livre', -- 'livre'|'livre_avec_reserve'|'refuse'
  reserve_text    text,                      -- réserves éventuelles (casse, manquant…)
  signature_path  text,                      -- chemin storage (privé)
  lat numeric, lng numeric,
  signed_at       timestamptz NOT NULL DEFAULT now(),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (mission_id)
);

-- Pièces jointes d'une preuve (photos, scans)
CREATE TABLE IF NOT EXISTS public.pod_attachments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pod_id      uuid NOT NULL REFERENCES public.proof_of_delivery(id) ON DELETE CASCADE,
  kind        text NOT NULL DEFAULT 'photo', -- 'photo'|'scan'
  file_path   text NOT NULL,                 -- chemin storage privé
  barcode     text,                          -- valeur scannée si kind='scan'
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_delivery_events_mission ON public.delivery_events(mission_id, occurred_at);
CREATE INDEX IF NOT EXISTS idx_pod_mission             ON public.proof_of_delivery(mission_id);
CREATE INDEX IF NOT EXISTS idx_pod_attachments_pod     ON public.pod_attachments(pod_id);

-- Statut de livraison sur la mission (suivi rapide)
ALTER TABLE public.missions
  ADD COLUMN IF NOT EXISTS delivery_status text DEFAULT 'a_traiter', -- 'a_traiter'|'enleve'|'en_transit'|'en_livraison'|'livre'|'echec'
  ADD COLUMN IF NOT EXISTS delivered_at    timestamptz,
  ADD COLUMN IF NOT EXISTS pod_id          uuid REFERENCES public.proof_of_delivery(id) ON DELETE SET NULL;

-- RLS
ALTER TABLE public.delivery_events   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.proof_of_delivery ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pod_attachments   ENABLE ROW LEVEL SECURITY;
CREATE POLICY auth_all_delivery_events   ON public.delivery_events   FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_proof_of_delivery ON public.proof_of_delivery FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_pod_attachments   ON public.pod_attachments   FOR ALL TO authenticated USING (true) WITH CHECK (true);
```

### 1.2 Fichiers à créer

#### `lib/pod-queries.ts`
Types `DeliveryEvent`, `ProofOfDelivery`, `PodAttachment`, `MissionDeliveryRow`.
Fonctions :
- `getMissionDelivery(missionId)` → `{ mission, events: DeliveryEvent[], pod: ProofOfDelivery | null, attachments: PodAttachment[] }`
- `listDriverDeliveries(driverId, date)` → missions du chauffeur avec `delivery_status` (pour l'app chauffeur)
- `getSignedUrl(path)` → URL signée (validité 1 h) via `getServerSupabase().storage.from('pod-proofs').createSignedUrl(path, 3600)`
- `computeDeliveryKpis(missions)` → `{ total, livrees, echecs, enCours, otdPct }` (OTD = livré dans la fenêtre `delivery_window_*`)

#### `app/chauffeur/tournee/[id]/livraison/[missionId]/page.tsx` (Server Component)
Charge la mission + l'état de livraison. Garde `requireRole(["chauffeur","client","chef_site","gerant_societe","gerant_groupe","super_admin"])`.

#### `components/chauffeur/pod-capture.tsx` (Client Component)
Workflow mobile de validation :
1. **Changement de statut** : boutons `Enlevé → En transit → En livraison → Livré / Échec`.
2. **Signature** : canvas tactile (`<canvas>` + pointer events, pas de lib) → export `toBlob('image/png')`.
3. **Photos** : `<input type="file" accept="image/*" capture="environment" multiple>` (caméra mobile).
4. **Scan code-barres** : `BarcodeDetector` API si dispo (Chrome Android), sinon saisie manuelle fallback.
5. **Nom réceptionnaire** + réserves (textarea optionnelle).
6. Capture `navigator.geolocation` au moment de la signature.
7. Bouton **Valider la livraison** → `submitPodAction(formData)`.

> Fonctionne offline-first souhaitable (v2) : stocker en IndexedDB et rejouer. Pour la v1, exiger la connexion.

#### `app/chauffeur/tournee/actions.ts` (compléter)
- `recordDeliveryEventAction(missionId, eventType, { lat, lng, failureReason?, notes? })`
  → insère `delivery_events`, met à jour `missions.delivery_status`. Si `livre`/`echec`, notifie l'exploitation via `notifyAll`.
- `submitPodAction(formData)` :
  1. `requireUser()` (doit être le `driver_id` assigné — vérifier).
  2. Upload signature + photos dans `pod-proofs` (service role) → chemins privés.
  3. Insert `proof_of_delivery` + `pod_attachments`.
  4. Update `missions` : `delivery_status='livre'`, `delivered_at=now()`, `pod_id`.
  5. `notifyAll` → exploitation + (option) email client avec lien tracking.
  6. `setFlash('success')` + `revalidatePath('/chauffeur')`.

#### `components/planning/pod-viewer.tsx` (Client Component)
Côté exploitation/détail mission : affiche timeline des `delivery_events`, signature (URL signée), galerie photos, réserves, bouton **Télécharger le POD (PDF)**.

#### `app/missions/[id]/pod/route.ts` (Route Handler — génération PDF)
GET → génère un PDF de la preuve (en-tête société, mission, réceptionnaire, signature, photos, horodatage/géoloc). Lib PDF au choix (`pdf-lib` recommandé, léger). Renvoie `application/pdf`.

#### Intégration UI
- App chauffeur (`app/chauffeur/tournee/[id]`) : bouton « Valider la livraison » par mission.
- Planning (`components/planning/tournee-planning.tsx`) : colonne/badge `delivery_status` + accès au POD.

---

## MODULE 2 — Suivi temps réel + tracking client public

> **But** : carte temps réel des chauffeurs/tournées pour l'exploitation, ETA dynamique, et page
> publique de suivi pour le client final (sans authentification, via token).

### 2.1 Schéma SQL

```sql
-- Historique de positions (au lieu d'écraser profiles.last_*) — pour le tracé et l'ETA
CREATE TABLE IF NOT EXISTS public.driver_positions (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  driver_id   uuid NOT NULL,
  company_id  uuid,
  lat numeric NOT NULL, lng numeric NOT NULL,
  speed_kmh   numeric,
  heading     numeric,
  recorded_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_driver_positions_driver ON public.driver_positions(driver_id, recorded_at DESC);

-- Token public de suivi par mission (lien partageable au client)
ALTER TABLE public.missions
  ADD COLUMN IF NOT EXISTS tracking_token text UNIQUE DEFAULT encode(gen_random_bytes(12), 'hex'),
  ADD COLUMN IF NOT EXISTS eta           timestamptz;

-- RLS
ALTER TABLE public.driver_positions ENABLE ROW LEVEL SECURITY;
CREATE POLICY auth_all_driver_positions ON public.driver_positions FOR ALL TO authenticated USING (true) WITH CHECK (true);
-- ⚠️ Pas de policy anon : le suivi public passe par un Route Handler service-role filtré par token.
```

### 2.2 Fichiers à créer / modifier

#### `lib/tracking-queries.ts`
- `getLiveFleet(companyId)` → dernière position de chaque chauffeur actif + tournée en cours + ETA.
- `getMissionTrackingByToken(token)` → **service role**, renvoie un sous-ensemble SÛR (pas de données sensibles) : statut livraison, position chauffeur approximative, ETA, fenêtre de livraison, ville d'enlèvement/livraison. **Jamais** le prix, ni les coordonnées exactes du domicile au-delà du nécessaire.
- `estimateEta(driverPos, deliveryPoint)` → ETA simple (distance haversine ÷ vitesse moyenne) en v1 ; brancher OSRM/Mapbox en v2.

#### `components/chauffeur/geolocation-tracker.tsx` (modifier)
En plus de `updateMyPositionAction`, insérer dans `driver_positions` (échantillonnage ~60 s) pour conserver l'historique et la vitesse/cap.

#### `app/actions.ts` (modifier `updateMyPositionAction`)
- Met à jour `profiles.last_*` **et** insère une ligne `driver_positions`.
- Recalcule l'`eta` de la mission active si possible.

#### `app/tournees/page.tsx` + `components/planning/live-map.tsx`
Onglet **Carte** (Leaflet, import dynamique `ssr:false`) :
- Markers chauffeurs (bleu) depuis `getLiveFleet`, rafraîchis via realtime `postgres_changes` sur `driver_positions` (filtre `company_id`).
- Markers missions (enlèvement vert / livraison rouge), polylignes enlèvement→livraison.
- Popup : chauffeur, tournée, statut livraison, ETA.

#### `app/suivi/[token]/page.tsx` (Server Component — PUBLIC, hors auth)
- À ajouter dans `PUBLIC_PATHS` de `proxy.ts` (`/suivi`).
- Charge `getMissionTrackingByToken(token)` (service role). 404 si token inconnu.
- Affiche : barre de progression du statut (Enlevé → En transit → En livraison → Livré), ETA, fenêtre de livraison, mini-carte (position approx.), pas de données financières.

#### `app/suivi/[token]/tracking-live.tsx` (Client Component)
- Polling léger (30 s) d'un endpoint public `app/api/suivi/[token]/route.ts` (service role, payload minimal) pour rafraîchir position + statut.
- Pas de souscription realtime directe (éviter d'exposer la clé à des non-authentifiés).

#### `app/api/suivi/[token]/route.ts` (Route Handler — public)
GET → JSON minimal `{ status, eta, lat, lng, pickup_city, delivery_city, window_start, window_end }`. Rate-limit basique recommandé.

#### Intégration
- À l'envoi/assignation d'une mission, possibilité d'envoyer au client le lien `https://<app>/suivi/{tracking_token}` via `sendEmail`/`sendSms`.

> **Sécurité** : le token donne accès en lecture seule à des infos non sensibles. Ne jamais inclure prix, marge, coûts, ni l'identité complète du chauffeur.

---

## MODULE 3 — Tarification automatique + surcharge gazole

> **But** : appliquer automatiquement des grilles tarifaires par client (km / poids / forfait / zone)
> sur les tournées et missions, avec une surcharge gazole indexée (indice CNR), pour alimenter la
> pré-facturation sans saisie manuelle.

### 3.1 Schéma SQL

```sql
-- Grilles tarifaires (par client, ou par défaut société si client_id NULL)
CREATE TABLE IF NOT EXISTS public.pricing_grids (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  client_id   uuid REFERENCES public.invoice_clients(id) ON DELETE CASCADE,
  label       text NOT NULL,
  method      text NOT NULL DEFAULT 'per_km', -- 'per_km'|'per_kg'|'flat'|'zone'
  base_price        numeric NOT NULL DEFAULT 0, -- forfait de base / minimum de perception
  price_per_km      numeric,
  price_per_kg      numeric,
  min_charge        numeric,                    -- minimum facturable
  fuel_surcharge_enabled boolean NOT NULL DEFAULT true,
  valid_from  date, valid_to date,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Tranches par zone (si method='zone')
CREATE TABLE IF NOT EXISTS public.pricing_zones (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  grid_id      uuid NOT NULL REFERENCES public.pricing_grids(id) ON DELETE CASCADE,
  label        text NOT NULL,            -- ex. 'Île-de-France', 'Zone A'
  postal_prefix text,                     -- ex. '75','77' (préfixe CP destination)
  price        numeric NOT NULL DEFAULT 0
);

-- Indice gazole (surcharge carburant indexée, type CNR)
CREATE TABLE IF NOT EXISTS public.fuel_index (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  period        text NOT NULL,           -- 'YYYY-MM'
  diesel_price  numeric NOT NULL,        -- prix gazole pro du mois (€/L)
  base_price    numeric NOT NULL,        -- prix de référence contractuel (€/L)
  fuel_part_pct numeric NOT NULL DEFAULT 25, -- part gazole dans le prix de transport (%)
  surcharge_pct numeric,                 -- calculé : ((diesel-base)/base) * fuel_part_pct
  UNIQUE (period)
);

ALTER TABLE public.pricing_grids ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pricing_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fuel_index    ENABLE ROW LEVEL SECURITY;
CREATE POLICY auth_all_pricing_grids ON public.pricing_grids FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_pricing_zones ON public.pricing_zones FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_fuel_index    ON public.fuel_index    FOR ALL TO authenticated USING (true) WITH CHECK (true);
```

### 3.2 Fichiers à créer

#### `lib/pricing.ts` (logique pure, testable)
```typescript
type PricingGrid = { method: 'per_km'|'per_kg'|'flat'|'zone'; base_price: number;
  price_per_km?: number; price_per_kg?: number; min_charge?: number; fuel_surcharge_enabled: boolean };
type PriceInputs = { distance_km?: number; weight_kg?: number; postal_prefix?: string };
type PriceResult = { baseHt: number; fuelSurcharge: number; totalHt: number; breakdown: { label: string; amount: number }[] };

function computePrice(grid: PricingGrid, inputs: PriceInputs, fuelSurchargePct: number, zones?: PricingZone[]): PriceResult
function computeFuelSurchargePct(dieselPrice: number, basePrice: number, fuelPartPct: number): number
```
Logique :
- `per_km` : `base_price + price_per_km × distance_km`
- `per_kg` : `base_price + price_per_kg × weight_kg`
- `flat`   : `base_price`
- `zone`   : `base_price + zone.price` (zone matchée par préfixe CP destination)
- Appliquer `min_charge` si total < min.
- Surcharge gazole = `totalHt × (surcharge_pct / 100)` si `fuel_surcharge_enabled`.
- Tout arrondi à 2 décimales.

#### `lib/pricing-queries.ts`
- `listPricingGrids(companyId)` / `getGridForClient(companyId, clientId)` (fallback grille par défaut).
- `getCurrentFuelIndex()` → indice du mois courant (ou dernier connu).
- `priceTournee(tournee, grid, fuelIndex)` → renseigne `flat_rate_revenue` + `surcharge_fuel`.

#### `app/facturation/tarifs/page.tsx` + `tarifs-client.tsx`
- CRUD des grilles tarifaires (liste + modal création/édition) et des zones.
- Onglet **Indice gazole** : saisie mensuelle `diesel_price`/`base_price`/`fuel_part_pct`, affichage `surcharge_pct` calculé, historique.

#### `app/facturation/tarifs/actions.ts`
- `upsertPricingGridAction`, `deletePricingGridAction`, `upsertPricingZoneAction`, `deletePricingZoneAction`
- `upsertFuelIndexAction` (calcule et stocke `surcharge_pct`)
- `applyPricingToTourneesAction(tourneeIds[])` → calcule et écrit revenus/surcharge sur les tournées sélectionnées.

#### Intégration pré-facturation
- Dans `app/facturation/prefacturation/prefac-client.tsx` : bouton **« Tarifer automatiquement »** qui applique la grille du client à chaque tournée avant génération des factures.
- La ligne de facture intègre la surcharge gazole en ligne distincte ou dans le HT (au choix, paramétrable).

---

## MODULE 4 — Gestion de flotte (maintenance + documents réglementaires)

> **But** : suivi du parc au-delà de la fiche véhicule actuelle : maintenance préventive,
> échéances réglementaires (CT, assurance, tachygraphe), consommation, et alertes automatiques.
> `tms_vehicles` possède déjà : `insurance_expiry`, `technical_control_expiry`,
> `next_maintenance_date`, `last_maintenance_date`, `mileage`, coûts/km. On enrichit.

### 4.1 Schéma SQL

```sql
-- Interventions de maintenance (historique + planifié)
CREATE TABLE IF NOT EXISTS public.fleet_maintenance (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid,
  vehicle_id    uuid NOT NULL REFERENCES public.tms_vehicles(id) ON DELETE CASCADE,
  type          text NOT NULL DEFAULT 'revision', -- 'revision'|'pneus'|'vidange'|'reparation'|'controle_technique'|'autre'
  status        text NOT NULL DEFAULT 'planned',  -- 'planned'|'in_progress'|'done'|'cancelled'
  scheduled_date date, completed_date date,
  mileage_at    numeric,
  cost          numeric,
  garage        text,
  description   text,
  -- planification récurrente
  interval_km     numeric,   -- ex. révision tous les 30 000 km
  interval_months int,       -- ou tous les 12 mois
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- Documents réglementaires véhicule (échéances) — au-delà des 3 docs déjà sur tms_vehicles
CREATE TABLE IF NOT EXISTS public.vehicle_compliance (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  vehicle_id  uuid NOT NULL REFERENCES public.tms_vehicles(id) ON DELETE CASCADE,
  doc_type    text NOT NULL, -- 'controle_technique'|'assurance'|'carte_grise'|'tachygraphe'|'licence_transport'|'extincteur'|'autre'
  reference   text,
  issued_on   date, expires_on date,
  file_path   text,          -- bucket 'vehicle-docs'
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Relevés carburant (consommation réelle)
CREATE TABLE IF NOT EXISTS public.fuel_logs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  vehicle_id  uuid NOT NULL REFERENCES public.tms_vehicles(id) ON DELETE CASCADE,
  date        date NOT NULL DEFAULT current_date,
  liters      numeric NOT NULL,
  cost        numeric,
  mileage     numeric,        -- compteur au plein
  full_tank   boolean NOT NULL DEFAULT true,
  driver_id   uuid,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_fleet_maintenance_vehicle ON public.fleet_maintenance(vehicle_id, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_vehicle_compliance_expiry ON public.vehicle_compliance(expires_on);
CREATE INDEX IF NOT EXISTS idx_fuel_logs_vehicle         ON public.fuel_logs(vehicle_id, date);

ALTER TABLE public.fleet_maintenance   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.vehicle_compliance  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.fuel_logs           ENABLE ROW LEVEL SECURITY;
CREATE POLICY auth_all_fleet_maintenance  ON public.fleet_maintenance  FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_vehicle_compliance ON public.vehicle_compliance FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_fuel_logs          ON public.fuel_logs          FOR ALL TO authenticated USING (true) WITH CHECK (true);
```

### 4.2 RPC d'alertes

```sql
-- Échéances flotte à venir (CT, assurance, tachy, maintenance, expirations)
CREATE OR REPLACE FUNCTION public.get_fleet_alerts(p_company_id uuid, p_days int DEFAULT 30)
RETURNS TABLE (
  vehicle_id uuid, plate_number text, alert_type text,
  label text, due_date date, days_left int, severity text  -- 'info'|'warning'|'error'
)
-- UNION : tms_vehicles.technical_control_expiry, insurance_expiry, next_maintenance_date
--       + vehicle_compliance.expires_on + fleet_maintenance.scheduled_date (status='planned')
-- severity : error si due_date < now, warning si < p_days, sinon info
```

### 4.3 Fichiers à créer

#### `lib/fleet-queries.ts`
- `listMaintenance(companyId, vehicleId?)`, `listCompliance(companyId, vehicleId?)`, `listFuelLogs(companyId, vehicleId?)`
- `getFleetAlerts(companyId, days)` → via RPC `get_fleet_alerts`
- `computeFuelConsumption(logs)` → L/100km réel par véhicule (sur pleins complets consécutifs), comparé à `fuel_consumption_l_100km` théorique.
- `computeVehicleTco(vehicle, maintenance, fuelLogs)` → coût total de possession / coût au km.

#### `app/vehicules/page.tsx` (enrichir l'existant)
- Bandeau d'alertes (`get_fleet_alerts`) en haut : échéances CT/assurance/maintenance, code couleur.
- Par véhicule : onglets **Maintenance** | **Documents** | **Carburant** | **Coûts**.

#### `app/vehicules/[id]/page.tsx` + composants
- `components/fleet/maintenance-list.tsx` : historique + planification (modal `upsertMaintenanceAction`), bouton « Marquer comme fait » (met à jour `tms_vehicles.last_maintenance_date` + recalcule `next_maintenance_date` selon `interval_km`/`interval_months`).
- `components/fleet/compliance-list.tsx` : documents réglementaires + upload (`vehicle-docs`), badges d'expiration.
- `components/fleet/fuel-log.tsx` : saisie pleins + courbe conso réelle vs théorique.

#### `app/vehicules/actions.ts`
- `upsertMaintenanceAction`, `completeMaintenanceAction`, `deleteMaintenanceAction`
- `upsertComplianceAction` (+ upload), `deleteComplianceAction`
- `addFuelLogAction`, `deleteFuelLogAction`

#### Notifications & cron
- `app/api/cron/fleet-alerts/route.ts` (suivre le pattern de `app/api/cron/`) : quotidien, lit `get_fleet_alerts` pour toutes les sociétés et `notifyAll` aux gérants/chefs de site pour les échéances ≤ N jours.
- Intégrer les alertes flotte au dashboard (`get_dashboard_fleet_alerts` existe déjà — l'étendre à ces nouvelles sources).

---

## MODULE 5 — Temps de conduite / repos (RSE)

> **But** : suivre les temps de conduite et de repos des chauffeurs selon la réglementation sociale
> européenne (Règl. CE 561/2006), détecter les dépassements et alerter. Données saisies/mobiles
> en v1 (idéalement import fichier tachygraphe `.ddd` en v2).

### 5.1 Rappels réglementaires (constantes — `lib/driving-time.ts`)

```typescript
export const RSE = {
  MAX_DAILY_DRIVING: 9 * 60,        // 9 h/jour (extensible à 10 h 2×/semaine)
  MAX_DAILY_DRIVING_EXT: 10 * 60,
  EXT_PER_WEEK: 2,
  MAX_WEEKLY_DRIVING: 56 * 60,      // 56 h/semaine
  MAX_BIWEEKLY_DRIVING: 90 * 60,    // 90 h sur 2 semaines glissantes
  CONTINUOUS_DRIVING_LIMIT: 4.5 * 60, // 4 h 30 avant pause
  REQUIRED_BREAK: 45,               // pause 45 min (ou 15 + 30)
  DAILY_REST: 11 * 60,              // repos journalier 11 h (réduit 9 h, 3×/sem max)
  DAILY_REST_REDUCED: 9 * 60,
  WEEKLY_REST: 45 * 60,             // repos hebdo normal 45 h (réduit 24 h)
};
```

### 5.2 Schéma SQL

```sql
-- Journal d'activité chauffeur (modèle tachygraphe simplifié)
CREATE TABLE IF NOT EXISTS public.driver_activities (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  driver_id   uuid NOT NULL,            -- profiles.id
  activity    text NOT NULL,            -- 'conduite'|'travail'|'disponibilite'|'repos'
  started_at  timestamptz NOT NULL,
  ended_at    timestamptz,
  source      text NOT NULL DEFAULT 'manual', -- 'manual'|'tournee'|'tachy'
  tournee_id  uuid REFERENCES public.tournees(id) ON DELETE SET NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_driver_activities ON public.driver_activities(driver_id, started_at);

-- Infractions détectées (calculées)
CREATE TABLE IF NOT EXISTS public.driving_violations (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid,
  driver_id   uuid NOT NULL,
  rule        text NOT NULL,   -- 'daily_driving'|'continuous_driving'|'missing_break'|'daily_rest'|'weekly_driving'|'weekly_rest'
  severity    text NOT NULL DEFAULT 'warning', -- 'warning'|'error'
  reference_date date NOT NULL,
  detail      text,
  acknowledged boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.driver_activities  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.driving_violations ENABLE ROW LEVEL SECURITY;
CREATE POLICY auth_all_driver_activities  ON public.driver_activities  FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY auth_all_driving_violations ON public.driving_violations FOR ALL TO authenticated USING (true) WITH CHECK (true);
```

### 5.3 Fichiers à créer

#### `lib/driving-time.ts` (logique pure, testable — cœur du module)
```typescript
type Activity = { activity: 'conduite'|'travail'|'disponibilite'|'repos'; started_at: string; ended_at: string | null };
type DrivingSummary = {
  dailyDrivingMin: number; continuousDrivingMin: number; weeklyDrivingMin: number;
  lastBreakOk: boolean; dailyRestMin: number;
  remainingDailyDriving: number; nextBreakDueAt: string | null;
  violations: { rule: string; severity: 'warning'|'error'; detail: string }[];
};
function summarizeDriving(activities: Activity[], referenceDate: Date): DrivingSummary
function detectViolations(activities: Activity[], referenceDate: Date): Violation[]
```
Logique :
- Agrège les segments `conduite` du jour → `dailyDrivingMin` (alerte > 9 h, erreur > 10 h).
- Conduite continue sans pause ≥ 45 min → alerte à 4 h 30.
- Repos journalier entre deux journées de travail ≥ 11 h (réduit 9 h).
- Conduite hebdo (semaine ISO) ≤ 56 h ; bi-hebdo ≤ 90 h.

#### `components/chauffeur/activity-tracker.tsx` (Client Component)
- Boutons gros format : **Conduite / Travail / Dispo / Repos** (un seul actif).
- Démarre/clôt automatiquement les segments `driver_activities` via `setActivityAction`.
- Affiche en direct : conduite du jour, temps avant pause obligatoire, repos restant.
- Auto-dérivation : quand une tournée passe `in_progress` → activité `conduite` ; `completed` → `travail` puis `repos`.

#### `app/chauffeur/actions.ts` (compléter)
- `setActivityAction(activity)` → clôt le segment courant, ouvre le nouveau. Recalcule le résumé, crée des `driving_violations` si dépassement, `notifyAll` au chauffeur + exploitation si `error`.

#### `app/social/temps-conduite/page.tsx` (Server Component) + `client`
- Vue exploitation : par chauffeur, conduite du jour/semaine, prochaines pauses, infractions non acquittées.
- Filtre par période, bouton « Acquitter » une infraction.
- KPIs : conducteurs en alerte, infractions de la semaine.

#### `app/social/temps-conduite/actions.ts`
- `acknowledgeViolationAction(id)`, `addManualActivityAction(formData)` (correction/saisie a posteriori).

#### `app/api/cron/driving-violations/route.ts`
- Quotidien : recalcule les infractions de la veille pour tous les chauffeurs, notifie l'exploitation des dépassements.

---

## Tâches transverses

### Storage à provisionner
- Bucket **privé** `pod-proofs` (module 1) — URLs signées uniquement.
- Réutiliser `vehicle-docs` pour `vehicle_compliance` (module 4).

### Variables d'environnement (déjà présentes pour la plupart)
```env
RESEND_API_KEY=        # emails (notifications, lien de suivi)
TWILIO_ACCOUNT_SID=    # SMS (option)
TWILIO_AUTH_TOKEN=
TWILIO_FROM=
```

### `proxy.ts`
- Ajouter `/suivi` et `/api/suivi` aux `PUBLIC_PATHS` (tracking client public).

### Tests unitaires recommandés (logique pure, fort ROI)
- `lib/pricing.ts` → `computePrice`, `computeFuelSurchargePct`
- `lib/driving-time.ts` → `summarizeDriving`, `detectViolations`
- `lib/fleet-queries.ts` → `computeFuelConsumption`, `computeVehicleTco`
- `lib/pod-queries.ts` → `computeDeliveryKpis` (OTD)

---

## Ordre d'implémentation recommandé

1. **Storage** : créer le bucket `pod-proofs` + policies.
2. **Module 1 — POD** : migration → `lib/pod-queries.ts` → `pod-capture.tsx` (chauffeur) → actions → viewer exploitation → PDF.
3. **Module 2 — Tracking** : migration `driver_positions` + tokens → `tracking-queries.ts` → `live-map.tsx` → page publique `/suivi/[token]` + route API.
4. **Module 3 — Tarification** : migration → `lib/pricing.ts` (+ tests) → `pricing-queries.ts` → écran tarifs/indice gazole → intégration pré-facturation.
5. **Module 4 — Flotte** : migration → RPC `get_fleet_alerts` → `fleet-queries.ts` → écrans véhicule (maintenance/compliance/carburant) → cron alertes.
6. **Module 5 — RSE** : `lib/driving-time.ts` (+ tests) → migration → `activity-tracker.tsx` (chauffeur) → vue exploitation → cron infractions.

> **Note sécurité** : comme dans l'app actuelle, les policies RLS sont en `USING(true)`. Tant que
> l'isolation par `company_id` n'est pas durcie en base, **chaque Server Action doit impérativement
> scoper les lectures/écritures sur `user.company_id`** et vérifier l'appartenance des ressources.
