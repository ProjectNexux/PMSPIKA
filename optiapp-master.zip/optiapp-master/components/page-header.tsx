import type { ReactNode } from "react";

export function PageHeader({
  eyebrow,
  title,
  children
}: {
  eyebrow?: ReactNode;
  title: string;
  children?: ReactNode;
}) {
  return (
    <div className="page-header flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between mb-6">
      <div className="flex flex-col gap-1">
        {eyebrow ? (
          <span className="eyebrow text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            {eyebrow}
          </span>
        ) : null}
        <h1 className="text-2xl font-semibold tracking-tight text-foreground leading-tight">
          {title}
        </h1>
      </div>
      {children ? (
        <div className="page-actions flex flex-wrap items-center gap-2">{children}</div>
      ) : null}
    </div>
  );
}
