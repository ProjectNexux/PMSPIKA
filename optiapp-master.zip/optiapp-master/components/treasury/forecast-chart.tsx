"use client";

import type { WeeklyBucket } from "@/lib/treasury-queries";
import { formatCurrency } from "@/lib/format";

type Props = {
  buckets: WeeklyBucket[];
  initialBalance: number;
};

export function ForecastChart({ buckets, initialBalance }: Props) {
  if (!buckets.length) return null;

  // Build running balance series
  const running: number[] = [];
  let balance = initialBalance;
  for (const b of buckets) {
    balance += b.inflow - b.outflow;
    running.push(balance);
  }

  const maxBar = Math.max(...buckets.map((b) => Math.max(b.inflow, b.outflow)), 1);
  const minBal = Math.min(...running, initialBalance);
  const maxBal = Math.max(...running, initialBalance);
  const balRange = maxBal - minBal || 1;

  const W = 700;
  const H = 180;
  const BAR_ZONE = 120;  // bottom zone for bars
  const LINE_ZONE_TOP = 10;
  const LINE_ZONE_H = H - BAR_ZONE - LINE_ZONE_TOP;
  const barW = Math.max(8, (W / buckets.length) * 0.35);
  const gap  = W / buckets.length;

  const cx = (i: number) => gap * i + gap / 2;

  // Balance line points
  const linePoints = running.map((v, i) => {
    const x = cx(i);
    const y = LINE_ZONE_TOP + LINE_ZONE_H - ((v - minBal) / balRange) * (LINE_ZONE_H - 4);
    return [x, y] as const;
  });

  const linePath = linePoints
    .map(([x, y], i) => (i === 0 ? `M ${x.toFixed(1)},${y.toFixed(1)}` : `L ${x.toFixed(1)},${y.toFixed(1)}`))
    .join(" ");

  const barTop = H - BAR_ZONE + 8;

  return (
    <div style={{ width: "100%", overflowX: "auto" }}>
      <svg
        viewBox={`0 0 ${W} ${H + 28}`}
        width="100%"
        style={{ display: "block", fontFamily: "inherit" }}
        aria-label="Graphique prévisionnel de trésorerie"
      >
        {/* Zero line for balance zone */}
        <line
          x1={0} y1={LINE_ZONE_TOP + LINE_ZONE_H}
          x2={W} y2={LINE_ZONE_TOP + LINE_ZONE_H}
          stroke="var(--border)" strokeWidth={1} strokeDasharray="4 3"
        />

        {/* Separator */}
        <line x1={0} y1={barTop - 4} x2={W} y2={barTop - 4} stroke="var(--border)" strokeWidth={1} />

        {buckets.map((b, i) => {
          const x = cx(i);

          // Inflow bar (green, going up from barTop)
          const inH = Math.max(2, (b.inflow / maxBar) * (BAR_ZONE - 28));
          // Outflow bar (red, going up from barTop but offset)
          const outH = Math.max(2, (b.outflow / maxBar) * (BAR_ZONE - 28));

          return (
            <g key={b.weekStart}>
              {/* Inflow */}
              {b.inflow > 0 && (
                <rect
                  x={x - barW - 1}
                  y={H - inH - 16}
                  width={barW}
                  height={inH}
                  rx={2}
                  fill="var(--green)"
                  opacity={0.75}
                />
              )}
              {/* Outflow */}
              {b.outflow > 0 && (
                <rect
                  x={x + 1}
                  y={H - outH - 16}
                  width={barW}
                  height={outH}
                  rx={2}
                  fill="var(--red)"
                  opacity={0.65}
                />
              )}

              {/* Week label */}
              <text
                x={x}
                y={H + 14}
                textAnchor="middle"
                fontSize={9}
                fill="var(--muted-foreground)"
              >
                {b.weekLabel}
              </text>
            </g>
          );
        })}

        {/* Balance area fill */}
        <path
          d={`${linePath} L ${linePoints[linePoints.length - 1][0]},${LINE_ZONE_TOP + LINE_ZONE_H} L ${linePoints[0][0]},${LINE_ZONE_TOP + LINE_ZONE_H} Z`}
          fill="var(--blue)"
          opacity={0.08}
        />

        {/* Balance line */}
        <path d={linePath} fill="none" stroke="var(--blue)" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" />

        {/* Balance dots + tooltip labels at first/last/min/max */}
        {linePoints.map(([x, y], i) => {
          const isFirst = i === 0;
          const isLast  = i === linePoints.length - 1;
          if (!isFirst && !isLast) return null;
          return (
            <g key={i}>
              <circle cx={x} cy={y} r={3.5} fill="var(--blue)" />
              <text
                x={x}
                y={y - 6}
                textAnchor={isFirst ? "start" : "end"}
                fontSize={9}
                fontWeight={600}
                fill="var(--blue)"
              >
                {formatCurrency(running[i])}
              </text>
            </g>
          );
        })}

        {/* Legend */}
        <g transform={`translate(${W - 140}, 2)`}>
          <rect x={0} y={0} width={8} height={8} rx={2} fill="var(--green)" opacity={0.75} />
          <text x={11} y={8} fontSize={9} fill="var(--muted-foreground)">Encaissements</text>
          <rect x={0} y={13} width={8} height={8} rx={2} fill="var(--red)" opacity={0.65} />
          <text x={11} y={21} fontSize={9} fill="var(--muted-foreground)">Décaissements</text>
          <line x1={0} y1={30} x2={8} y2={30} stroke="var(--blue)" strokeWidth={2} />
          <text x={11} y={34} fontSize={9} fill="var(--muted-foreground)">Solde prévisionnel</text>
        </g>
      </svg>
    </div>
  );
}
