"use client";

import { useState, useMemo } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { formatCurrency } from "@/lib/format";

// ── Types ─────────────────────────────────────────────────────────────────────

export type CalendarEvent = {
  id: string;
  date: string;       // ISO YYYY-MM-DD
  label: string;
  amount: number;     // + encaissement / - décaissement
  category: string;
  type: "realized" | "forecast" | "invoice";
};

type Props = {
  events: CalendarEvent[];
  initialBalance: number;  // solde total actuel
  todayStr: string;        // YYYY-MM-DD
  initialMonth: string;    // YYYY-MM
};

// ── Helpers ───────────────────────────────────────────────────────────────────

const DAYS_FR = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];
const MONTHS_FR = [
  "Janvier", "Février", "Mars", "Avril", "Mai", "Juin",
  "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre",
];

function isoToDate(s: string) {
  return new Date(`${s}T00:00:00`);
}

function addMonths(ym: string, delta: number): string {
  const [y, m] = ym.split("-").map(Number);
  const d = new Date(y, m - 1 + delta, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

/** Returns Monday-aligned grid cells for a YYYY-MM month */
function buildGrid(ym: string): (string | null)[] {
  const [y, m] = ym.split("-").map(Number);
  const first = new Date(y, m - 1, 1);
  const last  = new Date(y, m, 0);
  // Mon=0 … Sun=6
  const startOffset = (first.getDay() + 6) % 7;
  const totalDays   = last.getDate();
  const cells: (string | null)[] = [];
  for (let i = 0; i < startOffset; i++) cells.push(null);
  for (let d = 1; d <= totalDays; d++) {
    cells.push(`${ym}-${String(d).padStart(2, "0")}`);
  }
  // Pad to full weeks
  while (cells.length % 7 !== 0) cells.push(null);
  return cells;
}

function typeLabel(t: CalendarEvent["type"]) {
  if (t === "realized") return "Réalisé";
  if (t === "invoice")  return "Facture (auto)";
  return "Prévision";
}

// ── Component ─────────────────────────────────────────────────────────────────

export function TreasuryCalendar({ events, initialBalance, todayStr, initialMonth }: Props) {
  const [month, setMonth]             = useState(initialMonth);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  const [year, monthNum] = month.split("-").map(Number);
  const grid = useMemo(() => buildGrid(month), [month]);

  // Index events by date
  const byDate = useMemo(() => {
    const map = new Map<string, CalendarEvent[]>();
    for (const ev of events) {
      const list = map.get(ev.date) ?? [];
      list.push(ev);
      map.set(ev.date, list);
    }
    return map;
  }, [events]);

  // Running daily balance (only realized transactions contribute to rolling balance)
  // We show the expected balance per day including forecasts
  const dailyBalance = useMemo(() => {
    const sorted = [...events].sort((a, b) => a.date.localeCompare(b.date));
    let bal = initialBalance;
    // subtract everything after today from balance (forecasts haven't happened yet)
    // We build a map: date → balance after all events of that day
    const realized = sorted.filter((e) => e.type === "realized");
    // Recompute initial balance = current balance - sum of all realized events
    // (current balance already includes realized, so we start from it and walk forward for forecasts)
    const balMap = new Map<string, number>();
    // For each date in grid that has events, cumulate
    const allDates = [...new Set(sorted.map((e) => e.date))].sort();
    for (const d of allDates) {
      const evs = byDate.get(d) ?? [];
      bal += evs.reduce((s, e) => s + e.amount, 0);
      balMap.set(d, bal);
    }
    return balMap;
  }, [events, byDate, initialBalance]);

  const selectedEvents = selectedDay ? (byDate.get(selectedDay) ?? []) : [];

  return (
    <div>
      {/* ── Month navigation ──────────────────────────────────────────── */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
        <button
          onClick={() => setMonth((m) => addMonths(m, -1))}
          className="btn-secondary"
          style={{ padding: "6px 10px" }}
          aria-label="Mois précédent"
        >
          <ChevronLeft size={16} />
        </button>
        <h3 style={{ fontWeight: 600, fontSize: 16, textTransform: "capitalize" }}>
          {MONTHS_FR[monthNum - 1]} {year}
        </h3>
        <button
          onClick={() => setMonth((m) => addMonths(m, 1))}
          className="btn-secondary"
          style={{ padding: "6px 10px" }}
          aria-label="Mois suivant"
        >
          <ChevronRight size={16} />
        </button>
      </div>

      {/* ── Day headers ───────────────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 2 }}>
        {DAYS_FR.map((d) => (
          <div
            key={d}
            style={{
              textAlign: "center",
              fontSize: 11,
              fontWeight: 600,
              color: "var(--muted-foreground)",
              padding: "4px 0",
              textTransform: "uppercase",
              letterSpacing: "0.05em",
            }}
          >
            {d}
          </div>
        ))}
      </div>

      {/* ── Calendar grid ─────────────────────────────────────────────── */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2 }}>
        {grid.map((dateStr, idx) => {
          if (!dateStr) {
            return <div key={`empty-${idx}`} style={{ minHeight: 72, borderRadius: 6, background: "var(--muted)", opacity: 0.3 }} />;
          }

          const dayEvents    = byDate.get(dateStr) ?? [];
          const isToday      = dateStr === todayStr;
          const isPast       = dateStr < todayStr;
          const isSelected   = dateStr === selectedDay;
          const realized     = dayEvents.filter((e) => e.type === "realized");
          const pending      = dayEvents.filter((e) => e.type !== "realized");
          const dayNet       = dayEvents.reduce((s, e) => s + e.amount, 0);
          const hasEvents    = dayEvents.length > 0;
          const dayNum       = parseInt(dateStr.slice(8), 10);

          const balAfter     = dailyBalance.get(dateStr);

          return (
            <button
              key={dateStr}
              onClick={() => setSelectedDay(isSelected ? null : dateStr)}
              style={{
                minHeight: 72,
                borderRadius: 6,
                border: isToday
                  ? "2px solid var(--primary)"
                  : isSelected
                  ? "2px solid var(--blue)"
                  : "1px solid var(--border)",
                background: isSelected
                  ? "color-mix(in oklab, var(--blue) 8%, transparent)"
                  : isPast && !isToday
                  ? "var(--muted)"
                  : "var(--card)",
                cursor: hasEvents ? "pointer" : "default",
                padding: "6px 8px",
                textAlign: "left",
                display: "flex",
                flexDirection: "column",
                gap: 3,
                position: "relative",
                transition: "border-color 0.1s",
              }}
              aria-pressed={isSelected}
            >
              {/* Day number */}
              <span
                style={{
                  fontSize: 12,
                  fontWeight: isToday ? 700 : 500,
                  color: isToday ? "var(--primary)" : isPast ? "var(--muted-foreground)" : "var(--foreground)",
                  lineHeight: 1,
                }}
              >
                {dayNum}
              </span>

              {/* Event dots */}
              {realized.length > 0 && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                  {realized.slice(0, 3).map((e) => (
                    <span
                      key={e.id}
                      style={{
                        width: 6,
                        height: 6,
                        borderRadius: "50%",
                        background: e.amount >= 0 ? "var(--green)" : "var(--red)",
                        flexShrink: 0,
                      }}
                      title={e.label}
                    />
                  ))}
                  {realized.length > 3 && (
                    <span style={{ fontSize: 9, color: "var(--muted-foreground)" }}>+{realized.length - 3}</span>
                  )}
                </div>
              )}

              {/* Forecast pills */}
              {pending.length > 0 && (
                <div style={{ display: "flex", flexWrap: "wrap", gap: 2 }}>
                  {pending.slice(0, 2).map((e) => (
                    <span
                      key={e.id}
                      style={{
                        fontSize: 9,
                        padding: "1px 4px",
                        borderRadius: 4,
                        background: e.amount >= 0
                          ? "color-mix(in oklab, var(--green) 18%, transparent)"
                          : "color-mix(in oklab, var(--red) 15%, transparent)",
                        color: e.amount >= 0 ? "var(--green)" : "var(--red)",
                        border: `1px dashed ${e.amount >= 0 ? "var(--green)" : "var(--red)"}`,
                        whiteSpace: "nowrap",
                        overflow: "hidden",
                        maxWidth: 56,
                        textOverflow: "ellipsis",
                      }}
                      title={e.label}
                    >
                      {e.amount >= 0 ? "+" : ""}{formatCurrency(e.amount)}
                    </span>
                  ))}
                  {pending.length > 2 && (
                    <span style={{ fontSize: 9, color: "var(--muted-foreground)" }}>+{pending.length - 2}</span>
                  )}
                </div>
              )}

              {/* Net amount if has events */}
              {hasEvents && (
                <span
                  style={{
                    fontSize: 10,
                    fontWeight: 700,
                    marginTop: "auto",
                    color: dayNet >= 0 ? "var(--green)" : "var(--red)",
                  }}
                >
                  {dayNet >= 0 ? "+" : ""}{formatCurrency(dayNet)}
                </span>
              )}

              {/* Running balance hint */}
              {balAfter !== undefined && (
                <span style={{ fontSize: 9, color: "var(--muted-foreground)", marginTop: 1 }}>
                  {formatCurrency(balAfter)}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ── Selected day detail panel ──────────────────────────────────── */}
      {selectedDay && selectedEvents.length > 0 && (
        <div
          style={{
            marginTop: 12,
            padding: "12px 16px",
            background: "var(--card)",
            borderRadius: 8,
            border: "1px solid var(--border)",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
            <span style={{ fontWeight: 600, fontSize: 14 }}>
              {isoToDate(selectedDay).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}
            </span>
            <button
              onClick={() => setSelectedDay(null)}
              style={{ fontSize: 18, lineHeight: 1, color: "var(--muted-foreground)", background: "none", border: "none", cursor: "pointer" }}
            >
              ×
            </button>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {selectedEvents.map((ev) => (
              <div
                key={ev.id}
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  gap: 8,
                  padding: "8px 10px",
                  borderRadius: 6,
                  background: ev.type === "realized"
                    ? "var(--muted)"
                    : "color-mix(in oklab, var(--primary) 6%, transparent)",
                  border: ev.type !== "realized" ? "1px dashed var(--border)" : "none",
                }}
              >
                <div style={{ display: "flex", flexDirection: "column", gap: 2, minWidth: 0 }}>
                  <span style={{ fontSize: 13, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {ev.label}
                  </span>
                  <span style={{ fontSize: 11, color: "var(--muted-foreground)" }}>
                    {ev.category}
                    {" · "}
                    <span style={{ fontStyle: "italic" }}>{typeLabel(ev.type)}</span>
                  </span>
                </div>
                <span
                  style={{
                    fontWeight: 700,
                    fontSize: 14,
                    whiteSpace: "nowrap",
                    color: ev.amount >= 0 ? "var(--green)" : "var(--red)",
                  }}
                >
                  {ev.amount >= 0 ? "+" : ""}{formatCurrency(ev.amount)}
                </span>
              </div>
            ))}
            {/* Day total */}
            <div style={{ display: "flex", justifyContent: "flex-end", paddingTop: 4, borderTop: "1px solid var(--border)", marginTop: 2 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: selectedEvents.reduce((s, e) => s + e.amount, 0) >= 0 ? "var(--green)" : "var(--red)" }}>
                Net du jour :{" "}
                {(() => {
                  const net = selectedEvents.reduce((s, e) => s + e.amount, 0);
                  return `${net >= 0 ? "+" : ""}${formatCurrency(net)}`;
                })()}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* ── Legend ────────────────────────────────────────────────────── */}
      <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "var(--muted-foreground)" }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--green)", display: "inline-block" }} />
          Encaissement réalisé
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "var(--muted-foreground)" }}>
          <span style={{ width: 8, height: 8, borderRadius: "50%", background: "var(--red)", display: "inline-block" }} />
          Décaissement réalisé
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "var(--muted-foreground)" }}>
          <span style={{ width: 10, height: 10, borderRadius: 2, background: "color-mix(in oklab, var(--green) 18%, transparent)", border: "1px dashed var(--green)", display: "inline-block" }} />
          Entrée prévue
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 11, color: "var(--muted-foreground)" }}>
          <span style={{ width: 10, height: 10, borderRadius: 2, background: "color-mix(in oklab, var(--red) 15%, transparent)", border: "1px dashed var(--red)", display: "inline-block" }} />
          Sortie prévue
        </div>
      </div>
    </div>
  );
}
