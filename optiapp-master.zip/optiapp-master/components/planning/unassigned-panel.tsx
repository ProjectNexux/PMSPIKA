"use client";

import { Inbox, ArrowRight } from "lucide-react";
import type { PlanningMission } from "@/lib/planning";

export function UnassignedPanel({
  missions,
  onDragStart,
  onDragEnd,
  draggingId,
}: {
  missions: PlanningMission[];
  onDragStart: (missionId: string) => void;
  onDragEnd: () => void;
  draggingId: string | null;
}) {
  return (
    <aside className="unassigned-panel" aria-label="Missions à rattacher">
      <h3>
        <Inbox size={16} />
        Missions à rattacher
        <span className="count">{missions.length}</span>
      </h3>
      {missions.length === 0 ? (
        <p className="muted" style={{ fontSize: 12, margin: 0 }}>
          Toutes les missions de la période sont rattachées à une tournée.
        </p>
      ) : (
        <div className="unassigned-list">
          {missions.map((m) => (
            <div
              key={m.id}
              className={`unassigned-item${draggingId === m.id ? " dragging" : ""}`}
              draggable
              onDragStart={(e) => {
                e.dataTransfer.setData("text/mission-id", m.id);
                e.dataTransfer.effectAllowed = "move";
                onDragStart(m.id);
              }}
              onDragEnd={onDragEnd}
              title="Glissez sur une tournée pour rattacher"
            >
              <div className="head">
                <span className="ref">{m.reference}</span>
                {m.scheduled_time && (
                  <span style={{ fontSize: 10.5, color: "var(--muted)" }}>
                    {m.scheduled_time.slice(0, 5)}
                  </span>
                )}
                <span style={{ marginLeft: "auto", fontSize: 10.5, color: "var(--muted)" }}>
                  {fmtDate(m.scheduled_date)}
                </span>
              </div>
              <div className="route">
                {m.pickup_city}
                <ArrowRight size={11} />
                {m.delivery_city}
              </div>
              {m.client_name && (
                <span style={{ fontSize: 11, color: "var(--muted)" }}>{m.client_name}</span>
              )}
            </div>
          ))}
        </div>
      )}
    </aside>
  );
}

function fmtDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", { day: "2-digit", month: "short" });
}
