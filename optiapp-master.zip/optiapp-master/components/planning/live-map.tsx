"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { supabase } from "@/lib/db";
import type {
  DriverPosition,
  MapData,
  PlanningMission,
  PlanningTournee,
  TmsSitePoint,
} from "@/lib/planning";
import { Layers, Radio, Truck, Warehouse, MapPin } from "lucide-react";

/* ──────────────────────────────────────────────────────────────────────────
   Couleurs & icônes
   ────────────────────────────────────────────────────────────────────────── */
const STATUS_COLOR: Record<string, string> = {
  draft: "#94a3b8",
  scheduled: "#3b82f6",
  in_progress: "#f97316",
  completed: "#10b981",
  cancelled: "#ef4444",
  assigned: "#3b82f6",
};

function divIcon(html: string, size: [number, number] = [32, 32]) {
  return L.divIcon({
    html,
    className: "live-map-marker",
    iconSize: size,
    iconAnchor: [size[0] / 2, size[1] / 2],
  });
}

function driverIcon(color: string, label: string) {
  return divIcon(
    `<div class="lm-driver" style="background:${color}">
       <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 18H3v-6a2 2 0 0 1 2-2h11a2 2 0 0 1 2 2v6h-2"/><path d="M14 9V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v3"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></svg>
       <span>${escapeHtml(label)}</span>
     </div>`,
    [90, 32],
  );
}

function pointIcon(kind: "pickup" | "delivery" | "site", color: string) {
  const inner = kind === "site"
    ? `<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5"><path d="M3 21h18M5 21V8l7-5 7 5v13M9 21V12h6v9"/></svg>`
    : kind === "pickup"
      ? `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="3"><path d="M5 12l5 5L20 7"/></svg>`
      : `<svg width="10" height="10" viewBox="0 0 24 24" fill="white"><circle cx="12" cy="12" r="4"/></svg>`;
  return divIcon(
    `<div class="lm-point" style="background:${color}">${inner}</div>`,
    [20, 20],
  );
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[c] ?? c));
}

/* ──────────────────────────────────────────────────────────────────────────
   Composant principal
   ────────────────────────────────────────────────────────────────────────── */
export function LiveMap({
  initialData,
  tournees,
  onOpenAssign,
}: {
  initialData: MapData;
  tournees: PlanningTournee[];
  onOpenAssign: (t: PlanningTournee) => void;
}) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const mapRef = useRef<L.Map | null>(null);
  const driverLayerRef = useRef<L.LayerGroup | null>(null);
  const siteLayerRef = useRef<L.LayerGroup | null>(null);
  const missionLayerRef = useRef<L.LayerGroup | null>(null);

  const [drivers, setDrivers] = useState<DriverPosition[]>(initialData.drivers);
  const driversRef = useRef<DriverPosition[]>(initialData.drivers);
  useEffect(() => { driversRef.current = drivers; }, [drivers]);

  const [filter, setFilter] = useState<"all" | "active" | "scheduled">("all");
  const [layers, setLayers] = useState({ drivers: true, sites: true, missions: true });
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const filteredMissions = useMemo(() => {
    if (filter === "all") return initialData.missions;
    if (filter === "active") return initialData.missions.filter((m) => m.status === "in_progress");
    return initialData.missions.filter((m) => m.status === "scheduled" || m.status === "assigned");
  }, [initialData.missions, filter]);

  /* Init Leaflet une seule fois */
  useEffect(() => {
    const el = containerRef.current;
    if (!el || mapRef.current) return;

    // Reset éventuel instance Leaflet précédente (React StrictMode dev)
    // @ts-expect-error _leaflet_id est interne mais nécessaire pour éviter "Map container is already initialized"
    if (el._leaflet_id) { try { delete el._leaflet_id; } catch {} }

    const map = L.map(el, {
      center: [46.6, 2.5],
      zoom: 6,
      zoomControl: true,
      scrollWheelZoom: true,
    });

    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap",
      maxZoom: 19,
      detectRetina: true,
    }).addTo(map);

    driverLayerRef.current  = L.layerGroup().addTo(map);
    siteLayerRef.current    = L.layerGroup().addTo(map);
    missionLayerRef.current = L.layerGroup().addTo(map);

    mapRef.current = map;

    // invalidate après mount pour bien dimensionner
    requestAnimationFrame(() => { try { map.invalidateSize(); } catch {} });

    return () => {
      try { map.remove(); } catch {}
      mapRef.current = null;
      driverLayerRef.current = null;
      siteLayerRef.current = null;
      missionLayerRef.current = null;
    };
  }, []);

  /* Re-render sites */
  useEffect(() => {
    const layer = siteLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    if (!layers.sites) return;
    for (const s of initialData.sites) {
      L.marker([s.lat, s.lng], { icon: pointIcon("site", "#475569") })
        .bindPopup(siteHtml(s))
        .addTo(layer);
    }
  }, [initialData.sites, layers.sites]);

  /* Re-render missions (markers + lignes) */
  useEffect(() => {
    const layer = missionLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    if (!layers.missions) return;
    for (const m of filteredMissions) {
      if (m.pickup_lat == null || m.pickup_lng == null || m.delivery_lat == null || m.delivery_lng == null) continue;
      const color = STATUS_COLOR[m.status] ?? "#3b82f6";

      // Ligne
      L.polyline(
        [[m.pickup_lat, m.pickup_lng], [m.delivery_lat, m.delivery_lng]],
        { color, weight: 3, opacity: 0.55, dashArray: m.status === "draft" ? "6, 6" : undefined },
      ).addTo(layer);

      // Pickup (vert)
      L.marker([m.pickup_lat, m.pickup_lng], { icon: pointIcon("pickup", "#10b981") })
        .bindPopup(missionHtml(m, "pickup"))
        .addTo(layer);

      // Delivery (couleur statut)
      L.marker([m.delivery_lat, m.delivery_lng], { icon: pointIcon("delivery", color) })
        .bindPopup(missionHtml(m, "delivery"))
        .addTo(layer);
    }
  }, [filteredMissions, layers.missions]);

  /* Re-render drivers à chaque update temps réel */
  useEffect(() => {
    const layer = driverLayerRef.current;
    if (!layer) return;
    layer.clearLayers();
    if (!layers.drivers) return;
    for (const d of drivers) {
      const ageMs = d.last_position_at ? Date.now() - new Date(d.last_position_at).getTime() : Infinity;
      const fresh = ageMs < 5 * 60 * 1000; // < 5min
      const color = fresh ? "#10b981" : "#f97316";
      L.marker([d.lat, d.lng], { icon: driverIcon(color, d.full_name.split(" ")[0]) })
        .bindPopup(driverHtml(d, fresh))
        .addTo(layer);
    }
  }, [drivers, layers.drivers]);

  /* Auto-fit aux bounds initiaux */
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const pts: L.LatLngExpression[] = [];
    for (const d of drivers) pts.push([d.lat, d.lng]);
    for (const s of initialData.sites) pts.push([s.lat, s.lng]);
    for (const m of filteredMissions) {
      if (m.pickup_lat != null && m.pickup_lng != null) pts.push([m.pickup_lat, m.pickup_lng]);
      if (m.delivery_lat != null && m.delivery_lng != null) pts.push([m.delivery_lat, m.delivery_lng]);
    }
    if (pts.length > 0) {
      const bounds = L.latLngBounds(pts);
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 11 });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* Realtime : abonnement Supabase aux changements de positions.
     IMPORTANT : on s'abonne UNE seule fois au montage. On lit les drivers
     courants via `driversRef` pour éviter de resouscrire à chaque MAJ
     (sinon : boucle infinie subscribe → setState → resubscribe). */
  useEffect(() => {
    const channel = supabase
      .channel("planning-driver-positions")
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "profiles" },
        (payload) => {
          const row = payload.new as { id: string; last_lat: number | string | null; last_lng: number | string | null; last_position_at: string | null };
          if (row.last_lat == null || row.last_lng == null) return;
          const existing = driversRef.current.find((d) => d.id === row.id);
          if (!existing) return; // chauffeur hors-périmètre
          const newLat = Number(row.last_lat);
          const newLng = Number(row.last_lng);
          // Ignore si la position n'a pas changé (évite re-render inutile)
          if (existing.lat === newLat && existing.lng === newLng && existing.last_position_at === row.last_position_at) return;
          setDrivers((prev) => prev.map((d) =>
            d.id === row.id
              ? { ...d, lat: newLat, lng: newLng, last_position_at: row.last_position_at }
              : d,
          ));
          setLastUpdate(new Date());
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  /* Polling fallback toutes les 60s — ne met à jour que si une position a changé */
  useEffect(() => {
    const id = setInterval(async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, full_name, last_lat, last_lng, last_position_at")
        .eq("role", "chauffeur")
        .not("last_lat", "is", null);
      if (!data) return;
      const fresh = new Map(
        (data as Array<{ id: string; full_name: string; last_lat: number; last_lng: number; last_position_at: string | null }>)
          .map((d) => [d.id, d]),
      );
      let changed = false;
      const next = driversRef.current.map((d) => {
        const f = fresh.get(d.id);
        if (!f) return d;
        const lat = Number(f.last_lat);
        const lng = Number(f.last_lng);
        if (lat === d.lat && lng === d.lng && f.last_position_at === d.last_position_at) return d;
        changed = true;
        return { ...d, lat, lng, last_position_at: f.last_position_at };
      });
      if (changed) {
        setDrivers(next);
        setLastUpdate(new Date());
      }
    }, 60000);
    return () => clearInterval(id);
  }, []);

  // Tournée pour le popup driver
  const tourneeByDriver = useMemo(() => {
    const m = new Map<string, PlanningTournee>();
    for (const t of tournees) {
      if (t.driver_id && (t.status === "in_progress" || t.status === "scheduled")) {
        if (!m.has(t.driver_id)) m.set(t.driver_id, t);
      }
    }
    return m;
  }, [tournees]);
  void onOpenAssign; void tourneeByDriver; // hooks pour évolution future

  return (
    <div className="live-map">
      <div className="live-map-toolbar">
        <div className="lm-status">
          <span className="lm-pulse" />
          <Radio size={12} /> Temps réel
          <small>· MAJ {lastUpdate.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</small>
        </div>

        <div className="lm-filter-group">
          <Layers size={13} />
          <button
            type="button"
            className={layers.drivers ? "lm-chip active" : "lm-chip"}
            onClick={() => setLayers((l) => ({ ...l, drivers: !l.drivers }))}
          >
            <Truck size={12} /> Chauffeurs ({drivers.length})
          </button>
          <button
            type="button"
            className={layers.sites ? "lm-chip active" : "lm-chip"}
            onClick={() => setLayers((l) => ({ ...l, sites: !l.sites }))}
          >
            <Warehouse size={12} /> Sites ({initialData.sites.length})
          </button>
          <button
            type="button"
            className={layers.missions ? "lm-chip active" : "lm-chip"}
            onClick={() => setLayers((l) => ({ ...l, missions: !l.missions }))}
          >
            <MapPin size={12} /> Missions ({filteredMissions.length})
          </button>
        </div>

        <div className="lm-filter-group">
          <span className="muted" style={{ fontSize: 11 }}>Filtre :</span>
          {(["all", "active", "scheduled"] as const).map((f) => (
            <button
              key={f}
              type="button"
              className={filter === f ? "lm-chip active" : "lm-chip"}
              onClick={() => setFilter(f)}
            >
              {f === "all" ? "Tout" : f === "active" ? "En cours" : "Planifié"}
            </button>
          ))}
        </div>

      </div>

      <div ref={containerRef} className="live-map-canvas" />

      <div className="lm-legend">
        <span><i className="lm-dot" style={{ background: "#10b981" }} /> Pickup</span>
        <span><i className="lm-dot" style={{ background: "#3b82f6" }} /> Planifié</span>
        <span><i className="lm-dot" style={{ background: "#f97316" }} /> En cours</span>
        <span><i className="lm-dot" style={{ background: "#10b981" }} /> Terminé</span>
        <span><i className="lm-dot" style={{ background: "#94a3b8" }} /> Brouillon</span>
        <span><i className="lm-dot" style={{ background: "#475569" }} /> Site / hub</span>
      </div>
    </div>
  );
}

/* ──────────────────────────────────────────────────────────────────────────
   Popups HTML
   ────────────────────────────────────────────────────────────────────────── */
function driverHtml(d: DriverPosition, fresh: boolean) {
  const ago = d.last_position_at
    ? formatAgo(new Date(d.last_position_at))
    : "—";
  return `
    <div class="lm-popup">
      <strong>${escapeHtml(d.full_name)}</strong>
      <div class="lm-row"><span class="lm-tag ${fresh ? "ok" : "warn"}">${fresh ? "Actif" : "Inactif"}</span></div>
      <div class="lm-row"><small>Dernière position : ${ago}</small></div>
      ${d.current_mission_ref ? `<div class="lm-row"><small>Mission en cours : <strong>${escapeHtml(d.current_mission_ref)}</strong></small></div>` : ""}
    </div>
  `;
}

function siteHtml(s: TmsSitePoint) {
  return `
    <div class="lm-popup">
      <strong>${escapeHtml(s.name)}</strong>
      <div class="lm-row"><small>${escapeHtml(s.city)}</small></div>
      ${s.address ? `<div class="lm-row"><small>${escapeHtml(s.address)}</small></div>` : ""}
    </div>
  `;
}

function missionHtml(m: PlanningMission, side: "pickup" | "delivery") {
  const isPickup = side === "pickup";
  return `
    <div class="lm-popup">
      <strong>${escapeHtml(m.reference)}</strong>
      <div class="lm-row"><span class="lm-tag" style="background:${STATUS_COLOR[m.status] ?? "#3b82f6"};color:#fff">${escapeHtml(m.status)}</span></div>
      <div class="lm-row"><small><strong>${isPickup ? "Enlèvement" : "Livraison"}</strong> · ${escapeHtml(isPickup ? m.pickup_city : m.delivery_city)}</small></div>
      <div class="lm-row"><small>${escapeHtml(isPickup ? m.pickup_address : m.delivery_address)}</small></div>
      ${m.cargo_description ? `<div class="lm-row"><small>${escapeHtml(m.cargo_description)}</small></div>` : ""}
    </div>
  `;
}

function formatAgo(d: Date) {
  const diff = Math.round((Date.now() - d.getTime()) / 1000);
  if (diff < 60) return "à l'instant";
  if (diff < 3600) return `il y a ${Math.floor(diff / 60)} min`;
  if (diff < 86400) return `il y a ${Math.floor(diff / 3600)} h`;
  return d.toLocaleString("fr-FR");
}
