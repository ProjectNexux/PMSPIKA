"use client";

import { useMemo, useState } from "react";
import { AlertTriangle, TrendingUp, Settings2 } from "lucide-react";
import { Modal } from "./modal";
import { assignTournee, duplicateTournee, cancelTournee, deleteTournee, resetTournee } from "@/app/actions";
import {
  type PlanningPayload,
  type PlanningTournee,
  detectConflicts,
} from "@/lib/planning";
import { computeProfitability, marginTone } from "@/lib/profitability";
import { formatCurrency } from "@/lib/format";

export function AssignModal({
  tournee,
  drivers,
  vehicles,
  tournees,
  redir,
  onClose,
}: {
  tournee: PlanningTournee;
  drivers: PlanningPayload["drivers"];
  vehicles: PlanningPayload["vehicles"];
  tournees: PlanningTournee[];
  redir: string;
  onClose: () => void;
}) {
  const [driverId, setDriverId]   = useState(tournee.driver_id ?? "");
  const [vehicleId, setVehicleId] = useState(tournee.vehicle_id ?? "");
  const [date, setDate]           = useState(tournee.scheduled_date);
  const [name, setName]           = useState(tournee.name);
  const [notes, setNotes]         = useState(tournee.notes ?? "");
  const [dist, setDist]           = useState<string>(
    tournee.total_distance_km != null ? String(tournee.total_distance_km) : "",
  );
  const [dupDate, setDupDate]     = useState(addDaysStr(tournee.scheduled_date, 1));
  const [tab, setTab]             = useState<"general" | "rentab">("general");

  // État local des champs rentabilité (pour prévisualisation live de la marge)
  const [rev, setRev] = useState(() => initFields(tournee));
  const setRevField = (k: keyof typeof rev, v: string) => setRev((s) => ({ ...s, [k]: v }));

  const selectedVehicle = useMemo(
    () => vehicles.find((v) => v.id === vehicleId),
    [vehicles, vehicleId],
  );
  const selectedDriver = useMemo(
    () => drivers.find((d) => d.id === driverId),
    [drivers, driverId],
  );

  const missionsRevenue = tournee.missions.reduce((s, m) => s + (m.price ?? 0), 0);

  const preview = useMemo(
    () => computeProfitability({
      total_distance_km: numOrNull(dist),
      estimated_hours: numOrNull(rev.estimated_hours),
      missions_revenue: missionsRevenue,
      flat_rate_revenue: numOrNull(rev.flat_rate_revenue),
      surcharge_fuel: numOrNull(rev.surcharge_fuel),
      surcharge_adr: numOrNull(rev.surcharge_adr),
      surcharge_wait: numOrNull(rev.surcharge_wait),
      surcharge_other: numOrNull(rev.surcharge_other),
      other_revenue: numOrNull(rev.other_revenue),
      toll_cost: numOrNull(rev.toll_cost),
      fuel_cost_override: numOrNull(rev.fuel_cost_override),
      driver_cost_override: numOrNull(rev.driver_cost_override),
      vehicle_cost_override: numOrNull(rev.vehicle_cost_override),
      subcontractor_cost: numOrNull(rev.subcontractor_cost),
      cold_unit_cost_override: numOrNull(rev.cold_unit_cost_override),
      maintenance_cost_override: numOrNull(rev.maintenance_cost_override),
      tire_cost_override: numOrNull(rev.tire_cost_override),
      misc_cost: numOrNull(rev.misc_cost),
      fuel_consumption_l_100km: selectedVehicle?.fuel_consumption_l_100km ?? null,
      fuel_price_per_l: selectedVehicle?.fuel_price_per_l ?? null,
      amortization_per_km: selectedVehicle?.amortization_per_km ?? null,
      tire_cost_per_km: selectedVehicle?.tire_cost_per_km ?? null,
      maintenance_cost_per_km: selectedVehicle?.maintenance_cost_per_km ?? null,
      has_cold_unit: selectedVehicle?.has_cold_unit ?? null,
      cold_unit_cost_per_hour: selectedVehicle?.cold_unit_cost_per_hour ?? null,
      driver_hourly_cost: selectedDriver?.hourly_cost_rate ?? null,
    }),
    [dist, rev, missionsRevenue, selectedVehicle, selectedDriver],
  );

  const conflicts = useMemo(
    () => detectConflicts(tournees, {
      tourneeId: tournee.id,
      date,
      driver_id: driverId || null,
      vehicle_id: vehicleId || null,
    }),
    [tournees, tournee.id, date, driverId, vehicleId],
  );

  return (
    <Modal
      title={`${tournee.reference} — ${tournee.name}`}
      onClose={onClose}
      size="lg"
      footer={
        <>
          <button type="button" className="toolbar-ghost" onClick={onClose}>Fermer</button>
          <button type="submit" form="assign-form" className="toolbar-primary">
            Enregistrer
          </button>
        </>
      }
    >
      <form id="assign-form" action={assignTournee}>
        <input type="hidden" name="id" value={tournee.id} />
        <input type="hidden" name="redirect_to" value={redir} />

        {/* Onglets */}
        <div role="tablist" aria-label="Sections" style={{ display: "flex", gap: 4, marginBottom: 12, borderBottom: "1px solid var(--border)" }}>
          <button
            type="button"
            role="tab"
            aria-selected={tab === "general"}
            onClick={() => setTab("general")}
            className={tab === "general" ? "view-tab active" : "view-tab"}
          >
            <Settings2 size={14} /> Général
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === "rentab"}
            onClick={() => setTab("rentab")}
            className={tab === "rentab" ? "view-tab active" : "view-tab"}
          >
            <TrendingUp size={14} /> Rentabilité
            <span
              style={{
                marginLeft: 6,
                padding: "1px 6px",
                borderRadius: 999,
                fontSize: 11,
                fontWeight: 700,
                color: "#fff",
                background: toneColor(marginTone(preview.marginPct)),
              }}
            >
              {preview.marginPct == null ? "—" : `${preview.marginPct.toFixed(0)}%`}
            </span>
          </button>
        </div>

        {/* ── Onglet Général ── */}
        <div style={{ display: tab === "general" ? "block" : "none" }}>
        <div className="form-grid">
          <div className="field full">
            <label htmlFor="a_name">Nom</label>
            <input id="a_name" name="name" value={name} onChange={(e) => setName(e.target.value)} required />
          </div>
          <div className="field">
            <label htmlFor="a_date">Date prévue</label>
            <input
              id="a_date"
              name="scheduled_date"
              type="date"
              required
              value={date}
              onChange={(e) => setDate(e.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="a_dist">Distance (km)</label>
            <input
              id="a_dist"
              name="total_distance_km"
              type="number"
              min="0"
              value={dist}
              onChange={(e) => setDist(e.target.value)}
            />
          </div>
          <div className="field">
            <label htmlFor="a_driver">Chauffeur</label>
            <select id="a_driver" name="driver_id" value={driverId} onChange={(e) => setDriverId(e.target.value)}>
              <option value="">— Non affecté —</option>
              {drivers.map((d) => (
                <option key={d.id} value={d.id}>{d.full_name}</option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="a_vehicle">Véhicule</label>
            <select id="a_vehicle" name="vehicle_id" value={vehicleId} onChange={(e) => setVehicleId(e.target.value)}>
              <option value="">— Non affecté —</option>
              {vehicles.map((v) => (
                <option key={v.id} value={v.id}>{v.plate_number} — {v.brand} {v.model}</option>
              ))}
            </select>
          </div>
          <div className="field full">
            <label htmlFor="a_notes">Notes</label>
            <textarea
              id="a_notes"
              name="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
            />
          </div>
        </div>

        {conflicts.length > 0 && (
          <div className="conflict-banner" style={{ marginTop: 12 }}>
            <AlertTriangle size={16} />
            <div>
              <strong>Conflit détecté</strong>
              <ul>
                {conflicts.map((c, i) => (
                  <li key={i}>
                    {c.type === "driver" ? "Chauffeur" : "Véhicule"} <strong>{c.resourceLabel}</strong>{" "}
                    déjà sur <em>{c.conflictWith.reference}</em>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
        </div>

        {/* ── Onglet Rentabilité ── */}
        <div style={{ display: tab === "rentab" ? "block" : "none" }}>
          <ProfitabilityPane
            rev={rev}
            setRevField={setRevField}
            preview={preview}
            missionsRevenue={missionsRevenue}
            selectedVehicle={selectedVehicle}
            selectedDriver={selectedDriver}
            distKm={numOrNull(dist) ?? 0}
          />
        </div>
      </form>

      {/* Actions secondaires */}
      <div
        style={{
          marginTop: 18,
          paddingTop: 14,
          borderTop: "1px dashed var(--border)",
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 12,
        }}
      >
        <form action={duplicateTournee} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <input type="hidden" name="id" value={tournee.id} />
          <input type="hidden" name="redirect_to" value={redir} />
          <label style={{ fontSize: 12, fontWeight: 600 }}>Dupliquer vers</label>
          <div style={{ display: "flex", gap: 6 }}>
            <input
              type="date"
              name="scheduled_date"
              value={dupDate}
              onChange={(e) => setDupDate(e.target.value)}
              required
              style={{ flex: 1 }}
            />
            <button type="submit" className="toolbar-ghost">Dupliquer</button>
          </div>
          <label style={{ fontSize: 11, color: "var(--muted)", display: "flex", alignItems: "center", gap: 4 }}>
            <input type="checkbox" name="keep_assign" defaultChecked style={{ width: "auto" }} />
            Conserver chauffeur / véhicule
          </label>
        </form>

        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <span style={{ fontSize: 12, fontWeight: 600 }}>Cycle de vie</span>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {(tournee.status === "completed" || tournee.status === "cancelled") && (
              <form action={resetTournee}>
                <input type="hidden" name="id" value={tournee.id} />
                <input type="hidden" name="redirect_to" value={redir} />
                <button type="submit" className="toolbar-ghost">Réinitialiser</button>
              </form>
            )}
            {tournee.status !== "cancelled" && tournee.status !== "completed" && (
              <form action={cancelTournee}>
                <input type="hidden" name="id" value={tournee.id} />
                <input type="hidden" name="redirect_to" value={redir} />
                <button type="submit" className="toolbar-ghost" style={{ color: "var(--orange)" }}>
                  Annuler la tournée
                </button>
              </form>
            )}
            <form action={deleteTournee}>
              <input type="hidden" name="id" value={tournee.id} />
              <input type="hidden" name="redirect_to" value={redir} />
              <button
                type="submit"
                className="toolbar-ghost"
                style={{ color: "var(--red)" }}
                onClick={(e) => {
                  if (!confirm("Supprimer définitivement cette tournée ?")) e.preventDefault();
                }}
              >
                Supprimer
              </button>
            </form>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function addDaysStr(iso: string, n: number) {
  const d = new Date(iso);
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

/* ───────────────────────────────────────────────────────────────────────
   Onglet Rentabilité
   ─────────────────────────────────────────────────────────────────────── */

type RevFields = {
  flat_rate_revenue: string;
  surcharge_fuel: string;
  surcharge_adr: string;
  surcharge_wait: string;
  surcharge_other: string;
  other_revenue: string;
  toll_cost: string;
  fuel_cost_override: string;
  driver_cost_override: string;
  vehicle_cost_override: string;
  subcontractor_cost: string;
  cold_unit_cost_override: string;
  maintenance_cost_override: string;
  tire_cost_override: string;
  misc_cost: string;
  estimated_hours: string;
};

function initFields(t: PlanningTournee): RevFields {
  const s = (n: number | null) => (n == null ? "" : String(n));
  return {
    flat_rate_revenue:         s(t.flat_rate_revenue),
    surcharge_fuel:            s(t.surcharge_fuel),
    surcharge_adr:             s(t.surcharge_adr),
    surcharge_wait:            s(t.surcharge_wait),
    surcharge_other:           s(t.surcharge_other),
    other_revenue:             s(t.other_revenue),
    toll_cost:                 s(t.toll_cost),
    fuel_cost_override:        s(t.fuel_cost_override),
    driver_cost_override:      s(t.driver_cost_override),
    vehicle_cost_override:     s(t.vehicle_cost_override),
    subcontractor_cost:        s(t.subcontractor_cost),
    cold_unit_cost_override:   s(t.cold_unit_cost_override),
    maintenance_cost_override: s(t.maintenance_cost_override),
    tire_cost_override:        s(t.tire_cost_override),
    misc_cost:                 s(t.misc_cost),
    estimated_hours:           s(t.estimated_hours),
  };
}

function numOrNull(v: string): number | null {
  if (!v || !v.trim()) return null;
  const n = Number(v.replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function toneColor(tone: "green" | "orange" | "red" | "muted"): string {
  return tone === "green" ? "#16a34a"
    : tone === "orange"   ? "#ea580c"
    : tone === "red"      ? "#dc2626"
    : "#94a3b8";
}

function ProfitabilityPane({
  rev,
  setRevField,
  preview,
  missionsRevenue,
  selectedVehicle,
  selectedDriver,
  distKm,
}: {
  rev: RevFields;
  setRevField: (k: keyof RevFields, v: string) => void;
  preview: ReturnType<typeof computeProfitability>;
  missionsRevenue: number;
  selectedVehicle: PlanningPayload["vehicles"][number] | undefined;
  selectedDriver: PlanningPayload["drivers"][number] | undefined;
  distKm: number;
}) {
  const tone = marginTone(preview.marginPct);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
      {/* Bandeau résultat */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(4, 1fr)",
          gap: 10,
          padding: 12,
          borderRadius: 10,
          background: "var(--surface-2, #f8fafc)",
          border: "1px solid var(--border)",
        }}
      >
        <Kpi label="Revenu" value={formatCurrency(preview.revenue)} color="#0f172a" />
        <Kpi label="Coût"    value={formatCurrency(preview.cost)} color="#0f172a" />
        <Kpi label="Marge €" value={formatCurrency(preview.margin)} color={toneColor(tone)} />
        <Kpi
          label="Marge %"
          value={preview.marginPct == null ? "—" : `${preview.marginPct.toFixed(1)}%`}
          color={toneColor(tone)}
        />
      </div>

      {/* Revenus */}
      <Section title="Revenus">
        <Field label="Forfait tournée (€ HT)" hint="Si renseigné, remplace la somme des prix de missions.">
          <input
            type="number" step="0.01" min="0"
            name="flat_rate_revenue"
            value={rev.flat_rate_revenue}
            onChange={(e) => setRevField("flat_rate_revenue", e.target.value)}
            placeholder={`Missions : ${formatCurrency(missionsRevenue)}`}
          />
        </Field>
        <Field label="Surcharge gasoil (€)">
          <input type="number" step="0.01" name="surcharge_fuel" value={rev.surcharge_fuel} onChange={(e) => setRevField("surcharge_fuel", e.target.value)} />
        </Field>
        <Field label="Surcharge ADR (€)">
          <input type="number" step="0.01" name="surcharge_adr" value={rev.surcharge_adr} onChange={(e) => setRevField("surcharge_adr", e.target.value)} />
        </Field>
        <Field label="Surcharge attente (€)">
          <input type="number" step="0.01" name="surcharge_wait" value={rev.surcharge_wait} onChange={(e) => setRevField("surcharge_wait", e.target.value)} />
        </Field>
        <Field label="Surcharge autre (€)">
          <input type="number" step="0.01" name="surcharge_other" value={rev.surcharge_other} onChange={(e) => setRevField("surcharge_other", e.target.value)} />
        </Field>
        <Field label="Autre recette (€)">
          <input type="number" step="0.01" name="other_revenue" value={rev.other_revenue} onChange={(e) => setRevField("other_revenue", e.target.value)} />
        </Field>
      </Section>

      {/* Coûts */}
      <Section title="Coûts">
        <Field label="Heures chauffeur (h)" hint="Utilisé pour estimer coût chauffeur + groupe froid.">
          <input type="number" step="0.25" min="0" name="estimated_hours" value={rev.estimated_hours} onChange={(e) => setRevField("estimated_hours", e.target.value)} />
        </Field>
        <Field
          label="Coût carburant (€)"
          hint={fuelHint(selectedVehicle, distKm, preview.costs.fuel, preview.overrides.fuel)}
        >
          <input type="number" step="0.01" name="fuel_cost_override" value={rev.fuel_cost_override} onChange={(e) => setRevField("fuel_cost_override", e.target.value)} placeholder={`Auto : ${formatCurrency(preview.overrides.fuel ? 0 : preview.costs.fuel)}`} />
        </Field>
        <Field
          label="Coût chauffeur (€)"
          hint={driverHint(selectedDriver, preview.costs.driver, preview.overrides.driver)}
        >
          <input type="number" step="0.01" name="driver_cost_override" value={rev.driver_cost_override} onChange={(e) => setRevField("driver_cost_override", e.target.value)} placeholder={`Auto : ${formatCurrency(preview.overrides.driver ? 0 : preview.costs.driver)}`} />
        </Field>
        <Field
          label="Coût véhicule total (€)"
          hint="Override global. Sinon on additionne amortissement + pneus + entretien."
        >
          <input type="number" step="0.01" name="vehicle_cost_override" value={rev.vehicle_cost_override} onChange={(e) => setRevField("vehicle_cost_override", e.target.value)} placeholder={`Auto : ${formatCurrency(preview.overrides.vehicle ? 0 : preview.costs.vehicle)}`} />
        </Field>
        <Field label="Coût pneus (€)">
          <input type="number" step="0.01" name="tire_cost_override" value={rev.tire_cost_override} onChange={(e) => setRevField("tire_cost_override", e.target.value)} placeholder={`Auto : ${formatCurrency((selectedVehicle?.tire_cost_per_km ?? 0) * distKm)}`} />
        </Field>
        <Field label="Coût entretien (€)">
          <input type="number" step="0.01" name="maintenance_cost_override" value={rev.maintenance_cost_override} onChange={(e) => setRevField("maintenance_cost_override", e.target.value)} placeholder={`Auto : ${formatCurrency((selectedVehicle?.maintenance_cost_per_km ?? 0) * distKm)}`} />
        </Field>
        <Field
          label="Coût groupe froid (€)"
          hint={selectedVehicle?.has_cold_unit ? `Auto : ${formatCurrency(preview.overrides.cold_unit ? 0 : preview.costs.cold_unit)}` : "Véhicule non frigorifique."}
        >
          <input type="number" step="0.01" name="cold_unit_cost_override" value={rev.cold_unit_cost_override} onChange={(e) => setRevField("cold_unit_cost_override", e.target.value)} />
        </Field>
        <Field label="Péages (€)">
          <input type="number" step="0.01" name="toll_cost" value={rev.toll_cost} onChange={(e) => setRevField("toll_cost", e.target.value)} />
        </Field>
        <Field label="Sous-traitance (€)">
          <input type="number" step="0.01" name="subcontractor_cost" value={rev.subcontractor_cost} onChange={(e) => setRevField("subcontractor_cost", e.target.value)} />
        </Field>
        <Field label="Frais divers (€)" hint="Repas, hôtel, lavage…">
          <input type="number" step="0.01" name="misc_cost" value={rev.misc_cost} onChange={(e) => setRevField("misc_cost", e.target.value)} />
        </Field>
      </Section>

      <p style={{ fontSize: 11, color: "var(--muted)", margin: 0 }}>
        💡 Les taux par défaut (€/km, conso, prix L, €/h…) sont configurés sur la fiche véhicule et la fiche chauffeur.
      </p>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <fieldset style={{ border: "1px solid var(--border)", borderRadius: 10, padding: 12, margin: 0 }}>
      <legend style={{ padding: "0 6px", fontSize: 12, fontWeight: 700, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.4 }}>{title}</legend>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 10 }}>{children}</div>
    </fieldset>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <span style={{ fontSize: 12, fontWeight: 600 }}>{label}</span>
      {children}
      {hint ? <span style={{ fontSize: 10, color: "var(--muted)" }}>{hint}</span> : null}
    </label>
  );
}

function Kpi({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
      <span style={{ fontSize: 11, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.4 }}>{label}</span>
      <strong style={{ fontSize: 18, color, lineHeight: 1.1 }}>{value}</strong>
    </div>
  );
}

function fuelHint(v: PlanningPayload["vehicles"][number] | undefined, km: number, _cost: number, isOverride: boolean): string {
  if (isOverride) return "Override saisi manuellement.";
  if (!v || !v.fuel_consumption_l_100km || !v.fuel_price_per_l) return "Renseignez conso & prix L sur la fiche véhicule.";
  return `${km} km × ${v.fuel_consumption_l_100km} L/100 × ${v.fuel_price_per_l} €/L`;
}

function driverHint(d: PlanningPayload["drivers"][number] | undefined, _cost: number, isOverride: boolean): string {
  if (isOverride) return "Override saisi manuellement.";
  if (!d || !d.hourly_cost_rate) return "Renseignez le taux horaire sur la fiche chauffeur.";
  return `Taux horaire : ${d.hourly_cost_rate} €/h • charges incluses.`;
}
