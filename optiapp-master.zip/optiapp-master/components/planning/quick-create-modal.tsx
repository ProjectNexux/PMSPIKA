"use client";

import { useMemo, useState, useTransition } from "react";
import { AlertTriangle, Clock, Route, Plus, Trash2, Repeat2, Settings2, MapPin } from "lucide-react";
import { Modal } from "./modal";
import { createTournee } from "@/app/actions";
import {
  type PlanningPayload,
  type PlanningTournee,
  detectConflicts,
} from "@/lib/planning";

type ContractorLite = { id: string; name: string };

type StopInput = {
  id: string;
  pickup_city: string;
  pickup_address: string;
  delivery_city: string;
  delivery_address: string;
  scheduled_time: string;
  cargo_description: string;
  distance_km: string;
  price: string;
};

function emptyStop(): StopInput {
  return {
    id: Math.random().toString(36).slice(2),
    pickup_city: "", pickup_address: "",
    delivery_city: "", delivery_address: "",
    scheduled_time: "", cargo_description: "",
    distance_km: "", price: "",
  };
}

type Tab = "general" | "stops" | "recurrence";

export function QuickCreateModal({
  companyId,
  defaultDate,
  redir,
  drivers,
  vehicles,
  contractors,
  tournees,
  onClose,
}: {
  companyId: string;
  defaultDate: string;
  redir: string;
  drivers: PlanningPayload["drivers"];
  vehicles: PlanningPayload["vehicles"];
  contractors: ContractorLite[];
  tournees: PlanningTournee[];
  onClose: () => void;
}) {
  const [tab, setTab] = useState<Tab>("general");
  const [date, setDate] = useState(defaultDate);
  const [driverId, setDriverId] = useState("");
  const [vehicleId, setVehicleId] = useState("");
  const [affectationType, setAffectationType] = useState<"internal" | "subcontractor">("internal");
  const [subcontractorId, setSubcontractorId] = useState("");
  const [recurrenceType, setRecurrenceType] = useState<"none" | "daily" | "weekly" | "monthly">("none");
  const [recurrenceInterval, setRecurrenceInterval] = useState(1);
  const [recurrenceDays, setRecurrenceDays] = useState<number[]>([]);
  const [recurrenceEndMode, setRecurrenceEndMode] = useState<"date" | "count">("date");
  const [recurrenceEnd, setRecurrenceEnd] = useState("");
  const [recurrenceOccurrences, setRecurrenceOccurrences] = useState(4);
  const [recurrenceSkipWeekends, setRecurrenceSkipWeekends] = useState(false);
  const [stops, setStops] = useState<StopInput[]>([]);
  const [pending, startTransition] = useTransition();

  /* ── Conflits ── */
  const conflicts = useMemo(
    () => detectConflicts(tournees, {
      date,
      driver_id: affectationType === "internal" ? (driverId || null) : null,
      vehicle_id: vehicleId || null,
    }),
    [tournees, date, driverId, vehicleId, affectationType],
  );

  /* ── Ressources déjà occupées ce jour ── */
  const busyDriverIds = useMemo(
    () => new Set(
      tournees
        .filter((t) => t.scheduled_date === date && t.status !== "cancelled" && t.status !== "completed" && t.driver_id)
        .map((t) => t.driver_id as string),
    ),
    [tournees, date],
  );
  const busyVehicleIds = useMemo(
    () => new Set(
      tournees
        .filter((t) => t.scheduled_date === date && t.status !== "cancelled" && t.status !== "completed" && t.vehicle_id)
        .map((t) => t.vehicle_id as string),
    ),
    [tournees, date],
  );

  /* ── Dates générées (aperçu) ── */
  const recurrenceDates = useMemo(() => {
    if (recurrenceType === "none") return [date];
    const parseD = (s: string) => { const [y, m, d] = s.split("-").map(Number); return new Date(y, m - 1, d); };
    const fmtD = (d: Date) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const isoWd = (d: Date) => (d.getDay() + 6) % 7;
    const MAX = 365;
    const result: string[] = [];
    const maxCount = recurrenceEndMode === "count" ? Math.min(recurrenceOccurrences, MAX) : MAX;
    const limitDate = recurrenceEndMode === "date" && recurrenceEnd && recurrenceEnd >= date ? recurrenceEnd : null;
    if (recurrenceEndMode === "date" && !limitDate) return [date];

    if (recurrenceType === "weekly" && recurrenceDays.length > 0) {
      const startD = parseD(date);
      const weekStart = new Date(startD);
      weekStart.setDate(startD.getDate() - isoWd(startD));
      let wo = 0;
      outer: while (result.length < maxCount) {
        if (wo % recurrenceInterval === 0) {
          for (const day of [...recurrenceDays].sort((a, b) => a - b)) {
            const d = new Date(weekStart);
            d.setDate(weekStart.getDate() + wo * 7 + day);
            if (d < startD) continue;
            const s = fmtD(d);
            if (limitDate && s > limitDate) break outer;
            if (result.length >= maxCount) break outer;
            result.push(s);
          }
        }
        if (++wo > 1040) break;
      }
      return result;
    }
    if (recurrenceType === "monthly") {
      const startD = parseD(date);
      const origDay = startD.getDate();
      for (let i = 0; result.length < maxCount && i < 1200; i++) {
        const mo = i * recurrenceInterval;
        const y = startD.getFullYear() + Math.floor((startD.getMonth() + mo) / 12);
        const m = (startD.getMonth() + mo) % 12;
        const d = new Date(y, m, Math.min(origDay, new Date(y, m + 1, 0).getDate()));
        const s = fmtD(d);
        if (limitDate && s > limitDate) break;
        result.push(s);
      }
      return result;
    }
    // daily / weekly (no day selection)
    const cur = parseD(date);
    let safety = 0;
    while (result.length < maxCount && safety++ < 5000) {
      const s = fmtD(cur);
      if (limitDate && s > limitDate) break;
      const isWe = cur.getDay() === 0 || cur.getDay() === 6;
      if (!recurrenceSkipWeekends || !isWe) result.push(s);
      if (recurrenceType === "daily") cur.setDate(cur.getDate() + recurrenceInterval);
      else if (recurrenceType === "weekly") cur.setDate(cur.getDate() + 7 * recurrenceInterval);
      else break;
    }
    return result;
  }, [recurrenceType, recurrenceInterval, recurrenceDays, recurrenceEndMode, recurrenceEnd, recurrenceOccurrences, recurrenceSkipWeekends, date]);
  const recurrenceCount = recurrenceDates.length;

  /* ── Stops helpers ── */
  const addStop = () => setStops((s) => [...s, emptyStop()]);
  const removeStop = (id: string) => setStops((s) => s.filter((x) => x.id !== id));
  const updateStop = (id: string, field: keyof StopInput, val: string) =>
    setStops((s) => s.map((x) => x.id === id ? { ...x, [field]: val } : x));

  /* ── Submit ── */
  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    // Inject stops as JSON
    const stopsData = stops.map((s) => ({
      pickup_city: s.pickup_city,
      pickup_address: s.pickup_address,
      delivery_city: s.delivery_city,
      delivery_address: s.delivery_address,
      scheduled_time: s.scheduled_time || null,
      cargo_description: s.cargo_description || null,
      distance_km: s.distance_km ? Number(s.distance_km) : null,
      price: s.price ? Number(s.price) : null,
    }));
    fd.set("stops_json", JSON.stringify(stopsData));
    fd.set("recurrence_type", recurrenceType);
    fd.set("recurrence_interval", String(recurrenceInterval));
    fd.set("recurrence_days", recurrenceDays.join(","));
    fd.set("recurrence_end_mode", recurrenceEndMode);
    fd.set("recurrence_end_count", String(recurrenceOccurrences));
    fd.set("recurrence_skip_weekends", recurrenceSkipWeekends ? "true" : "false");
    if (recurrenceEnd) fd.set("recurrence_end_date", recurrenceEnd);
    startTransition(async () => { await createTournee(fd); });
  };

  return (
    <Modal
      title="Nouvelle tournée"
      onClose={onClose}
      size="lg"
      footer={
        <>
          <button type="button" className="toolbar-ghost" onClick={onClose} disabled={pending}>
            Annuler
          </button>
          <button type="submit" form="quick-create-form" className="toolbar-primary" disabled={pending}>
            {pending
              ? "Création…"
              : recurrenceCount > 1
                ? `Créer ${recurrenceCount} tournées`
                : "Créer la tournée"}
          </button>
        </>
      }
    >
      <form id="quick-create-form" onSubmit={handleSubmit}>
        <input type="hidden" name="company_id" value={companyId} />
        <input type="hidden" name="redirect_to" value={redir} />

        {/* Tabs */}
        <div role="tablist" style={{ display: "flex", gap: 4, marginBottom: 16, borderBottom: "1px solid var(--border)" }}>
          {([
            { key: "general",    label: "Général",     icon: Settings2 },
            { key: "stops",      label: `Arrêts${stops.length > 0 ? ` (${stops.length})` : ""}`, icon: MapPin },
            { key: "recurrence", label: "Récurrence",  icon: Repeat2 },
          ] as { key: Tab; label: string; icon: typeof Settings2 }[]).map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={tab === key}
              onClick={() => setTab(key)}
              className={tab === key ? "view-tab active" : "view-tab"}
            >
              <Icon size={13} /> {label}
            </button>
          ))}
        </div>

        {/* ── Onglet Général ── */}
        <div style={{ display: tab === "general" ? "contents" : "none" }}>
          <div className="form-grid">
            <div className="field full">
              <label htmlFor="qc_name">Nom de la tournée</label>
              <input id="qc_name" name="name" required placeholder="Ex. Paris Nord — Lundi" autoFocus disabled={pending} />
            </div>

            <div className="field">
              <label htmlFor="qc_date">Date</label>
              <input id="qc_date" name="scheduled_date" type="date" required
                value={date} onChange={(e) => setDate(e.target.value)} disabled={pending} />
            </div>
            <div className="field">
              <label htmlFor="qc_status">Statut initial</label>
              <select id="qc_status" name="status" defaultValue="scheduled" disabled={pending}>
                <option value="scheduled">Planifiée</option>
                <option value="draft">Brouillon</option>
              </select>
            </div>

            {/* Affectation toggle */}
            <div className="field full">
              <label>Type d&apos;affectation</label>
              <div style={{ display: "flex", gap: 8 }}>
                <button
                  type="button"
                  onClick={() => setAffectationType("internal")}
                  className={affectationType === "internal" ? "toolbar-primary" : "toolbar-ghost"}
                  style={{ flex: 1, justifyContent: "center" }}
                >
                  Chauffeur interne
                </button>
                <button
                  type="button"
                  onClick={() => setAffectationType("subcontractor")}
                  className={affectationType === "subcontractor" ? "toolbar-primary" : "toolbar-ghost"}
                  style={{ flex: 1, justifyContent: "center" }}
                  disabled={contractors.length === 0}
                >
                  Sous-traitant{contractors.length === 0 ? " (aucun)" : ""}
                </button>
              </div>
            </div>

            {affectationType === "internal" ? (
              <>
                <div className="field">
                  <label htmlFor="qc_driver">
                    Chauffeur
                    {driverId && busyDriverIds.has(driverId) && (
                      <span style={{ marginLeft: 6, color: "var(--destructive)", fontSize: 11, fontWeight: 600 }}>⚠ Déjà affecté</span>
                    )}
                  </label>
                  <select id="qc_driver" name="driver_id" value={driverId}
                    onChange={(e) => setDriverId(e.target.value)} disabled={pending}>
                    <option value="">— Non affecté —</option>
                    {drivers.map((d) => (
                      <option key={d.id} value={d.id}>{busyDriverIds.has(d.id) ? "⚠ " : ""}{d.full_name}</option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label htmlFor="qc_vehicle">
                    Véhicule
                    {vehicleId && busyVehicleIds.has(vehicleId) && (
                      <span style={{ marginLeft: 6, color: "var(--destructive)", fontSize: 11, fontWeight: 600 }}>⚠ Déjà affecté</span>
                    )}
                  </label>
                  <select id="qc_vehicle" name="vehicle_id" value={vehicleId}
                    onChange={(e) => setVehicleId(e.target.value)} disabled={pending}>
                    <option value="">— Non affecté —</option>
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.id}>{busyVehicleIds.has(v.id) ? "⚠ " : ""}{v.plate_number} — {v.brand} {v.model}</option>
                    ))}
                  </select>
                </div>
              </>
            ) : (
              <div className="field full">
                <label htmlFor="qc_sub">Sous-traitant</label>
                <select id="qc_sub" name="subcontractor_id" value={subcontractorId}
                  onChange={(e) => setSubcontractorId(e.target.value)} disabled={pending} required>
                  <option value="">— Sélectionner —</option>
                  {contractors.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
            )}

            <div className="field">
              <label htmlFor="qc_dist">
                <Route size={12} style={{ display: "inline", verticalAlign: "middle", marginRight: 4 }} />
                Distance prévue (km)
              </label>
              <input id="qc_dist" name="total_distance_km" type="number" min="0" step="0.1" placeholder="0" disabled={pending} />
            </div>
            <div className="field">
              <label htmlFor="qc_hours">
                <Clock size={12} style={{ display: "inline", verticalAlign: "middle", marginRight: 4 }} />
                Durée estimée (h)
              </label>
              <input id="qc_hours" name="estimated_hours" type="number" min="0" step="0.5" placeholder="0" disabled={pending} />
            </div>
            <div className="field full">
              <label htmlFor="qc_flat_rate">Prix de la tournée (€ — forfait)</label>
              <input id="qc_flat_rate" name="flat_rate_revenue" type="number" min="0" step="0.01" placeholder="0.00" disabled={pending} />
            </div>

            <div className="field full">
              <label htmlFor="qc_notes">Notes</label>
              <textarea id="qc_notes" name="notes" placeholder="Instructions, zone, observations…" disabled={pending} />
            </div>
          </div>

          {conflicts.length > 0 && (
            <div className="conflict-banner" style={{ marginTop: 12 }}>
              <AlertTriangle size={16} style={{ flexShrink: 0, marginTop: 1 }} />
              <div>
                <strong>Conflit d&apos;affectation détecté</strong>
                <ul>
                  {conflicts.map((c, i) => (
                    <li key={i}>
                      {c.type === "driver" ? "Chauffeur" : "Véhicule"} <strong>{c.resourceLabel}</strong>{" "}
                      déjà sur <em>{c.conflictWith.reference}</em>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* ── Onglet Arrêts ── */}
        <div style={{ display: tab === "stops" ? "block" : "none" }}>
          <p style={{ margin: "0 0 12px", fontSize: 13, color: "var(--muted-foreground)" }}>
            Définissez les points d&apos;embarquement et de livraison de cette tournée. Chaque arrêt crée une mission liée.
          </p>

          {stops.length === 0 ? (
            <div style={{ textAlign: "center", padding: "24px 0", color: "var(--muted-foreground)", fontSize: 13 }}>
              Aucun arrêt défini — la tournée sera créée sans missions.
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {stops.map((stop, idx) => (
                <div key={stop.id} style={{
                  border: "1px solid var(--border)", borderRadius: "var(--radius-md)",
                  padding: "12px", background: "var(--muted)",
                }}>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
                    <span style={{ fontSize: 12, fontWeight: 600, color: "var(--muted-foreground)" }}>Arrêt {idx + 1}</span>
                    <button type="button" className="btn-icon btn-icon-danger" onClick={() => removeStop(stop.id)} aria-label="Supprimer">
                      <Trash2 size={13} />
                    </button>
                  </div>
                  <div className="form-grid" style={{ gap: 8 }}>
                    <div className="field">
                      <label>Ville départ (embarquement)</label>
                      <input value={stop.pickup_city} onChange={(e) => updateStop(stop.id, "pickup_city", e.target.value)}
                        placeholder="Ex. Paris" disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Adresse départ</label>
                      <input value={stop.pickup_address} onChange={(e) => updateStop(stop.id, "pickup_address", e.target.value)}
                        placeholder="10 rue de la Paix" disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Ville arrivée (livraison)</label>
                      <input value={stop.delivery_city} onChange={(e) => updateStop(stop.id, "delivery_city", e.target.value)}
                        placeholder="Ex. Lyon" disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Adresse arrivée</label>
                      <input value={stop.delivery_address} onChange={(e) => updateStop(stop.id, "delivery_address", e.target.value)}
                        placeholder="5 av. Berthelot" disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Heure départ</label>
                      <input type="time" value={stop.scheduled_time} onChange={(e) => updateStop(stop.id, "scheduled_time", e.target.value)} disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Marchandise / description</label>
                      <input value={stop.cargo_description} onChange={(e) => updateStop(stop.id, "cargo_description", e.target.value)}
                        placeholder="Palette, colis…" disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Distance (km)</label>
                      <input type="number" min="0" step="0.1" value={stop.distance_km}
                        onChange={(e) => updateStop(stop.id, "distance_km", e.target.value)} placeholder="0" disabled={pending} />
                    </div>
                    <div className="field">
                      <label>Prix (€)</label>
                      <input type="number" min="0" step="0.01" value={stop.price}
                        onChange={(e) => updateStop(stop.id, "price", e.target.value)} placeholder="0" disabled={pending} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          <button type="button" className="toolbar-ghost" onClick={addStop}
            style={{ marginTop: 12, width: "100%", justifyContent: "center" }} disabled={pending}>
            <Plus size={14} /> Ajouter un arrêt
          </button>
        </div>

        {/* ── Onglet Récurrence ── */}
        <div style={{ display: tab === "recurrence" ? "block" : "none" }}>
          <p style={{ margin: "0 0 14px", fontSize: 13, color: "var(--muted-foreground)" }}>
            Créez automatiquement plusieurs tournées identiques sur une période.
          </p>

          {/* Type */}
          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 6 }}>Type de récurrence</div>
            <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              {([
                ["none",    "Aucune"],
                ["daily",   "Quotidienne"],
                ["weekly",  "Hebdomadaire"],
                ["monthly", "Mensuelle"],
              ] as const).map(([val, label]) => (
                <button
                  key={val}
                  type="button"
                  className={recurrenceType === val ? "toolbar-primary" : "toolbar-ghost"}
                  style={{ fontSize: 12 }}
                  disabled={pending}
                  onClick={() => {
                    setRecurrenceType(val);
                    if (val === "weekly" && recurrenceDays.length === 0) {
                      const d = new Date(date + "T00:00:00");
                      setRecurrenceDays([(d.getDay() + 6) % 7]);
                    }
                  }}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {recurrenceType !== "none" && (
            <div className="form-grid">
              {/* Intervalle */}
              <div className="field full">
                <label style={{ fontWeight: 600 }}>Intervalle</label>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <span style={{ fontSize: 13, color: "var(--muted-foreground)" }}>Tous les</span>
                  <input
                    type="number" min={1} max={99}
                    value={recurrenceInterval}
                    onChange={(e) => setRecurrenceInterval(Math.max(1, parseInt(e.target.value) || 1))}
                    style={{ width: 64 }}
                    disabled={pending}
                  />
                  <span style={{ fontSize: 13, color: "var(--muted-foreground)" }}>
                    {recurrenceType === "daily"   && (recurrenceInterval > 1 ? "jours"    : "jour")}
                    {recurrenceType === "weekly"  && (recurrenceInterval > 1 ? "semaines" : "semaine")}
                    {recurrenceType === "monthly" && "mois"}
                  </span>
                </div>
              </div>

              {/* Jours de la semaine (weekly) */}
              {recurrenceType === "weekly" && (
                <div className="field full">
                  <label style={{ fontWeight: 600, display: "block", marginBottom: 6 }}>Jours de la semaine</label>
                  <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
                    {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].map((label, idx) => (
                      <button
                        key={idx}
                        type="button"
                        className={recurrenceDays.includes(idx) ? "toolbar-primary" : "toolbar-ghost"}
                        style={{ minWidth: 42, fontSize: 11, padding: "4px 6px" }}
                        disabled={pending}
                        onClick={() =>
                          setRecurrenceDays(
                            recurrenceDays.includes(idx)
                              ? recurrenceDays.filter((d) => d !== idx)
                              : [...recurrenceDays, idx],
                          )
                        }
                      >
                        {label}
                      </button>
                    ))}
                  </div>
                  {recurrenceDays.length === 0 && (
                    <p style={{ fontSize: 11, color: "var(--destructive)", marginTop: 4 }}>
                      Sélectionnez au moins un jour.
                    </p>
                  )}
                </div>
              )}

              {/* Ignorer week-ends (daily) */}
              {recurrenceType === "daily" && (
                <div className="field full">
                  <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, fontWeight: "normal" }}>
                    <input
                      type="checkbox"
                      checked={recurrenceSkipWeekends}
                      onChange={(e) => setRecurrenceSkipWeekends(e.target.checked)}
                      disabled={pending}
                    />
                    Ignorer les week-ends (sam. et dim.)
                  </label>
                </div>
              )}

              {/* Fin de récurrence */}
              <div className="field full">
                <label style={{ fontWeight: 600, display: "block", marginBottom: 8 }}>Fin de récurrence</label>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, fontWeight: "normal" }}>
                    <input
                      type="radio"
                      name="qc_rec_end_mode"
                      checked={recurrenceEndMode === "date"}
                      onChange={() => setRecurrenceEndMode("date")}
                      disabled={pending}
                    />
                    Par date :
                    <input
                      type="date"
                      value={recurrenceEnd}
                      min={date}
                      onChange={(e) => setRecurrenceEnd(e.target.value)}
                      disabled={pending || recurrenceEndMode !== "date"}
                      style={{ marginLeft: 4 }}
                    />
                  </label>
                  <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13, fontWeight: "normal" }}>
                    <input
                      type="radio"
                      name="qc_rec_end_mode"
                      checked={recurrenceEndMode === "count"}
                      onChange={() => setRecurrenceEndMode("count")}
                      disabled={pending}
                    />
                    Après
                    <input
                      type="number"
                      min={1} max={365}
                      value={recurrenceOccurrences}
                      onChange={(e) => setRecurrenceOccurrences(Math.max(1, parseInt(e.target.value) || 1))}
                      style={{ width: 64, marginLeft: 4 }}
                      disabled={pending || recurrenceEndMode !== "count"}
                    />
                    <span>occurrence{recurrenceOccurrences !== 1 ? "s" : ""}</span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* Aperçu */}
          {recurrenceType !== "none" && recurrenceCount > 0 &&
            (recurrenceEndMode === "count" || (recurrenceEnd && recurrenceEnd >= date)) && (
            <div style={{
              marginTop: 14, padding: "12px 14px",
              background: "color-mix(in oklab, var(--ring) 10%, transparent)",
              border: "1px solid color-mix(in oklab, var(--ring) 30%, transparent)",
              borderRadius: "var(--radius-md)", fontSize: 13,
            }}>
              <strong>{recurrenceCount} tournée{recurrenceCount !== 1 ? "s" : ""}</strong>
              {recurrenceCount > 1
                ? ` — du ${new Date(recurrenceDates[0] + "T00:00:00").toLocaleDateString("fr-FR")} au ${new Date(recurrenceDates[recurrenceDates.length - 1] + "T00:00:00").toLocaleDateString("fr-FR")}`
                : ` le ${new Date(recurrenceDates[0] + "T00:00:00").toLocaleDateString("fr-FR")}`
              }.
              {recurrenceType === "daily" && (
                <span> {recurrenceInterval === 1 ? "Chaque jour" : `Tous les ${recurrenceInterval} jours`}{recurrenceSkipWeekends ? ", week-ends exclus" : ""}.</span>
              )}
              {recurrenceType === "weekly" && recurrenceDays.length > 0 && (
                <span> {recurrenceInterval > 1 ? `Toutes les ${recurrenceInterval} semaines` : "Chaque semaine"} : {["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"].filter((_, i) => recurrenceDays.includes(i)).join(", ")}.</span>
              )}
              {recurrenceType === "monthly" && (
                <span> {recurrenceInterval === 1 ? "Chaque mois" : `Tous les ${recurrenceInterval} mois`}.</span>
              )}
              {stops.length > 0 && (
                <span> Chaque tournée aura <strong>{stops.length} arrêt{stops.length !== 1 ? "s" : ""}</strong>.</span>
              )}
            </div>
          )}
        </div>
      </form>
    </Modal>
  );
}

