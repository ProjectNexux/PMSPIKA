"use client";

import { useMemo } from "react";
import type { PlanningTournee } from "@/lib/planning";
import { marginTone } from "@/lib/profitability";
import { formatCurrency } from "@/lib/format";

const HOURS = Array.from({ length: 24 }, (_, i) => i);

export function DayView({
  tournees,
  date,
  onOpenAssign,
}: {
  tournees: PlanningTournee[];
  date: string;
  onOpenAssign: (t: PlanningTournee) => void;
}) {
  const dayTournees = useMemo(
    () => tournees.filter((t) => t.scheduled_date === date),
    [tournees, date],
  );

  if (dayTournees.length === 0) {
    return (
      <div className="empty-state">
        <h3>Aucune tournée le {formatLong(date)}</h3>
        <p>Naviguez vers une autre date ou créez une tournée.</p>
      </div>
    );
  }

  return (
    <div className="day-timeline" aria-label={`Tournées du ${date}`}>
      <div className="day-hour-labels">
        <div></div>
        <div className="day-hour-row">
          {HOURS.map((h) => (
            <span key={h}>{h.toString().padStart(2, "0")}h</span>
          ))}
        </div>
      </div>
      <div className="day-timeline-grid">
        {dayTournees.map((t) => {
          const { startH, endH } = computeRange(t);
          const leftPct = (startH / 24) * 100;
          const widthPct = Math.max(((endH - startH) / 24) * 100, 4);
          return (
            <div className="day-row" key={t.id}>
              <div className="day-row-label">
                <strong>{t.reference}</strong>
                <small>{t.driver_name ?? "Non affecté"} · {t.vehicle_plate ?? "—"}</small>
              </div>
              <div className="day-row-track">
                <button
                  type="button"
                  className={`day-bar ${t.status}`}
                  style={{ left: `${leftPct}%`, width: `${widthPct}%` }}
                  onClick={() => onOpenAssign(t)}
                  title={`${t.name} · ${formatHour(startH)} → ${formatHour(endH)}\nRevenu ${formatCurrency(t.profitability.revenue)} • Marge ${formatCurrency(t.profitability.margin)}`}
                >
                  <strong>{t.name}</strong>
                  <span>{formatHour(startH)} — {formatHour(endH)} · {t.missions.length} mission{t.missions.length > 1 ? "s" : ""}</span>
                  <MarginChip t={t} />
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function computeRange(t: PlanningTournee) {
  const times = t.missions
    .map((m) => m.scheduled_time)
    .filter((x): x is string => !!x)
    .map((s) => parseFloat(s.slice(0, 2)) + parseFloat(s.slice(3, 5)) / 60);
  if (times.length === 0) {
    if (t.actual_start) {
      const h = new Date(t.actual_start).getHours() + new Date(t.actual_start).getMinutes() / 60;
      return { startH: h, endH: Math.min(24, h + 4) };
    }
    return { startH: 8, endH: 17 };
  }
  const minT = Math.min(...times);
  const maxT = Math.max(...times) + 1;
  return { startH: Math.max(0, Math.floor(minT)), endH: Math.min(24, Math.ceil(maxT)) };
}

function formatHour(h: number) {
  const hh = Math.floor(h);
  const mm = Math.round((h - hh) * 60);
  return `${hh.toString().padStart(2, "0")}:${mm.toString().padStart(2, "0")}`;
}

function formatLong(iso: string) {
  return new Date(iso).toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
  });
}

function MarginChip({ t }: { t: PlanningTournee }) {
  const { revenue, margin, marginPct } = t.profitability;
  if (revenue === 0 && margin === 0) return null;
  const tone = marginTone(marginPct);
  const bg = tone === "green" ? "rgba(22,163,74,0.18)"
    : tone === "orange" ? "rgba(234,88,12,0.18)"
    : tone === "red" ? "rgba(220,38,38,0.18)" : "rgba(148,163,184,0.18)";
  const fg = tone === "green" ? "#15803d"
    : tone === "orange" ? "#c2410c"
    : tone === "red" ? "#b91c1c" : "#475569";
  return (
    <span style={{
      position: "absolute", top: 4, right: 6,
      fontSize: 10, fontWeight: 700,
      padding: "1px 6px", borderRadius: 999,
      background: bg, color: fg,
    }}>
      {marginPct != null ? `${marginPct.toFixed(0)}%` : "—"}
    </span>
  );
}
