"use client";

import { useMemo } from "react";
import { UserRound, AlertCircle } from "lucide-react";
import { addDays, startOfWeek, toIsoDate } from "@/lib/planning";
import type { PlanningPayload, PlanningTournee } from "@/lib/planning";

const DAY_NAMES = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

export function GanttView({
  tournees,
  drivers,
  anchorDate,
  onOpenAssign,
}: {
  tournees: PlanningTournee[];
  drivers: PlanningPayload["drivers"];
  anchorDate: string;
  onOpenAssign: (t: PlanningTournee) => void;
}) {
  const week = useMemo(() => {
    const start = startOfWeek(new Date(anchorDate));
    return Array.from({ length: 7 }, (_, i) => {
      const d = addDays(start, i);
      const iso = toIsoDate(d);
      return {
        iso,
        dayName: DAY_NAMES[i],
        dayNum: d.getDate(),
        isWeekend: i >= 5,
        isToday: iso === toIsoDate(new Date()),
      };
    });
  }, [anchorDate]);

  // Group tournees by driver (or "unassigned")
  const byDriver = useMemo(() => {
    const map = new Map<string, { id: string; name: string; items: Map<string, PlanningTournee[]> }>();
    // Seed with all drivers (even if empty) so user sees full capacity
    for (const d of drivers) {
      map.set(d.id, { id: d.id, name: d.full_name, items: new Map() });
    }
    map.set("__unassigned__", { id: "__unassigned__", name: "Non affecté", items: new Map() });
    for (const t of tournees) {
      const key = t.driver_id ?? "__unassigned__";
      let row = map.get(key);
      if (!row) {
        row = { id: key, name: t.driver_name ?? "Inconnu", items: new Map() };
        map.set(key, row);
      }
      const arr = row.items.get(t.scheduled_date) ?? [];
      arr.push(t);
      row.items.set(t.scheduled_date, arr);
    }
    // Filter empty driver rows (keep only ones with tournées on the week)
    const weekIsos = new Set(week.map((w) => w.iso));
    return [...map.values()].filter((row) => {
      if (row.id === "__unassigned__") {
        for (const iso of weekIsos) if (row.items.has(iso)) return true;
        return false;
      }
      for (const iso of weekIsos) if (row.items.has(iso)) return true;
      return false;
    });
  }, [tournees, drivers, week]);

  if (byDriver.length === 0) {
    return (
      <div className="empty-state">
        <h3>Aucune tournée affectée cette semaine</h3>
        <p>Affectez vos tournées à des chauffeurs pour voir le planning Gantt.</p>
      </div>
    );
  }

  return (
    <div className="gantt-grid">
      <div className="gantt-table" style={{ ["--gantt-cols" as string]: "7" }}>
        <div className="gantt-cell header">Chauffeur</div>
        {week.map((d) => (
          <div key={d.iso} className={`gantt-cell header${d.isToday ? " is-today" : ""}`}>
            {d.dayName} {d.dayNum}
          </div>
        ))}

        {byDriver.map((row) => (
          <RowFragment key={row.id} row={row} week={week} onOpenAssign={onOpenAssign} />
        ))}
      </div>
    </div>
  );
}

function RowFragment({
  row,
  week,
  onOpenAssign,
}: {
  row: { id: string; name: string; items: Map<string, PlanningTournee[]> };
  week: { iso: string; isWeekend: boolean; isToday: boolean }[];
  onOpenAssign: (t: PlanningTournee) => void;
}) {
  return (
    <>
      <div className="gantt-cell driver-name">
        {row.id === "__unassigned__" ? <AlertCircle size={14} /> : <UserRound size={14} />}
        <div>
          {row.name}
          <small style={{ display: "block" }}>
            {[...row.items.values()].reduce((s, arr) => s + arr.length, 0)} tournée(s)
          </small>
        </div>
      </div>
      {week.map((d) => {
        const items = row.items.get(d.iso) ?? [];
        return (
          <div
            key={d.iso}
            className={`gantt-cell${d.isToday ? " is-today" : ""}${d.isWeekend ? " is-weekend" : ""}`}
          >
            {items.map((t) => (
              <button
                key={t.id}
                type="button"
                className={`gantt-pill ${t.status}`}
                onClick={() => onOpenAssign(t)}
                title={`${t.reference} · ${t.name}`}
              >
                <strong>{t.name}</strong>
                <small>
                  {t.vehicle_plate ?? "—"} · {t.missions.length}m
                </small>
              </button>
            ))}
          </div>
        );
      })}
    </>
  );
}
