"use client";

import { useMemo } from "react";
import { TourneeCard } from "../tournee-card";
import type { PlanningTournee } from "@/lib/planning";

export function ListView({
  tournees,
  redir,
  onOpenAssign,
  onDropMission,
  draggingMissionId,
}: {
  tournees: PlanningTournee[];
  redir: string;
  onOpenAssign: (t: PlanningTournee) => void;
  onDropMission: (mid: string, tid: string) => void;
  draggingMissionId: string | null;
}) {
  const groups = useMemo(() => groupByDate(tournees), [tournees]);

  if (tournees.length === 0) {
    return (
      <div className="empty-state">
        <h3>Aucune tournée sur la période</h3>
        <p>Créez une tournée pour commencer à planifier.</p>
      </div>
    );
  }

  return (
    <div>
      {groups.map(({ date, items }) => (
        <section key={date} className="planning-group">
          <header className="planning-group-header">
            <h3>{formatGroupDate(date)}</h3>
            <span className="count">{items.length}</span>
          </header>
          <div className="planning-group-grid">
            {items.map((t) => (
              <TourneeCard
                key={t.id}
                tournee={t}
                redir={redir}
                onOpenAssign={onOpenAssign}
                onDropMission={onDropMission}
                draggingMissionId={draggingMissionId}
              />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

function groupByDate(tournees: PlanningTournee[]) {
  const map = new Map<string, PlanningTournee[]>();
  for (const t of tournees) {
    const arr = map.get(t.scheduled_date) ?? [];
    arr.push(t);
    map.set(t.scheduled_date, arr);
  }
  return [...map.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, items]) => ({ date, items }));
}

function formatGroupDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
}
