"use client";

import { useMemo } from "react";
import { addDays, startOfWeek, toIsoDate } from "@/lib/planning";
import type { PlanningTournee } from "@/lib/planning";
import { marginTone } from "@/lib/profitability";

const DAY_NAMES = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

export function WeekView({
  tournees,
  anchorDate,
  onOpenAssign,
  onDropMission,
  draggingMissionId,
}: {
  tournees: PlanningTournee[];
  anchorDate: string;
  onOpenAssign: (t: PlanningTournee) => void;
  onDropMission: (mid: string, tid: string) => void;
  draggingMissionId: string | null;
}) {
  const week = useMemo(() => {
    const start = startOfWeek(new Date(anchorDate));
    return Array.from({ length: 7 }, (_, i) => {
      const d = addDays(start, i);
      const iso = toIsoDate(d);
      return {
        iso,
        dayName: DAY_NAMES[i],
        dayNum: d.getDate(),
        isToday: iso === toIsoDate(new Date()),
        items: tournees.filter((t) => t.scheduled_date === iso),
      };
    });
  }, [tournees, anchorDate]);

  return (
    <div className="week-grid">
      <div className="week-grid-inner">
        {week.map((d) => (
          <div
            key={d.iso}
            className={`week-day${d.isToday ? " is-today" : ""}`}
          >
            <div className="week-day-header">
              <span className="day-name">{d.dayName}</span>
              <span className="day-num">{d.dayNum}</span>
            </div>
            {d.items.length === 0 ? (
              <div className="week-day-empty">—</div>
            ) : (
              d.items.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  className="week-day-card"
                  data-status={t.status}
                  onClick={() => onOpenAssign(t)}
                  onDragOver={(e) => {
                    if (draggingMissionId) { e.preventDefault(); e.dataTransfer.dropEffect = "move"; }
                  }}
                  onDrop={(e) => {
                    e.preventDefault();
                    const mid = e.dataTransfer.getData("text/mission-id");
                    if (mid) onDropMission(mid, t.id);
                  }}
                  title={`${t.reference} · ${t.name}`}
                >
                  <strong>{t.name}</strong>
                  <small>{t.driver_name ?? "Non affecté"}</small>
                  <small>{t.missions.length} mission{t.missions.length > 1 ? "s" : ""}</small>
                  {(() => {
                    const { revenue, marginPct } = t.profitability;
                    if (revenue === 0) return null;
                    const tone = marginTone(marginPct);
                    const color = tone === "green" ? "#15803d" : tone === "orange" ? "#c2410c" : tone === "red" ? "#b91c1c" : "#475569";
                    return (
                      <small style={{ color, fontWeight: 700 }}>
                        {marginPct != null ? `${marginPct.toFixed(0)}%` : "—"} marge
                      </small>
                    );
                  })()}
                </button>
              ))
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
