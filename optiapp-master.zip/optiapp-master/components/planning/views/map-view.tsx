"use client";

import dynamic from "next/dynamic";
import type { MapData, PlanningTournee } from "@/lib/planning";

const LiveMap = dynamic(
  () => import("../live-map").then((m) => m.LiveMap),
  {
    ssr: false,
    loading: () => (
      <div className="live-map">
        <div
          className="live-map-canvas"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--muted)",
            fontSize: 13,
          }}
        >
          Chargement de la carte…
        </div>
      </div>
    ),
  },
);

export function MapView({
  mapData,
  tournees,
  onOpenAssign,
}: {
  mapData: MapData;
  tournees: PlanningTournee[];
  onOpenAssign: (t: PlanningTournee) => void;
}) {
  return <LiveMap initialData={mapData} tournees={tournees} onOpenAssign={onOpenAssign} />;
}
