"use client";

import { useTransition } from "react";
import {
  ArrowRight,
  CheckCircle2,
  PlayCircle,
  Truck,
  UserRound,
  X,
  Settings2,
  TrendingUp,
} from "lucide-react";
import {
  attachMissionToTournee,
  completeTournee,
  detachMissionFromTournee,
  startTournee,
} from "@/app/actions";
import type { PlanningMission, PlanningTournee } from "@/lib/planning";
import { marginTone } from "@/lib/profitability";
import { formatCurrency } from "@/lib/format";

const STATUS_LABELS: Record<string, string> = {
  draft: "Brouillon",
  scheduled: "Planifiée",
  in_progress: "En cours",
  completed: "Terminée",
  cancelled: "Annulée",
};

export function TourneeCard({
  tournee,
  redir,
  onOpenAssign,
  onDropMission,
  draggingMissionId,
}: {
  tournee: PlanningTournee;
  redir: string;
  onOpenAssign: (t: PlanningTournee) => void;
  /** Appelé quand une mission est déposée sur cette carte (optionnel). */
  onDropMission?: (missionId: string, tourneeId: string) => void;
  draggingMissionId: string | null;
}) {
  const [pending] = useTransition();
  const isDropTarget = !!draggingMissionId && !!onDropMission;

  return (
    <article
      className={`tournee-card${isDropTarget ? " is-drop-target" : ""}`}
      data-status={tournee.status}
      onDragOver={onDropMission ? (e) => { e.preventDefault(); e.dataTransfer.dropEffect = "move"; } : undefined}
      onDrop={onDropMission ? (e) => {
        e.preventDefault();
        const mid = e.dataTransfer.getData("text/mission-id");
        if (mid) onDropMission(mid, tournee.id);
      } : undefined}
    >
      <header className="tournee-head">
        <span className="tournee-ref">{tournee.reference}</span>
        <h3 title={tournee.name}>{tournee.name}</h3>
        <span className={`status-pill-v2 ${tournee.status}`}>{STATUS_LABELS[tournee.status] ?? tournee.status}</span>
      </header>

      <div className="assign-chips">
        <button
          type="button"
          className={`assign-chip${tournee.driver_id ? "" : " empty"}`}
          onClick={() => onOpenAssign(tournee)}
          title="Modifier l'affectation"
        >
          <UserRound size={13} />
          {tournee.driver_name ?? "Affecter un chauffeur"}
        </button>
        <button
          type="button"
          className={`assign-chip${tournee.vehicle_id ? "" : " empty"}`}
          onClick={() => onOpenAssign(tournee)}
          title="Modifier l'affectation"
        >
          <Truck size={13} />
          {tournee.vehicle_plate ?? "Affecter un véhicule"}
        </button>
      </div>

      <div className="mission-list">
        {tournee.missions.length === 0 ? (
          <div className="mission-empty">Aucune mission rattachée — glissez-déposez ici</div>
        ) : (
          tournee.missions.map((m, i) => (
            <MissionRow
              key={m.id}
              mission={m}
              index={i + 1}
              redir={redir}
            />
          ))
        )}
      </div>

      <footer className="tournee-foot">
        <span className="tournee-kpi">
          {tournee.missions.length} mission{tournee.missions.length > 1 ? "s" : ""}
        </span>
        {tournee.total_distance_km != null && (
          <span className="tournee-kpi">{Math.round(tournee.total_distance_km)} km</span>
        )}
        <MarginBadge tournee={tournee} />
        <span className="spacer" />

        <button type="button" onClick={() => onOpenAssign(tournee)} disabled={pending}>
          <Settings2 size={13} /> Éditer
        </button>

        {tournee.status === "scheduled" || tournee.status === "draft" ? (
          <form action={startTournee} style={{ display: "inline" }}>
            <input type="hidden" name="id" value={tournee.id} />
            <input type="hidden" name="redirect_to" value={redir} />
            <button type="submit" className="primary">
              <PlayCircle size={13} /> Démarrer
            </button>
          </form>
        ) : tournee.status === "in_progress" ? (
          <form action={completeTournee} style={{ display: "inline" }}>
            <input type="hidden" name="id" value={tournee.id} />
            <input type="hidden" name="redirect_to" value={redir} />
            <button type="submit" className="success">
              <CheckCircle2 size={13} /> Terminer
            </button>
          </form>
        ) : null}
      </footer>
    </article>
  );
}

function MarginBadge({ tournee }: { tournee: PlanningTournee }) {
  const { revenue, margin, marginPct } = tournee.profitability;
  if (revenue === 0 && margin === 0) {
    return (
      <span
        className="tournee-kpi"
        title="Aucune donnée de rentabilité saisie"
        style={{ color: "var(--muted)", fontStyle: "italic" }}
      >
        € —
      </span>
    );
  }
  const tone = marginTone(marginPct);
  const color =
    tone === "green" ? "#16a34a" :
    tone === "orange" ? "#ea580c" :
    tone === "red" ? "#dc2626" : "#94a3b8";
  return (
    <span
      className="tournee-kpi"
      title={`Revenu ${formatCurrency(revenue)} • Marge ${formatCurrency(margin)}`}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 4,
        color,
        fontWeight: 700,
      }}
    >
      <TrendingUp size={11} />
      {formatCurrency(margin)} {marginPct != null && <span style={{ opacity: 0.8 }}>({marginPct.toFixed(0)}%)</span>}
    </span>
  );
}

function MissionRow({
  mission,
  index,
  redir,
}: {
  mission: PlanningMission;
  index: number;
  redir: string;
}) {
  return (
    <div className="mission-item">
      <span className="mission-num">{index}</span>
      <span className="mission-route" title={`${mission.pickup_city} → ${mission.delivery_city}`}>
        {mission.pickup_city}
        <ArrowRight size={11} className="arrow" />
        {mission.delivery_city}
      </span>
      <span className="mission-time">
        {mission.scheduled_time ? mission.scheduled_time.slice(0, 5) : "—"}
      </span>
      <span className="mission-actions">
        <form action={detachMissionFromTournee}>
          <input type="hidden" name="mission_id" value={mission.id} />
          <input type="hidden" name="redirect_to" value={redir} />
          <button type="submit" title="Détacher de la tournée" aria-label="Détacher">
            <X size={13} />
          </button>
        </form>
      </span>
    </div>
  );
}
