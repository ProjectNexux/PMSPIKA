"use client";

import { useMemo, useState, useTransition } from "react";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  CalendarDays,
  CalendarRange,
  List,
  Map,
  GanttChartSquare,
} from "lucide-react";
import { UnassignedPanel } from "./unassigned-panel";
import { Modal } from "./modal";
import { QuickCreateModal } from "./quick-create-modal";
import { AssignModal } from "./assign-modal";
import { DayView } from "./views/day-view";
import { WeekView } from "./views/week-view";
import { ListView } from "./views/list-view";
import { GanttView } from "./views/gantt-view";
import { MapView } from "./views/map-view";
import {
  addDays,
  startOfWeek,
  toIsoDate,
  type MapData,
  type PlanningPayload,
  type PlanningTournee,
} from "@/lib/planning";
import { attachMissionToTournee } from "@/app/actions";

type ViewKey = "list" | "day" | "week" | "gantt" | "map";

const VIEWS: { key: ViewKey; label: string; icon: typeof CalendarDays }[] = [
  { key: "list",  label: "Liste",   icon: List },
  { key: "day",   label: "Jour",    icon: CalendarDays },
  { key: "week",  label: "Semaine", icon: CalendarRange },
  { key: "gantt", label: "Gantt",   icon: GanttChartSquare },
  { key: "map",   label: "Carte",   icon: Map },
];

export function TourneePlanning({
  companyId,
  payload,
  mapData,
  redir,
}: {
  companyId: string;
  payload: PlanningPayload;
  mapData: MapData;
  redir: string;
}) {
  const [view, setView] = useState<ViewKey>("list");
  const [anchorDate, setAnchorDate] = useState<string>(toIsoDate(new Date()));
  const [editing, setEditing] = useState<PlanningTournee | null>(null);
  const [creating, setCreating] = useState(false);
  const [draggingMissionId, setDraggingMissionId] = useState<string | null>(null);
  const [attachConfirm, setAttachConfirm] = useState<{ missionId: string; tourneeId: string } | null>(null);
  const [pending, startTransition] = useTransition();

  const dateLabel = useMemo(() => formatDateLabel(view, anchorDate), [view, anchorDate]);

  const goPrev = () => setAnchorDate(toIsoDate(addDays(new Date(anchorDate), view === "week" || view === "gantt" ? -7 : -1)));
  const goNext = () => setAnchorDate(toIsoDate(addDays(new Date(anchorDate), view === "week" || view === "gantt" ? 7 : 1)));
  const goToday = () => setAnchorDate(toIsoDate(new Date()));

  const handleDropMission = (missionId: string, tourneeId: string) => {
    setDraggingMissionId(null);
    setAttachConfirm({ missionId, tourneeId });
  };

  const confirmAttach = () => {
    if (!attachConfirm) return;
    const fd = new FormData();
    fd.set("mission_id", attachConfirm.missionId);
    fd.set("tournee_id", attachConfirm.tourneeId);
    fd.set("redirect_to", redir);
    startTransition(async () => {
      await attachMissionToTournee(fd);
      setAttachConfirm(null);
    });
  };

  return (
    <>
      {/* Toolbar */}
      <div className="planning-toolbar">
        <div className="view-tabs" role="tablist" aria-label="Vue du planning">
          {VIEWS.map((v) => {
            const Icon = v.icon;
            const active = view === v.key;
            return (
              <button
                key={v.key}
                type="button"
                role="tab"
                aria-selected={active}
                className={active ? "view-tab active" : "view-tab"}
                onClick={() => setView(v.key)}
              >
                <Icon size={14} />
                <span>{v.label}</span>
              </button>
            );
          })}
        </div>

        {view !== "list" && (
          <div className="date-nav">
            <button type="button" onClick={goPrev} aria-label="Précédent">
              <ChevronLeft size={16} />
            </button>
            <span className="date-nav-label">{dateLabel}</span>
            <button type="button" onClick={goNext} aria-label="Suivant">
              <ChevronRight size={16} />
            </button>
            <button type="button" className="date-nav-today" onClick={goToday}>
              Aujourd&apos;hui
            </button>
          </div>
        )}

        <span className="toolbar-spacer" />

        <button type="button" className="toolbar-primary" onClick={() => setCreating(true)}>
          <Plus size={14} /> Nouvelle tournée
        </button>
      </div>

      {/* Layout: contenu + panneau missions non-rattachées */}
      <div className="planning-layout">
        <div>
          {view === "list" && (
            <ListView
              tournees={payload.tournees}
              redir={redir}
              onOpenAssign={setEditing}
              onDropMission={handleDropMission}
              draggingMissionId={draggingMissionId}
            />
          )}
          {view === "day" && (
            <DayView
              tournees={payload.tournees}
              date={anchorDate}
              onOpenAssign={setEditing}
            />
          )}
          {view === "week" && (
            <WeekView
              tournees={payload.tournees}
              anchorDate={anchorDate}
              onOpenAssign={setEditing}
              onDropMission={handleDropMission}
              draggingMissionId={draggingMissionId}
            />
          )}
          {view === "gantt" && (
            <GanttView
              tournees={payload.tournees}
              drivers={payload.drivers}
              anchorDate={anchorDate}
              onOpenAssign={setEditing}
            />
          )}
          {view === "map" && (
            <MapView mapData={mapData} tournees={payload.tournees} onOpenAssign={setEditing} />
          )}
        </div>

        <UnassignedPanel
          missions={payload.looseMissions}
          onDragStart={setDraggingMissionId}
          onDragEnd={() => setDraggingMissionId(null)}
          draggingId={draggingMissionId}
        />
      </div>

      {/* Modales */}
      {creating && (
        <QuickCreateModal
          companyId={companyId}
          defaultDate={anchorDate}
          redir={redir}
          drivers={payload.drivers}
          vehicles={payload.vehicles}
          contractors={payload.contractors}
          tournees={payload.tournees}
          onClose={() => setCreating(false)}
        />
      )}
      {editing && (
        <AssignModal
          tournee={editing}
          drivers={payload.drivers}
          vehicles={payload.vehicles}
          tournees={payload.tournees}
          redir={redir}
          onClose={() => setEditing(null)}
        />
      )}
      {attachConfirm && (
        <AttachConfirmModal
          missionRef={payload.looseMissions.find((m) => m.id === attachConfirm.missionId)?.reference ?? "?"}
          tourneeRef={payload.tournees.find((t) => t.id === attachConfirm.tourneeId)?.reference ?? "?"}
          tourneeName={payload.tournees.find((t) => t.id === attachConfirm.tourneeId)?.name ?? ""}
          pending={pending}
          onCancel={() => setAttachConfirm(null)}
          onConfirm={confirmAttach}
        />
      )}
    </>
  );
}

function AttachConfirmModal({
  missionRef,
  tourneeRef,
  tourneeName,
  pending,
  onCancel,
  onConfirm,
}: {
  missionRef: string;
  tourneeRef: string;
  tourneeName: string;
  pending: boolean;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <Modal
      title="Rattacher la mission"
      onClose={onCancel}
      footer={
        <>
          <button type="button" className="toolbar-ghost" onClick={onCancel}>Annuler</button>
          <button type="button" className="toolbar-primary" onClick={onConfirm} disabled={pending}>
            {pending ? "Rattachement…" : "Confirmer"}
          </button>
        </>
      }
    >
      <p style={{ margin: 0, fontSize: 14 }}>
        Rattacher la mission <strong>{missionRef}</strong> à la tournée{" "}
        <strong>{tourneeRef}</strong> ({tourneeName}) ?
      </p>
      <p style={{ margin: 0, fontSize: 12, color: "var(--muted)" }}>
        La mission héritera du chauffeur, du véhicule et de la date de la tournée.
      </p>
    </Modal>
  );
}

function formatDateLabel(view: ViewKey, iso: string) {
  const d = new Date(iso);
  if (view === "week" || view === "gantt") {
    const start = startOfWeek(d);
    const end = addDays(start, 6);
    return `${start.toLocaleDateString("fr-FR", { day: "2-digit", month: "short" })} – ${end.toLocaleDateString(
      "fr-FR",
      { day: "2-digit", month: "short", year: "numeric" },
    )}`;
  }
  if (view === "day") {
    return d.toLocaleDateString("fr-FR", {
      weekday: "long",
      day: "2-digit",
      month: "long",
      year: "numeric",
    });
  }
  return d.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
}


