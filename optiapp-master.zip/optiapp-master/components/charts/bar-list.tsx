import type { ReactNode } from "react";

export type BarItem = {
  label: string;
  value: number;
  /** Optional sub-label shown under main label */
  meta?: string;
  /** Optional displayed value (default = value) */
  display?: ReactNode;
  /** Optional color override */
  color?: string;
};

type Props = {
  items: BarItem[];
  total?: number;
  emptyLabel?: string;
  /** Default bar color */
  color?: string;
};

export function BarList({ items, total, emptyLabel = "Aucune donnée.", color = "#10b981" }: Props) {
  if (!items.length) return <p className="empty-state">{emptyLabel}</p>;
  const max = total ?? Math.max(...items.map((i) => i.value), 1);

  return (
    <ul className="bar-list">
      {items.map((item, idx) => {
        const pct = Math.max(0, Math.min(100, (item.value / max) * 100));
        return (
          <li key={`${item.label}-${idx}`} className="bar-list-item">
            <div className="bar-list-head">
              <div className="bar-list-main">
                <span className="bar-list-label">{item.label}</span>
                {item.meta ? <span className="bar-list-meta">{item.meta}</span> : null}
              </div>
              <span className="bar-list-value">{item.display ?? item.value}</span>
            </div>
            <div className="bar-list-track">
              <span
                className="bar-list-fill"
                style={{ width: `${pct}%`, background: item.color ?? color }}
              />
            </div>
          </li>
        );
      })}
    </ul>
  );
}
