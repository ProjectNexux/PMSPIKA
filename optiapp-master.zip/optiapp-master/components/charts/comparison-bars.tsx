type Props = {
  current: number;
  previous: number;
  currentLabel?: string;
  previousLabel?: string;
  formatValue?: (n: number) => string;
};

export function ComparisonBars({
  current,
  previous,
  currentLabel = "Période",
  previousLabel = "Précédent",
  formatValue = (n) => n.toString(),
}: Props) {
  const max = Math.max(Math.abs(current), Math.abs(previous), 1);
  const curPct = (Math.abs(current) / max) * 100;
  const prevPct = (Math.abs(previous) / max) * 100;
  const delta = current - previous;
  const deltaPct = previous !== 0 ? (delta / Math.abs(previous)) * 100 : null;

  return (
    <div className="cmp-bars">
      <div className="cmp-row">
        <span className="cmp-label">{currentLabel}</span>
        <div className="cmp-track">
          <span className="cmp-fill cur" style={{ width: `${curPct}%` }} />
        </div>
        <span className="cmp-value">{formatValue(current)}</span>
      </div>
      <div className="cmp-row prev">
        <span className="cmp-label">{previousLabel}</span>
        <div className="cmp-track">
          <span className="cmp-fill prev" style={{ width: `${prevPct}%` }} />
        </div>
        <span className="cmp-value">{formatValue(previous)}</span>
      </div>
      {deltaPct !== null ? (
        <div className={`cmp-delta ${delta >= 0 ? "up" : "down"}`}>
          <span aria-hidden>{delta >= 0 ? "▲" : "▼"}</span>
          {Math.abs(deltaPct).toFixed(1)} %
          <small> ({formatValue(Math.abs(delta))} vs précédent)</small>
        </div>
      ) : null}
    </div>
  );
}
