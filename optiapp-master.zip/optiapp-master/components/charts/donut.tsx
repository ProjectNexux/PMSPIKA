import type { ReactNode } from "react";

export type DonutSlice = {
  label: string;
  value: number;
  color: string;
};

type Props = {
  slices: DonutSlice[];
  size?: number;
  thickness?: number;
  centerLabel?: ReactNode;
  centerSub?: ReactNode;
};

export function Donut({
  slices,
  size = 168,
  thickness = 22,
  centerLabel,
  centerSub,
}: Props) {
  const total = slices.reduce((s, sl) => s + Math.max(0, sl.value), 0);
  const radius = size / 2 - thickness / 2;
  const circumference = 2 * Math.PI * radius;

  let offset = 0;
  const segments = slices
    .filter((s) => s.value > 0 && total > 0)
    .map((s) => {
      const len = (s.value / total) * circumference;
      const seg = (
        <circle
          key={s.label}
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={s.color}
          strokeWidth={thickness}
          strokeDasharray={`${len} ${circumference - len}`}
          strokeDashoffset={-offset}
          strokeLinecap="butt"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      );
      offset += len;
      return seg;
    });

  return (
    <div className="donut-chart">
      <div className="donut-svg-wrap" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="var(--border)"
            strokeWidth={thickness}
          />
          {segments}
        </svg>
        <div className="donut-center">
          <span className="donut-center-value">{centerLabel ?? total}</span>
          {centerSub ? <span className="donut-center-sub">{centerSub}</span> : null}
        </div>
      </div>
      <ul className="donut-legend">
        {slices.map((s) => {
          const pct = total > 0 ? (s.value / total) * 100 : 0;
          return (
            <li key={s.label}>
              <span className="donut-dot" style={{ background: s.color }} aria-hidden />
              <span className="donut-legend-label">{s.label}</span>
              <span className="donut-legend-value">
                {s.value}
                <small> · {pct.toFixed(0)}%</small>
              </span>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
