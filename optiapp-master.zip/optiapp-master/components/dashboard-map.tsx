"use client";

import dynamic from "next/dynamic";
import type { MapData } from "@/lib/planning";

const LiveMap = dynamic(
  () => import("./planning/live-map").then((m) => m.LiveMap),
  {
    ssr: false,
    loading: () => (
      <div className="live-map">
        <div
          className="live-map-canvas"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "var(--muted)",
            fontSize: 13,
          }}
        >
          Chargement de la carte…
        </div>
      </div>
    ),
  },
);

export function DashboardMap({ data }: { data: MapData }) {
  return <LiveMap initialData={data} tournees={[]} onOpenAssign={() => {}} />;
}
