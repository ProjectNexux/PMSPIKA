"use client";

import { useEffect, useRef } from "react";
import { Toaster as SonnerToaster, toast } from "sonner";
import type { Flash } from "@/lib/flash";

type Props = {
  flash: Flash | null;
};

/**
 * Wrapper du `Toaster` sonner. Si un flash est passé (lu côté serveur depuis
 * le cookie), il est joué une seule fois au montage / au changement de valeur.
 */
export function Toaster({ flash }: Props) {
  const lastKey = useRef<string | null>(null);

  useEffect(() => {
    if (!flash) return;
    const key = `${flash.kind}|${flash.message}`;
    if (lastKey.current === key) return;
    lastKey.current = key;

    switch (flash.kind) {
      case "success":
        toast.success(flash.message);
        break;
      case "error":
        toast.error(flash.message);
        break;
      case "warning":
        toast.warning(flash.message);
        break;
      default:
        toast(flash.message);
    }
  }, [flash]);

  return (
    <SonnerToaster
      position="top-right"
      richColors
      closeButton
      toastOptions={{ duration: 4500 }}
    />
  );
}
