"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  AlertTriangle, Route, Truck, Users, Activity, Banknote,
  RefreshCw, X, Filter, MapPin, TrendingUp, TrendingDown,
  CheckCircle2, AlertCircle, Calendar, ChevronDown,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { formatCurrency, formatDate, formatNumber } from "@/lib/format";
import type {
  DashboardOverview, DashboardTournee, DashboardFleetAlert,
  DashboardInvoice, DashboardIncident, DashboardFinanceTrend,
  VehicleRow, EmployeeRow, DocumentRow,
} from "@/lib/queries";

// ────────────────────────────────────────────────────────────────────────────
// Period helpers
// ────────────────────────────────────────────────────────────────────────────

export type Period = "day" | "week" | "month" | "year" | "custom";

const PERIOD_LABELS: Record<Period, string> = {
  day: "Jour",
  week: "Semaine",
  month: "Mois",
  year: "Année",
  custom: "Personnalisé",
};

function getDateRange(
  period: Period,
  customFrom?: string,
  customTo?: string,
): { from: Date; to: Date } {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  switch (period) {
    case "day":
      return { from: today, to: new Date(today.getTime() + 86_400_000 - 1) };
    case "week": {
      const dow = today.getDay(); // 0=Sun
      const mon = new Date(today.getTime() - (dow === 0 ? 6 : dow - 1) * 86_400_000);
      return { from: mon, to: new Date(mon.getTime() + 7 * 86_400_000 - 1) };
    }
    case "month":
      return {
        from: new Date(now.getFullYear(), now.getMonth(), 1),
        to: new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59),
      };
    case "year":
      return {
        from: new Date(now.getFullYear(), 0, 1),
        to: new Date(now.getFullYear(), 11, 31, 23, 59, 59),
      };
    case "custom":
      return {
        from: customFrom ? new Date(customFrom) : new Date(now.getFullYear(), now.getMonth(), 1),
        to: customTo
          ? new Date(customTo + "T23:59:59")
          : new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59),
      };
  }
}

function getPrevDateRange(period: Period, from: Date, to: Date): { from: Date; to: Date } {
  switch (period) {
    case "day":
      return { from: new Date(from.getTime() - 86_400_000), to: new Date(to.getTime() - 86_400_000) };
    case "week":
      return { from: new Date(from.getTime() - 7 * 86_400_000), to: new Date(to.getTime() - 7 * 86_400_000) };
    case "month": {
      const m = from.getMonth() - 1;
      const y = m < 0 ? from.getFullYear() - 1 : from.getFullYear();
      const pm = m < 0 ? 11 : m;
      return {
        from: new Date(y, pm, 1),
        to: new Date(y, pm + 1, 0, 23, 59, 59),
      };
    }
    case "year":
      return {
        from: new Date(from.getFullYear() - 1, 0, 1),
        to: new Date(from.getFullYear() - 1, 11, 31, 23, 59, 59),
      };
    default: {
      const duration = to.getTime() - from.getTime();
      return { from: new Date(from.getTime() - duration - 1), to: new Date(from.getTime() - 1) };
    }
  }
}

function formatPeriodLabel(period: Period, from: Date, to: Date): string {
  const fmt = (d: Date) =>
    d.toLocaleDateString("fr-FR", { day: "numeric", month: "short", year: "numeric" });
  if (period === "day") return fmt(from);
  if (period === "month")
    return from.toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
  if (period === "year") return String(from.getFullYear());
  return `${fmt(from)} — ${fmt(to)}`;
}

// ────────────────────────────────────────────────────────────────────────────
// Types
// ────────────────────────────────────────────────────────────────────────────

export type DashboardClientProps = {
  overview: DashboardOverview | null;
  tournees: DashboardTournee[];
  fleetAlerts: DashboardFleetAlert[];
  invoices: DashboardInvoice[];
  incidents: DashboardIncident[];
  financeTrend: DashboardFinanceTrend | null;
  vehicles: VehicleRow[];
  employees: EmployeeRow[];
  documents: DocumentRow[];
  /** Optionnel : si fourni, le header affiche le nom de la société */
  companyName?: string;
  /** Optionnel : utilisé pour les liens internes (mode société) */
  companyId?: string;
};

type FilterState = {
  tourneeStatus?: string;
  vehicleStatus?: string;
  driverId?: string;
  city?: string;
};

const TOURNEE_LABELS: Record<string, string> = {
  draft: "Brouillon",
  scheduled: "Planifiée",
  planned: "Planifiée",
  in_progress: "En cours",
  en_cours: "En cours",
  completed: "Terminée",
  termine: "Terminée",
  cancelled: "Annulée",
};

const TOURNEE_COLORS: Record<string, string> = {
  draft:       "#94a3b8",
  scheduled:   "#3b82f6",
  planned:     "#3b82f6",
  in_progress: "#f59e0b",
  en_cours:    "#f59e0b",
  completed:   "#10b981",
  termine:     "#10b981",
  cancelled:   "#ef4444",
};

// Statuts de la table `vehicles` (administrative) — valeurs françaises capitalisées
const VEHICLE_LABELS: Record<string, string> = {
  // Table administrative (vehicles)
  "Actif": "Actif",
  "Maintenance": "En maintenance",
  "Inactif": "Inactif",
  "Hors service": "Hors service",
  // Table TMS (tms_vehicles)
  available: "Disponible",
  in_use: "En mission",
  on_mission: "En mission",
  maintenance: "Maintenance",
  out_of_service: "Hors service",
};

const VEHICLE_COLORS: Record<string, string> = {
  // Table administrative (vehicles)
  "Actif":         "#10b981",
  "Maintenance":   "#f59e0b",
  "Inactif":       "#94a3b8",
  "Hors service":  "#ef4444",
  // Table TMS (tms_vehicles)
  available:       "#10b981",
  in_use:          "#3b82f6",
  on_mission:      "#3b82f6",
  maintenance:     "#f59e0b",
  out_of_service:  "#ef4444",
};

// ────────────────────────────────────────────────────────────────────────────
// Sub-components (interactive primitives)
// ────────────────────────────────────────────────────────────────────────────

/** Interactive KPI tile — clickable to toggle filter */
function KpiTile({
  label, value, sub, icon, accent = "emerald", active = false,
  onClick, danger = false, delta, deltaInverted = false,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ReactNode;
  accent?: "emerald" | "blue" | "amber" | "violet" | "red" | "slate";
  active?: boolean;
  onClick?: () => void;
  danger?: boolean;
  /** Percentage change vs previous period (positive = up) */
  delta?: number | null;
  /** If true, a positive delta is displayed as bad (e.g. alerts) */
  deltaInverted?: boolean;
}) {
  const accents = {
    emerald: { bg: "bg-emerald-500/10", text: "text-emerald-600", ring: "ring-emerald-500" },
    blue:    { bg: "bg-blue-500/10",    text: "text-blue-600",    ring: "ring-blue-500"    },
    amber:   { bg: "bg-amber-500/10",   text: "text-amber-600",   ring: "ring-amber-500"   },
    violet:  { bg: "bg-violet-500/10",  text: "text-violet-600",  ring: "ring-violet-500"  },
    red:     { bg: "bg-red-500/10",     text: "text-red-600",     ring: "ring-red-500"     },
    slate:   { bg: "bg-slate-500/10",   text: "text-slate-600",   ring: "ring-slate-400"   },
  }[accent];

  const Comp = onClick ? "button" : "div";
  return (
    <Comp
      type={onClick ? "button" : undefined}
      onClick={onClick}
      className={cn(
        "relative flex flex-col gap-3 overflow-hidden rounded-xl border bg-card p-5 text-left shadow-sm transition-all",
        onClick && "cursor-pointer hover:shadow-md hover:border-slate-300",
        active && `ring-2 ring-offset-1 ${accents.ring}`,
        danger && "ring-2 ring-destructive/30"
      )}
    >
      {/* Top shimmer (slate-light signature) */}
      <span aria-hidden className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent" />

      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          {label}
        </span>
        <span className={cn("flex h-8 w-8 items-center justify-center rounded-lg [&_svg]:size-4", accents.bg, accents.text)}>
          {icon}
        </span>
      </div>

      <div className="flex flex-col">
        <span className={cn(
          "text-[30px] font-semibold leading-none tabular-nums tracking-[-0.025em]",
          danger && "text-destructive"
        )}>
          {value}
        </span>
        {delta !== null && delta !== undefined && (
          <span className={cn(
            "mt-1.5 inline-flex items-center gap-0.5 text-[11px] font-semibold",
            (deltaInverted ? delta <= 0 : delta >= 0) ? "text-emerald-600" : "text-red-500"
          )}>
            {(deltaInverted ? delta <= 0 : delta >= 0)
              ? <TrendingUp className="size-3" />
              : <TrendingDown className="size-3" />}
            {delta >= 0 ? "+" : ""}{delta.toFixed(1)}% vs préc.
          </span>
        )}
        {sub && <span className="mt-1.5 text-xs text-muted-foreground">{sub}</span>}
      </div>
    </Comp>
  );
}

/** Interactive donut chart with click-to-filter slices */
function InteractiveDonut({
  data, title, description, activeKey, onSliceClick, size = 180, thickness = 28,
}: {
  data: { key: string; label: string; value: number; color: string }[];
  title: string;
  description?: string;
  activeKey?: string;
  onSliceClick?: (key: string) => void;
  size?: number;
  thickness?: number;
}) {
  const total = data.reduce((s, d) => s + Math.max(0, d.value), 0);
  const radius = size / 2 - thickness / 2;
  const circumference = 2 * Math.PI * radius;
  let offset = 0;

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className="flex flex-col items-center gap-5 pb-5">
        {total === 0 ? (
          <div className="flex flex-col items-center gap-2 py-10 text-sm text-muted-foreground">
            <AlertCircle className="size-5 opacity-40" />
            Aucune donnée
          </div>
        ) : (
          <>
            <div className="relative" style={{ width: size, height: size }}>
              <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
                <circle
                  cx={size / 2}
                  cy={size / 2}
                  r={radius}
                  fill="none"
                  stroke="#e2e8f0"
                  strokeWidth={thickness}
                />
                {data
                  .filter((d) => d.value > 0)
                  .map((d) => {
                    const len = (d.value / total) * circumference;
                    const isActive = activeKey === d.key;
                    const isOther = activeKey && activeKey !== d.key;
                    const seg = (
                      <circle
                        key={d.key}
                        cx={size / 2}
                        cy={size / 2}
                        r={radius}
                        fill="none"
                        stroke={d.color}
                        strokeWidth={isActive ? thickness + 4 : thickness}
                        strokeDasharray={`${len} ${circumference - len}`}
                        strokeDashoffset={-offset}
                        opacity={isOther ? 0.25 : 1}
                        transform={`rotate(-90 ${size / 2} ${size / 2})`}
                        className={cn(
                          "transition-all duration-200",
                          onSliceClick && "cursor-pointer hover:opacity-80"
                        )}
                        onClick={() => onSliceClick?.(d.key)}
                      />
                    );
                    offset += len;
                    return seg;
                  })}
              </svg>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-semibold tabular-nums tracking-[-0.025em]">
                  {activeKey
                    ? data.find((d) => d.key === activeKey)?.value ?? total
                    : total}
                </span>
                <span className="mt-0.5 text-xs uppercase tracking-wider text-muted-foreground">
                  {activeKey
                    ? data.find((d) => d.key === activeKey)?.label ?? "total"
                    : "total"}
                </span>
              </div>
            </div>

            <ul className="flex w-full flex-col gap-1.5">
              {data.map((d) => {
                const pct = total > 0 ? (d.value / total) * 100 : 0;
                const isActive = activeKey === d.key;
                return (
                  <li key={d.key}>
                    <button
                      type="button"
                      onClick={() => onSliceClick?.(d.key)}
                      disabled={!onSliceClick}
                      className={cn(
                        "flex w-full items-center gap-2.5 rounded-md px-2 py-1.5 text-sm transition-colors",
                        onSliceClick && "cursor-pointer hover:bg-muted/60",
                        isActive && "bg-muted font-medium"
                      )}
                    >
                      <span
                        aria-hidden
                        className="h-2.5 w-2.5 shrink-0 rounded-full"
                        style={{ backgroundColor: d.color }}
                      />
                      <span className="flex-1 truncate text-left">{d.label}</span>
                      <span className="tabular-nums text-muted-foreground">
                        {d.value} <span className="text-[11px]">· {pct.toFixed(0)}%</span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </>
        )}
      </CardContent>
    </Card>
  );
}

/** Interactive bar list with click-to-filter */
function InteractiveBarList({
  items, title, description, activeKey, onItemClick, color = "#10b981",
}: {
  items: { key: string; label: string; value: number; meta?: string }[];
  title: string;
  description?: string;
  activeKey?: string;
  onItemClick?: (key: string) => void;
  color?: string;
}) {
  const max = Math.max(...items.map((i) => i.value), 1);

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-base">{title}</CardTitle>
        {description && <CardDescription>{description}</CardDescription>}
      </CardHeader>
      <CardContent className="pb-5">
        {items.length === 0 ? (
          <div className="flex flex-col items-center gap-2 py-8 text-sm text-muted-foreground">
            <AlertCircle className="size-5 opacity-40" />
            Aucune donnée
          </div>
        ) : (
          <ul className="flex flex-col gap-2.5">
            {items.map((item) => {
              const pct = (item.value / max) * 100;
              const isActive = activeKey === item.key;
              const isOther = activeKey && activeKey !== item.key;
              return (
                <li key={item.key}>
                  <button
                    type="button"
                    onClick={() => onItemClick?.(item.key)}
                    disabled={!onItemClick}
                    className={cn(
                      "flex w-full flex-col gap-1 rounded-md p-2 text-left transition-colors",
                      onItemClick && "cursor-pointer hover:bg-muted/60",
                      isActive && "bg-muted",
                      isOther && "opacity-50"
                    )}
                  >
                    <div className="flex items-center justify-between gap-2 text-sm">
                      <span className={cn("truncate", isActive && "font-semibold")}>
                        {item.label}
                      </span>
                      <span className="shrink-0 font-medium tabular-nums">
                        {item.value}
                        {item.meta && <span className="ml-1 text-xs font-normal text-muted-foreground">{item.meta}</span>}
                      </span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full rounded-full transition-all duration-300"
                        style={{ width: `${pct}%`, backgroundColor: color }}
                      />
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Main component
// ────────────────────────────────────────────────────────────────────────────

export function DashboardClient({
  overview, tournees, fleetAlerts, invoices, incidents, financeTrend,
  vehicles, employees, companyName, companyId,
}: DashboardClientProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [filters, setFilters] = useState<FilterState>({});

  // ── Period selector ────────────────────────────────────────────────────
  const [period, setPeriod] = useState<Period>("month");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");

  const dateRange = useMemo(
    () => getDateRange(period, customFrom, customTo),
    [period, customFrom, customTo],
  );

  const prevDateRange = useMemo(
    () => getPrevDateRange(period, dateRange.from, dateRange.to),
    [period, dateRange],
  );

  const periodLabel = useMemo(
    () => formatPeriodLabel(period, dateRange.from, dateRange.to),
    [period, dateRange],
  );

  const ov = (overview ?? {}) as Partial<DashboardOverview>;
  const trend = financeTrend;

  // ── Toggle filters (Power BI style) ──────────────────────────────────────
  const toggleFilter = (k: keyof FilterState, v: string | undefined) =>
    setFilters((f) => ({ ...f, [k]: f[k] === v ? undefined : v }));

  const clearFilters = () => setFilters({});
  const activeFilters = Object.entries(filters).filter(([, v]) => v !== undefined);

  // ── Aggregations ─────────────────────────────────────────────────────────

  // ── Period-filtered tournees ──────────────────────────────────────────
  const periodTournees = useMemo(() => {
    const fromStr = dateRange.from.toISOString().slice(0, 10);
    const toStr = dateRange.to.toISOString().slice(0, 10);
    return tournees.filter((t) => t.scheduled_date >= fromStr && t.scheduled_date <= toStr);
  }, [tournees, dateRange]);

  const prevPeriodTournees = useMemo(() => {
    const fromStr = prevDateRange.from.toISOString().slice(0, 10);
    const toStr = prevDateRange.to.toISOString().slice(0, 10);
    return tournees.filter((t) => t.scheduled_date >= fromStr && t.scheduled_date <= toStr);
  }, [tournees, prevDateRange]);

  const tourneeStatusCounts = useMemo(() => {
    const map = new Map<string, number>();
    periodTournees.forEach((t) => map.set(t.status, (map.get(t.status) ?? 0) + 1));
    return Array.from(map.entries())
      .map(([key, value]) => ({
        key,
        label: TOURNEE_LABELS[key] ?? key,
        value,
        color: TOURNEE_COLORS[key] ?? "#64748b",
      }))
      .sort((a, b) => b.value - a.value);
  }, [periodTournees]);

  const fleetStatusCounts = useMemo(() => {
    const map = new Map<string, number>();
    vehicles.forEach((v) => map.set(v.status, (map.get(v.status) ?? 0) + 1));
    return Array.from(map.entries())
      .map(([key, value]) => ({
        key,
        label: VEHICLE_LABELS[key] ?? key,
        value,
        color: VEHICLE_COLORS[key] ?? "#94a3b8",
      }))
      .sort((a, b) => b.value - a.value);
  }, [vehicles]);

  const driverWorkload = useMemo(() => {
    const map = new Map<string, number>();
    periodTournees.forEach((t) => {
      if (t.driver_name) map.set(t.driver_name, (map.get(t.driver_name) ?? 0) + 1);
    });
    return Array.from(map.entries())
      .map(([key, value]) => ({ key, label: key, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [periodTournees]);

  // Period-scoped KPIs derived from client-side filtered tournees
  const periodCompleted = useMemo(
    () => periodTournees.filter((t) => t.status === "completed" || t.status === "termine").length,
    [periodTournees],
  );
  const periodInProgress = useMemo(
    () => periodTournees.filter((t) => t.status === "in_progress" || t.status === "en_cours").length,
    [periodTournees],
  );

  const prevCompleted = useMemo(
    () => prevPeriodTournees.filter((t) => t.status === "completed" || t.status === "termine").length,
    [prevPeriodTournees],
  );
  const prevInProgress = useMemo(
    () => prevPeriodTournees.filter((t) => t.status === "in_progress" || t.status === "en_cours").length,
    [prevPeriodTournees],
  );

  // Utility: % change, returns null if prev === 0
  const deltaPct = (current: number, prev: number): number | null =>
    prev === 0 ? null : ((current - prev) / Math.abs(prev)) * 100;

  // ── Filtered tournees (applies all active filters) ───────────────────────
  const filteredTournees = useMemo(() => {
    return periodTournees.filter((t) => {
      if (filters.tourneeStatus && t.status !== filters.tourneeStatus) return false;
      if (filters.driverId && t.driver_name !== filters.driverId) return false;
      return true;
    });
  }, [periodTournees, filters]);

  const filteredVehicles = useMemo(() => {
    return vehicles.filter((v) => {
      if (filters.vehicleStatus && v.status !== filters.vehicleStatus) return false;
      return true;
    });
  }, [vehicles, filters]);

  // ── Counts based on filters ──────────────────────────────────────────────
  const totalAlerts =
    (ov.documents_critical ?? 0) +
    (ov.vehicles_ct_30d ?? 0) +
    (ov.vehicles_ins_30d ?? 0) +
    (ov.incidents_open ?? 0);

  const margin = trend?.margin_period ?? ov.margin_period ?? 0;
  const marginPrev = trend?.margin_prev ?? 0;
  const marginDiff = margin - marginPrev;

  const refresh = () => startTransition(() => router.refresh());

  return (
    <main className="page pb-12">
      {/* ─── HEADER ─── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            {companyName ? `Pilotage · ${companyName}` : "Pilotage groupe · temps réel"}
          </span>
          <h1 className="text-[28px] font-semibold leading-tight tracking-[-0.025em] text-foreground">
            {companyName ? `${companyName} — Tableau de bord` : "Tableau de bord interactif"}
          </h1>
          <p className="mt-0.5 flex items-center gap-2 text-sm text-muted-foreground">
            <span aria-hidden className="inline-flex h-2 w-2 rounded-full bg-emerald-500 shadow-[0_0_0_3px_rgb(16_185_129_/_0.2)]" />
            {ov.period && <span>Période {ov.period}</span>}
            {ov.period && <span aria-hidden>·</span>}
            <span>{companyName ? `Vue ${companyName}` : "Cliquez sur un graphique pour filtrer"}</span>
          </p>
        </div>
        <div className="flex items-center gap-2">
          {totalAlerts > 0 && (
            <Badge variant="destructive" className="gap-1 px-2.5 py-1 text-xs">
              <AlertTriangle className="size-3" />
              {totalAlerts} alerte{totalAlerts > 1 ? "s" : ""}
            </Badge>
          )}
          <Button variant="outline" size="sm" onClick={refresh} disabled={isPending} className="gap-2">
            <RefreshCw className={cn("size-4", isPending && "animate-spin")} />
            Actualiser
          </Button>
        </div>
      </div>

      {/* ─── PERIOD SELECTOR ─── */}
      <div className="flex flex-col gap-2 rounded-xl border bg-card p-3 shadow-sm sm:flex-row sm:items-center sm:gap-3">
        <div className="flex items-center gap-1.5">
          <Calendar className="size-4 shrink-0 text-muted-foreground" />
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Période</span>
        </div>
        <div className="flex flex-wrap items-center gap-1.5">
          {(["day", "week", "month", "year", "custom"] as Period[]).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPeriod(p)}
              className={cn(
                "inline-flex h-7 items-center gap-1 rounded-md px-3 text-xs font-medium transition-all",
                period === p
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "border bg-background text-foreground hover:bg-muted"
              )}
            >
              {PERIOD_LABELS[p]}
              {p === "custom" && period === "custom" && <ChevronDown className="size-3" />}
            </button>
          ))}
        </div>
        {period === "custom" && (
          <div className="flex flex-wrap items-center gap-2">
            <Input
              type="date"
              value={customFrom}
              onChange={(e) => setCustomFrom(e.target.value)}
              className="h-7 w-36 text-xs"
              aria-label="Date de début"
            />
            <span className="text-xs text-muted-foreground">→</span>
            <Input
              type="date"
              value={customTo}
              onChange={(e) => setCustomTo(e.target.value)}
              className="h-7 w-36 text-xs"
              aria-label="Date de fin"
            />
          </div>
        )}
        <span className="ml-auto shrink-0 text-xs text-muted-foreground tabular-nums">
          {periodLabel} · <span className="font-semibold text-foreground">{periodTournees.length}</span> tournée{periodTournees.length !== 1 ? "s" : ""}
        </span>
      </div>

      {/* ─── ACTIVE FILTERS BAR (visible only when filters set) ─── */}
      {activeFilters.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50/60 px-3 py-2">
          <Filter className="size-4 text-emerald-600" />
          <span className="text-xs font-semibold uppercase tracking-wider text-emerald-700">
            Filtres actifs :
          </span>
          {activeFilters.map(([k, v]) => {
            const label =
              k === "tourneeStatus"
                ? `Statut tournée : ${TOURNEE_LABELS[v as string] ?? v}`
                : k === "vehicleStatus"
                ? `État véhicule : ${VEHICLE_LABELS[v as string] ?? v}`
                : k === "driverId"
                ? `Chauffeur : ${v}`
                : `${k} : ${v}`;
            return (
              <button
                key={k}
                type="button"
                onClick={() => setFilters((f) => ({ ...f, [k]: undefined }))}
                className="inline-flex items-center gap-1.5 rounded-full border border-emerald-300 bg-white px-2.5 py-0.5 text-xs font-medium text-emerald-800 transition-colors hover:bg-emerald-50"
              >
                {label}
                <X className="size-3" />
              </button>
            );
          })}
          <Button
            variant="ghost"
            size="sm"
            onClick={clearFilters}
            className="ml-auto h-6 px-2 text-xs text-emerald-700 hover:bg-emerald-100 hover:text-emerald-900"
          >
            Tout effacer
          </Button>
        </div>
      )}

      {/* ─── 6 INTERACTIVE KPI TILES ─── */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <KpiTile
          label="Tournées"
          value={periodTournees.length}
          sub={`${periodCompleted} terminées · ${PERIOD_LABELS[period].toLowerCase()}`}
          icon={<Route />}
          accent="emerald"
          delta={deltaPct(periodTournees.length, prevPeriodTournees.length)}
        />
        <KpiTile
          label="En cours"
          value={period === "day" || period === "week" ? ov.tournees_in_progress ?? periodInProgress : periodInProgress}
          sub={`${ov.missions_in_progress ?? 0} missions actives`}
          icon={<Activity />}
          accent="amber"
          active={filters.tourneeStatus === "in_progress"}
          onClick={() => toggleFilter("tourneeStatus", "in_progress")}
          delta={deltaPct(periodInProgress, prevInProgress)}
        />
        <KpiTile
          label="Flotte dispo"
          value={`${ov.tms_fleet_available ?? 0}/${ov.tms_fleet_total ?? 0}`}
          sub={`${ov.tms_fleet_on_mission ?? 0} en mission`}
          icon={<Truck />}
          accent="blue"
          active={filters.vehicleStatus === "Actif"}
          onClick={() => toggleFilter("vehicleStatus", "Actif")}
        />
        <KpiTile
          label="Chauffeurs actifs"
          value={ov.drivers_active ?? 0}
          sub={`${ov.absences_active ?? 0} absence${(ov.absences_active ?? 0) > 1 ? "s" : ""}`}
          icon={<Users />}
          accent="violet"
        />
        <KpiTile
          label="CA du mois"
          value={formatCurrency(ov.revenue_period ?? 0)}
          sub={
            marginDiff !== 0
              ? `Marge ${marginDiff >= 0 ? "+" : ""}${formatCurrency(marginDiff)}`
              : "Stable"
          }
          icon={<Banknote />}
          accent="emerald"
          delta={trend?.revenue_prev ? deltaPct(ov.revenue_period ?? 0, trend.revenue_prev) : null}
        />
        <KpiTile
          label="Alertes"
          value={totalAlerts}
          sub={`${ov.documents_critical ?? 0} docs · ${ov.incidents_open ?? 0} incidents`}
          icon={<AlertTriangle />}
          accent={totalAlerts > 0 ? "red" : "slate"}
          danger={totalAlerts > 0}
        />
      </div>

      {/* ─── FINANCE STRIP ─── */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Performance financière</CardTitle>
            {trend && (
              <span className="text-xs text-muted-foreground">
                {trend.prev_period} → {trend.period}
              </span>
            )}
          </div>
        </CardHeader>
        <CardContent className="grid grid-cols-1 gap-6 pb-5 sm:grid-cols-3">
          {[
            {
              label: "Recettes",
              current: ov.revenue_period ?? 0,
              prev: trend?.revenue_prev ?? 0,
              color: "#10b981",
            },
            {
              label: "Dépenses",
              current: ov.expenses_period ?? 0,
              prev: trend?.expenses_prev ?? 0,
              color: "#f59e0b",
            },
            {
              label: "Marge",
              current: margin,
              prev: marginPrev,
              color: "#3b82f6",
            },
          ].map(({ label, current, prev, color }) => {
            const diff = current - prev;
            const hasPrev = prev !== 0;
            const diffPct = hasPrev ? (diff / Math.abs(prev)) * 100 : null;
            const max = Math.max(Math.abs(current), Math.abs(prev), 1);
            return (
              <div key={label} className="flex flex-col gap-2">
                <div className="flex items-end justify-between">
                  <div className="flex flex-col">
                    <span className="text-xs font-medium uppercase tracking-wider text-muted-foreground">{label}</span>
                    <span className="text-xl font-semibold tabular-nums tracking-[-0.02em]">
                      {formatCurrency(current)}
                    </span>
                  </div>
                  {diffPct !== null ? (
                    <Badge
                      variant={diff >= 0 ? "success" : "destructive"}
                      className="gap-0.5 px-2 text-[11px]"
                    >
                      {diff >= 0 ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
                      {diff >= 0 ? "+" : ""}
                      {diffPct.toFixed(1)}%
                    </Badge>
                  ) : (
                    <span className="text-[11px] text-muted-foreground">1er mois</span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{ width: `${(Math.abs(current) / max) * 100}%`, backgroundColor: color }}
                    />
                  </div>
                </div>
                <div className="flex items-center gap-2 opacity-60">
                  <div className="h-1 w-full overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full"
                      style={{ width: `${(Math.abs(prev) / max) * 100}%`, backgroundColor: color }}
                    />
                  </div>
                  <span className="shrink-0 text-[10px] text-muted-foreground">préc.</span>
                </div>
              </div>
            );
          })}
        </CardContent>
      </Card>

      {/* ─── COMPARATIF PÉRIODE PRÉCÉDENTE ─── */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-base">Comparatif période précédente</CardTitle>
              <CardDescription>
                {formatPeriodLabel(period, prevDateRange.from, prevDateRange.to)}{" "}
                <span aria-hidden>→</span>{" "}
                {periodLabel}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pb-5">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
            {[
              {
                label: "Tournées",
                current: periodTournees.length,
                prev: prevPeriodTournees.length,
                format: (v: number) => String(v),
                inverted: false,
              },
              {
                label: "Terminées",
                current: periodCompleted,
                prev: prevCompleted,
                format: (v: number) => String(v),
                inverted: false,
              },
              {
                label: "Recettes",
                current: ov.revenue_period ?? 0,
                prev: trend?.revenue_prev ?? 0,
                format: (v: number) => formatCurrency(v),
                inverted: false,
              },
              {
                label: "Dépenses",
                current: ov.expenses_period ?? 0,
                prev: trend?.expenses_prev ?? 0,
                format: (v: number) => formatCurrency(v),
                inverted: true,
              },
              {
                label: "Marge",
                current: margin,
                prev: marginPrev,
                format: (v: number) => formatCurrency(v),
                inverted: false,
              },
            ].map(({ label, current, prev, format, inverted }) => {
              const diff = current - prev;
              const pct = prev !== 0 ? (diff / Math.abs(prev)) * 100 : null;
              const isGood = pct !== null && (inverted ? diff <= 0 : diff >= 0);
              const isNeutral = pct === null || diff === 0;
              return (
                <div key={label} className="flex flex-col gap-1.5 rounded-lg border bg-muted/30 p-3">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                    {label}
                  </span>
                  <div className="flex flex-col gap-0.5">
                    <span className="text-base font-semibold tabular-nums leading-tight">
                      {format(current)}
                    </span>
                    <span className="text-[11px] text-muted-foreground tabular-nums">
                      préc. {format(prev)}
                    </span>
                  </div>
                  {!isNeutral && pct !== null ? (
                    <span
                      className={cn(
                        "inline-flex w-fit items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[10px] font-semibold",
                        isGood
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-red-100 text-red-700"
                      )}
                    >
                      {isGood ? <TrendingUp className="size-3" /> : <TrendingDown className="size-3" />}
                      {diff >= 0 ? "+" : ""}{pct.toFixed(1)}%
                    </span>
                  ) : (
                    <span className="text-[10px] text-muted-foreground">stable</span>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* ─── 3 INTERACTIVE CHARTS ─── */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        <InteractiveDonut
          title="Statut tournées"
          description="Cliquez sur une part pour filtrer"
          data={tourneeStatusCounts}
          activeKey={filters.tourneeStatus}
          onSliceClick={(k) => toggleFilter("tourneeStatus", k)}
        />
        <InteractiveDonut
          title="État de la flotte"
          description="Cliquez sur une part pour filtrer"
          data={fleetStatusCounts}
          activeKey={filters.vehicleStatus}
          onSliceClick={(k) => toggleFilter("vehicleStatus", k)}
        />
        <InteractiveBarList
          title="Charge par chauffeur"
          description="Top 8 — cliquez pour filtrer"
          items={driverWorkload}
          activeKey={filters.driverId}
          onItemClick={(k) => toggleFilter("driverId", k)}
          color="#8b5cf6"
        />
      </div>

      {/* ─── FILTERED TOURNEE TABLE ─── */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between gap-2">
            <div>
              <CardTitle className="text-base">
                Tournées
                {filteredTournees.length !== tournees.length && (
                  <Badge variant="info" className="ml-2 text-[10px]">
                    {filteredTournees.length}/{periodTournees.length} filtrées
                  </Badge>
                )}
              </CardTitle>
              <CardDescription>
                {activeFilters.length > 0
                  ? "Résultats avec filtres actifs"
                  : "Toutes les tournées récentes — utilisez les graphiques pour filtrer"}
              </CardDescription>
            </div>
            <Button variant="ghost" size="sm" asChild>
              <a href={companyId ? `/societes/${companyId}/pilotage` : "/pilotage"} className="gap-1 text-xs">
                Planning <span aria-hidden>→</span>
              </a>
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          {filteredTournees.length === 0 ? (
            <div className="flex flex-col items-center gap-2 py-12 text-sm text-muted-foreground">
              <CheckCircle2 className="size-8 opacity-30" />
              {activeFilters.length > 0
                ? "Aucune tournée ne correspond aux filtres"
                : "Aucune tournée planifiée"}
              {activeFilters.length > 0 && (
                <Button variant="outline" size="sm" onClick={clearFilters} className="mt-1">
                  Effacer les filtres
                </Button>
              )}
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Référence</TableHead>
                  <TableHead>Chauffeur</TableHead>
                  <TableHead>Véhicule</TableHead>
                  <TableHead>Statut</TableHead>
                  <TableHead className="text-right">Miss.</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredTournees.map((t) => {
                  const color = TOURNEE_COLORS[t.status] ?? "#64748b";
                  return (
                    <TableRow key={t.id}>
                      <TableCell className="whitespace-nowrap text-xs text-muted-foreground">
                        <span className="inline-flex items-center gap-1.5">
                          <Calendar className="size-3 opacity-50" />
                          {formatDate(t.scheduled_date)}
                        </span>
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col gap-0.5">
                          <span className="font-mono text-xs font-semibold text-primary">{t.reference}</span>
                          {t.name && <span className="line-clamp-1 text-xs text-muted-foreground">{t.name}</span>}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm">
                        {t.driver_name ?? <span className="italic text-muted-foreground">Non assigné</span>}
                      </TableCell>
                      <TableCell>
                        {t.vehicle_plate ? (
                          <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{t.vehicle_plate}</span>
                        ) : (
                          <span className="text-muted-foreground">—</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <span
                          className="inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[11px] font-medium"
                          style={{
                            backgroundColor: `${color}1f`,
                            color: color,
                          }}
                        >
                          <span aria-hidden className="size-1.5 rounded-full" style={{ backgroundColor: color }} />
                          {TOURNEE_LABELS[t.status] ?? t.status}
                        </span>
                      </TableCell>
                      <TableCell className="text-right tabular-nums text-sm">{t.missions_count}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      {/* ─── BOTTOM ROW : Fleet alerts + Incidents + Invoices ─── */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
        {/* Fleet alerts */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Alertes flotte</CardTitle>
            <CardDescription>{fleetAlerts.length} véhicule{fleetAlerts.length !== 1 ? "s" : ""} à surveiller (60 j)</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 pb-4">
            {fleetAlerts.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-8 text-sm text-muted-foreground">
                <CheckCircle2 className="size-6 opacity-30 text-emerald-600" />
                Aucune alerte
              </div>
            ) : (
              fleetAlerts.slice(0, 5).map((a) => {
                const dl = a.earliest_due
                  ? Math.ceil((new Date(a.earliest_due).getTime() - Date.now()) / 86_400_000)
                  : null;
                const isCritical = dl !== null && dl <= 15;
                return (
                  <div
                    key={a.id}
                    className={cn(
                      "flex items-center gap-3 rounded-lg border p-2.5",
                      isCritical && "border-destructive/30 bg-destructive/5"
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center rounded-md",
                        isCritical ? "bg-destructive/15 text-destructive" : "bg-amber-100 text-amber-700"
                      )}
                    >
                      <Truck className="size-4" />
                    </span>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <span className="font-mono text-xs font-semibold">{a.plate}</span>
                      <span className="line-clamp-1 text-[11px] text-muted-foreground">
                        {a.alert_kind} · {a.company_name ?? "—"}
                      </span>
                    </div>
                    <span
                      className={cn(
                        "shrink-0 text-xs font-semibold tabular-nums",
                        isCritical ? "text-destructive" : "text-amber-700"
                      )}
                    >
                      {dl !== null ? (dl <= 0 ? "Expiré" : `J-${dl}`) : "—"}
                    </span>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        {/* Incidents */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Incidents récents</CardTitle>
            <CardDescription>{incidents.length} incident{incidents.length !== 1 ? "s" : ""} ouvert{incidents.length !== 1 ? "s" : ""}</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 pb-4">
            {incidents.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-8 text-sm text-muted-foreground">
                <CheckCircle2 className="size-6 opacity-30 text-emerald-600" />
                Aucun incident
              </div>
            ) : (
              incidents.slice(0, 5).map((inc) => {
                const variant: "destructive" | "warning" | "muted" =
                  inc.severity?.toLowerCase().includes("haut") || inc.severity?.toLowerCase().includes("crit") || inc.severity?.toLowerCase() === "high"
                    ? "destructive"
                    : inc.severity?.toLowerCase().includes("moy") || inc.severity?.toLowerCase() === "medium"
                    ? "warning"
                    : "muted";
                return (
                  <div key={inc.id} className="flex flex-col gap-1 rounded-lg border p-2.5">
                    <div className="flex items-start justify-between gap-2">
                      <span className="line-clamp-1 text-sm font-medium leading-snug">{inc.title}</span>
                      <Badge variant={variant} className="shrink-0 text-[10px]">{inc.severity}</Badge>
                    </div>
                    <span className="line-clamp-1 text-[11px] text-muted-foreground">
                      {inc.driver_name ?? "—"} {inc.mission_ref && <>· <span className="font-mono">{inc.mission_ref}</span></>}
                    </span>
                  </div>
                );
              })
            )}
          </CardContent>
        </Card>

        {/* Overdue invoices */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Factures en retard</CardTitle>
            <CardDescription>
              {(ov.invoices_overdue_count ?? 0) > 0
                ? formatCurrency(ov.invoices_overdue_amount ?? 0) + " à recouvrer"
                : "À jour"}
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2 pb-4">
            {invoices.length === 0 ? (
              <div className="flex flex-col items-center gap-2 py-8 text-sm text-muted-foreground">
                <CheckCircle2 className="size-6 opacity-30 text-emerald-600" />
                Aucune facture en retard
              </div>
            ) : (
              invoices.slice(0, 5).map((inv) => (
                <div key={inv.id} className="flex items-center gap-3 rounded-lg border p-2.5">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-destructive/15 text-destructive">
                    <Banknote className="size-4" />
                  </span>
                  <div className="flex min-w-0 flex-1 flex-col">
                    <span className="font-mono text-xs font-semibold">{inv.invoice_number}</span>
                    <span className="line-clamp-1 text-[11px] text-muted-foreground">{inv.client_name ?? "—"}</span>
                  </div>
                  <div className="flex shrink-0 flex-col items-end gap-0.5">
                    <span className="text-xs font-semibold tabular-nums">{formatCurrency(inv.total_amount)}</span>
                    <Badge variant={inv.days_overdue > 30 ? "destructive" : "warning"} className="text-[10px]">
                      J+{inv.days_overdue}
                    </Badge>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>
      </div>

      {/* ─── FOOTER : filtered fleet count + last update ─── */}
      <div className="flex flex-col items-center gap-1 pt-2 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <Truck className="size-3.5" />
          {filteredVehicles.length}/{vehicles.length} véhicule{vehicles.length > 1 ? "s" : ""}
          <Separator orientation="vertical" className="h-3" />
          <Users className="size-3.5" />
          {employees.length} salarié{employees.length > 1 ? "s" : ""}
          {ov.period && (
            <>
              <Separator orientation="vertical" className="h-3" />
              <MapPin className="size-3.5" />
              Période {ov.period}
            </>
          )}
        </div>
      </div>
    </main>
  );
}
