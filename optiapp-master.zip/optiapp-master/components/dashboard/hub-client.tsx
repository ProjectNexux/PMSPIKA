"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  Truck, Users, AlertTriangle, Activity, Route, RefreshCw, ArrowRight,
  CheckCircle2, Clock, AlertCircle, FileWarning, Car, BarChart3,
  TrendingUp, TrendingDown, Banknote,
} from "lucide-react";
import {
  Card, CardContent, CardHeader, CardTitle, CardDescription,
} from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { formatCurrency, formatNumber, formatDate } from "@/lib/format";
import type {
  DashboardOverview, DashboardTournee, DashboardFleetAlert,
  DashboardInvoice, DashboardIncident, DashboardFinanceTrend,
  CompanySummary, Totals,
} from "@/lib/queries";

// ─── Types ─────────────────────────────────────────────────────────────────

type BadgeVariant =
  | "default" | "secondary" | "destructive" | "outline"
  | "success" | "warning" | "info" | "muted";

export type HubClientProps = {
  overview: DashboardOverview | null;
  tournees: DashboardTournee[];
  fleetAlerts: DashboardFleetAlert[];
  invoices: DashboardInvoice[];
  incidents: DashboardIncident[];
  financeTrend: DashboardFinanceTrend | null;
  companies: CompanySummary[];
  totals: Totals | null;
};

// ─── Helpers ────────────────────────────────────────────────────────────────

function tourneeVariant(status: string): BadgeVariant {
  const map: Record<string, BadgeVariant> = {
    // French keys
    planifie: "info", en_cours: "warning", termine: "success", annule: "destructive",
    // English keys (from DB)
    planned: "info", in_progress: "warning", completed: "success", cancelled: "destructive",
    // Mixed
    scheduled: "info", done: "success",
  };
  return map[status] ?? "muted";
}

function tourneeLabel(status: string) {
  const map: Record<string, string> = {
    planifie: "Planifié", en_cours: "En cours", termine: "Terminé", annule: "Annulé",
    planned: "Planifié", in_progress: "En cours", completed: "Terminé", cancelled: "Annulé",
    scheduled: "Planifié", done: "Terminé",
  };
  return map[status] ?? status;
}

function severityVariant(severity: string): BadgeVariant {
  const map: Record<string, BadgeVariant> = {
    critique: "destructive", haute: "warning", moyenne: "info", faible: "muted",
  };
  return map[severity.toLowerCase()] ?? "muted";
}

function daysLeft(dateStr: string | null | undefined): number | null {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr).getTime() - Date.now()) / 86_400_000);
}

// ─── Sub-components ─────────────────────────────────────────────────────────

type KpiTone = "blue" | "green" | "amber" | "red" | "violet" | "neutral";

const kpiColors: Record<KpiTone, { bg: string; text: string }> = {
  blue:    { bg: "bg-blue-500/10",    text: "text-blue-600"    },
  green:   { bg: "bg-emerald-500/10", text: "text-emerald-600" },
  amber:   { bg: "bg-amber-500/10",   text: "text-amber-600"   },
  red:     { bg: "bg-red-500/10",     text: "text-red-600"     },
  violet:  { bg: "bg-violet-500/10",  text: "text-violet-600"  },
  neutral: { bg: "bg-muted",          text: "text-muted-foreground" },
};

function KpiCard({
  label, value, sub, icon, tone = "neutral", danger = false,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ReactNode;
  tone?: KpiTone;
  danger?: boolean;
}) {
  const c = kpiColors[tone];
  return (
    <Card className={cn(
      "relative flex flex-col gap-3 p-5 overflow-hidden",
      danger && "ring-2 ring-destructive/20"
    )}>
      {/* Slate-light shimmer top line */}
      <span aria-hidden className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-emerald-400/50 to-transparent" />
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          {label}
        </span>
        <span className={cn("flex h-8 w-8 items-center justify-center rounded-lg [&_svg]:size-4", c.bg, c.text)}>
          {icon}
        </span>
      </div>
      <div className="flex flex-col gap-1">
        <span className={cn("text-[30px] font-semibold tabular-nums leading-none tracking-[-0.025em]", danger && "text-destructive")}>
          {value}
        </span>
        {sub ? <span className="text-xs text-muted-foreground mt-1">{sub}</span> : null}
      </div>
    </Card>
  );
}

function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
      <div
        className="h-full rounded-full transition-all duration-300"
        style={{ width: `${pct}%`, backgroundColor: color }}
      />
    </div>
  );
}

function EmptyState({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex flex-col items-center gap-3 py-12 text-sm text-muted-foreground">
      <span className="opacity-30 [&_svg]:size-8">{icon}</span>
      {label}
    </div>
  );
}

// ─── Main component ──────────────────────────────────────────────────────────

export function HubClient({
  overview, tournees, fleetAlerts, invoices, incidents, financeTrend, companies,
}: HubClientProps) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const ov = (overview ?? {}) as Partial<DashboardOverview>;

  const totalAlerts =
    (ov.documents_critical ?? 0) +
    (ov.vehicles_ct_30d ?? 0) +
    (ov.vehicles_ins_30d ?? 0);
  const margin = ov.margin_period ?? 0;
  const revenue = ov.revenue_period ?? 0;

  function refresh() {
    startTransition(() => router.refresh());
  }

  return (
    <main className="page pb-12">

      {/* ── Header ── */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="flex flex-col gap-1">
          <span className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted-foreground">
            PIKA TRANSPORT
          </span>
          <h1 className="text-2xl font-semibold tracking-tight text-foreground">
            Dashboard Groupe
          </h1>
          {ov.period && (
            <p className="text-sm text-muted-foreground">Période : {ov.period}</p>
          )}
        </div>
        <div className="flex items-center gap-2">
          {totalAlerts > 0 && (
            <Badge variant="destructive" className="gap-1 text-xs">
              <AlertTriangle className="size-3" />
              {totalAlerts} alerte{totalAlerts > 1 ? "s" : ""}
            </Badge>
          )}
          <Button
            variant="outline"
            size="sm"
            onClick={refresh}
            disabled={isPending}
            className="gap-2"
          >
            <RefreshCw className={cn("size-4", isPending && "animate-spin")} />
            Actualiser
          </Button>
        </div>
      </div>

      {/* ── 6 KPI Cards ── */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <KpiCard
          label="Tournées / jour"
          value={ov.tournees_today ?? 0}
          sub={`${ov.tournees_scheduled_week ?? 0} cette semaine`}
          icon={<Route />}
          tone="blue"
        />
        <KpiCard
          label="En cours"
          value={ov.tournees_in_progress ?? 0}
          sub={`${ov.missions_in_progress ?? 0} missions actives`}
          icon={<Activity />}
          tone="amber"
        />
        <KpiCard
          label="Flotte active"
          value={ov.fleet_active ?? 0}
          sub={`sur ${ov.fleet_total ?? 0} véhicules`}
          icon={<Truck />}
          tone="green"
        />
        <KpiCard
          label="Effectif"
          value={ov.employees_active ?? 0}
          sub={`${ov.drivers_active ?? 0} chauffeurs`}
          icon={<Users />}
          tone="violet"
        />
        <KpiCard
          label="CA du mois"
          value={formatCurrency(revenue)}
          sub={ov.period ?? ""}
          icon={<Banknote />}
          tone="neutral"
        />
        <KpiCard
          label="Alertes"
          value={totalAlerts}
          sub={`${ov.documents_critical ?? 0} docs · ${(ov.vehicles_ct_30d ?? 0) + (ov.vehicles_ins_30d ?? 0)} véhicules`}
          icon={<AlertTriangle />}
          tone={totalAlerts > 0 ? "red" : "neutral"}
          danger={totalAlerts > 0}
        />
      </div>

      {/* ── Finance Banner ── */}
      <Card>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base">Bilan financier consolidé</CardTitle>
            <span className="text-sm text-muted-foreground">{ov.period ?? "Période actuelle"}</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-3">
            {/* Bars */}
            <div className="col-span-1 flex flex-col gap-4 sm:col-span-1">
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Recettes</span>
                  <span className="font-semibold tabular-nums">{formatCurrency(revenue)}</span>
                </div>
                <ProgressBar value={revenue} max={revenue || 1} color="#10b981" />
              </div>
              <div className="flex flex-col gap-1.5">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Dépenses</span>
                  <span className="font-semibold tabular-nums">{formatCurrency(ov.expenses_period ?? 0)}</span>
                </div>
                <ProgressBar value={ov.expenses_period ?? 0} max={revenue || 1} color="#f59e0b" />
              </div>
            </div>

            {/* Net margin */}
            <div className="flex items-center justify-center">
              <div className="flex flex-col items-center gap-1 text-center">
                <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Marge nette
                </span>
                <span
                  className={cn(
                    "text-4xl font-bold tabular-nums tracking-tight",
                    margin >= 0 ? "text-emerald-600" : "text-destructive"
                  )}
                >
                  {formatCurrency(margin)}
                </span>
                {revenue > 0 && (
                  <span
                    className={cn(
                      "flex items-center gap-1 text-sm font-medium",
                      margin >= 0 ? "text-emerald-600" : "text-destructive"
                    )}
                  >
                    {margin >= 0 ? <TrendingUp className="size-4" /> : <TrendingDown className="size-4" />}
                    {((margin / revenue) * 100).toFixed(1)} %
                  </span>
                )}
              </div>
            </div>

            {/* Invoice alerts */}
            <div className="flex flex-col gap-2.5">
              {(ov.invoices_overdue_count ?? 0) > 0 ? (
                <div className="flex items-center justify-between rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2.5">
                  <div className="flex items-center gap-2 text-sm text-destructive">
                    <AlertCircle className="size-4" />
                    {ov.invoices_overdue_count} facture{(ov.invoices_overdue_count ?? 0) > 1 ? "s" : ""} en retard
                  </div>
                  <span className="text-sm font-semibold tabular-nums text-destructive">
                    {formatCurrency(ov.invoices_overdue_amount ?? 0)}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2.5 text-sm text-emerald-700">
                  <CheckCircle2 className="size-4" />
                  Aucune facture en retard
                </div>
              )}
              {(ov.invoices_outstanding_count ?? 0) > 0 && (
                <div className="flex items-center justify-between rounded-lg border bg-muted/40 px-3 py-2.5">
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="size-4" />
                    {ov.invoices_outstanding_count} en attente de paiement
                  </div>
                  <span className="text-sm font-semibold tabular-nums">
                    {formatCurrency(ov.invoices_outstanding_amount ?? 0)}
                  </span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* ── Interactive Tabs ── */}
      <Tabs defaultValue="operations">
        <TabsList className="h-auto flex-wrap gap-1 p-1">
          <TabsTrigger value="operations" className="gap-1.5">
            <Route className="size-3.5" />
            Opérations
            {(ov.tournees_in_progress ?? 0) > 0 && (
              <Badge variant="secondary" className="ml-1 h-4 min-w-4 px-1 text-[10px]">
                {ov.tournees_in_progress}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="flotte" className="gap-1.5">
            <Truck className="size-3.5" />
            Flotte
            {fleetAlerts.length > 0 && (
              <Badge variant="destructive" className="ml-1 h-4 min-w-4 px-1 text-[10px]">
                {fleetAlerts.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="finance" className="gap-1.5">
            <BarChart3 className="size-3.5" />
            Finance
            {(ov.invoices_overdue_count ?? 0) > 0 && (
              <Badge variant="destructive" className="ml-1 h-4 min-w-4 px-1 text-[10px]">
                {ov.invoices_overdue_count}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="alertes" className="gap-1.5">
            <AlertTriangle className="size-3.5" />
            Alertes
            {totalAlerts > 0 && (
              <Badge variant="destructive" className="ml-1 h-4 min-w-4 px-1 text-[10px]">
                {totalAlerts}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* ── Tab : Opérations ── */}
        <TabsContent value="operations" className="mt-4">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Tournées récentes</CardTitle>
                <CardDescription>Les 8 dernières tournées actives ou planifiées</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {tournees.length === 0 ? (
                  <EmptyState icon={<Route />} label="Aucune tournée" />
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Référence</TableHead>
                        <TableHead>Chauffeur</TableHead>
                        <TableHead>Véhicule</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Statut</TableHead>
                        <TableHead className="text-right">Miss.</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {tournees.map((t) => (
                        <TableRow key={t.id}>
                          <TableCell>
                            <div className="flex flex-col gap-0.5">
                              <span className="font-mono text-xs font-medium text-primary">
                                {t.reference}
                              </span>
                              <span className="text-xs text-muted-foreground line-clamp-1">
                                {t.name}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">
                            {t.driver_name ?? (
                              <span className="italic text-muted-foreground">Non assigné</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {t.vehicle_plate ? (
                              <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">
                                {t.vehicle_plate}
                              </span>
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {formatDate(t.scheduled_date)}
                          </TableCell>
                          <TableCell>
                            <Badge variant={tourneeVariant(t.status)}>
                              {tourneeLabel(t.status)}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right tabular-nums text-sm">
                            {t.missions_count}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Incidents ouverts</CardTitle>
                <CardDescription>
                  {incidents.length} incident{incidents.length !== 1 ? "s" : ""} récent{incidents.length !== 1 ? "s" : ""}
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-col gap-2.5 p-4">
                {incidents.length === 0 ? (
                  <EmptyState icon={<CheckCircle2 />} label="Aucun incident ouvert" />
                ) : (
                  incidents.map((inc) => (
                    <div key={inc.id} className="flex flex-col gap-1.5 rounded-lg border p-3">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-sm font-medium leading-snug">{inc.title}</span>
                        <Badge variant={severityVariant(inc.severity)} className="shrink-0">
                          {inc.severity}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                        {inc.driver_name && <span>{inc.driver_name}</span>}
                        {inc.driver_name && inc.mission_ref && <span>·</span>}
                        {inc.mission_ref && (
                          <span className="font-mono">{inc.mission_ref}</span>
                        )}
                      </div>
                      {inc.estimated_cost != null && (
                        <span className="text-xs font-medium text-destructive">
                          {formatCurrency(inc.estimated_cost)} estimé
                        </span>
                      )}
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── Tab : Flotte ── */}
        <TabsContent value="flotte" className="mt-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Alertes flotte — 60 jours</CardTitle>
              <CardDescription>
                Véhicules avec contrôle technique ou assurance à échéance proche
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              {fleetAlerts.length === 0 ? (
                <EmptyState icon={<CheckCircle2 />} label="Aucune alerte véhicule dans les 60 jours" />
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Véhicule</TableHead>
                      <TableHead>Société</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>CT</TableHead>
                      <TableHead>Assurance</TableHead>
                      <TableHead>Échéance</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {fleetAlerts.map((a) => {
                      const dl = daysLeft(a.earliest_due);
                      return (
                        <TableRow key={a.id}>
                          <TableCell>
                            <div className="flex flex-col gap-0.5">
                              <span className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs w-fit">
                                {a.plate}
                              </span>
                              {a.brand && (
                                <span className="text-xs text-muted-foreground">
                                  {a.brand} {a.model}
                                </span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell className="text-sm">{a.company_name ?? "—"}</TableCell>
                          <TableCell>
                            <Badge
                              variant={
                                a.alert_kind === "CT+ASSURANCE" ? "destructive" : "warning"
                              }
                            >
                              {a.alert_kind ?? "Alerte"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-sm">
                            {a.ct_due ? (
                              formatDate(a.ct_due)
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell className="text-sm">
                            {a.ins_due ? (
                              formatDate(a.ins_due)
                            ) : (
                              <span className="text-muted-foreground">—</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {dl !== null ? (
                              <span
                                className={cn(
                                  "text-sm font-semibold tabular-nums",
                                  dl <= 0
                                    ? "text-destructive"
                                    : dl <= 15
                                    ? "text-destructive"
                                    : dl <= 30
                                    ? "text-amber-600"
                                    : "text-foreground"
                                )}
                              >
                                {dl <= 0 ? "Expiré" : `J-${dl}`}
                              </span>
                            ) : (
                              "—"
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* ── Tab : Finance ── */}
        <TabsContent value="finance" className="mt-4">
          <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
            {/* Trend comparison */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Comparatif mensuel</CardTitle>
                {financeTrend ? (
                  <CardDescription>
                    {financeTrend.prev_period} → {financeTrend.period}
                  </CardDescription>
                ) : (
                  <CardDescription>Données non disponibles</CardDescription>
                )}
              </CardHeader>
              <CardContent className="flex flex-col gap-5">
                {financeTrend ? (
                  [
                    {
                      label: "Recettes",
                      current: financeTrend.revenue_period,
                      prev: financeTrend.revenue_prev,
                      color: "#10b981",
                    },
                    {
                      label: "Dépenses",
                      current: financeTrend.expenses_period,
                      prev: financeTrend.expenses_prev,
                      color: "#f59e0b",
                    },
                    {
                      label: "Marge",
                      current: financeTrend.margin_period,
                      prev: financeTrend.margin_prev,
                      color: "#3b82f6",
                    },
                  ].map(({ label, current, prev, color }) => {
                    const diff = current - prev;
                    const diffPct = prev !== 0 ? (diff / Math.abs(prev)) * 100 : 0;
                    const max = Math.max(Math.abs(current), Math.abs(prev), 1);
                    return (
                      <div key={label} className="flex flex-col gap-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{label}</span>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold tabular-nums">
                              {formatCurrency(current)}
                            </span>
                            <span
                              className={cn(
                                "flex items-center gap-0.5 text-xs font-medium",
                                diff >= 0 ? "text-emerald-600" : "text-destructive"
                              )}
                            >
                              {diff >= 0 ? (
                                <TrendingUp className="size-3" />
                              ) : (
                                <TrendingDown className="size-3" />
                              )}
                              {diff >= 0 ? "+" : ""}
                              {diffPct.toFixed(1)}%
                            </span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                            <span className="w-20 shrink-0 text-right text-[10px] text-muted-foreground">
                              Ce mois
                            </span>
                            <ProgressBar value={Math.abs(current)} max={max} color={color} />
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="w-20 shrink-0 text-right text-[10px] text-muted-foreground">
                              Mois préc.
                            </span>
                            <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                              <div
                                className="h-full rounded-full opacity-35 transition-all duration-300"
                                style={{
                                  width: `${(Math.abs(prev) / max) * 100}%`,
                                  backgroundColor: color,
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })
                ) : (
                  <EmptyState icon={<BarChart3 />} label="Données comparatives non disponibles" />
                )}
              </CardContent>
            </Card>

            {/* Overdue invoices */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-base">Factures en retard</CardTitle>
                <CardDescription>
                  {invoices.length} facture{invoices.length !== 1 ? "s" : ""} en retard de paiement
                </CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                {invoices.length === 0 ? (
                  <EmptyState icon={<CheckCircle2 />} label="Aucune facture en retard" />
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>N°</TableHead>
                        <TableHead>Client</TableHead>
                        <TableHead className="text-right">Montant</TableHead>
                        <TableHead>Retard</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {invoices.map((inv) => (
                        <TableRow key={inv.id}>
                          <TableCell className="font-mono text-xs">
                            {inv.invoice_number}
                          </TableCell>
                          <TableCell className="text-sm">{inv.client_name ?? "—"}</TableCell>
                          <TableCell className="text-right text-sm font-semibold tabular-nums">
                            {formatCurrency(inv.total_amount)}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant={inv.days_overdue > 30 ? "destructive" : "warning"}
                            >
                              J+{inv.days_overdue}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ── Tab : Alertes ── */}
        <TabsContent value="alertes" className="mt-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {[
              {
                icon: <FileWarning />,
                color: "text-destructive",
                label: "Documents critiques",
                value: ov.documents_critical ?? 0,
                sub: `+ ${ov.documents_expiring_30d ?? 0} expirent dans 30j`,
                danger: (ov.documents_critical ?? 0) > 0,
              },
              {
                icon: <Car />,
                color: "text-amber-600",
                label: "CT dans 30 jours",
                value: ov.vehicles_ct_30d ?? 0,
                sub: `${ov.vehicles_ct_60d ?? 0} dans 60 jours`,
                danger: false,
              },
              {
                icon: <AlertCircle />,
                color: "text-amber-600",
                label: "Assurances dans 30j",
                value: ov.vehicles_ins_30d ?? 0,
                sub: `${ov.vehicles_ins_60d ?? 0} dans 60 jours`,
                danger: false,
              },
              {
                icon: <Users />,
                color: "text-muted-foreground",
                label: "Absences en cours",
                value: ov.absences_active ?? 0,
                sub: "",
                danger: false,
              },
              {
                icon: <AlertTriangle />,
                color: "text-destructive",
                label: "Incidents ouverts",
                value: ov.incidents_open ?? 0,
                sub: "à traiter",
                danger: (ov.incidents_open ?? 0) > 0,
              },
              {
                icon: <Activity />,
                color: "text-amber-600",
                label: "Tâches haute priorité",
                value: ov.tasks_open_high ?? 0,
                sub: "ouvertes",
                danger: false,
              },
            ].map(({ icon, color, label, value, sub, danger }) => (
              <Card
                key={label}
                className={cn("p-5", danger && "ring-2 ring-destructive/25")}
              >
                <div className={cn("mb-3 [&_svg]:size-5", color)}>{icon}</div>
                <div
                  className={cn(
                    "text-4xl font-bold tabular-nums tracking-tight",
                    danger ? "text-destructive" : ""
                  )}
                >
                  {value}
                </div>
                <p className="mt-1 text-sm font-medium">{label}</p>
                {sub && <p className="mt-0.5 text-xs text-muted-foreground">{sub}</p>}
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* ── Company Cards ── */}
      <div className="flex flex-col gap-4">
        <h2 className="text-base font-semibold text-foreground">Sociétés du groupe</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {companies.map((company) => {
            const solde = company.revenue - company.expenses;
            const maxFinance = Math.max(company.revenue, company.expenses, 1);
            return (
              <Card
                key={company.id}
                className="relative flex flex-col overflow-hidden"
              >
                {/* Top accent bar */}
                <div
                  className="absolute left-0 right-0 top-0 h-1"
                  style={{ backgroundColor: company.color }}
                />

                <CardHeader className="pb-3 pt-5">
                  <div className="flex items-center gap-2.5">
                    <span
                      className="h-3 w-3 shrink-0 rounded-full ring-2 ring-background"
                      style={{ backgroundColor: company.color }}
                    />
                    <CardTitle className="text-base leading-snug">{company.name}</CardTitle>
                  </div>
                  {company.notes && (
                    <CardDescription className="mt-0.5 text-xs">{company.notes}</CardDescription>
                  )}
                </CardHeader>

                <CardContent className="flex flex-col gap-4 pb-4">
                  {/* Metrics 2×2 */}
                  <div className="grid grid-cols-2 gap-x-4 gap-y-3">
                    {[
                      { label: "Sites", value: company.site_count },
                      { label: "Véhicules", value: company.vehicles },
                      { label: "Salariés", value: company.employees },
                      { label: "Tournées/mois", value: company.monthly_routes },
                    ].map(({ label, value }) => (
                      <div key={label} className="flex flex-col gap-0.5">
                        <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                          {label}
                        </span>
                        <span className="text-xl font-semibold tabular-nums">
                          {formatNumber(value)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Finance mini bars */}
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Recettes</span>
                      <span className="font-medium tabular-nums">
                        {formatCurrency(company.revenue)}
                      </span>
                    </div>
                    <ProgressBar value={company.revenue} max={maxFinance} color="#10b981" />

                    <div className="flex items-center justify-between text-xs">
                      <span className="text-muted-foreground">Dépenses</span>
                      <span className="font-medium tabular-nums">
                        {formatCurrency(company.expenses)}
                      </span>
                    </div>
                    <ProgressBar value={company.expenses} max={maxFinance} color="#f59e0b" />

                    <div className="mt-1 flex items-center justify-between text-sm">
                      <span className="font-medium">Solde net</span>
                      <span
                        className={cn(
                          "font-semibold tabular-nums",
                          solde >= 0 ? "text-emerald-600" : "text-destructive"
                        )}
                      >
                        {formatCurrency(solde)}
                      </span>
                    </div>
                  </div>
                </CardContent>

                {/* Link */}
                <div className="mt-auto border-t">
                  <Link
                    href={`/societes/${company.id}`}
                    className="flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted/50 hover:text-foreground"
                  >
                    Tableau de bord
                    <ArrowRight className="size-4" />
                  </Link>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </main>
  );
}
