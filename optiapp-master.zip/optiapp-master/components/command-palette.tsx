"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Building2, MapPin, Package, Search, Truck, UsersRound } from "lucide-react";
import { getSupabaseBrowser } from "@/lib/supabase-browser";

type SearchHit = {
  kind: "company" | "employee" | "vehicle" | "mission" | "site";
  id: string;
  title: string;
  subtitle: string | null;
  href: string;
  rank: number | null;
};

const ICONS = {
  company: Building2,
  employee: UsersRound,
  vehicle: Truck,
  mission: Package,
  site: MapPin,
} as const;

const LABELS = {
  company: "Société",
  employee: "Salarié",
  vehicle: "Véhicule",
  mission: "Mission",
  site: "Site",
} as const;

export function CommandPalette() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [hits, setHits] = useState<SearchHit[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ⌘K / Ctrl+K toggle + ouverture via barre de recherche de la topbar
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      } else if (e.key === "Escape" && open) {
        setOpen(false);
      }
    };
    const onOpenEvent = () => setOpen(true);
    window.addEventListener("keydown", onKey);
    window.addEventListener("open-command-palette", onOpenEvent);
    return () => {
      window.removeEventListener("keydown", onKey);
      window.removeEventListener("open-command-palette", onOpenEvent);
    };
  }, [open]);

  useEffect(() => {
    if (open) {
      setTimeout(() => inputRef.current?.focus(), 30);
    } else {
      setQ("");
      setHits([]);
      setActiveIdx(0);
    }
  }, [open]);

  // Debounced search
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    const trimmed = q.trim();
    if (trimmed.length < 2) {
      setHits([]);
      return;
    }
    debounceRef.current = setTimeout(async () => {
      setLoading(true);
      try {
        const sb = getSupabaseBrowser();
        const { data, error } = await sb.rpc("global_search", { p_q: trimmed, p_limit: 20 });
        if (!error && Array.isArray(data)) {
          setHits(data as SearchHit[]);
          setActiveIdx(0);
        }
      } finally {
        setLoading(false);
      }
    }, 180);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [q]);

  const go = useCallback(
    (hit: SearchHit) => {
      setOpen(false);
      router.push(hit.href);
    },
    [router],
  );

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIdx((i) => Math.min(i + 1, Math.max(0, hits.length - 1)));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIdx((i) => Math.max(0, i - 1));
    } else if (e.key === "Enter" && hits[activeIdx]) {
      e.preventDefault();
      go(hits[activeIdx]);
    }
  };

  if (!open) return null;

  return (
    <div className="cmdk-overlay" onClick={() => setOpen(false)}>
      <div className="cmdk-panel" role="dialog" aria-label="Recherche globale" onClick={(e) => e.stopPropagation()}>
        <div className="cmdk-input-row">
          <Search size={16} aria-hidden="true" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Rechercher sociétés, salariés, véhicules, missions…"
            autoComplete="off"
            spellCheck={false}
          />
          <kbd>Esc</kbd>
        </div>

        <div className="cmdk-results">
          {q.trim().length < 2 && (
            <div className="cmdk-empty">Tapez au moins 2 caractères pour rechercher.</div>
          )}
          {q.trim().length >= 2 && loading && <div className="cmdk-empty">Recherche…</div>}
          {q.trim().length >= 2 && !loading && hits.length === 0 && (
            <div className="cmdk-empty">Aucun résultat pour « {q.trim()} ».</div>
          )}
          {hits.map((hit, idx) => {
            const Icon = ICONS[hit.kind];
            return (
              <button
                key={`${hit.kind}-${hit.id}`}
                type="button"
                className={idx === activeIdx ? "cmdk-row active" : "cmdk-row"}
                onMouseEnter={() => setActiveIdx(idx)}
                onClick={() => go(hit)}
              >
                <Icon size={16} aria-hidden="true" />
                <span className="cmdk-row-main">
                  <strong>{hit.title}</strong>
                  {hit.subtitle && <small>{hit.subtitle}</small>}
                </span>
                <span className="cmdk-row-kind">{LABELS[hit.kind]}</span>
              </button>
            );
          })}
        </div>

        <div className="cmdk-footer">
          <span><kbd>↑</kbd><kbd>↓</kbd> Naviguer</span>
          <span><kbd>↵</kbd> Ouvrir</span>
          <span><kbd>⌘</kbd><kbd>K</kbd> Fermer</span>
        </div>
      </div>
    </div>
  );
}
