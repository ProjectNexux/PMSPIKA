"use client";

/**
 * components/user-scope.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Met à disposition côté client l'utilisateur courant + ses rôles/affiliations.
 * Peuplé par le root layout (Server Component) qui appelle getCurrentUser().
 */

import { createContext, useContext, type ReactNode } from "react";

export type AppRole =
  | "super_admin"
  | "gerant_groupe"
  | "gerant_societe"
  | "chef_site"
  | "chauffeur"
  | "client";

export type ScopedUser = {
  id: string;
  email: string | null;
  full_name: string;
  role: AppRole;
  company_id: string | null;
  site_id: string | null;
  company_name: string | null;
  is_admin: boolean;
  is_super_admin: boolean;
};

const UserScopeContext = createContext<ScopedUser | null>(null);

export function UserScopeProvider({
  user,
  children,
}: {
  user: ScopedUser | null;
  children: ReactNode;
}) {
  return (
    <UserScopeContext.Provider value={user}>{children}</UserScopeContext.Provider>
  );
}

export function useScopedUser(): ScopedUser | null {
  return useContext(UserScopeContext);
}
