"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Bell,
  CheckCheck,
  CircleAlert,
  CircleCheck,
  Info,
  TriangleAlert,
} from "lucide-react";
import { getSupabaseBrowser } from "@/lib/supabase-browser";
import { useScopedUser } from "@/components/user-scope";

type Notification = {
  id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  link: string | null;
  read: boolean;
  created_at: string;
};

const TYPE_ICON = {
  info: Info,
  success: CircleCheck,
  warning: TriangleAlert,
  error: CircleAlert,
} as const;

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `il y a ${h} h`;
  const d = Math.floor(h / 24);
  return `il y a ${d} j`;
}

export function NotificationBell() {
  const router = useRouter();
  const user = useScopedUser();
  const userId = user?.id;
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(false);
  const rootRef = useRef<HTMLDivElement>(null);

  const unread = items.filter((n) => !n.read).length;

  const load = useCallback(async () => {
    if (!userId) return;
    setLoading(true);
    try {
      const sb = getSupabaseBrowser();
      const { data } = await sb
        .from("notifications")
        .select("id, title, message, type, link, read, created_at")
        .order("created_at", { ascending: false })
        .limit(20);
      if (Array.isArray(data)) setItems(data as Notification[]);
    } finally {
      setLoading(false);
    }
  }, [userId]);

  // Chargement initial + rafraîchissement périodique
  useEffect(() => {
    if (!userId) return;
    load();
    const interval = setInterval(load, 60_000);
    return () => clearInterval(interval);
  }, [userId, load]);

  // Realtime : nouvelles notifications poussées
  useEffect(() => {
    if (!userId) return;
    const sb = getSupabaseBrowser();
    const channel = sb
      .channel(`notifications:${userId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` },
        () => load(),
      )
      .subscribe();
    return () => {
      sb.removeChannel(channel);
    };
  }, [userId, load]);

  // Fermeture au clic extérieur
  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", onClick);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onClick);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const markAllRead = useCallback(async () => {
    const unreadIds = items.filter((n) => !n.read).map((n) => n.id);
    if (unreadIds.length === 0) return;
    setItems((prev) => prev.map((n) => ({ ...n, read: true })));
    const sb = getSupabaseBrowser();
    await sb.from("notifications").update({ read: true }).in("id", unreadIds);
  }, [items]);

  const onSelect = useCallback(
    async (n: Notification) => {
      if (!n.read) {
        setItems((prev) => prev.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
        const sb = getSupabaseBrowser();
        await sb.from("notifications").update({ read: true }).eq("id", n.id);
      }
      if (n.link) {
        setOpen(false);
        router.push(n.link);
      }
    },
    [router],
  );

  if (!userId) return null;

  return (
    <div className="notif" ref={rootRef}>
      <button
        type="button"
        className="notif-trigger"
        aria-label={`Notifications${unread ? ` (${unread} non lues)` : ""}`}
        aria-expanded={open}
        onClick={() => setOpen((v) => !v)}
      >
        <Bell size={18} aria-hidden="true" />
        {unread > 0 && <span className="notif-dot">{unread > 9 ? "9+" : unread}</span>}
      </button>

      {open && (
        <div className="notif-panel" role="dialog" aria-label="Notifications">
          <div className="notif-head">
            <strong>Notifications</strong>
            {unread > 0 && (
              <button type="button" className="notif-markall" onClick={markAllRead}>
                <CheckCheck size={14} aria-hidden="true" />
                Tout marquer comme lu
              </button>
            )}
          </div>

          <div className="notif-list">
            {loading && items.length === 0 && <div className="notif-empty">Chargement…</div>}
            {!loading && items.length === 0 && (
              <div className="notif-empty">Aucune notification.</div>
            )}
            {items.map((n) => {
              const Icon = TYPE_ICON[n.type] ?? Info;
              return (
                <button
                  key={n.id}
                  type="button"
                  className={n.read ? "notif-row" : "notif-row unread"}
                  onClick={() => onSelect(n)}
                >
                  <span className={`notif-ico notif-ico-${n.type}`}>
                    <Icon size={16} aria-hidden="true" />
                  </span>
                  <span className="notif-row-main">
                    <strong>{n.title}</strong>
                    {n.message && <small>{n.message}</small>}
                    <span className="notif-time">{timeAgo(n.created_at)}</span>
                  </span>
                  {!n.read && <span className="notif-unread-dot" aria-hidden="true" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
