﻿"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { type ReactNode, useEffect, useState } from "react";
import {
  ClipboardList,
  FileCheck2,
  FileText,
  Handshake,
  Landmark,
  LayoutDashboard,
  LogOut,
  MapPin,
  Menu,
  Package,
  ReceiptText,
  Route,
  ScrollText,
  Search,
  Settings,
  ShieldCheck,
  Truck,
  UsersRound,
  X,
} from "lucide-react";
import { useScopedUser } from "@/components/user-scope";
import { NotificationBell } from "@/components/notification-bell";

const navItems = [
  { href: "/",               label: "Tableau de bord", icon: LayoutDashboard },
  { href: "/tournees",       label: "Tournees",         icon: Route },
  { href: "/missions",       label: "Missions",         icon: Package },
  { href: "/vehicules",      label: "Flotte",           icon: Truck },
  { href: "/sites",          label: "Sites",            icon: MapPin },
  { href: "/social",         label: "Social",           icon: UsersRound },
  { href: "/documents",      label: "Documents",        icon: FileCheck2 },
  { href: "/facturation",    label: "Facturation",      icon: FileText },
  { href: "/tresorerie",     label: "Trésorerie",       icon: Landmark },
  { href: "/comptabilite",   label: "Comptabilite",     icon: ReceiptText },
  { href: "/sous-traitance", label: "Sous-traitance",   icon: Handshake },
  { href: "/pilotage",       label: "Pilotage",         icon: ClipboardList },
  { href: "/parametres",     label: "Parametres",       icon: Settings },
  { href: "/audit",          label: "Audit log",        icon: ScrollText },
];

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const user = useScopedUser();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [pathname]);

  if (
    pathname === "/login" ||
    pathname.startsWith("/login/") ||
    pathname.startsWith("/auth/") ||
    pathname === "/suivi" ||
    pathname.startsWith("/suivi/") ||
    pathname === "/chauffeur" ||
    pathname.startsWith("/chauffeur/")
  ) {
    return <>{children}</>;
  }

  return (
    <div className="app-shell">
      <div
        className={`mobile-nav-backdrop ${mobileMenuOpen ? "open" : ""}`}
        onClick={() => setMobileMenuOpen(false)}
        aria-hidden="true"
      />

      <aside className={`sidebar ${mobileMenuOpen ? "sidebar-open" : ""}`}>
        <div className="brand">
          <img src="/pika-logo.svg" alt="Pika Transport" className="brand-mark" />
          <small>{roleBadge(user?.role)}</small>
        </div>
        <button
          type="button"
          className="sidebar-close"
          onClick={() => setMobileMenuOpen(false)}
          aria-label="Fermer le menu"
        >
          <X size={18} aria-hidden="true" />
        </button>

        <nav className="nav-list" aria-label="Navigation principale">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname === item.href || pathname.startsWith(item.href + "/");
            return (
              <Link
                key={item.href}
                href={item.href}
                className={active ? "nav-link active" : "nav-link"}
                onClick={() => setMobileMenuOpen(false)}
              >
                <Icon size={18} aria-hidden="true" />
                <span>{item.label}</span>
              </Link>
            );
          })}

          {(user?.is_admin) && (
            <>
              <div className="nav-separator" aria-hidden="true" />
              <Link
                href="/admin/utilisateurs"
                className={
                  pathname.startsWith("/admin")
                    ? "nav-link nav-link-admin active"
                    : "nav-link nav-link-admin"
                }
                onClick={() => setMobileMenuOpen(false)}
              >
                <ShieldCheck size={18} aria-hidden="true" />
                <span>Utilisateurs</span>
              </Link>
            </>
          )}
        </nav>

        {user && (
          <form action="/auth/signout" method="post" className="sidebar-signout-form">
            <button
              type="submit"
              className="nav-link sidebar-signout"
              onClick={() => setMobileMenuOpen(false)}
            >
              <LogOut size={18} aria-hidden="true" />
              <span>Deconnexion</span>
            </button>
          </form>
        )}
      </aside>

      <div className="workspace">
        <header className="topbar">
          <div className="topbar-left">
            <button
              type="button"
              className="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen((value) => !value)}
              aria-label={mobileMenuOpen ? "Fermer le menu" : "Ouvrir le menu"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X size={18} aria-hidden="true" /> : <Menu size={18} aria-hidden="true" />}
            </button>
            <strong>{user?.full_name || "PIKA TRANSPORT"}</strong>
          </div>

          <div className="topbar-center">
            <button
              type="button"
              className="topbar-search"
              onClick={() => window.dispatchEvent(new Event("open-command-palette"))}
              aria-label="Recherche globale"
            >
              <Search size={16} aria-hidden="true" />
              <span>Rechercher sociétés, salariés, véhicules, missions…</span>
              <span className="topbar-search-kbd">
                <kbd>Cmd</kbd>
                <kbd>K</kbd>
              </span>
            </button>
          </div>

          <div className="topbar-right">
            <NotificationBell />
            <span className="topbar-badge">{roleBadge(user?.role)}</span>
          </div>
        </header>
        {children}
      </div>
    </div>
  );
}

function roleBadge(role: string | undefined): string {
  switch (role) {
    case "super_admin":     return "Super admin";
    case "gerant_groupe":   return "Gerant du groupe";
    case "gerant_societe":  return "Gerant";
    case "chef_site":       return "Chef de site";
    case "chauffeur":       return "Chauffeur";
    case "client":          return "Client";
    default:                return "Utilisateur";
  }
}