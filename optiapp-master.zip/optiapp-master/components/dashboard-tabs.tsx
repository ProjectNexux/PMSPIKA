"use client";

import { useState, type ReactNode } from "react";

export type DashboardTab = {
  key: string;
  label: string;
  /** Optional count badge displayed inside the pill. */
  count?: number;
  /** If true, the badge gets the "alert" tone (red). */
  alert?: boolean;
  content: ReactNode;
};

export function DashboardTabs({
  tabs,
  initialKey,
}: {
  tabs: DashboardTab[];
  initialKey?: string;
}) {
  const [active, setActive] = useState<string>(initialKey ?? tabs[0]?.key ?? "");
  const current = tabs.find((t) => t.key === active) ?? tabs[0];

  return (
    <>
      <nav className="dashboard-tabs" role="tablist" aria-label="Sections du tableau de bord">
        {tabs.map((t) => {
          const isActive = t.key === active;
          return (
            <button
              key={t.key}
              role="tab"
              aria-selected={isActive}
              aria-controls={`dashboard-panel-${t.key}`}
              id={`dashboard-tab-${t.key}`}
              tabIndex={isActive ? 0 : -1}
              className={`dashboard-tab${isActive ? " active" : ""}`}
              onClick={() => setActive(t.key)}
              type="button"
            >
              <span>{t.label}</span>
              {typeof t.count === "number" ? (
                <span className={`dashboard-tab-count${t.alert ? " alert" : ""}`}>{t.count}</span>
              ) : null}
            </button>
          );
        })}
      </nav>
      <div
        role="tabpanel"
        id={`dashboard-panel-${current?.key}`}
        aria-labelledby={`dashboard-tab-${current?.key}`}
        className="dashboard-panel"
      >
        {current?.content}
      </div>
    </>
  );
}
