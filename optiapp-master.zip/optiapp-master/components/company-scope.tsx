"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type CompanyInfo = { id: string; name: string; color: string } | null;

const CompanyScopeContext = createContext<{
  company: CompanyInfo;
  setCompany: (c: CompanyInfo) => void;
}>({ company: null, setCompany: () => {} });

export function CompanyScopeProvider({ children }: { children: ReactNode }) {
  const [company, setCompany] = useState<CompanyInfo>(null);
  return (
    <CompanyScopeContext.Provider value={{ company, setCompany }}>
      {children}
    </CompanyScopeContext.Provider>
  );
}

/**
 * Rendered inside the company layout (server component can call this via a child
 * client component). On mount, pushes company info into the shared context so the
 * sidebar can switch to company-mode nav. Clears on unmount (navigating away).
 */
export function CompanyScopeInitializer({
  id,
  name,
  color,
}: {
  id: string;
  name: string;
  color: string;
}) {
  const { setCompany } = useContext(CompanyScopeContext);

  useEffect(() => {
    setCompany({ id, name, color });
    return () => setCompany(null);
  }, [id, name, color, setCompany]);

  return null;
}

export function useCompanyScope(): CompanyInfo {
  return useContext(CompanyScopeContext).company;
}
