import Link from "next/link";
import { Fragment } from "react";
import { ChevronLeft, ChevronRight, Download, FileText, Lock, Pencil, RefreshCw, Save, Unlock, Wand2, X, Zap } from "lucide-react";
import {
  recalculatePayrollPeriod,
  setPayrollPeriodStatus,
  updateEmployeePay,
  upsertPayrollVariable,
} from "@/app/actions";
import { StatusPill } from "@/components/status-pill";
import { formatCurrency, formatNumber } from "@/lib/format";
import {
  PAYROLL_DEFAULTS,
  computePayroll,
  formatPeriod,
  shiftPeriod,
  type PayrollInputs,
} from "@/lib/payroll";
import type { DriverOption, PrePaieRow } from "@/lib/queries";

type Props = {
  rows: PrePaieRow[];
  period: string;
  basePath: string;          // ex: "/social" ou "/societes/abc/social"
  exportPath: string;        // route handler CSV : "/social/pre-paie/export"
  bulletinPath: string;      // page bulletin : "/social/pre-paie/bulletin"
  companyId?: string;        // scope société
  editEmployeeId?: string;   // ligne en édition variables paie
  editBaseId?: string;       // ligne en édition fiche paie (socle)
  drivers?: DriverOption[];  // chauffeurs TMS disponibles
  hideToolbar?: boolean;     // masque la barre interne (période/actions remontées ailleurs)
  hideTitle?: boolean;       // masque le titre interne du panel
  extraQueryParams?: Record<string, string>; // params à conserver dans les liens internes (ex: view)
};

function n(v: number | null | undefined, digits = 2) {
  return (Number(v) || 0).toFixed(digits);
}

export function PrePaieSection({
  rows,
  period,
  basePath,
  exportPath,
  bulletinPath,
  companyId,
  editEmployeeId,
  editBaseId,
  drivers = [],
  hideToolbar = false,
  hideTitle = false,
  extraQueryParams,
}: Props) {
  const prevPeriod = shiftPeriod(period, -1);
  const nextPeriod = shiftPeriod(period, 1);

  // Calcul de chaque ligne
  const enriched = rows.map((row) => {
    const inputs: PayrollInputs = {
      pay_mode: row.pay_mode ?? "mensualise",
      monthly_gross_salary: row.monthly_gross_salary,
      hourly_rate: row.hourly_rate,
      contract_hours: row.contract_hours,
      meal_allowance_daily: row.meal_allowance_daily ?? 0,
      overtime_hours: row.overtime_hours ?? 0,
      bonus_amount: row.bonus_amount ?? 0,
      deductions: row.deductions ?? 0,
      worked_days: row.worked_days ?? 0,
      meal_allowance_amount: row.meal_allowance_amount,
      km_allowance: row.km_allowance ?? 0,
      unpaid_absence_hours: row.unpaid_absence_hours ?? 0,
    };
    return { row, comp: computePayroll(inputs) };
  });

  const totals = enriched.reduce(
    (acc, { comp }) => {
      acc.gross += comp.grossTaxable;
      acc.net += comp.netPayable;
      acc.employerCost += comp.totalEmployerCost;
      acc.overtime += comp.overtimePay;
      acc.indemn += comp.mealAllowance + comp.kmAllowance;
      return acc;
    },
    { gross: 0, net: 0, employerCost: 0, overtime: 0, indemn: 0 }
  );

  const readyCount = enriched.filter(({ row }) => row.variable_status === "Pret paie").length;
  const periodLocked = enriched.length > 0 && readyCount === enriched.length;

  const buildHref = (params: Record<string, string | undefined>) => {
    const search = new URLSearchParams();
    search.set("period", period);
    if (extraQueryParams) {
      Object.entries(extraQueryParams).forEach(([k, v]) => {
        if (v) search.set(k, v);
      });
    }
    Object.entries(params).forEach(([k, v]) => {
      if (v) search.set(k, v);
    });
    return `${basePath}?${search.toString()}`;
  };

  return (
    <section className="panel prepaie-panel">
      {!hideToolbar || !hideTitle ? (
      <div className="panel-header prepaie-header">
        <div>
          {!hideTitle ? <h2>Pré-paie — {formatPeriod(period)}</h2> : null}
          <p>
            {enriched.length} salarié{enriched.length > 1 ? "s" : ""} •{" "}
            {readyCount} validé{readyCount > 1 ? "s" : ""}
            {" • "}Estimations basées sur charges salariales {Math.round(PAYROLL_DEFAULTS.employeeChargesRate * 100)}% / patronales {Math.round(PAYROLL_DEFAULTS.employerChargesRate * 100)}%
          </p>
        </div>
        {!hideToolbar ? (
        <div className="prepaie-toolbar">
          <Link className="button secondary" href={buildHref({ period: prevPeriod })} aria-label="Mois précédent">
            <ChevronLeft size={15} />
            {formatPeriod(prevPeriod)}
          </Link>
          <Link className="button secondary" href={buildHref({ period: nextPeriod })} aria-label="Mois suivant">
            {formatPeriod(nextPeriod)}
            <ChevronRight size={15} />
          </Link>
          <a
            className="button secondary"
            href={`${exportPath}?period=${period}${companyId ? `&company=${companyId}` : ""}`}
            title="Télécharger CSV pré-paie"
          >
            <Download size={15} />
            Export CSV
          </a>
          <form action={recalculatePayrollPeriod}>
            <input type="hidden" name="period" value={period} />
            <input type="hidden" name="redirect_to" value={buildHref({})} />
            {companyId ? <input type="hidden" name="company_id" value={companyId} /> : null}
            <button type="submit" className="button secondary" title="Recharger heures, jours, primes depuis le TMS (les lignes 'Prêt paie' ne sont pas touchées)">
              <RefreshCw size={15} />
              Recalculer TMS
            </button>
          </form>
          <form action={setPayrollPeriodStatus}>
            <input type="hidden" name="period" value={period} />
            <input type="hidden" name="redirect_to" value={buildHref({})} />
            {companyId ? <input type="hidden" name="company_id" value={companyId} /> : null}
            <input type="hidden" name="status" value={periodLocked ? "A valider" : "Pret paie"} />
            <button type="submit" className="button" title={periodLocked ? "Déverrouiller la période" : "Valider toutes les lignes en Prêt paie"}>
              {periodLocked ? <Unlock size={15} /> : <Lock size={15} />}
              {periodLocked ? "Déverrouiller" : "Valider la période"}
            </button>
          </form>
        </div>
        ) : null}
      </div>
      ) : null}

      <div className="prepaie-kpis">
        <KpiTile label="Brut soumis" value={formatCurrency(totals.gross)} />
        <KpiTile label="Heures supp." value={formatCurrency(totals.overtime)} />
        <KpiTile label="Indemnités" value={formatCurrency(totals.indemn)} />
        <KpiTile label="Net à verser" value={formatCurrency(totals.net)} tone="good" />
        <KpiTile label="Coût employeur" value={formatCurrency(totals.employerCost)} tone="warn" />
      </div>

      <div className="table-wrap prepaie-table-wrap">
        <table className="data-table prepaie-table">
          <thead>
            <tr>
              <th>Salarié</th>
              <th>Site</th>
              <th>Contrat</th>
              <th className="num">Base brute</th>
              <th className="num">HS</th>
              <th className="num">Primes</th>
              <th className="num">Indemn.</th>
              <th className="num">Retenue</th>
              <th className="num">Brut soumis</th>
              <th className="num">Net est.</th>
              <th className="num">Coût empl.</th>
              <th>État</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {enriched.map(({ row, comp }) => {
              const isEditingVar = editEmployeeId === row.employee_id;
              const isEditingBase = editBaseId === row.employee_id;
              const baseMissing =
                (row.pay_mode === "mensualise" && !row.monthly_gross_salary) ||
                (row.pay_mode === "horaire" && !row.hourly_rate);

              return (
                <Fragment key={row.employee_id}>
                  <tr className={isEditingVar || isEditingBase ? "row-editing" : undefined}>
                    <td className="strong-cell">
                      {row.first_name} {row.last_name}
                      <div className="muted prepaie-sub">
                        {row.role} · {row.pay_mode === "horaire"
                          ? `${formatCurrency(row.hourly_rate)} /h`
                          : `${formatCurrency(row.monthly_gross_salary)} /mois`}
                      </div>
                      {row.profile_label ? (
                        <div className="prepaie-link">
                          <Zap size={11} /> TMS · {row.profile_label}
                          {row.tournees_done > 0 ? ` · ${row.tournees_done} tournée${row.tournees_done > 1 ? "s" : ""} · ${formatNumber(Math.round(row.tms_hours))} h`: ""}
                        </div>
                      ) : (
                        <div className="prepaie-unlinked">Aucun chauffeur TMS lié</div>
                      )}
                      {baseMissing ? (
                        <div className="prepaie-warn">Socle de paie manquant</div>
                      ) : null}
                      {row.auto_filled_at ? (
                        <div className="prepaie-auto" title={`Auto-alimenté le ${new Date(row.auto_filled_at).toLocaleString("fr-FR")}`}>
                          <Wand2 size={11} /> Auto-alimenté
                        </div>
                      ) : null}
                    </td>
                    <td>{row.site_name}</td>
                    <td>{row.contract_type}</td>
                    <td className="num">{formatCurrency(comp.baseSalary - comp.absenceDeduction)}</td>
                    <td className="num">
                      {row.overtime_hours ? `${formatNumber(row.overtime_hours)} h` : "—"}
                      {comp.overtimePay > 0 ? (
                        <div className="muted prepaie-sub">{formatCurrency(comp.overtimePay)}</div>
                      ) : null}
                    </td>
                    <td className="num">{row.bonus_amount ? formatCurrency(row.bonus_amount) : "—"}</td>
                    <td className="num">
                      {comp.mealAllowance + comp.kmAllowance > 0
                        ? formatCurrency(comp.mealAllowance + comp.kmAllowance)
                        : "—"}
                    </td>
                    <td className="num">{row.deductions ? formatCurrency(row.deductions) : "—"}</td>
                    <td className="num strong-cell">{formatCurrency(comp.grossTaxable)}</td>
                    <td className="num strong-cell">{formatCurrency(comp.netPayable)}</td>
                    <td className="num">{formatCurrency(comp.totalEmployerCost)}</td>
                    <td><StatusPill value={row.variable_status} /></td>
                    <td>
                      <div className="row-actions">
                        <Link
                          className="btn-icon"
                          href={buildHref({ paie: row.employee_id })}
                          title="Éditer variables du mois"
                        >
                          <Pencil size={14} />
                        </Link>
                        <Link
                          className="btn-icon"
                          href={buildHref({ socle: row.employee_id })}
                          title="Éditer le socle de rémunération"
                        >
                          <FileText size={14} />
                        </Link>
                        <a
                          className="btn-icon"
                          href={`${bulletinPath}/${row.employee_id}?period=${period}&back=${encodeURIComponent(basePath)}`}
                          title="Bulletin imprimable"
                          target="_blank"
                          rel="noopener"
                        >
                          <Download size={14} />
                        </a>
                      </div>
                    </td>
                  </tr>

                  {isEditingVar ? (
                    <tr className="prepaie-edit-row">
                      <td colSpan={13}>
                        <form action={upsertPayrollVariable} className="prepaie-edit-form">
                          <input type="hidden" name="employee_id" value={row.employee_id} />
                          <input type="hidden" name="period" value={period} />
                          {row.variable_id ? <input type="hidden" name="variable_id" value={row.variable_id} /> : null}
                          <input type="hidden" name="redirect_to" value={buildHref({})} />

                          <div className="prepaie-edit-grid">
                            <Field label="Heures supp." name="overtime_hours" step="0.25" defaultValue={row.overtime_hours} />
                            <Field label="Prime (€)" name="bonus_amount" step="1" defaultValue={row.bonus_amount} />
                            <Field label="Retenue (€)" name="deductions" step="1" defaultValue={row.deductions} />
                            <Field label="Jours travaillés" name="worked_days" step="0.5" defaultValue={row.worked_days} />
                            <Field
                              label={`Indemnité repas (€) — défaut ${n(row.worked_days * (row.meal_allowance_daily ?? 0), 2)}`}
                              name="meal_allowance_amount"
                              step="0.01"
                              defaultValue={row.meal_allowance_amount ?? ""}
                              placeholder="Auto si vide"
                            />
                            <Field label="Frais km (€)" name="km_allowance" step="0.01" defaultValue={row.km_allowance} />
                            <Field
                              label={`Heures absence non rémun. (info absences mois : ${row.unpaid_absence_days_in_period} j non rému., ${row.absence_days_in_period} j total)`}
                              name="unpaid_absence_hours"
                              step="0.25"
                              defaultValue={row.unpaid_absence_hours}
                            />
                            <div className="field">
                              <label>État</label>
                              <select name="status" defaultValue={row.variable_status}>
                                <option value="A valider">À valider</option>
                                <option value="Pret paie">Prêt paie</option>
                              </select>
                            </div>
                            <div className="field full">
                              <label>Notes</label>
                              <textarea name="notes" defaultValue={row.notes ?? ""} rows={2} />
                            </div>
                            <div className="full form-actions">
                              <button type="submit" className="button">
                                <Save size={15} /> Enregistrer
                              </button>
                              <Link href={buildHref({})} className="button secondary">
                                <X size={15} /> Annuler
                              </Link>
                            </div>
                          </div>
                        </form>
                      </td>
                    </tr>
                  ) : null}

                  {isEditingBase ? (
                    <tr className="prepaie-edit-row">
                      <td colSpan={13}>
                        <form action={updateEmployeePay} className="prepaie-edit-form">
                          <input type="hidden" name="id" value={row.employee_id} />
                          <input type="hidden" name="redirect_to" value={buildHref({})} />
                          <div className="prepaie-edit-grid">
                            <div className="field">
                              <label>Mode de paie</label>
                              <select name="pay_mode" defaultValue={row.pay_mode}>
                                <option value="mensualise">Mensualisé</option>
                                <option value="horaire">Horaire</option>
                              </select>
                            </div>
                            <Field label="Salaire mensuel brut (€)" name="monthly_gross_salary" step="0.01" defaultValue={row.monthly_gross_salary ?? ""} />
                            <Field label="Taux horaire (€)" name="hourly_rate" step="0.01" defaultValue={row.hourly_rate ?? ""} />
                            <Field label="Heures contractuelles" name="contract_hours" step="0.01" defaultValue={row.contract_hours ?? 151.67} />
                            <Field label="Indemnité repas / jour (€)" name="meal_allowance_daily" step="0.01" defaultValue={row.meal_allowance_daily ?? 0} />
                            <Field label="Prime par tournée (€)" name="tournee_rate" step="0.01" defaultValue={row.tournee_rate ?? 0} />
                            <div className="field">
                              <label>Compte chauffeur TMS</label>
                              <select name="profile_id" defaultValue={row.profile_id ?? ""}>
                                <option value="">— Non lié —</option>
                                {drivers.map((d) => {
                                  const usedElsewhere = d.linked_employee_id && d.linked_employee_id !== row.employee_id;
                                  return (
                                    <option key={d.id} value={d.id} disabled={!!usedElsewhere}>
                                      {d.label}{usedElsewhere ? " (déjà lié)" : ""}
                                    </option>
                                  );
                                })}
                              </select>
                            </div>
                            <div className="field full">
                              <label>Notes paie</label>
                              <textarea name="pay_notes" defaultValue={row.pay_notes ?? ""} rows={2} />
                            </div>
                            <div className="full form-actions">
                              <button type="submit" className="button">
                                <Save size={15} /> Enregistrer le socle
                              </button>
                              <Link href={buildHref({})} className="button secondary">
                                <X size={15} /> Annuler
                              </Link>
                            </div>
                          </div>
                        </form>
                      </td>
                    </tr>
                  ) : null}
                </Fragment>
              );
            })}

            {enriched.length === 0 ? (
              <tr>
                <td colSpan={13} className="muted" style={{ padding: 24, textAlign: "center" }}>
                  Aucun salarié actif pour cette période.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function Field({
  label,
  name,
  defaultValue,
  step,
  placeholder,
}: {
  label: string;
  name: string;
  defaultValue?: string | number;
  step?: string;
  placeholder?: string;
}) {
  return (
    <div className="field">
      <label htmlFor={name}>{label}</label>
      <input
        id={name}
        name={name}
        type="number"
        step={step ?? "1"}
        defaultValue={defaultValue ?? ""}
        placeholder={placeholder}
      />
    </div>
  );
}

function KpiTile({ label, value, tone }: { label: string; value: string; tone?: "good" | "warn" }) {
  return (
    <div className={`prepaie-kpi ${tone ?? ""}`}>
      <span>{label}</span>
      <strong>{value}</strong>
    </div>
  );
}
