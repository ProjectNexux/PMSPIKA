"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Building2,
  ClipboardList,
  FileCheck2,
  Handshake,
  LayoutDashboard,
  MapPin,
  ReceiptText,
  Settings,
  ShieldCheck,
  Truck,
  UsersRound,
} from "lucide-react";

type Item = {
  href: string;
  label: string;
  icon: React.ComponentType<{ size?: number; "aria-hidden"?: boolean }>;
};

export function CompanySubNav({ companyId }: { companyId: string }) {
  const pathname = usePathname();
  const base = `/societes/${companyId}`;

  const items: Item[] = [
    { href: base, label: "Tableau de bord", icon: LayoutDashboard },
    { href: `${base}/sites`, label: "Sites", icon: MapPin },
    { href: `${base}/social`, label: "Social", icon: UsersRound },
    { href: `${base}/vehicules`, label: "Vehicules", icon: Truck },
    { href: `${base}/documents`, label: "Documents", icon: FileCheck2 },
    { href: `${base}/conformite-loti`, label: "Conformité LOTI", icon: ShieldCheck },
    { href: `${base}/comptabilite`, label: "Comptabilite", icon: ReceiptText },
    { href: `${base}/sous-traitance`, label: "Sous-traitance", icon: Handshake },
    { href: `${base}/pilotage`, label: "Pilotage", icon: ClipboardList },
    { href: `${base}/parametres`, label: "Paramètres", icon: Settings },
  ];

  return (
    <nav className="company-subnav" aria-label="Navigation societe">
      {items.map((item) => {
        const Icon = item.icon;
        const active = item.href === base ? pathname === base : pathname === item.href || pathname.startsWith(item.href + "/");
        return (
          <Link key={item.href} href={item.href} className={active ? "subnav-link active" : "subnav-link"}>
            <Icon size={16} aria-hidden={true} />
            <span>{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

export function CompanyIdentityBar({
  name,
  color,
  legalName,
  notes,
}: {
  name: string;
  color: string;
  legalName?: string | null;
  notes?: string | null;
}) {
  return (
    <div className="company-identity-bar" style={{ borderLeftColor: color }}>
      <span
        className="company-dot"
        style={{ backgroundColor: color, width: 12, height: 12, flexShrink: 0 }}
      />
      <div>
        <strong>{name}</strong>
        {legalName && legalName !== name ? (
          <span className="muted" style={{ marginLeft: 10, fontSize: 13 }}>({legalName})</span>
        ) : null}
        {notes ? (
          <span className="muted" style={{ marginLeft: 12, fontSize: 13 }}>{notes}</span>
        ) : null}
      </div>
      <Building2 size={14} aria-hidden={true} style={{ marginLeft: "auto", color: "var(--muted)" }} />
    </div>
  );
}

export { Building2 as _Building2 };
