import type { ReactNode } from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Sparkline } from "./sparkline";

type Tone = "neutral" | "blue" | "green" | "orange" | "red";

type Trend = {
  value: number;
  label?: string;
  direction?: "up" | "down" | "flat";
};

const accentByTone: Record<Tone, string> = {
  neutral: "bg-slate-500",
  blue: "bg-blue-500",
  green: "bg-emerald-500",
  orange: "bg-amber-500",
  red: "bg-red-500",
};

const iconBgByTone: Record<Tone, string> = {
  neutral: "bg-muted text-muted-foreground",
  blue: "bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-300",
  green: "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300",
  orange: "bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-300",
  red: "bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-300",
};

export function StatCard({
  label,
  value,
  detail,
  tone = "neutral",
  icon,
  trend,
  sparkline,
}: {
  label: string;
  value: string;
  detail?: string;
  tone?: Tone;
  icon?: ReactNode;
  trend?: Trend;
  sparkline?: number[];
}) {
  const dir =
    trend?.direction ??
    (trend ? (trend.value > 0 ? "up" : trend.value < 0 ? "down" : "flat") : undefined);

  const trendColor =
    dir === "up"
      ? "text-emerald-600 dark:text-emerald-400"
      : dir === "down"
      ? "text-red-600 dark:text-red-400"
      : "text-muted-foreground";

  const sparkColor =
    tone === "blue"
      ? "#2563eb"
      : tone === "green"
      ? "#10b981"
      : tone === "orange"
      ? "#d97706"
      : tone === "red"
      ? "#dc2626"
      : "#475569";

  return (
    <Card className={cn("stat-card relative overflow-hidden p-5 flex flex-col gap-3", tone)}>
      <span
        aria-hidden
        className={cn("absolute top-0 left-0 h-full w-1", accentByTone[tone])}
      />
      <header className="stat-card-head flex items-center justify-between gap-2">
        <span className="stat-card-label text-[11px] font-semibold uppercase tracking-[0.12em] text-muted-foreground">
          {label}
        </span>
        {icon ? (
          <span
            className={cn(
              "stat-card-icon flex h-8 w-8 items-center justify-center rounded-md [&>svg]:size-4",
              iconBgByTone[tone]
            )}
            aria-hidden
          >
            {icon}
          </span>
        ) : null}
      </header>
      <strong className="stat-card-value text-3xl font-semibold tracking-tight text-foreground tabular-nums">
        {value}
      </strong>
      <footer className="stat-card-foot mt-auto flex items-end justify-between gap-3">
        <div className="stat-card-meta flex flex-col gap-1">
          {detail ? <small className="text-xs text-muted-foreground">{detail}</small> : null}
          {trend ? (
            <span className={cn("stat-card-trend inline-flex items-center gap-1 text-xs font-medium", trendColor, dir ?? "flat")}>
              <span aria-hidden>{dir === "up" ? "▲" : dir === "down" ? "▼" : "•"}</span>
              {Math.abs(trend.value).toFixed(1)}%
              {trend.label ? (
                <span className="stat-card-trend-label text-muted-foreground font-normal"> {trend.label}</span>
              ) : null}
            </span>
          ) : null}
        </div>
        {sparkline && sparkline.length > 1 ? (
          <span className="stat-card-spark" style={{ color: sparkColor }}>
            <Sparkline data={sparkline} width={86} height={26} fill={`${sparkColor}1f`} />
          </span>
        ) : null}
      </footer>
    </Card>
  );
}
