"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/", label: "Synthèse" },
  { href: "/parametres", label: "Coûts & Salariés" },
  { href: "/tournees", label: "Tournées" },
  { href: "/scenarios", label: "Scénarios" },
  { href: "/analyse", label: "Analyse" },
  { href: "/simulateur", label: "Simulateur" },
];

export default function Navbar() {
  const pathname = usePathname();

  return (
    <nav className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4 max-w-6xl flex items-center justify-between h-14 gap-4">
        <Link href="/" className="flex items-center gap-2 shrink-0">
          <span className="text-lg font-bold text-blue-700">🚛 OptiApp</span>
          <span className="hidden md:inline text-xs text-slate-400 border-l border-slate-200 pl-2">
            Pilotage rentabilité transport
          </span>
        </Link>
        <div className="flex gap-1 overflow-x-auto">
          {links.map(({ href, label }) => {
            const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={`px-3 py-1.5 rounded-md text-sm font-medium whitespace-nowrap transition-colors ${
                  active
                    ? "bg-blue-600 text-white"
                    : "text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                }`}
              >
                {label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
