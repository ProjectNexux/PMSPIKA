import type { CSSProperties } from "react";

type Props = {
  className?: string;
  style?: CSSProperties;
};

export function Skeleton({ className, style }: Props) {
  return <span className={`skeleton ${className ?? ""}`} style={style} aria-hidden="true" />;
}

export function SkeletonText({ width = "100%" }: { width?: string | number }) {
  return <Skeleton style={{ height: "0.9em", width }} />;
}

export function SkeletonStatGrid({ count = 4 }: { count?: number }) {
  return (
    <section className="stat-grid">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="stat-card skeleton-card">
          <Skeleton style={{ height: 14, width: "55%", marginBottom: 12 }} />
          <Skeleton style={{ height: 32, width: "70%" }} />
        </div>
      ))}
    </section>
  );
}

export function SkeletonTable({ rows = 6, cols = 5 }: { rows?: number; cols?: number }) {
  return (
    <div className="skeleton-table" role="status" aria-label="Chargement…">
      <div className="skeleton-row skeleton-row-head">
        {Array.from({ length: cols }).map((_, i) => (
          <Skeleton key={i} style={{ height: 12, width: "65%" }} />
        ))}
      </div>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="skeleton-row">
          {Array.from({ length: cols }).map((_, c) => (
            <Skeleton key={c} style={{ height: 14, width: `${50 + ((r * 13 + c * 7) % 40)}%` }} />
          ))}
        </div>
      ))}
    </div>
  );
}

export function SkeletonPanel({ lines = 6, title = true }: { lines?: number; title?: boolean }) {
  return (
    <div className="panel" role="status" aria-label="Chargement…">
      {title ? (
        <div className="panel-header">
          <div>
            <Skeleton style={{ height: 18, width: 180, marginBottom: 8 }} />
            <Skeleton style={{ height: 12, width: 260 }} />
          </div>
        </div>
      ) : null}
      <div style={{ padding: "8px 0", display: "flex", flexDirection: "column", gap: 10 }}>
        {Array.from({ length: lines }).map((_, i) => (
          <Skeleton key={i} style={{ height: 14, width: `${60 + ((i * 11) % 35)}%` }} />
        ))}
      </div>
    </div>
  );
}

/** Layout standard d'une page liste : header + stats + table. */
export function SkeletonListPage({
  eyebrow,
  title,
  stats = 4,
  rows = 8,
  cols = 6,
}: {
  eyebrow?: string;
  title?: string;
  stats?: number;
  rows?: number;
  cols?: number;
}) {
  return (
    <main className="page" role="status" aria-label="Chargement…">
      <header className="page-header">
        {eyebrow ? <span className="eyebrow">{eyebrow}</span> : <Skeleton style={{ height: 12, width: 110 }} />}
        {title ? <h1 className="page-title">{title}</h1> : <Skeleton style={{ height: 28, width: 280, marginTop: 6 }} />}
      </header>
      <SkeletonStatGrid count={stats} />
      <div className="panel">
        <SkeletonTable rows={rows} cols={cols} />
      </div>
    </main>
  );
}
