"use client";

/**
 * components/chauffeur/geolocation-tracker.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Demande la permission de géolocalisation (mobile/web) puis pousse la position
 * du chauffeur toutes les ~60s tant que la page est visible.
 *
 * Affiche un petit bandeau d'état (autorisée / refusée / erreur).
 */

import { useEffect, useRef, useState } from "react";
import { updateMyPositionAction } from "@/app/chauffeur/actions";

const PUSH_INTERVAL_MS = 60_000; // ~1 minute
const MIN_ACCURACY_M = 250;      // on ignore les fix trop imprécis

export function GeolocationTracker() {
  const [status, setStatus] = useState<
    "idle" | "asking" | "tracking" | "denied" | "unsupported" | "error"
  >("idle");
  const [lastPush, setLastPush] = useState<Date | null>(null);
  const lastPushAtRef = useRef<number>(0);

  useEffect(() => {
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
      setStatus("unsupported");
      return;
    }
    setStatus("asking");
    let watchId: number | null = null;

    watchId = navigator.geolocation.watchPosition(
      async (pos) => {
        if (pos.coords.accuracy && pos.coords.accuracy > MIN_ACCURACY_M) return;
        const now = Date.now();
        if (now - lastPushAtRef.current < PUSH_INTERVAL_MS) return;
        lastPushAtRef.current = now;
        setStatus("tracking");

        try {
          const res = await updateMyPositionAction(
            pos.coords.latitude,
            pos.coords.longitude,
            pos.coords.speed != null ? pos.coords.speed * 3.6 : null,
            pos.coords.heading,
          );
          if (res.ok) setLastPush(new Date());
        } catch {
          // ignore single-update failures, on retentera au prochain tick
        }
      },
      (err) => {
        if (err.code === err.PERMISSION_DENIED) setStatus("denied");
        else setStatus("error");
      },
      {
        enableHighAccuracy: true,
        maximumAge: 30_000,
        timeout: 20_000,
      },
    );

    return () => {
      if (watchId !== null) navigator.geolocation.clearWatch(watchId);
    };
  }, []);

  const message =
    status === "tracking"
      ? lastPush
        ? `Position partagée à ${lastPush.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}`
        : "Position en cours de partage…"
      : status === "asking"
        ? "Autorisez la géolocalisation dans votre navigateur"
        : status === "denied"
          ? "Géolocalisation refusée — votre exploitant ne pourra pas vous suivre."
          : status === "unsupported"
            ? "Géolocalisation indisponible sur cet appareil"
            : status === "error"
              ? "Erreur de géolocalisation, nouvelle tentative…"
              : "Initialisation…";

  return (
    <div className={`ch-geo ch-geo-${status}`} role="status" aria-live="polite">
      <span aria-hidden>📍</span>
      <span>{message}</span>
    </div>
  );
}
