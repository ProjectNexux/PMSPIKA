"use client";

/**
 * components/chauffeur/pod-capture.tsx
 * ─────────────────────────────────────────────────────────────────────────────
 * Capture mobile d'une preuve de livraison (POD) :
 *  - progression du statut (enlevé → en transit → en livraison)
 *  - signature manuscrite (canvas tactile)
 *  - photos (caméra)
 *  - scan / saisie de codes-barres
 *  - géolocalisation au moment de la validation
 */

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import {
  recordDeliveryEventAction,
  submitPodAction,
} from "@/app/chauffeur/tournee/actions";
import type {
  DeliveryEventType,
  DeliveryStatus,
  PodStatus,
} from "@/lib/pod-queries";

type Props = {
  missionId: string;
  reference: string | null;
  deliveryLabel: string;
  initialStatus: DeliveryStatus;
  alreadyDelivered: boolean;
};

const STEP_FLOW: { type: DeliveryEventType; label: string; from: DeliveryStatus[] }[] = [
  { type: "enleve", label: "Marquer enlevé", from: ["a_traiter"] },
  { type: "en_transit", label: "Démarrer le transit", from: ["enleve"] },
  { type: "en_livraison", label: "En cours de livraison", from: ["en_transit"] },
];

// BarcodeDetector n'est pas typé dans la lib standard — déclaration minimale.
type BarcodeDetectorLike = {
  detect: (source: CanvasImageSource) => Promise<{ rawValue: string }[]>;
};
type BarcodeDetectorCtor = new (opts?: { formats?: string[] }) => BarcodeDetectorLike;

export function PodCapture({
  missionId,
  reference,
  deliveryLabel,
  initialStatus,
  alreadyDelivered,
}: Props) {
  const router = useRouter();
  const [isPending, startTransition] = useTransition();
  const [status, setStatus] = useState<DeliveryStatus>(initialStatus);
  const [error, setError] = useState<string | null>(null);

  // Formulaire de validation finale
  const [podStatus, setPodStatus] = useState<PodStatus>("livre");
  const [recipient, setRecipient] = useState("");
  const [reserve, setReserve] = useState("");
  const [failureReason, setFailureReason] = useState("absent");
  const [photos, setPhotos] = useState<File[]>([]);
  const [barcodes, setBarcodes] = useState<string[]>([]);
  const [manualCode, setManualCode] = useState("");
  const [hasSignature, setHasSignature] = useState(false);
  const [showFinal, setShowFinal] = useState(false);

  // Scanner
  const [scanning, setScanning] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // Canvas de signature
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const drawing = useRef(false);

  /* ── Signature : dessin tactile ── */
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#111827";
  }, [showFinal]);

  const pointerPos = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current!;
    const rect = canvas.getBoundingClientRect();
    return {
      x: (e.clientX - rect.left) * (canvas.width / rect.width),
      y: (e.clientY - rect.top) * (canvas.height / rect.height),
    };
  };

  const startDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    drawing.current = true;
    const { x, y } = pointerPos(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
  };

  const moveDraw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!drawing.current) return;
    e.preventDefault();
    const ctx = canvasRef.current?.getContext("2d");
    if (!ctx) return;
    const { x, y } = pointerPos(e);
    ctx.lineTo(x, y);
    ctx.stroke();
    setHasSignature(true);
  };

  const endDraw = () => {
    drawing.current = false;
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d");
    if (canvas && ctx) ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasSignature(false);
  };

  const getSignatureBlob = (): Promise<Blob | null> =>
    new Promise((resolve) => {
      const canvas = canvasRef.current;
      if (!canvas || !hasSignature) return resolve(null);
      canvas.toBlob((blob) => resolve(blob), "image/png");
    });

  /* ── Géolocalisation ── */
  const getPosition = (): Promise<{ lat: number | null; lng: number | null }> =>
    new Promise((resolve) => {
      if (!("geolocation" in navigator)) return resolve({ lat: null, lng: null });
      navigator.geolocation.getCurrentPosition(
        (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude }),
        () => resolve({ lat: null, lng: null }),
        { enableHighAccuracy: true, timeout: 5000 },
      );
    });

  /* ── Progression du statut ── */
  const advance = (type: DeliveryEventType) => {
    setError(null);
    startTransition(async () => {
      const pos = await getPosition();
      const res = await recordDeliveryEventAction(missionId, type, { lat: pos.lat, lng: pos.lng });
      if (!res.ok) {
        setError(res.error ?? "Erreur inconnue.");
        return;
      }
      const map: Record<string, DeliveryStatus> = {
        enleve: "enleve",
        en_transit: "en_transit",
        en_livraison: "en_livraison",
      };
      setStatus(map[type] ?? status);
      router.refresh();
    });
  };

  /* ── Scanner code-barres ── */
  const stopScan = useCallback(() => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setScanning(false);
  }, []);

  useEffect(() => () => stopScan(), [stopScan]);

  const startScan = async () => {
    const Ctor = (window as unknown as { BarcodeDetector?: BarcodeDetectorCtor }).BarcodeDetector;
    if (!Ctor) {
      setError("Scanner non supporté sur cet appareil — saisissez le code manuellement.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      streamRef.current = stream;
      setScanning(true);
      const detector = new Ctor();
      const video = videoRef.current!;
      video.srcObject = stream;
      await video.play();

      const tick = async () => {
        if (!streamRef.current) return;
        try {
          const codes = await detector.detect(video);
          if (codes.length > 0) {
            const code = codes[0].rawValue.trim();
            if (code) {
              setBarcodes((prev) => (prev.includes(code) ? prev : [...prev, code]));
              stopScan();
              return;
            }
          }
        } catch {
          /* frame ignorée */
        }
        requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    } catch {
      setError("Impossible d'accéder à la caméra.");
      stopScan();
    }
  };

  const addManualCode = () => {
    const c = manualCode.trim();
    if (c && !barcodes.includes(c)) setBarcodes((prev) => [...prev, c]);
    setManualCode("");
  };

  /* ── Validation finale ── */
  const submit = () => {
    setError(null);
    if (podStatus !== "refuse" && !hasSignature) {
      setError("La signature est requise pour valider la livraison.");
      return;
    }
    startTransition(async () => {
      const pos = await getPosition();
      const fd = new FormData();
      fd.set("mission_id", missionId);
      fd.set("status", podStatus);
      fd.set("recipient_name", recipient);
      fd.set("reserve_text", podStatus === "refuse" ? `Refus : ${failureReason}. ${reserve}` : reserve);
      if (pos.lat != null) fd.set("lat", String(pos.lat));
      if (pos.lng != null) fd.set("lng", String(pos.lng));
      fd.set("barcodes", JSON.stringify(barcodes));

      const sig = await getSignatureBlob();
      if (sig) fd.set("signature", new File([sig], "signature.png", { type: "image/png" }));
      photos.forEach((p) => fd.append("photo", p));

      await submitPodAction(fd);
      router.refresh();
      router.push("/chauffeur");
    });
  };

  if (alreadyDelivered) {
    return (
      <section className="ch-card">
        <h2>Livraison validée ✅</h2>
        <p>Une preuve de livraison a déjà été enregistrée pour cette mission.</p>
      </section>
    );
  }

  return (
    <>
      <section className="ch-card">
        <h2>Livraison {reference ? `· ${reference}` : ""}</h2>
        <p style={{ color: "var(--muted-foreground)" }}>{deliveryLabel}</p>
        <p style={{ marginTop: 8 }}>
          Statut : <strong>{labelStatus(status)}</strong>
        </p>
        {error && <p className="ch-error">{error}</p>}

        {/* Étapes intermédiaires */}
        {!showFinal && (
          <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 12 }}>
            {STEP_FLOW.filter((s) => s.from.includes(status)).map((s) => (
              <button
                key={s.type}
                type="button"
                className="ch-action-btn"
                style={{ background: "#10b981" }}
                onClick={() => advance(s.type)}
                disabled={isPending}
              >
                {isPending ? "…" : s.label}
              </button>
            ))}
            <button
              type="button"
              className="ch-action-btn"
              style={{ background: "#3b82f6" }}
              onClick={() => setShowFinal(true)}
              disabled={isPending}
            >
              Valider la livraison
            </button>
          </div>
        )}
      </section>

      {/* Formulaire de preuve */}
      {showFinal && (
        <section className="ch-card" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <h2>Preuve de livraison</h2>

          <label className="ch-field">
            <span>Résultat</span>
            <select
              className="ch-input"
              value={podStatus}
              onChange={(e) => setPodStatus(e.target.value as PodStatus)}
            >
              <option value="livre">Livré</option>
              <option value="livre_avec_reserve">Livré avec réserve</option>
              <option value="refuse">Refusé / échec</option>
            </select>
          </label>

          {podStatus === "refuse" && (
            <label className="ch-field">
              <span>Motif de l&apos;échec</span>
              <select
                className="ch-input"
                value={failureReason}
                onChange={(e) => setFailureReason(e.target.value)}
              >
                <option value="absent">Destinataire absent</option>
                <option value="refuse">Marchandise refusée</option>
                <option value="adresse_introuvable">Adresse introuvable</option>
                <option value="autre">Autre</option>
              </select>
            </label>
          )}

          {podStatus !== "refuse" && (
            <label className="ch-field">
              <span>Nom du réceptionnaire</span>
              <input
                className="ch-input"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                placeholder="Qui a réceptionné ?"
              />
            </label>
          )}

          {(podStatus === "livre_avec_reserve" || podStatus === "refuse") && (
            <label className="ch-field">
              <span>Réserves / commentaire</span>
              <textarea
                className="ch-textarea"
                rows={3}
                value={reserve}
                onChange={(e) => setReserve(e.target.value)}
                placeholder="Casse, colis manquant, retard…"
              />
            </label>
          )}

          {/* Signature */}
          {podStatus !== "refuse" && (
            <div className="ch-field">
              <span>Signature</span>
              <canvas
                ref={canvasRef}
                width={600}
                height={200}
                onPointerDown={startDraw}
                onPointerMove={moveDraw}
                onPointerUp={endDraw}
                onPointerLeave={endDraw}
                style={{
                  width: "100%",
                  height: 160,
                  border: "1px dashed #9ca3af",
                  borderRadius: 8,
                  touchAction: "none",
                  background: "#fff",
                }}
              />
              <button type="button" className="ch-btn-secondary" onClick={clearSignature} style={{ marginTop: 6 }}>
                Effacer
              </button>
            </div>
          )}

          {/* Photos */}
          <div className="ch-field">
            <span>Photos {photos.length > 0 ? `(${photos.length})` : ""}</span>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              multiple
              onChange={(e) => setPhotos(Array.from(e.target.files ?? []))}
            />
            {photos.length > 0 && (
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 6 }}>
                {photos.map((p, i) => (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    key={i}
                    src={URL.createObjectURL(p)}
                    alt={`photo ${i + 1}`}
                    style={{ width: 64, height: 64, objectFit: "cover", borderRadius: 6 }}
                  />
                ))}
              </div>
            )}
          </div>

          {/* Scan codes-barres */}
          <div className="ch-field">
            <span>Codes-barres {barcodes.length > 0 ? `(${barcodes.length})` : ""}</span>
            {scanning ? (
              <div>
                {/* eslint-disable-next-line jsx-a11y/media-has-caption */}
                <video ref={videoRef} style={{ width: "100%", borderRadius: 8, background: "#000" }} />
                <button type="button" className="ch-btn-secondary" onClick={stopScan} style={{ marginTop: 6 }}>
                  Arrêter
                </button>
              </div>
            ) : (
              <div style={{ display: "flex", gap: 6 }}>
                <input
                  className="ch-input"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="Saisir un code"
                  style={{ flex: 1 }}
                />
                <button type="button" className="ch-btn-secondary" onClick={addManualCode}>
                  Ajouter
                </button>
                <button type="button" className="ch-btn-secondary" onClick={startScan}>
                  Scanner
                </button>
              </div>
            )}
            {barcodes.length > 0 && (
              <ul style={{ margin: "8px 0 0", paddingLeft: 18, fontSize: 13 }}>
                {barcodes.map((c) => (
                  <li key={c}>{c}</li>
                ))}
              </ul>
            )}
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <button type="button" className="ch-btn-secondary" onClick={() => setShowFinal(false)} disabled={isPending}>
              Retour
            </button>
            <button
              type="button"
              className="ch-btn-primary"
              onClick={submit}
              disabled={isPending}
              style={{ flex: 1 }}
            >
              {isPending ? "Envoi…" : "Confirmer la livraison"}
            </button>
          </div>
        </section>
      )}
    </>
  );
}

function labelStatus(s: DeliveryStatus): string {
  switch (s) {
    case "a_traiter": return "À traiter";
    case "enleve": return "Enlevé";
    case "en_transit": return "En transit";
    case "en_livraison": return "En cours de livraison";
    case "livre": return "Livré";
    case "echec": return "Échec";
    default: return s;
  }
}
