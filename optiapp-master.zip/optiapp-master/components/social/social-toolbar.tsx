import Link from "next/link";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  Download,
  History,
  Lock,
  Plus,
  RefreshCw,
  Unlock,
  UsersRound,
  Wallet,
} from "lucide-react";
import {
  recalculatePayrollPeriod,
  setPayrollPeriodStatus,
} from "@/app/actions";
import { formatPeriod, shiftPeriod } from "@/lib/payroll";

export type SocialView = "effectif" | "prepaie" | "absences" | "historique";

export type SocialToolbarProps = {
  basePath: string;            // ex: /societes/abc/social
  companyId: string;
  view: SocialView;
  period: string;
  counts: {
    effectif: number;
    absences: number;
    prepaie: number;
    historique: number;
  };
  prepaie: {
    ready: number;
    total: number;
    locked: boolean;
  };
  exportPath: string;          // /social/pre-paie/export
};

function buildHref(
  basePath: string,
  params: Record<string, string | undefined>,
  base: { view: SocialView; period: string }
) {
  const search = new URLSearchParams();
  search.set("view", base.view);
  search.set("period", base.period);
  Object.entries(params).forEach(([k, v]) => {
    if (v === undefined) return;
    search.set(k, v);
  });
  return `${basePath}?${search.toString()}`;
}

export function SocialToolbar({
  basePath,
  companyId,
  view,
  period,
  counts,
  prepaie,
  exportPath,
}: SocialToolbarProps) {
  const prev = shiftPeriod(period, -1);
  const next = shiftPeriod(period, 1);

  const tabs: { id: SocialView; label: string; count: number; icon: React.ComponentType<{ size?: number }> }[] = [
    { id: "effectif",   label: "Effectif",        count: counts.effectif,   icon: UsersRound },
    { id: "prepaie",    label: "Pré-paie",        count: counts.prepaie,    icon: Wallet },
    { id: "absences",   label: "Absences",        count: counts.absences,   icon: CalendarDays },
    { id: "historique", label: "Historique paie", count: counts.historique, icon: History },
  ];

  const addEmployeeHref = buildHref(basePath, { new: "1" }, { view, period });
  const validateBackHref = buildHref(basePath, {}, { view, period });

  return (
    <section className="social-toolbar" aria-label="Barre d'actions sociales">
      {/* Ligne 1 : chips de stats + actions globales */}
      <div className="social-toolbar-row">
        <div className="social-chips">
          <span className="social-chip">
            <UsersRound size={13} aria-hidden /> Effectif <strong>{counts.effectif}</strong>
          </span>
          <span className="social-chip">
            <Wallet size={13} aria-hidden /> Pré-paie{" "}
            <strong>{prepaie.ready}/{prepaie.total}</strong>
          </span>
          <span className="social-chip">
            <CalendarDays size={13} aria-hidden /> Absences <strong>{counts.absences}</strong>
          </span>
          <span className={`social-chip ${prepaie.locked ? "ok" : "warn"}`}>
            {prepaie.locked ? <Lock size={13} aria-hidden /> : <Unlock size={13} aria-hidden />}
            {prepaie.locked ? "Période verrouillée" : "Période ouverte"}
          </span>
        </div>

        <div className="social-toolbar-actions">
          <div className="social-period">
            <Link
              className="btn-icon"
              href={buildHref(basePath, {}, { view, period: prev })}
              aria-label="Mois précédent"
              title="Mois précédent"
            >
              <ChevronLeft size={15} />
            </Link>
            <span className="social-period-label">{formatPeriod(period)}</span>
            <Link
              className="btn-icon"
              href={buildHref(basePath, {}, { view, period: next })}
              aria-label="Mois suivant"
              title="Mois suivant"
            >
              <ChevronRight size={15} />
            </Link>
          </div>

          <a
            className="button secondary"
            href={`${exportPath}?period=${period}&company=${companyId}`}
            title="Export CSV pré-paie"
          >
            <Download size={15} /> Export
          </a>

          <form action={recalculatePayrollPeriod}>
            <input type="hidden" name="period" value={period} />
            <input type="hidden" name="redirect_to" value={validateBackHref} />
            <input type="hidden" name="company_id" value={companyId} />
            <button
              type="submit"
              className="button secondary"
              title="Recharger heures, jours, primes depuis le TMS (les lignes 'Prêt paie' ne sont pas touchées)"
            >
              <RefreshCw size={15} /> Recalc. TMS
            </button>
          </form>

          <form action={setPayrollPeriodStatus}>
            <input type="hidden" name="period" value={period} />
            <input type="hidden" name="redirect_to" value={validateBackHref} />
            <input type="hidden" name="company_id" value={companyId} />
            <input
              type="hidden"
              name="status"
              value={prepaie.locked ? "A valider" : "Pret paie"}
            />
            <button
              type="submit"
              className="button"
              title={prepaie.locked ? "Déverrouiller la période" : "Valider toutes les lignes en Prêt paie"}
            >
              {prepaie.locked ? <Unlock size={15} /> : <Lock size={15} />}
              {prepaie.locked ? "Déverrouiller" : "Valider la période"}
            </button>
          </form>

          <Link className="button" href={addEmployeeHref} title="Ajouter un salarié">
            <Plus size={15} /> Salarié
          </Link>
        </div>
      </div>

      {/* Ligne 2 : onglets */}
      <nav className="social-tabs" aria-label="Vues sociales">
        {tabs.map((t) => {
          const Icon = t.icon;
          const active = t.id === view;
          return (
            <Link
              key={t.id}
              href={buildHref(basePath, {}, { view: t.id, period })}
              className={active ? "social-tab active" : "social-tab"}
              aria-current={active ? "page" : undefined}
            >
              <Icon size={14} />
              <span>{t.label}</span>
              <span className="social-tab-count">{t.count}</span>
            </Link>
          );
        })}
      </nav>
    </section>
  );
}
