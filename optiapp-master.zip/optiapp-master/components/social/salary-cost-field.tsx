"use client";

import { useState } from "react";

const EMPLOYER_LOAD = 1.42;     // Brut × charges patronales (≈ 42 %)
const MONTHLY_HOURS  = 151.67;  // 35 h hebdo × 52 / 12

/**
 * Saisie du salaire mensuel brut + affichage live du coût horaire employeur.
 * Le coût n'est pas posté : il est recalculé côté serveur lors de l'enregistrement.
 */
export function SalaryCostField({ defaultValue }: { defaultValue: number | null }) {
  const [salary, setSalary] = useState<string>(
    defaultValue != null && defaultValue > 0 ? String(defaultValue) : "",
  );
  const num = Number(salary);
  const cost = Number.isFinite(num) && num > 0 ? (num * EMPLOYER_LOAD) / MONTHLY_HOURS : null;

  return (
    <>
      <div className="field">
        <label htmlFor="monthly_gross_salary">Salaire mensuel brut (€)</label>
        <input
          id="monthly_gross_salary"
          name="monthly_gross_salary"
          type="number"
          step="0.01"
          min="0"
          value={salary}
          onChange={(e) => setSalary(e.target.value)}
          placeholder="Ex. 1800"
        />
      </div>
      <div className="field">
        <label>Coût horaire employeur</label>
        <input
          type="text"
          value={cost != null ? `${cost.toFixed(2)} €/h` : "—"}
          readOnly
          tabIndex={-1}
          aria-label="Coût horaire employeur calculé"
          style={{ background: "#f6f7f9", color: "#6b7280", cursor: "default" }}
        />
        <div className="muted" style={{ fontSize: 11, marginTop: 4 }}>
          Calcul auto : brut × {EMPLOYER_LOAD} ÷ {MONTHLY_HOURS} h. Utilisé pour la rentabilité TMS.
        </div>
      </div>
    </>
  );
}
