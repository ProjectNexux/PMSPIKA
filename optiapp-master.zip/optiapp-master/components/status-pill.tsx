import { Badge } from "@/components/ui/badge";

type Variant = "success" | "info" | "warning" | "destructive" | "muted";

const toneByStatus: Record<string, Variant> = {
  Actif: "success",
  Valide: "success",
  Pret: "success",
  "Pret paie": "success",
  "Envoye comptable": "success",
  Termine: "success",
  "En cours": "info",
  Moyenne: "info",
  "A faire": "warning",
  "A traiter": "warning",
  "A revoir": "warning",
  "A classer": "warning",
  "A valider": "warning",
  "Expire bientot": "warning",
  Haute: "warning",
  Maintenance: "warning",
  Absence: "warning",
  Manquant: "destructive",
  Bloque: "destructive",
  Critique: "destructive"
};

export function StatusPill({ value }: { value: string }) {
  const variant = toneByStatus[value] ?? "muted";
  return <Badge variant={variant}>{value}</Badge>;
}
