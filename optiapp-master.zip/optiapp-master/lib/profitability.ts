/* ──────────────────────────────────────────────────────────────────────────
   Calculs de rentabilité d'une tournée
   ────────────────────────────────────────────────────────────────────────── */

export type ProfitabilityInputs = {
  /** Distance totale de la tournée (km). */
  total_distance_km: number | null;
  /** Heures estimées (chauffeur) pour la tournée. */
  estimated_hours: number | null;

  // Revenus
  flat_rate_revenue: number | null;
  surcharge_fuel: number | null;
  surcharge_adr: number | null;
  surcharge_wait: number | null;
  surcharge_other: number | null;
  other_revenue: number | null;
  /** Somme des `missions.price` rattachées (utilisée si pas de forfait). */
  missions_revenue: number;

  // Overrides coûts (manuel > calculé)
  toll_cost: number | null;
  fuel_cost_override: number | null;
  driver_cost_override: number | null;
  vehicle_cost_override: number | null;
  subcontractor_cost: number | null;
  cold_unit_cost_override: number | null;
  maintenance_cost_override: number | null;
  tire_cost_override: number | null;
  misc_cost: number | null;

  // Taux par défaut (véhicule)
  fuel_consumption_l_100km: number | null;
  fuel_price_per_l: number | null;
  amortization_per_km: number | null;
  tire_cost_per_km: number | null;
  maintenance_cost_per_km: number | null;
  has_cold_unit: boolean | null;
  cold_unit_cost_per_hour: number | null;

  // Taux chauffeur
  driver_hourly_cost: number | null;
};

export type ProfitabilityBreakdown = {
  revenue: number;
  cost: number;
  margin: number;
  marginPct: number | null;
  revenues: {
    flat: number;
    missions: number;
    surcharge_fuel: number;
    surcharge_adr: number;
    surcharge_wait: number;
    surcharge_other: number;
    other: number;
  };
  costs: {
    fuel: number;
    driver: number;
    vehicle: number;
    cold_unit: number;
    tolls: number;
    subcontractor: number;
    misc: number;
  };
  /** Indique pour chaque ligne de coût si la valeur vient d'un override saisi. */
  overrides: {
    fuel: boolean;
    driver: boolean;
    vehicle: boolean;
    cold_unit: boolean;
  };
};

const n = (v: number | null | undefined) => (typeof v === "number" && !Number.isNaN(v) ? v : 0);

export function computeProfitability(i: ProfitabilityInputs): ProfitabilityBreakdown {
  const km    = n(i.total_distance_km);
  const hours = n(i.estimated_hours);

  // ── Revenus ────────────────────────────────────────────────────────────
  const flat            = n(i.flat_rate_revenue);
  const missionsRev     = flat > 0 ? 0 : n(i.missions_revenue);
  const sFuel           = n(i.surcharge_fuel);
  const sAdr            = n(i.surcharge_adr);
  const sWait           = n(i.surcharge_wait);
  const sOther          = n(i.surcharge_other);
  const otherRev        = n(i.other_revenue);
  const revenue         = flat + missionsRev + sFuel + sAdr + sWait + sOther + otherRev;

  // ── Coûts ──────────────────────────────────────────────────────────────
  const fuelAuto =
    n(i.fuel_consumption_l_100km) > 0 && n(i.fuel_price_per_l) > 0 && km > 0
      ? (km * n(i.fuel_consumption_l_100km) * n(i.fuel_price_per_l)) / 100
      : 0;
  const fuel = i.fuel_cost_override != null ? n(i.fuel_cost_override) : fuelAuto;

  const driverAuto = n(i.driver_hourly_cost) > 0 && hours > 0 ? hours * n(i.driver_hourly_cost) : 0;
  const driver = i.driver_cost_override != null ? n(i.driver_cost_override) : driverAuto;

  const vehiclePerKm =
    n(i.amortization_per_km) + n(i.tire_cost_per_km) + n(i.maintenance_cost_per_km);
  const vehicleAuto = vehiclePerKm > 0 && km > 0 ? vehiclePerKm * km : 0;
  // Si overrides spécifiques (tire / maintenance), on les additionne à l'amortissement de base
  let vehicle: number;
  if (i.vehicle_cost_override != null) {
    vehicle = n(i.vehicle_cost_override);
  } else {
    const tire        = i.tire_cost_override        != null ? n(i.tire_cost_override)        : n(i.tire_cost_per_km) * km;
    const maintenance = i.maintenance_cost_override != null ? n(i.maintenance_cost_override) : n(i.maintenance_cost_per_km) * km;
    const amort       = n(i.amortization_per_km) * km;
    vehicle = amort + tire + maintenance;
  }
  if (vehicle === 0 && i.vehicle_cost_override == null) vehicle = vehicleAuto;

  const coldAuto = i.has_cold_unit && n(i.cold_unit_cost_per_hour) > 0 && hours > 0
    ? hours * n(i.cold_unit_cost_per_hour)
    : 0;
  const cold = i.cold_unit_cost_override != null ? n(i.cold_unit_cost_override) : coldAuto;

  const tolls         = n(i.toll_cost);
  const subcontractor = n(i.subcontractor_cost);
  const misc          = n(i.misc_cost);

  const cost = fuel + driver + vehicle + cold + tolls + subcontractor + misc;

  // ── Marge ──────────────────────────────────────────────────────────────
  const margin = revenue - cost;
  const marginPct = revenue > 0 ? (margin / revenue) * 100 : null;

  return {
    revenue,
    cost,
    margin,
    marginPct,
    revenues: {
      flat,
      missions: missionsRev,
      surcharge_fuel: sFuel,
      surcharge_adr: sAdr,
      surcharge_wait: sWait,
      surcharge_other: sOther,
      other: otherRev,
    },
    costs: {
      fuel,
      driver,
      vehicle,
      cold_unit: cold,
      tolls,
      subcontractor,
      misc,
    },
    overrides: {
      fuel: i.fuel_cost_override != null,
      driver: i.driver_cost_override != null,
      vehicle: i.vehicle_cost_override != null,
      cold_unit: i.cold_unit_cost_override != null,
    },
  };
}

/** Couleur sémantique selon la marge %. */
export function marginTone(pct: number | null): "green" | "orange" | "red" | "muted" {
  if (pct == null) return "muted";
  if (pct >= 15) return "green";
  if (pct >= 5)  return "orange";
  return "red";
}
