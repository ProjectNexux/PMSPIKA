import "server-only";
import { getServerSupabase } from "@/lib/db-server";
import { getCurrentUser } from "@/lib/session";

export type AuditResult = "ok" | "error";

export type AuditEntry = {
  action: string;            // ex: "create_employee"
  entity: string;            // ex: "employees"
  entity_id?: string | null; // id de la ligne touchée
  company_id?: string | null;
  result?: AuditResult;
  message?: string | null;
  metadata?: Record<string, unknown> | null;
};

/**
 * Écrit une entrée d'audit. Service role (bypass RLS) — la table refuse
 * toute autre écriture. Erreurs swallowed pour ne jamais casser une action.
 */
export async function logAudit(entry: AuditEntry): Promise<void> {
  try {
    const user = await getCurrentUser();
    const supabase = getServerSupabase();
    const { error } = await supabase.from("audit_log").insert({
      actor_id: user?.id ?? null,
      actor_email: user?.email ?? null,
      actor_role: user?.role ?? null,
      company_id: entry.company_id ?? user?.company_id ?? null,
      action: entry.action,
      entity: entry.entity,
      entity_id: entry.entity_id ?? null,
      result: entry.result ?? "ok",
      message: entry.message ?? null,
      metadata: entry.metadata ?? null,
    });
    if (error) console.error("[audit] insert failed:", error.message);
  } catch (e) {
    console.error("[audit] unexpected:", e);
  }
}

/**
 * Wrapper pratique : exécute `fn`, audite succès / erreur, puis re-throw.
 * `entry` peut être enrichi dynamiquement via la valeur retournée par `fn`
 * (pour récupérer l'id généré, etc.) en utilisant `entryFromResult`.
 */
export async function withAudit<T>(
  entry: Omit<AuditEntry, "result" | "message">,
  fn: () => Promise<T>,
  entryFromResult?: (result: T) => Partial<AuditEntry>,
): Promise<T> {
  try {
    const result = await fn();
    const extra = entryFromResult ? entryFromResult(result) : {};
    await logAudit({ ...entry, ...extra, result: "ok" });
    return result;
  } catch (e) {
    const message = e instanceof Error ? e.message : String(e);
    await logAudit({ ...entry, result: "error", message });
    throw e;
  }
}
