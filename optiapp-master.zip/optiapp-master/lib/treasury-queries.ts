import { supabase } from "@/lib/db";
import { computeInvoiceTotals } from "@/lib/invoice-queries";
import { assertArray } from "@/lib/utils";

// ── Types ─────────────────────────────────────────────────────────────────────

export type CashAccount = {
  id: string;
  company_id: string | null;
  label: string;
  iban: string | null;
  balance: number;
  currency: string;
  qonto_account_id: string | null;
  is_default: boolean;
  notes: string | null;
  created_at: string;
  updated_at: string;
};

export type CashTransaction = {
  id: string;
  company_id: string | null;
  account_id: string | null;
  date: string;
  label: string;
  amount: number;
  category: string;
  source: string;
  source_id: string | null;
  reconciled: boolean;
  notes: string | null;
  created_at: string;
};

export type CashForecastEntry = {
  id: string;
  company_id: string | null;
  expected_date: string;
  label: string;
  amount: number;
  category: string;
  source: string;
  source_id: string | null;
  is_realized: boolean;
  notes: string | null;
  created_at: string;
};

/** Virtual forecast entry derived from an invoice (not stored in DB) */
export type InvoiceForecastItem = {
  id: string;           // invoice id
  expected_date: string;
  label: string;
  amount: number;       // TTC
  category: "Facture client";
  source: "invoice";
  source_id: string;
  invoice_number: string;
  client_name: string;
  status: string;
};

export const CASH_CATEGORIES_IN  = ["Facture client", "Subvention", "Remboursement", "Autre recette"] as const;
export const CASH_CATEGORIES_OUT = ["Salaires", "Charges sociales", "Carburant", "Loyer", "Fournisseur", "TVA / URSSAF", "Entretien véhicule", "Assurance", "Autre"] as const;
export type CashCategoryIn  = typeof CASH_CATEGORIES_IN[number];
export type CashCategoryOut = typeof CASH_CATEGORIES_OUT[number];

// ── Queries ───────────────────────────────────────────────────────────────────

export async function listCashAccounts(companyId?: string): Promise<CashAccount[]> {
  let q = supabase
    .from("cash_accounts")
    .select("id, company_id, label, iban, balance, currency, qonto_account_id, is_default, notes, created_at, updated_at")
    .order("is_default", { ascending: false })
    .order("created_at");
  if (companyId) q = q.eq("company_id", companyId);
  const { data, error } = await q;
  if (error) { console.error("[treasury] listCashAccounts:", error.message); return []; }
  return assertArray<CashAccount>(data, []);
}

export async function listCashTransactions(companyId?: string, limit = 50): Promise<CashTransaction[]> {
  let q = supabase
    .from("cash_transactions")
    .select("id, company_id, account_id, date, label, amount, category, source, source_id, reconciled, notes, created_at")
    .order("date", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(limit);
  if (companyId) q = q.eq("company_id", companyId);
  const { data, error } = await q;
  if (error) { console.error("[treasury] listCashTransactions:", error.message); return []; }
  return assertArray<CashTransaction>(data, []);
}

export async function listForecastEntries(companyId?: string): Promise<CashForecastEntry[]> {
  const today = new Date().toISOString().slice(0, 10);
  const in90d = new Date(Date.now() + 90 * 86_400_000).toISOString().slice(0, 10);
  let q = supabase
    .from("cash_forecast")
    .select("id, company_id, expected_date, label, amount, category, source, source_id, is_realized, notes, created_at")
    .eq("is_realized", false)
    .gte("expected_date", today)
    .lte("expected_date", in90d)
    .order("expected_date");
  if (companyId) q = q.eq("company_id", companyId);
  const { data, error } = await q;
  if (error) { console.error("[treasury] listForecastEntries:", error.message); return []; }
  return assertArray<CashForecastEntry>(data, []);
}

/**
 * Pulls unpaid invoices and converts them to virtual forecast inflow items.
 * Payment terms assumed: 30 days from issue_date.
 */
export async function getInvoiceForecastItems(companyId?: string): Promise<InvoiceForecastItem[]> {
  let q = supabase
    .from("invoices")
    .select("id, invoice_number, issue_date, client_name, status, tva_rate, image_rights_rate, invoice_lines(total_ht, ecotaxe)")
    .not("status", "eq", "Payée")
    .order("issue_date", { ascending: false });
  if (companyId) q = q.eq("company_id", companyId);
  const { data, error } = await q;
  if (error) { console.error("[treasury] getInvoiceForecastItems:", error.message); return []; }

  return (data ?? []).map((inv) => {
    const lines = (inv.invoice_lines ?? []) as { total_ht: number; ecotaxe: number }[];
    const { montantTTC } = computeInvoiceTotals(lines, inv.tva_rate ?? 20);
    const dueDate = new Date(`${inv.issue_date}T00:00:00`);
    dueDate.setDate(dueDate.getDate() + 30);
    return {
      id: inv.id,
      source_id: inv.id,
      expected_date: dueDate.toISOString().slice(0, 10),
      label: `${inv.invoice_number} — ${inv.client_name}`,
      amount: montantTTC,
      category: "Facture client" as const,
      source: "invoice" as const,
      invoice_number: inv.invoice_number,
      client_name: inv.client_name,
      status: inv.status,
    };
  });
}

// ── Aggregation helpers ───────────────────────────────────────────────────────

export type WeeklyBucket = {
  weekLabel: string; // "25 juin"
  weekStart: string; // ISO date
  inflow: number;
  outflow: number;
};

/**
 * Groups forecast entries (manual + invoice) into weekly buckets for the chart.
 * Returns up to 13 weeks (≈ 90 days).
 */
export function buildWeeklyBuckets(
  manualForecast: CashForecastEntry[],
  invoiceItems: InvoiceForecastItem[],
  alreadyRealizedSourceIds: Set<string>,
): WeeklyBucket[] {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  // Build 13 weekly buckets starting from today
  const buckets: WeeklyBucket[] = Array.from({ length: 13 }, (_, i) => {
    const d = new Date(today);
    d.setDate(d.getDate() + i * 7);
    return {
      weekLabel: d.toLocaleDateString("fr-FR", { day: "numeric", month: "short" }),
      weekStart: d.toISOString().slice(0, 10),
      inflow: 0,
      outflow: 0,
    };
  });

  const getWeekIndex = (dateStr: string): number => {
    const d = new Date(`${dateStr}T00:00:00`);
    const diff = Math.floor((d.getTime() - today.getTime()) / (7 * 86_400_000));
    return Math.max(0, Math.min(12, diff));
  };

  for (const entry of manualForecast) {
    const idx = getWeekIndex(entry.expected_date);
    if (entry.amount > 0) buckets[idx].inflow += entry.amount;
    else buckets[idx].outflow += Math.abs(entry.amount);
  }

  for (const item of invoiceItems) {
    if (alreadyRealizedSourceIds.has(item.source_id)) continue;
    const idx = getWeekIndex(item.expected_date);
    buckets[idx].inflow += item.amount;
  }

  return buckets;
}
