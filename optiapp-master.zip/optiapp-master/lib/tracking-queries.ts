import "server-only";
import { getServerSupabase } from "@/lib/db-server";
import { assertObject } from "@/lib/utils";

/**
 * lib/tracking-queries.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Suivi temps réel : flotte (exploitation) et tracking client public par token.
 *
 * Le tracking public passe TOUJOURS par le service role filtré par token, et ne
 * renvoie qu'un sous-ensemble SÛR (jamais de prix, marge, ni identité complète).
 */

export type LiveFleetDriver = {
  driver_id: string;
  full_name: string;
  lat: number;
  lng: number;
  last_position_at: string | null;
};

/** Dernière position connue de chaque chauffeur d'une société (pour la carte). */
export async function getLiveFleet(companyId: string): Promise<LiveFleetDriver[]> {
  const sb = getServerSupabase();
  const { data } = await sb
    .from("profiles")
    .select("id, full_name, last_lat, last_lng, last_position_at, company_id, role")
    .eq("company_id", companyId)
    .eq("role", "chauffeur")
    .not("last_lat", "is", null)
    .not("last_lng", "is", null);

  return (data ?? []).map((d) => {
    const row = d as {
      id: string;
      full_name: string | null;
      last_lat: number;
      last_lng: number;
      last_position_at: string | null;
    };
    return {
      driver_id: row.id,
      full_name: row.full_name ?? "Chauffeur",
      lat: row.last_lat,
      lng: row.last_lng,
      last_position_at: row.last_position_at,
    };
  });
}

export type PublicTracking = {
  reference: string | null;
  delivery_status: string;
  pickup_city: string | null;
  delivery_city: string | null;
  window_start: string | null;
  window_end: string | null;
  scheduled_date: string | null;
  /** Position approximative du chauffeur (si en transit). */
  driver_lat: number | null;
  driver_lng: number | null;
  driver_updated_at: string | null;
  /** Destination (pour la mini-carte). */
  delivery_lat: number | null;
  delivery_lng: number | null;
  eta: string | null;
};

/**
 * Données de suivi publiques d'une mission via son token.
 * ⚠️ Aucune donnée sensible (prix, coûts, identité chauffeur, adresse exacte).
 */
export async function getMissionTrackingByToken(
  token: string,
): Promise<PublicTracking | null> {
  if (!token || token.length < 8) return null;
  const sb = getServerSupabase();

  const { data: mission } = await sb
    .from("missions")
    .select(
      "id, reference, delivery_status, pickup_city, delivery_city, " +
        "delivery_window_start, delivery_window_end, scheduled_date, " +
        "delivery_lat, delivery_lng, driver_id, eta",
    )
    .eq("tracking_token", token)
    .maybeSingle();

  if (!mission) return null;
  
  type MissionTrackingData = {
    delivery_status: string | null;
    reference: string | null;
    pickup_city: string | null;
    delivery_city: string | null;
    delivery_window_start: string | null;
    delivery_window_end: string | null;
    scheduled_date: string | null;
    delivery_lat: number | null;
    delivery_lng: number | null;
    driver_id: string | null;
    eta: string | null;
  };
  
  const m = assertObject<MissionTrackingData>(mission);
  if (!m) return null;

  const status = m.delivery_status ?? "a_traiter";
  const inTransit = status === "en_transit" || status === "en_livraison";

  let driverLat: number | null = null;
  let driverLng: number | null = null;
  let driverUpdatedAt: string | null = null;

  // On ne révèle la position que pendant le transit/la livraison.
  if (inTransit && m.driver_id) {
    const { data: driver } = await sb
      .from("profiles")
      .select("last_lat, last_lng, last_position_at")
      .eq("id", m.driver_id)
      .maybeSingle();
    
    type DriverPositionData = { last_lat: number | null; last_lng: number | null; last_position_at: string | null };
    const d = assertObject<DriverPositionData>(driver);
    if (d) {
      driverLat = d.last_lat;
      driverLng = d.last_lng;
      driverUpdatedAt = d.last_position_at;
    }
  }

  // ETA : valeur stockée, sinon estimation à la volée si on a les coordonnées.
  let eta = m.eta;
  if (!eta && inTransit && driverLat != null && driverLng != null && m.delivery_lat != null && m.delivery_lng != null) {
    eta = estimateEta(
      { lat: driverLat, lng: driverLng },
      { lat: m.delivery_lat, lng: m.delivery_lng },
    );
  }

  return {
    reference: m.reference,
    delivery_status: status,
    pickup_city: m.pickup_city,
    delivery_city: m.delivery_city,
    window_start: m.delivery_window_start,
    window_end: m.delivery_window_end,
    scheduled_date: m.scheduled_date,
    driver_lat: driverLat,
    driver_lng: driverLng,
    driver_updated_at: driverUpdatedAt,
    delivery_lat: inTransit ? m.delivery_lat : null,
    delivery_lng: inTransit ? m.delivery_lng : null,
    eta,
  };
}

/** Distance haversine en km entre deux points. */
export function haversineKm(
  a: { lat: number; lng: number },
  b: { lat: number; lng: number },
): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const lat1 = (a.lat * Math.PI) / 180;
  const lat2 = (b.lat * Math.PI) / 180;
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/**
 * ETA simple : distance à vol d'oiseau × facteur route ÷ vitesse moyenne.
 * (v1 — brancher OSRM/Mapbox pour un calcul routier réel en v2.)
 */
export function estimateEta(
  from: { lat: number; lng: number },
  to: { lat: number; lng: number },
  avgSpeedKmh = 45,
  roadFactor = 1.3,
): string {
  const km = haversineKm(from, to) * roadFactor;
  const hours = km / avgSpeedKmh;
  const ms = Math.max(0, hours * 3600 * 1000);
  return new Date(Date.now() + ms).toISOString();
}
