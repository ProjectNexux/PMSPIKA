/**
 * Scraper URSSAF / Net-Entreprises.
 * ============================================================================
 * AVERTISSEMENT
 * ----------------------------------------------------------------------------
 * Les conditions générales d'utilisation de net-entreprises.fr et urssaf.fr
 * encadrent strictement les usages automatisés. Ce scraper est conçu pour être
 * exécuté avec le consentement explicite du titulaire des identifiants, qui
 * en assume la responsabilité. Pour un usage en production multi-clients,
 * privilégier un agrégateur conforme (e-Attestations, Provigis, Acyba).
 * ============================================================================
 *
 * Implémentation :
 *  - Utilise `playwright-core` + `@sparticuz/chromium` pour pouvoir tourner
 *    aussi bien en local qu'en environnement serverless type Vercel.
 *  - Les sélecteurs DOM ci-dessous sont des PLACEHOLDERS basés sur la structure
 *    publique connue ; à confirmer/ajuster lors du premier run réel via un
 *    devtools enregistré (`playwright codegen https://www.net-entreprises.fr`).
 *
 * Dépendances à installer (npm i) :
 *    playwright-core @sparticuz/chromium
 * Pour développement local hors Vercel :
 *    npm i -D playwright && npx playwright install chromium
 */

type ScrapeOk = {
  ok: true;
  pdf: Buffer;
  validFrom: Date | null;
  validUntil: Date | null;
};

type ScrapeErr = {
  ok: false;
  reason: "mfa_required" | "bad_credentials" | "not_found" | "captcha" | "unknown";
  message: string;
};

export type ScrapeResult = ScrapeOk | ScrapeErr;

export type ScrapeInput = {
  username: string;
  password: string;
  /** SIRET du compte (utilisé pour confirmer la bonne entité après login). */
  siret?: string | null;
};

const PORTAL_URL = "https://www.net-entreprises.fr/login/";

/**
 * Lance un navigateur headless adapté à l'environnement courant.
 * - Sur Vercel/Lambda : `@sparticuz/chromium`
 * - En local : Playwright installé classiquement
 *
 * Les imports passent par `Function("return require")()` pour empêcher
 * Turbopack/webpack de tenter de les résoudre au build : ces packages sont
 * optionnels et chargés à la volée uniquement quand le scraper s'exécute.
 */
async function launchBrowser(): Promise<any> {
  // eslint-disable-next-line @typescript-eslint/no-implied-eval
  const dynamicRequire = Function("m", "return require(m)") as (m: string) => unknown;
  const isServerless = !!process.env.VERCEL || !!process.env.AWS_LAMBDA_FUNCTION_NAME;

  if (isServerless) {
    const chromiumPkg = dynamicRequire("@sparticuz/chromium") as {
      default?: { args: string[]; executablePath: () => Promise<string> };
      args?: string[];
      executablePath?: () => Promise<string>;
    };
    const chromium = chromiumPkg.default ?? (chromiumPkg as never as { args: string[]; executablePath: () => Promise<string> });
    const { chromium: pwChromium } = dynamicRequire("playwright-core") as { chromium: { launch: (opts: unknown) => Promise<unknown> } };
    return pwChromium.launch({
      args: chromium.args,
      executablePath: await chromium.executablePath(),
      headless: true,
    });
  }

  // En local : on tente d'abord playwright (avec navigateurs installés),
  // sinon on retombe sur playwright-core (nécessite executablePath).
  try {
    const { chromium } = dynamicRequire("playwright") as { chromium: { launch: (opts: unknown) => Promise<unknown> } };
    return chromium.launch({ headless: true });
  } catch {
    const { chromium } = dynamicRequire("playwright-core") as { chromium: { launch: (opts: unknown) => Promise<unknown> } };
    return chromium.launch({ headless: true });
  }
}

/**
 * Récupère l'attestation de vigilance URSSAF du mois courant.
 * Stratégie générique (à finaliser avec sélecteurs réels) :
 *   1. Aller sur la page login Net-Entreprises
 *   2. Saisir identifiant + mot de passe
 *   3. Détecter MFA / mauvais mot de passe / CAPTCHA → retour structuré
 *   4. Naviguer vers le service "Attestation de vigilance"
 *   5. Cliquer "Télécharger PDF" et capturer le buffer
 */
export async function fetchUrssafAttestation(input: ScrapeInput): Promise<ScrapeResult> {
  let browser: Awaited<ReturnType<typeof launchBrowser>> | null = null;
  try {
    browser = await launchBrowser();
    const context = await browser.newContext({
      acceptDownloads: true,
      userAgent:
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36",
    });
    const page = await context.newPage();
    await page.goto(PORTAL_URL, { waitUntil: "domcontentloaded", timeout: 30_000 });

    // === Step 1 — login ===
    // TODO(selectors) : confirmer les sélecteurs réels via `npx playwright codegen`.
    await page.fill('input[name="j_username"], #username, input[type="text"]', input.username);
    await page.fill('input[name="j_password"], #password, input[type="password"]', input.password);
    await Promise.all([
      page.waitForLoadState("networkidle", { timeout: 30_000 }),
      page.click('button[type="submit"], input[type="submit"], button:has-text("Connexion")'),
    ]);

    // === Step 2 — détection des cas d'échec ===
    const url = page.url();
    if (/captcha/i.test(url) || (await page.locator("text=/captcha/i").count())) {
      return { ok: false, reason: "captcha", message: "CAPTCHA détecté — bascule manuelle requise" };
    }
    if (await page.locator("text=/identifiant.*incorrect|mot de passe.*incorrect/i").count()) {
      return { ok: false, reason: "bad_credentials", message: "Identifiants refusés" };
    }
    if (await page.locator("text=/code.*sécurité|authentification.*forte|otp/i").count()) {
      return { ok: false, reason: "mfa_required", message: "MFA requis — non automatisable sans 2FA partagé" };
    }

    // === Step 3 — navigation vers le service Attestation de vigilance ===
    // TODO(selectors) : adapter au libellé exact du tableau de bord post-login.
    const vigilance = page.locator(
      'a:has-text("Attestation de vigilance"), a:has-text("Attestation Vigilance")',
    );
    if (!(await vigilance.count())) {
      return { ok: false, reason: "not_found", message: "Service 'Attestation de vigilance' introuvable" };
    }
    await vigilance.first().click();
    await page.waitForLoadState("networkidle", { timeout: 30_000 });

    // === Step 4 — téléchargement PDF ===
    // Le portail expose en général un bouton qui déclenche un download direct.
    const [download] = await Promise.all([
      page.waitForEvent("download", { timeout: 30_000 }),
      page.click('a:has-text("Télécharger"), button:has-text("Télécharger")'),
    ]);
    const stream = await download.createReadStream();
    if (!stream) {
      return { ok: false, reason: "unknown", message: "Stream PDF indisponible" };
    }
    const chunks: Buffer[] = [];
    for await (const chunk of stream) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    const pdf = Buffer.concat(chunks);

    // === Step 5 — extraction des dates de validité ===
    // L'attestation URSSAF est valide ~6 mois ; on peut parser une date "valable
    // jusqu'au JJ/MM/AAAA" depuis le PDF, ou se contenter d'un calcul J+180.
    const validFrom = new Date();
    const validUntil = new Date(validFrom);
    validUntil.setMonth(validUntil.getMonth() + 6);

    return { ok: true, pdf, validFrom, validUntil };
  } catch (err) {
    return {
      ok: false,
      reason: "unknown",
      message: err instanceof Error ? err.message : String(err),
    };
  } finally {
    if (browser) await browser.close().catch(() => {});
  }
}
