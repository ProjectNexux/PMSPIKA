import "server-only";
import { getServerSupabase } from "@/lib/db-server";
import { assertArray, assertObject } from "@/lib/utils";

/**
 * lib/pod-queries.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Lectures liées aux preuves de livraison (POD) : événements de livraison,
 * preuve signée, pièces jointes, URLs signées et KPIs.
 *
 * Toutes les lectures passent par le service role (getServerSupabase) — à n'appeler
 * que depuis des Server Components / Server Actions / Route Handlers.
 */

export type DeliveryEventType =
  | "enleve"
  | "en_transit"
  | "en_livraison"
  | "livre"
  | "echec"
  | "reserve";

export type DeliveryStatus =
  | "a_traiter"
  | "enleve"
  | "en_transit"
  | "en_livraison"
  | "livre"
  | "echec";

export type PodStatus = "livre" | "livre_avec_reserve" | "refuse";

export type DeliveryEvent = {
  id: string;
  mission_id: string;
  driver_id: string | null;
  event_type: DeliveryEventType;
  failure_reason: string | null;
  lat: number | null;
  lng: number | null;
  occurred_at: string;
  notes: string | null;
};

export type ProofOfDelivery = {
  id: string;
  company_id: string | null;
  mission_id: string;
  driver_id: string | null;
  recipient_name: string | null;
  status: PodStatus;
  reserve_text: string | null;
  signature_path: string | null;
  lat: number | null;
  lng: number | null;
  signed_at: string;
};

export type PodAttachment = {
  id: string;
  pod_id: string;
  kind: "photo" | "scan";
  file_path: string;
  barcode: string | null;
};

export type MissionDeliveryRow = {
  id: string;
  reference: string | null;
  company_id: string | null;
  driver_id: string | null;
  scheduled_date: string | null;
  scheduled_time: string | null;
  pickup_city: string | null;
  pickup_address: string | null;
  delivery_city: string | null;
  delivery_address: string | null;
  delivery_window_start: string | null;
  delivery_window_end: string | null;
  cargo_description: string | null;
  delivery_status: DeliveryStatus | null;
  delivered_at: string | null;
  pod_id: string | null;
};

const MISSION_DELIVERY_COLS =
  "id, reference, company_id, driver_id, scheduled_date, scheduled_time, " +
  "pickup_city, pickup_address, delivery_city, delivery_address, " +
  "delivery_window_start, delivery_window_end, cargo_description, " +
  "delivery_status, delivered_at, pod_id";

/** Détail complet de la livraison d'une mission (mission + events + POD + pièces). */
export async function getMissionDelivery(missionId: string): Promise<{
  mission: MissionDeliveryRow | null;
  events: DeliveryEvent[];
  pod: ProofOfDelivery | null;
  attachments: PodAttachment[];
}> {
  const sb = getServerSupabase();

  const { data: mission } = await sb
    .from("missions")
    .select(MISSION_DELIVERY_COLS)
    .eq("id", missionId)
    .maybeSingle();

  const { data: events } = await sb
    .from("delivery_events")
    .select("id, mission_id, driver_id, event_type, failure_reason, lat, lng, occurred_at, notes")
    .eq("mission_id", missionId)
    .order("occurred_at", { ascending: true });

  const { data: pod } = await sb
    .from("proof_of_delivery")
    .select("id, company_id, mission_id, driver_id, recipient_name, status, reserve_text, signature_path, lat, lng, signed_at")
    .eq("mission_id", missionId)
    .maybeSingle();

  let attachments: PodAttachment[] = [];
  if (pod) {
    const { data: att } = await sb
      .from("pod_attachments")
      .select("id, pod_id, kind, file_path, barcode")
      .eq("pod_id", (pod as ProofOfDelivery).id)
      .order("created_at", { ascending: true });
    attachments = assertArray<PodAttachment>(att, []);
  }

  return {
    mission: assertObject<MissionDeliveryRow>(mission, null),
    events: assertArray<DeliveryEvent>(events, []),
    pod: assertObject<ProofOfDelivery>(pod, null),
    attachments,
  };
}

/** Missions d'un chauffeur pour une date donnée, avec leur statut de livraison. */
export async function listDriverDeliveries(
  driverId: string,
  date: string,
): Promise<MissionDeliveryRow[]> {
  const sb = getServerSupabase();
  const { data } = await sb
    .from("missions")
    .select(MISSION_DELIVERY_COLS)
    .eq("driver_id", driverId)
    .eq("scheduled_date", date)
    .order("scheduled_time", { ascending: true, nullsFirst: false });
  return assertArray<MissionDeliveryRow>(data, []);
}

/** Missions rattachées à une tournée (via tournee_missions), avec statut de livraison. */
export async function listTourneeDeliveries(tourneeId: string): Promise<MissionDeliveryRow[]> {
  const sb = getServerSupabase();

  const { data: links } = await sb
    .from("tournee_missions")
    .select("mission_id, order")
    .eq("tournee_id", tourneeId)
    .order("order", { ascending: true });

  const ids = (links ?? []).map((l) => (l as { mission_id: string }).mission_id);
  if (ids.length === 0) return [];

  const { data } = await sb
    .from("missions")
    .select(MISSION_DELIVERY_COLS)
    .in("id", ids);

  const rows = (data ?? []) as unknown as MissionDeliveryRow[];
  // Conserver l'ordre de la tournée.
  const orderMap = new Map(ids.map((id, i) => [id, i]));
  return rows.sort((a, b) => (orderMap.get(a.id) ?? 0) - (orderMap.get(b.id) ?? 0));
}

/** URL signée (validité 1 h) pour un objet du bucket privé `pod-proofs`. */
export async function getPodSignedUrl(path: string | null): Promise<string | null> {
  if (!path) return null;
  const sb = getServerSupabase();
  const { data, error } = await sb.storage.from("pod-proofs").createSignedUrl(path, 3600);
  if (error || !data) return null;
  return data.signedUrl;
}

export type DeliveryKpis = {
  total: number;
  livrees: number;
  echecs: number;
  enCours: number;
  /** Taux de livraison dans la fenêtre (On-Time Delivery), en %. */
  otdPct: number;
};

/** KPIs de livraison à partir d'une liste de missions (logique pure). */
export function computeDeliveryKpis(missions: MissionDeliveryRow[]): DeliveryKpis {
  let livrees = 0;
  let echecs = 0;
  let enCours = 0;
  let onTime = 0;

  for (const m of missions) {
    const s = m.delivery_status ?? "a_traiter";
    if (s === "livre") {
      livrees++;
      if (isOnTime(m)) onTime++;
    } else if (s === "echec") {
      echecs++;
    } else if (s === "enleve" || s === "en_transit" || s === "en_livraison") {
      enCours++;
    }
  }

  const otdPct = livrees > 0 ? Math.round((onTime / livrees) * 100) : 0;
  return { total: missions.length, livrees, echecs, enCours, otdPct };
}

/** Une mission livrée est "à l'heure" si delivered_at est avant la fin de la fenêtre. */
function isOnTime(m: MissionDeliveryRow): boolean {
  if (!m.delivered_at || !m.scheduled_date || !m.delivery_window_end) return true;
  const delivered = new Date(m.delivered_at).getTime();
  const windowEnd = new Date(`${m.scheduled_date}T${m.delivery_window_end}`).getTime();
  if (isNaN(delivered) || isNaN(windowEnd)) return true;
  return delivered <= windowEnd;
}
