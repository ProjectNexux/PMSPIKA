/**
 * lib/auth.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Module legacy : conservé pour compat. La logique d'authentification réelle
 * vit désormais dans :
 *   - lib/session.ts          : helpers serveur (getCurrentUser, requireUser…)
 *   - lib/supabase-server.ts  : client Supabase SSR (cookies)
 *   - lib/supabase-browser.ts : client Supabase navigateur
 *   - middleware.ts           : garde-fou auth + redirections par rôle
 *
 * L'authentification utilise Supabase Auth (email/mot de passe).
 * Les rôles applicatifs sont définis dans l'enum public.app_role :
 *   super_admin, gerant_groupe, gerant_societe, chef_site, chauffeur, client.
 */

export type {
  AppRole as UserRole,
  CurrentUser as SessionUser,
} from "./session";

export {
  getCurrentUser,
  requireUser,
  requireRole,
  homeForRole,
  canAccessHub,
  canAccessCompany,
  canAccessSite,
} from "./session";
