import { supabase } from "@/lib/db";
import { computeProfitability, type ProfitabilityBreakdown } from "@/lib/profitability";
import { assertArray, assertObject } from "@/lib/utils";
/* ──────────────────────────────────────────────────────────────────────────
   Types riches pour le planning (tournées + missions liées)
   ────────────────────────────────────────────────────────────────────────── */

export type PlanningStatus =
  | "draft" | "scheduled" | "in_progress" | "completed" | "cancelled";

export type PlanningMission = {
  id: string;
  reference: string;
  status: string;
  scheduled_date: string;
  scheduled_time: string | null;
  pickup_city: string;
  pickup_address: string;
  delivery_city: string;
  delivery_address: string;
  delivery_window_start: string | null;
  delivery_window_end: string | null;
  distance_km: number | null;
  cargo_description: string | null;
  price: number | null;
  priority: string | null;
  driver_id: string | null;
  vehicle_id: string | null;
  client_id: string | null;
  client_name: string | null;
  pickup_lat: number | null;
  pickup_lng: number | null;
  delivery_lat: number | null;
  delivery_lng: number | null;
  requires_adr: boolean | null;
  /** tournee_missions.order if attached, null otherwise */
  stop_order: number | null;
};

export type PlanningTournee = {
  id: string;
  reference: string;
  name: string;
  status: PlanningStatus;
  scheduled_date: string;
  notes: string | null;
  total_distance_km: number | null;
  actual_start: string | null;
  actual_end: string | null;
  driver_id: string | null;
  driver_name: string | null;
  vehicle_id: string | null;
  vehicle_plate: string | null;
  vehicle_brand: string | null;
  vehicle_model: string | null;
  recurrence_type: string | null;
  recurrence_group_id: string | null;
  subcontractor_id: string | null;
  subcontractor_name: string | null;
  missions: PlanningMission[];

  /* ── Rentabilité (saisi) ── */
  flat_rate_revenue: number | null;
  surcharge_fuel: number | null;
  surcharge_adr: number | null;
  surcharge_wait: number | null;
  surcharge_other: number | null;
  other_revenue: number | null;
  toll_cost: number | null;
  fuel_cost_override: number | null;
  driver_cost_override: number | null;
  vehicle_cost_override: number | null;
  subcontractor_cost: number | null;
  cold_unit_cost_override: number | null;
  maintenance_cost_override: number | null;
  tire_cost_override: number | null;
  misc_cost: number | null;
  estimated_hours: number | null;

  /** Rentabilité calculée (revenus, coûts, marge, %). */
  profitability: ProfitabilityBreakdown;
};

export type PlanningStats = {
  total: number;
  scheduled: number;
  in_progress: number;
  completed: number;
  draft: number;
  cancelled: number;
  total_distance: number;
  assigned_count: number;
  unassigned_count: number;
  /* Rentabilité agrégée période */
  total_revenue: number;
  total_cost: number;
  total_margin: number;
  margin_pct: number | null;
};

/* ──────────────────────────────────────────────────────────────────────────
   Récupération des tournées d'une société sur une plage [start, end]
   ────────────────────────────────────────────────────────────────────────── */

type TourneeRaw = {
  id: string;
  reference: string;
  name: string;
  status: PlanningStatus;
  scheduled_date: string;
  notes: string | null;
  total_distance_km: number | null;
  actual_start: string | null;
  actual_end: string | null;
  driver_id: string | null;
  vehicle_id: string | null;
  recurrence_type: string | null;
  recurrence_group_id: string | null;
  subcontractor_id: string | null;
  // Rentabilité
  flat_rate_revenue: number | null;
  surcharge_fuel: number | null;
  surcharge_adr: number | null;
  surcharge_wait: number | null;
  surcharge_other: number | null;
  other_revenue: number | null;
  toll_cost: number | null;
  fuel_cost_override: number | null;
  driver_cost_override: number | null;
  vehicle_cost_override: number | null;
  subcontractor_cost: number | null;
  cold_unit_cost_override: number | null;
  maintenance_cost_override: number | null;
  tire_cost_override: number | null;
  misc_cost: number | null;
  estimated_hours: number | null;
};

type ContractorLite = { id: string; name: string };
type DriverLite   = { id: string; full_name: string; hourly_cost_rate?: number | null; employee_id?: string | null };
type VehicleLite  = {
  id: string;
  plate_number: string;
  brand: string;
  model: string;
  fuel_consumption_l_100km?: number | null;
  fuel_price_per_l?: number | null;
  amortization_per_km?: number | null;
  tire_cost_per_km?: number | null;
  maintenance_cost_per_km?: number | null;
  has_cold_unit?: boolean | null;
  cold_unit_cost_per_hour?: number | null;
};
type ClientLite   = { id: string; company_name: string };
type LinkRow      = { tournee_id: string; mission_id: string; order: number };
type MissionRaw   = {
  id: string;
  reference: string;
  status: string;
  scheduled_date: string;
  scheduled_time: string | null;
  pickup_city: string;
  pickup_address: string;
  delivery_city: string;
  delivery_address: string;
  delivery_window_start: string | null;
  delivery_window_end: string | null;
  distance_km: number | null;
  cargo_description: string | null;
  price: number | null;
  priority: string | null;
  driver_id: string | null;
  vehicle_id: string | null;
  client_id: string | null;
  pickup_lat: number | null;
  pickup_lng: number | null;
  delivery_lat: number | null;
  delivery_lng: number | null;
  requires_adr: boolean | null;
};

const TOURNEE_COLS =
  "id, reference, name, status, scheduled_date, notes, total_distance_km, " +
  "actual_start, actual_end, driver_id, vehicle_id, recurrence_type, recurrence_group_id, subcontractor_id, " +
  "flat_rate_revenue, surcharge_fuel, surcharge_adr, surcharge_wait, surcharge_other, other_revenue, " +
  "toll_cost, fuel_cost_override, driver_cost_override, vehicle_cost_override, subcontractor_cost, " +
  "cold_unit_cost_override, maintenance_cost_override, tire_cost_override, misc_cost, estimated_hours";

const MISSION_COLS =
  "id, reference, status, scheduled_date, scheduled_time, pickup_city, pickup_address, " +
  "delivery_city, delivery_address, delivery_window_start, delivery_window_end, " +
  "distance_km, cargo_description, price, priority, driver_id, vehicle_id, client_id, " +
  "pickup_lat, pickup_lng, delivery_lat, delivery_lng, requires_adr";

/**
 * Charge un planning complet pour une société sur une plage de dates.
 * Inclut tournées + missions rattachées + missions libres + référentiels.
 */
export async function getPlanning(
  companyId: string,
  start: string,
  end: string,
) {
  // 1) Tournées de la société sur la plage
  const { data: tourneesRaw } = await supabase
    .from("tournees")
    .select(TOURNEE_COLS)
    .eq("company_id", companyId)
    .gte("scheduled_date", start)
    .lte("scheduled_date", end)
    .order("scheduled_date", { ascending: true });

  const tournees = assertArray<TourneeRaw>(tourneesRaw, []);
  const tourneeIds = tournees.map((t) => t.id);

  // 2) Liens tournee_missions
  const { data: linksRaw } = tourneeIds.length
    ? await supabase
        .from("tournee_missions")
        .select("tournee_id, mission_id, order")
        .in("tournee_id", tourneeIds)
    : { data: [] as LinkRow[] };
  const links = assertArray<LinkRow>(linksRaw, []);

  // 3) Missions de la société sur la plage (rattachées + libres)
  const { data: missionsRaw } = await supabase
    .from("missions")
    .select(MISSION_COLS)
    .eq("company_id", companyId)
    .gte("scheduled_date", start)
    .lte("scheduled_date", end)
    .order("scheduled_date", { ascending: true })
    .order("scheduled_time", { ascending: true, nullsFirst: false });
  const missions = assertArray<MissionRaw>(missionsRaw, []);

  // 4) Référentiels
  const [drivers, vehicles, clients, contractorsRes] = await Promise.all([
    supabase.from("profiles").select("id, full_name, hourly_cost_rate, employee_id").eq("role", "driver").order("full_name"),
    supabase
      .from("tms_vehicles")
      .select(
        "id, plate_number, brand, model, fuel_consumption_l_100km, fuel_price_per_l, " +
        "amortization_per_km, tire_cost_per_km, maintenance_cost_per_km, has_cold_unit, cold_unit_cost_per_hour",
      )
      .eq("company_id", companyId)
      .order("plate_number"),
    supabase.from("clients").select("id, company_name").order("company_name"),
    supabase.rpc("get_contractors_by_company", { p_company_id: companyId }),
  ]);
  const driverList      = assertArray<DriverLite>(drivers.data, []);
  const vehicleList     = assertArray<VehicleLite>(vehicles.data, []);
  const clientList      = assertArray<ClientLite>(clients.data, []);
  const contractorList  = assertArray<{ id: string; name: string }>(contractorsRes.data, []).map(
    (c): ContractorLite => ({ id: c.id, name: c.name }),
  );

  // 4b) Coûts horaires employeur depuis la fiche salarié (prioritaires sur profiles.hourly_cost_rate)
  const employeeIds = driverList.map((d) => d.employee_id).filter((x): x is string => !!x);
  const employeeCostMap = new Map<string, number | null>();
  if (employeeIds.length > 0) {
    const { data: empRates } = await supabase
      .from("employees")
      .select("id, hourly_cost_rate")
      .in("id", employeeIds);
    for (const e of (empRates ?? []) as { id: string; hourly_cost_rate: number | null }[]) {
      employeeCostMap.set(e.id, e.hourly_cost_rate);
    }
  }

  // Aplatit le taux effectif (employé prioritaire, fallback sur profil) sur chaque driver,
  // pour que la prévisualisation client (AssignModal) utilise la même valeur que le serveur.
  for (const d of driverList) {
    const empRate = d.employee_id ? employeeCostMap.get(d.employee_id) ?? null : null;
    d.hourly_cost_rate = empRate ?? d.hourly_cost_rate ?? null;
  }

  const driverMap       = new Map(driverList.map((d) => [d.id, d.full_name]));
  const driverRateMap   = new Map(driverList.map((d) => [d.id, d.hourly_cost_rate ?? null]));
  const vehicleMap      = new Map(vehicleList.map((v) => [v.id, v]));
  const clientMap       = new Map(clientList.map((c) => [c.id, c.company_name]));
  const contractorMap   = new Map(contractorList.map((c) => [c.id, c.name]));

  // 5) Index missions
  const missionById = new Map<string, PlanningMission>();
  for (const m of missions) {
    missionById.set(m.id, {
      ...m,
      client_name: m.client_id ? clientMap.get(m.client_id) ?? null : null,
      stop_order: null,
    });
  }

  // 6) Index liens par tournée
  const linksByTournee = new Map<string, LinkRow[]>();
  for (const l of links) {
    const arr = linksByTournee.get(l.tournee_id) ?? [];
    arr.push(l);
    linksByTournee.set(l.tournee_id, arr);
  }

  // 7) Construction des tournées enrichies
  const attached = new Set<string>();
  const planningTournees: PlanningTournee[] = tournees.map((t) => {
    const v = t.vehicle_id ? vehicleMap.get(t.vehicle_id) : undefined;
    const tLinks = (linksByTournee.get(t.id) ?? []).sort((a, b) => a.order - b.order);
    const tMissions: PlanningMission[] = [];
    for (const l of tLinks) {
      const m = missionById.get(l.mission_id);
      if (m) {
        attached.add(m.id);
        tMissions.push({ ...m, stop_order: l.order });
      }
    }
    const missionsRevenue = tMissions.reduce((s, m) => s + (m.price ?? 0), 0);
    const profitability = computeProfitability({
      total_distance_km: t.total_distance_km,
      estimated_hours: t.estimated_hours,
      flat_rate_revenue: t.flat_rate_revenue,
      surcharge_fuel: t.surcharge_fuel,
      surcharge_adr: t.surcharge_adr,
      surcharge_wait: t.surcharge_wait,
      surcharge_other: t.surcharge_other,
      other_revenue: t.other_revenue,
      missions_revenue: missionsRevenue,
      toll_cost: t.toll_cost,
      fuel_cost_override: t.fuel_cost_override,
      driver_cost_override: t.driver_cost_override,
      vehicle_cost_override: t.vehicle_cost_override,
      subcontractor_cost: t.subcontractor_cost,
      cold_unit_cost_override: t.cold_unit_cost_override,
      maintenance_cost_override: t.maintenance_cost_override,
      tire_cost_override: t.tire_cost_override,
      misc_cost: t.misc_cost,
      fuel_consumption_l_100km: v?.fuel_consumption_l_100km ?? null,
      fuel_price_per_l: v?.fuel_price_per_l ?? null,
      amortization_per_km: v?.amortization_per_km ?? null,
      tire_cost_per_km: v?.tire_cost_per_km ?? null,
      maintenance_cost_per_km: v?.maintenance_cost_per_km ?? null,
      has_cold_unit: v?.has_cold_unit ?? null,
      cold_unit_cost_per_hour: v?.cold_unit_cost_per_hour ?? null,
      driver_hourly_cost: t.driver_id ? driverRateMap.get(t.driver_id) ?? null : null,
    });

    return {
      id: t.id,
      reference: t.reference,
      name: t.name,
      status: t.status,
      scheduled_date: t.scheduled_date,
      notes: t.notes,
      total_distance_km: t.total_distance_km,
      actual_start: t.actual_start,
      actual_end: t.actual_end,
      driver_id: t.driver_id,
      driver_name: t.driver_id ? driverMap.get(t.driver_id) ?? null : null,
      vehicle_id: t.vehicle_id,
      vehicle_plate: v?.plate_number ?? null,
      vehicle_brand: v?.brand ?? null,
      vehicle_model: v?.model ?? null,
      recurrence_type: t.recurrence_type,
      recurrence_group_id: t.recurrence_group_id,
      subcontractor_id: t.subcontractor_id,
      subcontractor_name: t.subcontractor_id ? contractorMap.get(t.subcontractor_id) ?? null : null,
      missions: tMissions,
      flat_rate_revenue: t.flat_rate_revenue,
      surcharge_fuel: t.surcharge_fuel,
      surcharge_adr: t.surcharge_adr,
      surcharge_wait: t.surcharge_wait,
      surcharge_other: t.surcharge_other,
      other_revenue: t.other_revenue,
      toll_cost: t.toll_cost,
      fuel_cost_override: t.fuel_cost_override,
      driver_cost_override: t.driver_cost_override,
      vehicle_cost_override: t.vehicle_cost_override,
      subcontractor_cost: t.subcontractor_cost,
      cold_unit_cost_override: t.cold_unit_cost_override,
      maintenance_cost_override: t.maintenance_cost_override,
      tire_cost_override: t.tire_cost_override,
      misc_cost: t.misc_cost,
      estimated_hours: t.estimated_hours,
      profitability,
    };
  });

  // 8) Missions libres (non rattachées)
  const looseMissions: PlanningMission[] = [];
  for (const [id, m] of missionById) {
    if (!attached.has(id)) looseMissions.push(m);
  }

  // 9) Stats
  const total_revenue = planningTournees.reduce((s, t) => s + t.profitability.revenue, 0);
  const total_cost    = planningTournees.reduce((s, t) => s + t.profitability.cost, 0);
  const total_margin  = total_revenue - total_cost;
  const stats: PlanningStats = {
    total:          planningTournees.length,
    scheduled:      planningTournees.filter((t) => t.status === "scheduled").length,
    in_progress:    planningTournees.filter((t) => t.status === "in_progress").length,
    completed:      planningTournees.filter((t) => t.status === "completed").length,
    draft:          planningTournees.filter((t) => t.status === "draft").length,
    cancelled:      planningTournees.filter((t) => t.status === "cancelled").length,
    total_distance: planningTournees.reduce((s, t) => s + (t.total_distance_km ?? 0), 0),
    assigned_count: planningTournees.filter((t) => t.driver_id && t.vehicle_id).length,
    unassigned_count: planningTournees.filter((t) => !t.driver_id || !t.vehicle_id).length,
    total_revenue,
    total_cost,
    total_margin,
    margin_pct: total_revenue > 0 ? (total_margin / total_revenue) * 100 : null,
  };

  return {
    tournees: planningTournees,
    looseMissions,
    drivers: driverList,
    vehicles: vehicleList,
    clients: clientList,
    contractors: contractorList,
    stats,
    range: { start, end },
  };
}

export type PlanningPayload = Awaited<ReturnType<typeof getPlanning>>;

/* ──────────────────────────────────────────────────────────────────────────
   Détection de conflits (utilisée côté client pour avertir)
   ────────────────────────────────────────────────────────────────────────── */

export type Conflict = {
  type: "driver" | "vehicle";
  resourceId: string;
  resourceLabel: string;
  conflictWith: { tourneeId: string; reference: string; date: string };
};

/** Calcule les conflits pour une (date, driver, vehicle) candidats. Côté client. */
export function detectConflicts(
  tournees: PlanningTournee[],
  candidate: { tourneeId?: string; date: string; driver_id?: string | null; vehicle_id?: string | null },
): Conflict[] {
  const out: Conflict[] = [];
  for (const t of tournees) {
    if (t.id === candidate.tourneeId) continue;
    if (t.scheduled_date !== candidate.date) continue;
    if (t.status === "cancelled" || t.status === "completed") continue;

    if (candidate.driver_id && t.driver_id === candidate.driver_id) {
      out.push({
        type: "driver",
        resourceId: candidate.driver_id,
        resourceLabel: t.driver_name ?? "Chauffeur",
        conflictWith: { tourneeId: t.id, reference: t.reference, date: t.scheduled_date },
      });
    }
    if (candidate.vehicle_id && t.vehicle_id === candidate.vehicle_id) {
      out.push({
        type: "vehicle",
        resourceId: candidate.vehicle_id,
        resourceLabel: t.vehicle_plate ?? "Véhicule",
        conflictWith: { tourneeId: t.id, reference: t.reference, date: t.scheduled_date },
      });
    }
  }
  return out;
}

/* ──────────────────────────────────────────────────────────────────────────
   Helpers de dates
   ────────────────────────────────────────────────────────────────────────── */

/** Renvoie le lundi (lundi=jour 0) de la semaine ISO de `d`. */
export function startOfWeek(d: Date): Date {
  const dt = new Date(d);
  dt.setHours(0, 0, 0, 0);
  const day = dt.getDay(); // 0=Sun, 1=Mon, ...
  const diff = day === 0 ? -6 : 1 - day;
  dt.setDate(dt.getDate() + diff);
  return dt;
}

export function addDays(d: Date, n: number): Date {
  const dt = new Date(d);
  dt.setDate(dt.getDate() + n);
  return dt;
}

export function toIsoDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

/* ──────────────────────────────────────────────────────────────────────────
   Live map : chauffeurs + sites + missions actives (positions GPS)
   ────────────────────────────────────────────────────────────────────────── */

export type DriverPosition = {
  id: string;
  full_name: string;
  lat: number;
  lng: number;
  last_position_at: string | null;
  current_mission_ref: string | null;
};

export type TmsSitePoint = {
  id: string;
  name: string;
  address: string | null;
  city: string;
  lat: number;
  lng: number;
};

export type MapData = {
  drivers: DriverPosition[];
  sites: TmsSitePoint[];
  /** Missions de la plage avec coordonnées. On reuse PlanningMission. */
  missions: PlanningMission[];
};

/**
 * Charge les données de la carte temps réel pour une société.
 * - drivers : positions GPS connues (profiles.last_lat/lng)
 * - sites   : entrepôts/hubs (tms_sites)
 * - missions: missions de la société sur la plage avec coordonnées
 */
export async function getMapData(
  companyId: string,
  start: string,
  end: string,
): Promise<MapData> {
  // 1) Chauffeurs avec position connue, et leur mission "active" (in_progress
  //    ou assigned aujourd'hui) pour annoter le marker
  const [{ data: driversRaw }, { data: sitesRaw }, { data: missionsRaw }] = await Promise.all([
    supabase
      .from("profiles")
      .select("id, full_name, last_lat, last_lng, last_position_at")
      .eq("role", "chauffeur")
      .not("last_lat", "is", null)
      .not("last_lng", "is", null),
    supabase
      .from("tms_sites")
      .select("id, name, address, city, lat, lng")
      .not("lat", "is", null)
      .not("lng", "is", null),
    supabase
      .from("missions")
      .select(
        "id, reference, status, scheduled_date, scheduled_time, pickup_city, pickup_address, " +
        "delivery_city, delivery_address, delivery_window_start, delivery_window_end, " +
        "distance_km, cargo_description, price, priority, driver_id, vehicle_id, client_id, " +
        "pickup_lat, pickup_lng, delivery_lat, delivery_lng, requires_adr",
      )
      .eq("company_id", companyId)
      .gte("scheduled_date", start)
      .lte("scheduled_date", end)
      .not("pickup_lat", "is", null),
  ]);

  // Index du driver -> dernière mission active (in_progress > assigned > most recent)
  const allDriverIds = (driversRaw ?? []).map((d: { id: string }) => d.id);
  let activeByDriver = new Map<string, string>();
  if (allDriverIds.length) {
    const today = new Date().toISOString().slice(0, 10);
    const { data: active } = await supabase
      .from("missions")
      .select("driver_id, reference, status, scheduled_date")
      .in("driver_id", allDriverIds)
      .in("status", ["in_progress", "assigned"])
      .gte("scheduled_date", today)
      .order("scheduled_date", { ascending: true });
    for (const m of assertArray<{ driver_id: string; reference: string; status: string }>(active, [])) {
      if (!activeByDriver.has(m.driver_id)) activeByDriver.set(m.driver_id, m.reference);
    }
  }

  const drivers: DriverPosition[] = assertArray<{
    id: string; full_name: string; last_lat: number; last_lng: number; last_position_at: string | null;
  }>(driversRaw, []).map((d) => ({
    id: d.id,
    full_name: d.full_name,
    lat: Number(d.last_lat),
    lng: Number(d.last_lng),
    last_position_at: d.last_position_at,
    current_mission_ref: activeByDriver.get(d.id) ?? null,
  }));

  const sites: TmsSitePoint[] = assertArray<{
    id: string; name: string; address: string | null; city: string; lat: number; lng: number;
  }>(sitesRaw, []).map((s) => ({ ...s, lat: Number(s.lat), lng: Number(s.lng) }));

  const missions: PlanningMission[] = assertArray<MissionRaw>(missionsRaw, []).map((m) => ({
    ...m,
    client_name: null,
    stop_order: null,
  }));

  return { drivers, sites, missions };
}

/**
 * Variante globale (toutes sociétés) pour le tableau de bord principal.
 * Identique à getMapData mais sans filtre sur company_id.
 */
export async function getMapDataGlobal(
  start: string,
  end: string,
): Promise<MapData> {
  const [{ data: driversRaw }, { data: sitesRaw }, { data: missionsRaw }] = await Promise.all([
    supabase
      .from("profiles")
      .select("id, full_name, last_lat, last_lng, last_position_at")
      .eq("role", "chauffeur")
      .not("last_lat", "is", null)
      .not("last_lng", "is", null),
    supabase
      .from("tms_sites")
      .select("id, name, address, city, lat, lng")
      .not("lat", "is", null)
      .not("lng", "is", null),
    supabase
      .from("missions")
      .select(
        "id, reference, status, scheduled_date, scheduled_time, pickup_city, pickup_address, " +
        "delivery_city, delivery_address, delivery_window_start, delivery_window_end, " +
        "distance_km, cargo_description, price, priority, driver_id, vehicle_id, client_id, " +
        "pickup_lat, pickup_lng, delivery_lat, delivery_lng, requires_adr",
      )
      .gte("scheduled_date", start)
      .lte("scheduled_date", end)
      .not("pickup_lat", "is", null),
  ]);

  const allDriverIds = (driversRaw ?? []).map((d: { id: string }) => d.id);
  const activeByDriver = new Map<string, string>();
  if (allDriverIds.length) {
    const today = new Date().toISOString().slice(0, 10);
    const { data: active } = await supabase
      .from("missions")
      .select("driver_id, reference, status, scheduled_date")
      .in("driver_id", allDriverIds)
      .in("status", ["in_progress", "assigned"])
      .gte("scheduled_date", today)
      .order("scheduled_date", { ascending: true });
    for (const m of (active ?? []) as { driver_id: string; reference: string; status: string }[]) {
      if (!activeByDriver.has(m.driver_id)) activeByDriver.set(m.driver_id, m.reference);
    }
  }

  const drivers: DriverPosition[] = assertArray<{
    id: string; full_name: string; last_lat: number; last_lng: number; last_position_at: string | null;
  }>(driversRaw, []).map((d) => ({
    id: d.id,
    full_name: d.full_name,
    lat: Number(d.last_lat),
    lng: Number(d.last_lng),
    last_position_at: d.last_position_at,
    current_mission_ref: activeByDriver.get(d.id) ?? null,
  }));

  const sites: TmsSitePoint[] = assertArray<{
    id: string; name: string; address: string | null; city: string; lat: number; lng: number;
  }>(sitesRaw, []).map((s) => ({ ...s, lat: Number(s.lat), lng: Number(s.lng) }));

  const missions: PlanningMission[] = assertArray<MissionRaw>(missionsRaw, []).map((m) => ({
    ...m,
    client_name: null,
    stop_order: null,
  }));

  return { drivers, sites, missions };
}

