import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/**
 * Client Supabase côté serveur, utilise la SERVICE ROLE KEY.
 * À n'utiliser QUE dans des Server Actions / route handlers — jamais dans un composant client.
 * Cette clé bypass la RLS, donc protège les fichiers où elle est importée.
 */
let cached: SupabaseClient | null = null;

function cleanEnv(value: string | undefined): string {
  if (!value) return "";
  const trimmed = value.trim();
  // Accept values copied with surrounding quotes in .env files.
  return trimmed.replace(/^(["'])(.*)\1$/, "$2").trim();
}

function resolveServiceKey(): string {
  return cleanEnv(
    process.env.SUPABASE_SERVICE_ROLE_KEY
    ?? process.env.SUPABASE_SECRET_KEY
    ?? process.env.SUPABASE_SERVICE_KEY,
  );
}

export function getServerSupabase(): SupabaseClient {
  if (cached) return cached;
  const url = cleanEnv(process.env.NEXT_PUBLIC_SUPABASE_URL);
  const serviceKey = resolveServiceKey();
  if (!url || !serviceKey) {
    throw new Error(
      "Configuration Supabase invalide: renseignez NEXT_PUBLIC_SUPABASE_URL et une clé serveur (SUPABASE_SERVICE_ROLE_KEY ou SUPABASE_SECRET_KEY) valides dans .env.local.",
    );
  }

  cached = createClient(url, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
  return cached;
}
