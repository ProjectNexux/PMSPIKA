import "server-only";
import { cookies } from "next/headers";

export type FlashKind = "success" | "error" | "info" | "warning";

export type Flash = {
  kind: FlashKind;
  message: string;
};

const COOKIE_NAME = "jt_flash";

/**
 * À appeler depuis une server action AVANT `redirect()` ou `revalidatePath()`.
 * Le message sera affiché par le toaster client au prochain rendu.
 */
export async function setFlash(flash: Flash): Promise<void> {
  const store = await cookies();
  store.set(COOKIE_NAME, JSON.stringify(flash), {
    httpOnly: false, // lu côté client par le toaster
    sameSite: "lax",
    path: "/",
    maxAge: 30, // courte durée : juste le temps du prochain rendu
  });
}

/**
 * Lit puis efface le flash courant. À appeler depuis un Server Component
 * (typiquement le layout racine) qui passe la valeur au toaster client.
 */
export async function consumeFlash(): Promise<Flash | null> {
  const store = await cookies();
  const raw = store.get(COOKIE_NAME)?.value;
  if (!raw) return null;
  try {
    store.delete(COOKIE_NAME);
  } catch {
    // delete depuis un RSC peut throw selon le contexte ; ignoré.
  }
  try {
    const parsed = JSON.parse(raw) as Flash;
    if (
      parsed &&
      typeof parsed.message === "string" &&
      ["success", "error", "info", "warning"].includes(parsed.kind)
    ) {
      return parsed;
    }
  } catch {
    /* ignore */
  }
  return null;
}

export const flashSuccess = (message: string) => setFlash({ kind: "success", message });
export const flashError = (message: string) => setFlash({ kind: "error", message });
export const flashInfo = (message: string) => setFlash({ kind: "info", message });
export const flashWarning = (message: string) => setFlash({ kind: "warning", message });
