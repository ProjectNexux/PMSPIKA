import { supabase } from "@/lib/db";
import { getServerSupabase } from "@/lib/db-server";
import { decryptSecret, encryptSecret } from "@/lib/crypto";

export const URSSAF_BUCKET = "urssaf-attestations";

export type UrssafCredentialPublic = {
  company_id: string;
  username: string;
  portal: "net-entreprises" | "urssaf-direct";
  mfa_method: string | null;
  contact_email: string | null;
  enabled: boolean;
  last_run_at: string | null;
  last_run_status: "ok" | "error" | "skipped" | "mfa_required" | null;
  last_run_error: string | null;
  updated_at: string;
};

export type UrssafAttestationRow = {
  id: string;
  company_id: string;
  period: string;
  storage_path: string;
  file_size: number | null;
  valid_from: string | null;
  valid_until: string | null;
  status: "Valide" | "Expire bientot" | "Expiree" | "Erreur";
  source: "auto" | "manuel";
  downloaded_at: string;
};

/** Lecture sans le mot de passe — utilisée pour l'UI. */
export async function getUrssafCredentialPublic(
  companyId: string,
): Promise<UrssafCredentialPublic | null> {
  const { data, error } = await supabase
    .from("urssaf_credentials")
    .select(
      "company_id, username, portal, mfa_method, contact_email, enabled, last_run_at, last_run_status, last_run_error, updated_at",
    )
    .eq("company_id", companyId)
    .maybeSingle();
  if (error) {
    // Anon n'a pas accès — c'est attendu en mode prototype. On retourne null.
    console.warn("[urssaf] getUrssafCredentialPublic:", error.message);
    return null;
  }
  return (data as UrssafCredentialPublic) ?? null;
}

/** Lecture côté serveur uniquement : renvoie aussi le mot de passe déchiffré. */
export async function getUrssafCredentialFull(
  companyId: string,
): Promise<(UrssafCredentialPublic & { password: string }) | null> {
  const admin = getServerSupabase();
  const { data, error } = await admin
    .from("urssaf_credentials")
    .select("*")
    .eq("company_id", companyId)
    .maybeSingle();
  if (error) throw new Error(`urssaf_credentials read: ${error.message}`);
  if (!data) return null;
  const password = decryptSecret({
    ciphertext: data.password_ciphertext,
    iv: data.password_iv,
    tag: data.password_tag,
  });
  return { ...(data as UrssafCredentialPublic), password };
}

export async function upsertUrssafCredential(input: {
  companyId: string;
  username: string;
  password: string;
  portal?: "net-entreprises" | "urssaf-direct";
  mfaMethod?: string | null;
  contactEmail?: string | null;
  enabled?: boolean;
}) {
  const admin = getServerSupabase();
  const enc = encryptSecret(input.password);
  const { error } = await admin
    .from("urssaf_credentials")
    .upsert(
      {
        company_id: input.companyId,
        username: input.username,
        password_ciphertext: enc.ciphertext,
        password_iv: enc.iv,
        password_tag: enc.tag,
        portal: input.portal ?? "net-entreprises",
        mfa_method: input.mfaMethod ?? null,
        contact_email: input.contactEmail ?? null,
        enabled: input.enabled ?? true,
      },
      { onConflict: "company_id" },
    );
  if (error) throw new Error(`urssaf_credentials upsert: ${error.message}`);
}

export async function deleteUrssafCredential(companyId: string) {
  const admin = getServerSupabase();
  const { error } = await admin
    .from("urssaf_credentials")
    .delete()
    .eq("company_id", companyId);
  if (error) throw new Error(`urssaf_credentials delete: ${error.message}`);
}

export async function listAllEnabledCredentials() {
  const admin = getServerSupabase();
  const { data, error } = await admin
    .from("urssaf_credentials")
    .select("company_id")
    .eq("enabled", true);
  if (error) throw new Error(`urssaf_credentials list: ${error.message}`);
  return (data as { company_id: string }[]) ?? [];
}

export async function recordRunResult(
  companyId: string,
  status: "ok" | "error" | "skipped" | "mfa_required",
  error?: string | null,
) {
  const admin = getServerSupabase();
  await admin
    .from("urssaf_credentials")
    .update({
      last_run_at: new Date().toISOString(),
      last_run_status: status,
      last_run_error: error ?? null,
    })
    .eq("company_id", companyId);
}

export async function getAttestations(companyId: string, limit = 24) {
  const { data, error } = await supabase
    .from("urssaf_attestations")
    .select("*")
    .eq("company_id", companyId)
    .order("period", { ascending: false })
    .limit(limit);
  if (error) {
    console.warn("[urssaf] getAttestations:", error.message);
    return [];
  }
  return (data as UrssafAttestationRow[]) ?? [];
}

export async function saveAttestation(input: {
  companyId: string;
  period: string;
  pdf: Buffer;
  validFrom?: Date | null;
  validUntil?: Date | null;
  source?: "auto" | "manuel";
}) {
  const admin = getServerSupabase();
  const storagePath = `${input.companyId}/${input.period}.pdf`;

  const { error: upErr } = await admin.storage
    .from(URSSAF_BUCKET)
    .upload(storagePath, input.pdf, {
      contentType: "application/pdf",
      upsert: true,
    });
  if (upErr) throw new Error(`storage upload: ${upErr.message}`);

  const { error: dbErr } = await admin
    .from("urssaf_attestations")
    .upsert(
      {
        company_id: input.companyId,
        period: input.period,
        storage_path: storagePath,
        file_size: input.pdf.byteLength,
        valid_from: input.validFrom?.toISOString().slice(0, 10) ?? null,
        valid_until: input.validUntil?.toISOString().slice(0, 10) ?? null,
        status: "Valide",
        source: input.source ?? "auto",
        downloaded_at: new Date().toISOString(),
      },
      { onConflict: "company_id,period" },
    );
  if (dbErr) throw new Error(`urssaf_attestations upsert: ${dbErr.message}`);

  return { storagePath };
}

export async function signedAttestationUrl(storagePath: string, expiresIn = 300) {
  const admin = getServerSupabase();
  const { data, error } = await admin.storage
    .from(URSSAF_BUCKET)
    .createSignedUrl(storagePath, expiresIn);
  if (error) throw new Error(`signed url: ${error.message}`);
  return data.signedUrl;
}

export function currentPeriod(): string {
  const d = new Date();
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}
