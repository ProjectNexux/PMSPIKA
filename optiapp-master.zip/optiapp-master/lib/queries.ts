import { rpc, rpcOne, supabase } from "@/lib/db";

export type Totals = {
  companies: number;
  sites: number;
  monthly_routes: number;
  employees: number;
  vehicles: number;
  contractors: number;
  open_tasks: number;
  risky_documents: number;
  revenue: number;
  expenses: number;
};

export type CompanySummary = {
  id: string;
  name: string;
  legal_name: string | null;
  color: string;
  notes: string | null;
  site_count: number;
  monthly_routes: number;
  employees: number;
  vehicles: number;
  revenue: number;
  expenses: number;
};

export type SiteRow = {
  id: string;
  company_id: string;
  company_name: string;
  company_color: string;
  name: string;
  region: string;
  mode: string;
  monthly_routes: number;
  vehicles_target: number;
  employees_target: number;
  observations: string | null;
  actual_employees: number;
  actual_vehicles: number;
  contractor_count: number;
  completed_routes: number | null;
  incidents: number | null;
  on_time_rate: number | null;
};

export type EmployeeRow = {
  id: string;
  first_name: string;
  last_name: string;
  role: string;
  contract_type: string;
  status: string;
  hire_date: string;
  email: string | null;
  phone: string | null;
  company_id?: string;
  site_id?: string;
  company_name: string;
  site_name: string;
  // Payroll base (added in pré-paie migration)
  pay_mode?: "mensualise" | "horaire";
  monthly_gross_salary?: number | null;
  hourly_rate?: number | null;
  contract_hours?: number | null;
  meal_allowance_daily?: number | null;
  pay_notes?: string | null;
  tournee_rate?: number | null;
  hourly_cost_rate?: number | null;
  // HR identity / contact (added in HR migration)
  social_security_number?: string | null;
  birth_date?: string | null;
  birth_place?: string | null;
  nationality?: string | null;
  residence_permit_expiry?: string | null;
  address?: string | null;
  profile_id?: string | null;
  profile_label?: string | null;
};

export type VehicleRow = {
  id: string;
  plate: string;
  brand: string;
  model: string;
  status: string;
  mileage: number;
  next_inspection: string | null;
  insurance_due_date: string | null;
  vin: string | null;
  year: number | null;
  fuel_type: string | null;
  ptac: number | null;
  acquisition_type: string | null;
  acquisition_date: string | null;
  registration_doc: string | null;
  insurance_doc: string | null;
  inspection_doc: string | null;
  company_name: string;
  site_name: string;
};

export type DocumentRow = {
  id: string;
  title: string;
  category: string;
  status: string;
  due_date: string | null;
  owner_type: string;
  owner_name: string;
  company_name: string | null;
  site_name: string | null;
};

export type LedgerRow = {
  id: string;
  label: string;
  type: string;
  amount: number;
  tax_rate: number;
  status: string;
  period: string;
  due_date: string | null;
  company_name: string;
  site_name: string | null;
};

export type TaskRow = {
  id: string;
  title: string;
  domain: string;
  priority: string;
  status: string;
  due_date: string | null;
  owner: string;
  company_name: string | null;
  site_name: string | null;
};

export type ContractorRow = {
  id: string;
  name: string;
  monthly_routes: number;
  vehicles: number;
  employees: number;
  status: string;
  contact_name: string | null;
  notes: string | null;
  site_name: string;
  company_name: string;
  completed_routes: number | null;
  incidents: number | null;
  on_time_rate: number | null;
};

export type AbsenceRow = {
  id: string;
  type: string;
  start_date: string;
  end_date: string;
  status: string;
  employee_name: string;
  site_name: string;
};

export type PayrollVariableRow = {
  id: string;
  period: string;
  overtime_hours: number;
  bonus_amount: number;
  deductions: number;
  status: string;
  employee_name: string;
  site_name: string;
};

export type PrePaieRow = {
  employee_id: string;
  company_id: string;
  company_name: string;
  site_id: string;
  site_name: string;
  first_name: string;
  last_name: string;
  role: string;
  contract_type: string;
  employee_status: string;
  hire_date: string;
  pay_mode: "mensualise" | "horaire";
  monthly_gross_salary: number | null;
  hourly_rate: number | null;
  contract_hours: number | null;
  meal_allowance_daily: number;
  pay_notes: string | null;
  tournee_rate: number | null;
  hourly_cost_rate: number | null;
  profile_id: string | null;
  profile_label: string | null;
  variable_id: string | null;
  period: string;
  overtime_hours: number;
  bonus_amount: number;
  deductions: number;
  worked_days: number;
  meal_allowance_amount: number | null;
  km_allowance: number;
  unpaid_absence_hours: number;
  variable_status: string;
  notes: string | null;
  absence_days_in_period: number;
  unpaid_absence_days_in_period: number;
  auto_filled_at: string | null;
  tournees_done: number;
  tms_hours: number;
};

export type DriverOption = {
  id: string;
  label: string;
  full_name: string;
  linked_employee_id: string | null;
};

export type SelectOption = {
  id: string;
  label: string;
};

export function getTotals() {
  return rpcOne<Totals>("get_totals");
}

// ── Dashboard (homepage) ─────────────────────────────────────────────────────

export type DashboardOverview = {
  // Operations
  tournees_today: number;
  tournees_in_progress: number;
  tournees_scheduled_week: number;
  tournees_completed_week: number;
  missions_in_progress: number;
  missions_assigned: number;
  missions_today: number;
  missions_completed_30d: number;
  // Fleet (operational)
  fleet_total: number;
  fleet_active: number;
  fleet_maintenance: number;
  // Fleet (TMS live status)
  tms_fleet_total: number;
  tms_fleet_available: number;
  tms_fleet_on_mission: number;
  tms_fleet_maintenance: number;
  // HR
  employees_active: number;
  drivers_active: number;
  absences_active: number;
  // Alerts
  documents_critical: number;
  documents_expiring_30d: number;
  vehicles_ct_30d: number;
  vehicles_ct_60d: number;
  vehicles_ins_30d: number;
  vehicles_ins_60d: number;
  incidents_open: number;
  tasks_open_high: number;
  // Finance (current month)
  period: string;
  revenue_period: number;
  expenses_period: number;
  margin_period: number;
  invoices_overdue_count: number;
  invoices_overdue_amount: number;
  invoices_outstanding_count: number;
  invoices_outstanding_amount: number;
};

export type DashboardTournee = {
  id: string;
  reference: string;
  name: string;
  status: string;
  scheduled_date: string;
  total_distance_km: number | null;
  driver_name: string | null;
  vehicle_plate: string | null;
  company_name: string | null;
  missions_count: number;
};

export type DashboardFleetAlert = {
  id: string;
  plate: string;
  brand: string | null;
  model: string | null;
  company_name: string | null;
  site_name: string | null;
  ct_due: string | null;
  ins_due: string | null;
  earliest_due: string | null;
  alert_kind: "CT" | "ASSURANCE" | "CT+ASSURANCE" | null;
};

export type DashboardInvoice = {
  id: string;
  invoice_number: string;
  total_amount: number;
  status: string;
  issued_at: string | null;
  due_at: string | null;
  days_overdue: number;
  client_name: string | null;
  mission_ref: string | null;
};

export type DashboardIncident = {
  id: string;
  title: string;
  incident_type: string;
  severity: string;
  status: string;
  created_at: string;
  estimated_cost: number | null;
  mission_ref: string | null;
  driver_name: string | null;
};

export function getDashboardOverview() {
  return rpcOne<DashboardOverview>("get_dashboard_overview");
}

export function getDashboardTournees(limit = 8) {
  return rpc<DashboardTournee>("get_dashboard_tournees", { p_limit: limit });
}

export function getDashboardFleetAlerts(days = 60, limit = 8) {
  return rpc<DashboardFleetAlert>("get_dashboard_fleet_alerts", { p_days: days, p_limit: limit });
}

export function getDashboardOverdueInvoices(limit = 6) {
  return rpc<DashboardInvoice>("get_dashboard_overdue_invoices", { p_limit: limit });
}

export function getDashboardIncidents(limit = 5) {
  return rpc<DashboardIncident>("get_dashboard_incidents", { p_limit: limit });
}

// Per-company variants (same shapes as global)
export function getDashboardCompanyOverview(companyId: string) {
  return rpcOne<DashboardOverview>("get_dashboard_company_overview", { p_company_id: companyId });
}

export function getDashboardCompanyTournees(companyId: string, limit = 6) {
  return rpc<DashboardTournee>("get_dashboard_company_tournees", { p_company_id: companyId, p_limit: limit });
}

export function getDashboardCompanyFleetAlerts(companyId: string, days = 60, limit = 6) {
  return rpc<DashboardFleetAlert>("get_dashboard_company_fleet_alerts", { p_company_id: companyId, p_days: days, p_limit: limit });
}

export function getDashboardCompanyOverdueInvoices(companyId: string, limit = 5) {
  return rpc<DashboardInvoice>("get_dashboard_company_overdue_invoices", { p_company_id: companyId, p_limit: limit });
}

export function getDashboardCompanyIncidents(companyId: string, limit = 5) {
  return rpc<DashboardIncident>("get_dashboard_company_incidents", { p_company_id: companyId, p_limit: limit });
}

export type DashboardFinanceTrend = {
  period: string;
  prev_period: string;
  revenue_period: number;
  revenue_prev: number;
  expenses_period: number;
  expenses_prev: number;
  margin_period: number;
  margin_prev: number;
};

export type DashboardDocAlert = {
  id: string;
  title: string;
  status: string;
  due_date: string | null;
  category: string | null;
  company_name: string | null;
  days_left: number | null;
};

export function getDashboardFinanceTrend(companyId?: string | null) {
  return rpcOne<DashboardFinanceTrend>("get_dashboard_finance_trend", { p_company_id: companyId ?? null });
}

export function getDashboardDocAlerts(companyId?: string | null, limit = 5) {
  return rpc<DashboardDocAlert>("get_dashboard_documents_alerts", { p_company_id: companyId ?? null, p_limit: limit });
}


export function getCompanies() {
  return rpc<CompanySummary>("get_companies");
}

export function getSites() {
  return rpc<SiteRow>("get_sites");
}

export function getEmployees(limit = 80) {
  return rpc<EmployeeRow>("get_employees", { p_limit: limit });
}

export function getVehicles(limit = 120) {
  return rpc<VehicleRow>("get_vehicles", { p_limit: limit });
}

export function getDocuments(limit = 100) {
  return rpc<DocumentRow>("get_documents", { p_limit: limit });
}

export function getLedgerEntries(limit = 100) {
  return rpc<LedgerRow>("get_ledger_entries", { p_limit: limit });
}

export function getTasks(limit = 100) {
  return rpc<TaskRow>("get_tasks", { p_limit: limit });
}

export function getContractors() {
  return rpc<ContractorRow>("get_contractors");
}

export function getAbsences() {
  return rpc<AbsenceRow>("get_absences");
}

export function getPayrollVariables() {
  return rpc<PayrollVariableRow>("get_payroll_variables");
}

export async function getPayrollOverview(period: string, companyId?: string): Promise<PrePaieRow[]> {
  const filter = supabase
    .from("employees")
    .select("*")
    .in("status", ["active", "Actif"]);
  if (companyId) filter.eq("company_id", companyId);
  const { data: emps, error: empErr } = await filter.order("last_name");
  if (empErr) { console.error("getPayrollOverview (employees):", empErr.message); return []; }
  if (!emps || emps.length === 0) return [];

  const [companyRes, sitesRes, pvRes] = await Promise.all([
    companyId ? supabase.from("companies").select("id, name").eq("id", companyId).maybeSingle() : Promise.resolve({ data: null }),
    companyId ? supabase.from("sites").select("id, name").eq("company_id", companyId) : Promise.resolve({ data: [] }),
    supabase.from("payroll_variables").select("*").eq("period", period).in("employee_id", emps.map((e) => e.id)),
  ]);
  const company_name = companyRes.data?.name ?? companyId ?? "";
  const siteMap: Record<string, string> = Object.fromEntries(
    (sitesRes.data ?? []).map((s: { id: string; name: string }) => [s.id, s.name])
  );
  const pvMap: Record<string, Record<string, unknown>> = Object.fromEntries(
    (pvRes.data ?? []).map((pv) => [pv.employee_id, pv])
  );
  return emps.map((e) => {
    const pv = pvMap[e.id] ?? {};
    return {
      employee_id: e.id,
      company_id: e.company_id ?? "",
      company_name,
      site_id: e.site_id ?? "",
      site_name: siteMap[e.site_id ?? ""] ?? "",
      first_name: e.first_name,
      last_name: e.last_name,
      role: e.role,
      contract_type: e.contract_type,
      employee_status: e.status,
      hire_date: e.hire_date ?? "",
      pay_mode: (e.pay_mode ?? "mensualise") as "mensualise" | "horaire",
      monthly_gross_salary: e.monthly_gross_salary ?? null,
      hourly_rate: e.hourly_rate ?? null,
      contract_hours: e.contract_hours ?? null,
      meal_allowance_daily: e.meal_allowance_daily ?? 0,
      pay_notes: e.pay_notes ?? null,
      tournee_rate: e.tournee_rate ?? null,
      hourly_cost_rate: e.hourly_cost_rate ?? null,
      profile_id: e.profile_id ?? null,
      profile_label: e.profile_label ?? null,
      variable_id: (pv.id as string) ?? null,
      period: (pv.period as string) ?? period,
      overtime_hours: (pv.overtime_hours as number) ?? 0,
      bonus_amount: (pv.bonus_amount as number) ?? 0,
      deductions: (pv.deductions as number) ?? 0,
      worked_days: (pv.worked_days as number) ?? 0,
      meal_allowance_amount: (pv.meal_allowance_amount as number) ?? null,
      km_allowance: (pv.km_allowance as number) ?? 0,
      unpaid_absence_hours: (pv.unpaid_absence_hours as number) ?? 0,
      variable_status: (pv.status as string) ?? "En attente",
      notes: (pv.notes as string) ?? null,
      absence_days_in_period: (pv.absence_days_in_period as number) ?? 0,
      unpaid_absence_days_in_period: (pv.unpaid_absence_days_in_period as number) ?? 0,
      auto_filled_at: (pv.auto_filled_at as string) ?? null,
      tournees_done: (pv.tournees_done as number) ?? 0,
      tms_hours: (pv.tms_hours as number) ?? 0,
    } as PrePaieRow;
  });
}

export function getPayrollPeriods() {
  return rpc<{ period: string }>("get_payroll_periods");
}

export async function getDriverOptions(): Promise<DriverOption[]> {
  const { data, error } = await supabase
    .from("profiles")
    .select("id, full_name, email, employee_id")
    .eq("role", "chauffeur")
    .eq("is_active", true)
    .order("full_name");
  if (error) { console.error("getDriverOptions:", error.message); return []; }
  return (data ?? []).map((p) => ({
    id: p.id,
    label: p.full_name || p.email || p.id,
    full_name: p.full_name ?? "",
    linked_employee_id: p.employee_id ?? null,
  })) as DriverOption[];
}

export function getSiteOptions() {
  return rpc<SelectOption>("get_site_options");
}

export function getCompanyOptions() {
  return rpc<SelectOption>("get_company_options");
}

export type CompanyExtras = {
  open_tasks: number;
  risky_documents: number;
  contractors: number;
};

export function getCompanyById(id: string) {
  return rpcOne<CompanySummary>("get_company_by_id", { p_id: id });
}

export function getCompanyExtras(companyId: string) {
  return rpcOne<CompanyExtras>("get_company_extras", { p_company_id: companyId });
}

export async function getSitesByCompany(companyId: string): Promise<SiteRow[]> {
  if (!companyId) return [];

  const [sitesRes, companyRes, empsRes] = await Promise.all([
    supabase
      .from("sites")
      .select("id, company_id, name, region, mode, monthly_routes, vehicles_target, employees_target, observations")
      .eq("company_id", companyId)
      .order("name"),
    supabase
      .from("companies")
      .select("name, color")
      .eq("id", companyId)
      .maybeSingle(),
    supabase
      .from("employees")
      .select("site_id")
      .eq("company_id", companyId),
  ]);

  if (sitesRes.error) {
    console.error("getSitesByCompany:", sitesRes.error.message);
    return [];
  }

  const employeeCountBySite: Record<string, number> = {};
  for (const row of empsRes.data ?? []) {
    const siteId = row.site_id as string | null;
    if (!siteId) continue;
    employeeCountBySite[siteId] = (employeeCountBySite[siteId] ?? 0) + 1;
  }

  const companyName = companyRes.data?.name ?? companyId;
  const companyColor = companyRes.data?.color ?? "";

  return (sitesRes.data ?? []).map((s) => ({
    id: s.id,
    company_id: s.company_id,
    company_name: companyName,
    company_color: companyColor,
    name: s.name,
    region: s.region ?? "",
    mode: s.mode ?? "Propre",
    monthly_routes: s.monthly_routes ?? 0,
    vehicles_target: s.vehicles_target ?? 0,
    employees_target: s.employees_target ?? 0,
    observations: s.observations ?? null,
    actual_employees: employeeCountBySite[s.id] ?? 0,
    actual_vehicles: 0,
    contractor_count: 0,
    completed_routes: null,
    incidents: 0,
    on_time_rate: null,
  }));
}

export function getDocumentsByCompany(companyId: string, limit = 10) {
  return rpc<DocumentRow>("get_documents_by_company", { p_company_id: companyId, p_limit: limit });
}

export function getLedgerByCompany(companyId: string, limit = 8) {
  return rpc<LedgerRow>("get_ledger_by_company", { p_company_id: companyId, p_limit: limit });
}

export async function getEmployeesByCompany(companyId: string, limit = 200): Promise<EmployeeRow[]> {
  if (!companyId) return [];
  const [empsRes, companyRes, sitesRes] = await Promise.all([
    supabase.from("employees").select("*").eq("company_id", companyId).order("last_name").limit(limit),
    supabase.from("companies").select("id, name").eq("id", companyId).maybeSingle(),
    supabase.from("sites").select("id, name").eq("company_id", companyId),
  ]);
  if (empsRes.error) { console.error("getEmployeesByCompany:", empsRes.error.message); return []; }
  const company_name = companyRes.data?.name ?? companyId;
  const siteMap: Record<string, string> = Object.fromEntries(
    (sitesRes.data ?? []).map((s: { id: string; name: string }) => [s.id, s.name])
  );
  return (empsRes.data ?? []).map((e) => ({
    ...e,
    company_name,
    site_name: siteMap[e.site_id ?? ""] ?? "",
    hire_date: e.hire_date ?? "",
  })) as EmployeeRow[];
}

export function getVehiclesByCompany(companyId: string, limit = 200) {
  return rpc<VehicleRow>("get_vehicles_by_company", { p_company_id: companyId, p_limit: limit });
}

export function getTasksByCompany(companyId: string, limit = 200) {
  return rpc<TaskRow>("get_tasks_by_company", { p_company_id: companyId, p_limit: limit });
}

export function getContractorsByCompany(companyId: string) {
  return rpc<ContractorRow>("get_contractors_by_company", { p_company_id: companyId });
}

export async function getAbsencesByCompany(companyId: string): Promise<AbsenceRow[]> {
  if (!companyId) return [];
  const { data, error } = await supabase
    .from("absences")
    .select("id, type, start_date, end_date, status, employee_id, site_id")
    .eq("company_id", companyId)
    .order("start_date", { ascending: false });
  if (error) { console.error("getAbsencesByCompany:", error.message); return []; }
  // Récupérer les noms des employés et sites
  const empIds = [...new Set((data ?? []).map((a) => a.employee_id).filter(Boolean))];
  const siteIds = [...new Set((data ?? []).map((a) => a.site_id).filter(Boolean))];
  const [empsRes, sitesRes] = await Promise.all([
    empIds.length > 0 ? supabase.from("employees").select("id, first_name, last_name").in("id", empIds) : Promise.resolve({ data: [] }),
    siteIds.length > 0 ? supabase.from("sites").select("id, name").in("id", siteIds) : Promise.resolve({ data: [] }),
  ]);
  const empMap: Record<string, string> = Object.fromEntries(
    (empsRes.data ?? []).map((e: { id: string; first_name: string; last_name: string }) => [e.id, `${e.first_name} ${e.last_name}`])
  );
  const siteMap: Record<string, string> = Object.fromEntries(
    (sitesRes.data ?? []).map((s: { id: string; name: string }) => [s.id, s.name])
  );
  return (data ?? []).map((a) => ({
    id: a.id,
    type: a.type,
    start_date: a.start_date,
    end_date: a.end_date,
    status: a.status,
    employee_name: empMap[a.employee_id] ?? "Inconnu",
    site_name: siteMap[a.site_id ?? ""] ?? "",
  })) as AbsenceRow[];
}

export async function getPayrollVariablesByCompany(companyId: string): Promise<PayrollVariableRow[]> {
  if (!companyId) return [];
  const { data, error } = await supabase
    .from("payroll_variables")
    .select("id, period, overtime_hours, bonus_amount, deductions, status, employee_id, site_id")
    .eq("company_id", companyId)
    .order("period", { ascending: false });
  if (error) { console.error("getPayrollVariablesByCompany:", error.message); return []; }
  const empIds = [...new Set((data ?? []).map((r) => r.employee_id).filter(Boolean))];
  const siteIds = [...new Set((data ?? []).map((r) => r.site_id).filter(Boolean))];
  const [empsRes, sitesRes] = await Promise.all([
    empIds.length > 0 ? supabase.from("employees").select("id, first_name, last_name").in("id", empIds) : Promise.resolve({ data: [] }),
    siteIds.length > 0 ? supabase.from("sites").select("id, name").in("id", siteIds) : Promise.resolve({ data: [] }),
  ]);
  const empMap: Record<string, string> = Object.fromEntries(
    (empsRes.data ?? []).map((e: { id: string; first_name: string; last_name: string }) => [e.id, `${e.first_name} ${e.last_name}`])
  );
  const siteMap: Record<string, string> = Object.fromEntries(
    (sitesRes.data ?? []).map((s: { id: string; name: string }) => [s.id, s.name])
  );
  return (data ?? []).map((r) => ({
    id: r.id,
    period: r.period,
    overtime_hours: r.overtime_hours ?? 0,
    bonus_amount: r.bonus_amount ?? 0,
    deductions: r.deductions ?? 0,
    status: r.status,
    employee_name: empMap[r.employee_id] ?? "Inconnu",
    site_name: siteMap[r.site_id ?? ""] ?? "",
  })) as PayrollVariableRow[];
}

export async function getSiteOptionsByCompany(companyId: string): Promise<SelectOption[]> {
  if (!companyId) return [];
  const { data, error } = await supabase
    .from("sites")
    .select("id, name")
    .eq("company_id", companyId)
    .order("name");
  if (error) { console.error("getSiteOptionsByCompany:", error.message); return []; }
  return (data ?? []).map((s) => ({ id: s.id, label: s.name })) as SelectOption[];
}

export function getDocumentsByCompanyFull(companyId: string) {
  return rpc<DocumentRow>("get_documents_by_company_full", { p_company_id: companyId });
}

export function getLedgerByCompanyFull(companyId: string) {
  return rpc<LedgerRow>("get_ledger_by_company_full", { p_company_id: companyId });
}

// ── LOTI / capacité transport ────────────────────────────────────────────────

/**
 * Catégories `documents.category` reconnues pour la conformité LOTI.
 * Ces valeurs doivent matcher EXACTEMENT celles utilisées par les fonctions
 * SQL `get_loti_compliance` / `get_loti_vehicles`.
 */
export const LOTI_DOCUMENT_KINDS = [
  "Licence transport marchandises",
  "LCI",
  "Copie conforme",
  "Attestation capacité",
  "Inscription registre",
] as const;

export type LotiDocumentKind = typeof LOTI_DOCUMENT_KINDS[number];

export type LotiCompliance = {
  licence_id: string | null;
  licence_title: string | null;
  licence_due_date: string | null;
  licence_status: string | null;
  licence_days_left: number | null;
  vehicles_total: number;
  vehicles_with_copy: number;
  vehicles_missing_copy: number;
  vehicles_expiring: number;
  vehicles_expired: number;
};

export type LotiVehicleRow = {
  vehicle_id: string;
  plate_number: string;
  brand: string | null;
  model: string | null;
  max_payload_kg: number | null;
  vehicle_status: string;
  copy_doc_id: string | null;
  copy_title: string | null;
  copy_due_date: string | null;
  copy_status: string;
  days_left: number | null;
};

export function getLotiCompliance(companyId: string) {
  return rpcOne<LotiCompliance>("get_loti_compliance", { p_company_id: companyId });
}

export function getLotiVehicles(companyId: string) {
  return rpc<LotiVehicleRow>("get_loti_vehicles", { p_company_id: companyId });
}

// ── Audit log applicatif ────────────────────────────────────────────────────

export type AuditLogRow = {
  id: string;
  at: string;
  actor_id: string | null;
  actor_name: string;
  actor_email: string | null;
  actor_role: string | null;
  company_id: string | null;
  company_name: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  result: "ok" | "error";
  message: string | null;
  metadata: Record<string, unknown> | null;
};

export async function getAuditLog(limit = 200, companyId?: string | null): Promise<AuditLogRow[]> {
  // Lecture protégée par RLS (`app_is_admin()`) → impérativement le client serveur authentifié.
  const { getSupabaseServer } = await import("@/lib/supabase-server");
  const sb = await getSupabaseServer();
  let q = sb
    .from("audit_log_listing")
    .select("*")
    .order("at", { ascending: false })
    .limit(limit);
  if (companyId) q = q.eq("company_id", companyId);
  const { data, error } = await q;
  if (error) {
    console.error("[getAuditLog]", error.message);
    return [];
  }
  return (data ?? []) as AuditLogRow[];
}

// ── Dossiers salariés (documents personnels) ─────────────────────────────────

export const EMPLOYEE_DOC_CATEGORIES = [
  "Permis B",
  "Permis C",
  "Permis CE",
  "FIMO / FCO",
  "Carte conducteur",
  "CNI / Passeport",
  "Titre de séjour",
  "Carte vitale",
  "Mutuelle",
  "RIB",
  "Justif. domicile",
  "Contrat de travail",
  "Avenant",
  "Visite médicale",
  "Casier judiciaire",
  "Photo",
  "Autre",
] as const;

export type EmployeeDocCategory = typeof EMPLOYEE_DOC_CATEGORIES[number];

export type EmployeeDocumentRow = {
  id: string;
  employee_id: string;
  category: string;
  title: string | null;
  file_url: string | null;
  file_path: string | null;
  mime_type: string | null;
  file_size: number | null;
  issued_on: string | null;
  expires_on: string | null;
  notes: string | null;
  uploaded_at: string;
};

export type EmployeeDossierSummary = {
  employee_id: string;
  total: number;
  expired: number;
  expiring_soon: number;
};

export async function getEmployeeDocuments(employeeId: string): Promise<EmployeeDocumentRow[]> {
  const { data, error } = await supabase
    .from("employee_documents")
    .select("*")
    .eq("employee_id", employeeId)
    .order("uploaded_at", { ascending: false });
  if (error) throw new Error(`getEmployeeDocuments: ${error.message}`);
  return (data ?? []) as EmployeeDocumentRow[];
}

/**
 * Résumé du dossier par salarié pour une société : pour afficher l'indicateur
 * (compteur + alertes) dans la colonne "Dossier" de la table Effectif.
 */
export async function getEmployeeDossierSummaryByCompany(
  companyId: string
): Promise<Record<string, EmployeeDossierSummary>> {
  const { data: empData, error: empErr } = await supabase
    .from("employees")
    .select("id")
    .eq("company_id", companyId);
  if (empErr) throw new Error(`dossier summary employees: ${empErr.message}`);
  const ids = (empData ?? []).map((e: { id: string }) => e.id);
  if (ids.length === 0) return {};

  const { data, error } = await supabase
    .from("employee_documents")
    .select("employee_id, expires_on")
    .in("employee_id", ids);
  if (error) throw new Error(`dossier summary docs: ${error.message}`);

  const today = new Date();
  const horizon = new Date();
  horizon.setDate(horizon.getDate() + 30);

  const out: Record<string, EmployeeDossierSummary> = {};
  for (const id of ids) {
    out[id] = { employee_id: id, total: 0, expired: 0, expiring_soon: 0 };
  }
  for (const row of (data ?? []) as { employee_id: string; expires_on: string | null }[]) {
    const s = out[row.employee_id];
    if (!s) continue;
    s.total += 1;
    if (row.expires_on) {
      const exp = new Date(row.expires_on);
      if (exp < today) s.expired += 1;
      else if (exp <= horizon) s.expiring_soon += 1;
    }
  }
  return out;
}

// ── TMS : Tournées ────────────────────────────────────────────────────────────

export type TourneeRow = {
  id: string;
  reference: string;
  name: string;
  status: string;
  scheduled_date: string;
  total_distance_km: number | null;
  actual_start: string | null;
  actual_end: string | null;
  driver_name: string | null;
  vehicle_plate: string | null;
  vehicle_brand: string | null;
  vehicle_model: string | null;
  notes: string | null;
  mission_count: number;
};

export type TourneeStats = {
  total: number;
  in_progress: number;
  scheduled: number;
  completed: number;
  draft: number;
  total_distance: number;
};

export function getTourneesByCompany(companyId: string, limit = 60) {
  return rpc<TourneeRow>("get_tournees_by_company", {
    p_company_id: companyId,
    p_limit: limit,
  });
}

export function getTourneesStatsByCompany(companyId: string) {
  return rpcOne<TourneeStats>("get_tournees_stats_by_company", { p_company_id: companyId });
}

// ── TMS : Missions ────────────────────────────────────────────────────────────

export type MissionRow = {
  id: string;
  reference: string;
  status: string;
  scheduled_date: string;
  pickup_city: string;
  delivery_city: string;
  distance_km: number | null;
  cargo_description: string | null;
  price: number | null;
  driver_name: string | null;
  vehicle_plate: string | null;
  client_name: string | null;
  priority: string | null;
  billing_status: string | null;
  is_on_time: boolean | null;
  co2_kg: number | null;
  requires_adr: boolean | null;
  actual_margin: number | null;
};

export type MissionStats = {
  total: number;
  in_progress: number;
  assigned: number;
  completed: number;
  draft: number;
  cancelled: number;
  total_distance: number;
  total_revenue: number;
  avg_margin: number;
};

export function getMissionsByCompany(companyId: string, limit = 100) {
  return rpc<MissionRow>("get_missions_by_company", {
    p_company_id: companyId,
    p_limit: limit,
  });
}

export function getMissionsStatsByCompany(companyId: string) {
  return rpcOne<MissionStats>("get_missions_stats_by_company", { p_company_id: companyId });
}

// ── TMS : Flotte TMS + Maintenance ───────────────────────────────────────────

export type TmsVehicleRow = {
  id: string;
  plate_number: string;
  brand: string;
  model: string;
  year: number | null;
  status: string;
  mileage: number;
  fuel_type: string | null;
  insurance_expiry: string | null;
  technical_control_expiry: string | null;
  next_maintenance_date: string | null;
  last_maintenance_date: string | null;
  max_payload_kg: number | null;
  last_maintenance_type: string | null;
  last_maintenance_cost: number | null;
  registration_doc: string | null;
  insurance_doc: string | null;
  inspection_doc: string | null;
  vin: string | null;
  // Coûts d'exploitation
  fuel_consumption_l_100km: number | null;
  fuel_price_per_l: number | null;
  amortization_per_km: number | null;
  tire_cost_per_km: number | null;
  maintenance_cost_per_km: number | null;
  has_cold_unit: boolean | null;
  cold_unit_cost_per_hour: number | null;
};

export type MaintenanceRow = {
  id: string;
  vehicle_plate: string;
  vehicle_brand: string;
  vehicle_model: string;
  maintenance_type: string;
  description: string | null;
  service_date: string;
  cost: number | null;
  provider: string | null;
  next_service_date: string | null;
  mileage_at_service: number | null;
};

export async function getTmsVehiclesByCompany(companyId: string): Promise<TmsVehicleRow[]> {
  if (!companyId) return [];
  const { data, error } = await supabase
    .from("tms_vehicles")
    .select("*")
    .eq("company_id", companyId)
    .order("plate_number");
  if (error) { console.error("getTmsVehiclesByCompany:", error.message); return []; }
  return (data ?? []) as TmsVehicleRow[];
}

export async function getMaintenanceByCompany(companyId: string, limit = 100): Promise<MaintenanceRow[]> {
  if (!companyId) return [];
  // Récupérer les véhicules de la société pour filtrer
  const { data: vehicles, error: vErr } = await supabase
    .from("tms_vehicles")
    .select("id, plate_number, brand, model")
    .eq("company_id", companyId);
  if (vErr) { console.error("getMaintenanceByCompany (vehicles):", vErr.message); return []; }
  if (!vehicles || vehicles.length === 0) return [];
  const vMap: Record<string, { plate_number: string; brand: string; model: string }> = Object.fromEntries(
    (vehicles as Array<{ id: string; plate_number: string; brand: string; model: string }>)
      .map((v) => [v.id, { plate_number: v.plate_number, brand: v.brand ?? "", model: v.model ?? "" }])
  );
  const { data, error } = await supabase
    .from("maintenance_records")
    .select("*")
    .in("vehicle_id", Object.keys(vMap))
    .order("service_date", { ascending: false })
    .limit(limit);
  if (error) { console.error("getMaintenanceByCompany (records):", error.message); return []; }
  return (data ?? []).map((r) => ({
    id: r.id,
    vehicle_plate: vMap[r.vehicle_id]?.plate_number ?? "",
    vehicle_brand: vMap[r.vehicle_id]?.brand ?? "",
    vehicle_model: vMap[r.vehicle_id]?.model ?? "",
    maintenance_type: r.maintenance_type,
    description: r.description ?? null,
    service_date: r.service_date,
    cost: r.cost ?? null,
    provider: r.provider ?? null,
    next_service_date: r.next_service_date ?? null,
    mileage_at_service: r.mileage_at_service ?? null,
  })) as MaintenanceRow[];
}

// ── Dropdown helpers ──────────────────────────────────────────────────────────

export type ClientOption = { id: string; company_name: string };
export type VehicleOption = { id: string; plate_number: string; brand: string; model: string };

/** All clients */
export async function getClientOptions(): Promise<ClientOption[]> {
  const { data } = await supabase
    .from("clients")
    .select("id, company_name")
    .order("company_name");
  return (data ?? []) as ClientOption[];
}

/** TMS vehicles belonging to a company */
export async function getTmsVehicleOptionsByCompany(companyId: string): Promise<VehicleOption[]> {
  const { data } = await supabase
    .from("tms_vehicles")
    .select("id, plate_number, brand, model")
    .eq("company_id", companyId)
    .order("plate_number");
  return (data ?? []) as VehicleOption[];
}

