import { createCipheriv, createDecipheriv, randomBytes, createHash } from "node:crypto";

/**
 * Chiffrement symétrique AES-256-GCM pour les secrets URSSAF.
 *
 * Clé : variable d'environnement URSSAF_ENC_KEY
 *   - Idéalement : 32 bytes en base64 (`openssl rand -base64 32`)
 *   - Sinon : n'importe quelle string, hashée SHA-256 pour obtenir 32 bytes.
 *
 * Format de sortie : 3 champs séparés (ciphertext, iv, tag) tous en base64.
 * Pas de format "tout-en-un" pour rester explicite côté DB.
 */

const ALGO = "aes-256-gcm" as const;
const IV_BYTES = 12;
const TAG_BYTES = 16;

function getKey(): Buffer {
  const raw = process.env.URSSAF_ENC_KEY;
  if (!raw) {
    throw new Error(
      "URSSAF_ENC_KEY manquant. Générer avec `openssl rand -base64 32` et l'ajouter à .env.local",
    );
  }
  // Tentative base64 : si exactement 32 bytes décodés on l'utilise tel quel.
  try {
    const buf = Buffer.from(raw, "base64");
    if (buf.length === 32) return buf;
  } catch {
    // ignore
  }
  // Fallback : dérivation SHA-256 (déterministe, suffisante pour un secret long).
  return createHash("sha256").update(raw, "utf8").digest();
}

export type EncryptedSecret = {
  ciphertext: string;
  iv: string;
  tag: string;
};

export function encryptSecret(plaintext: string): EncryptedSecret {
  if (!plaintext) throw new Error("encryptSecret: plaintext vide");
  const key = getKey();
  const iv = randomBytes(IV_BYTES);
  const cipher = createCipheriv(ALGO, key, iv);
  const enc = Buffer.concat([cipher.update(plaintext, "utf8"), cipher.final()]);
  const tag = cipher.getAuthTag();
  return {
    ciphertext: enc.toString("base64"),
    iv: iv.toString("base64"),
    tag: tag.toString("base64"),
  };
}

export function decryptSecret(payload: EncryptedSecret): string {
  const key = getKey();
  const iv = Buffer.from(payload.iv, "base64");
  const tag = Buffer.from(payload.tag, "base64");
  if (iv.length !== IV_BYTES) throw new Error("decryptSecret: IV invalide");
  if (tag.length !== TAG_BYTES) throw new Error("decryptSecret: tag invalide");
  const decipher = createDecipheriv(ALGO, key, iv);
  decipher.setAuthTag(tag);
  const dec = Buffer.concat([
    decipher.update(Buffer.from(payload.ciphertext, "base64")),
    decipher.final(),
  ]);
  return dec.toString("utf8");
}
