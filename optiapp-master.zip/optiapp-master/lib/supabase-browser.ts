/**
 * lib/supabase-browser.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Client Supabase côté navigateur (Client Components).
 * Persiste la session via cookies (lus par le middleware côté serveur).
 */

"use client";

import { createBrowserClient } from "@supabase/ssr";

const URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

let cached: ReturnType<typeof createBrowserClient> | null = null;

export function getSupabaseBrowser() {
  if (!cached) {
    cached = createBrowserClient(URL, ANON_KEY);
  }
  return cached;
}
