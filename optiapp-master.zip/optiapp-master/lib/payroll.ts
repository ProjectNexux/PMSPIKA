// Pré-paie : moteur de calcul (estimations indicatives, hors calcul exact du cabinet de paie)
//
// Convention transport / cas standard :
//   • Salaire de base = mensualisé ou horaire × heures contractuelles
//   • Heures supp. : +25 % les 8 premières, +50 % au-delà
//   • Indemnités repas non soumises à cotisations (ajoutées au net)
//   • Indemnités km / frais : remboursés au net, non soumis
//   • Charges salariales ~22 % (estimation non-cadre)
//   • Charges patronales ~42 % (estimation)
//
// Tous les pourcentages sont paramétrables.

export const PAYROLL_DEFAULTS = {
  employeeChargesRate: 0.22,   // cotisations salariales (estimation)
  employerChargesRate: 0.42,   // cotisations patronales (estimation)
  ot25Threshold: 8,            // 8 premières heures majorées 25 %
  ot25Rate: 1.25,
  ot50Rate: 1.5,
  defaultContractHours: 151.67, // 35 h × 52 / 12
  workingDaysPerMonth: 22,
} as const;

export type PayrollInputs = {
  // Base salariale
  pay_mode: "mensualise" | "horaire";
  monthly_gross_salary: number | null;
  hourly_rate: number | null;
  contract_hours: number | null;
  meal_allowance_daily: number;
  // Variables du mois
  overtime_hours: number;
  bonus_amount: number;
  deductions: number;
  worked_days: number;
  meal_allowance_amount: number | null; // override manuel sinon worked_days × meal_allowance_daily
  km_allowance: number;
  unpaid_absence_hours: number;
};

export type PayrollComputation = {
  baseHourlyRate: number;
  contractHours: number;
  baseSalary: number;
  absenceDeduction: number;
  overtimeHours25: number;
  overtimeHours50: number;
  overtimePay: number;
  mealAllowance: number;
  kmAllowance: number;
  bonus: number;
  otherDeductions: number;
  grossTaxable: number;       // Brut soumis à cotisations
  employeeCharges: number;    // Cotisations salariales estimées
  netBeforeIndemnities: number;
  netPayable: number;         // Net à verser (= net + indemnités non soumises - retenues)
  employerCharges: number;    // Cotisations patronales estimées
  totalEmployerCost: number;  // Coût total employeur
};

function safe(n: number | null | undefined): number {
  const v = Number(n);
  return Number.isFinite(v) ? v : 0;
}

export function computePayroll(input: PayrollInputs): PayrollComputation {
  const contractHours = safe(input.contract_hours) || PAYROLL_DEFAULTS.defaultContractHours;
  const baseHourlyRate =
    input.pay_mode === "horaire"
      ? safe(input.hourly_rate)
      : contractHours > 0
        ? safe(input.monthly_gross_salary) / contractHours
        : 0;

  const baseSalary =
    input.pay_mode === "horaire"
      ? baseHourlyRate * contractHours
      : safe(input.monthly_gross_salary);

  const absenceDeduction = safe(input.unpaid_absence_hours) * baseHourlyRate;

  const totalOt = Math.max(0, safe(input.overtime_hours));
  const overtimeHours25 = Math.min(totalOt, PAYROLL_DEFAULTS.ot25Threshold);
  const overtimeHours50 = Math.max(0, totalOt - PAYROLL_DEFAULTS.ot25Threshold);
  const overtimePay =
    overtimeHours25 * baseHourlyRate * PAYROLL_DEFAULTS.ot25Rate +
    overtimeHours50 * baseHourlyRate * PAYROLL_DEFAULTS.ot50Rate;

  const mealAllowance =
    input.meal_allowance_amount != null && input.meal_allowance_amount > 0
      ? safe(input.meal_allowance_amount)
      : safe(input.worked_days) * safe(input.meal_allowance_daily);

  const kmAllowance = safe(input.km_allowance);
  const bonus = safe(input.bonus_amount);
  const otherDeductions = safe(input.deductions);

  const grossTaxable = Math.max(0, baseSalary - absenceDeduction + overtimePay + bonus);
  const employeeCharges = grossTaxable * PAYROLL_DEFAULTS.employeeChargesRate;
  const netBeforeIndemnities = grossTaxable - employeeCharges;
  const netPayable = netBeforeIndemnities + mealAllowance + kmAllowance - otherDeductions;

  const employerCharges = grossTaxable * PAYROLL_DEFAULTS.employerChargesRate;
  const totalEmployerCost = grossTaxable + employerCharges + mealAllowance + kmAllowance;

  return {
    baseHourlyRate,
    contractHours,
    baseSalary,
    absenceDeduction,
    overtimeHours25,
    overtimeHours50,
    overtimePay,
    mealAllowance,
    kmAllowance,
    bonus,
    otherDeductions,
    grossTaxable,
    employeeCharges,
    netBeforeIndemnities,
    netPayable,
    employerCharges,
    totalEmployerCost,
  };
}

export function currentPeriod(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

export function formatPeriod(period: string): string {
  if (!/^\d{4}-\d{2}$/.test(period)) return period;
  const [y, m] = period.split("-").map(Number);
  const d = new Date(Date.UTC(y, m - 1, 1));
  return new Intl.DateTimeFormat("fr-FR", { month: "long", year: "numeric", timeZone: "UTC" }).format(d);
}

export function shiftPeriod(period: string, delta: number): string {
  const m = /^(\d{4})-(\d{2})$/.exec(period);
  if (!m) return currentPeriod();
  const total = Number(m[1]) * 12 + (Number(m[2]) - 1) + delta;
  const y = Math.floor(total / 12);
  const mo = (total % 12) + 1;
  return `${y}-${String(mo).padStart(2, "0")}`;
}
