import "server-only";
import { getServerSupabase } from "@/lib/db-server";

/**
 * Multi-canal notifications.
 *
 * - `notifyInApp`  : insert dans la table `public.notifications` (toujours actif).
 * - `sendEmail`    : Resend HTTP API si `RESEND_API_KEY` est défini, sinon no-op (log).
 * - `sendSms`      : Twilio HTTP API si `TWILIO_ACCOUNT_SID` + `TWILIO_AUTH_TOKEN`
 *                    + `TWILIO_FROM_NUMBER` sont définis, sinon no-op (log).
 *
 * On évite d'ajouter `resend` / `twilio` en dépendances : les deux exposent
 * une HTTP API simple, on appelle `fetch` directement (compatible edge & node).
 */

export type EmailPayload = {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  from?: string;
};

export type SmsPayload = {
  to: string;
  body: string;
};

export type InAppPayload = {
  userId: string;
  title: string;
  message: string;
  type?: "info" | "warning" | "error" | "success";
  link?: string | null;
};

export type DispatchResult = {
  channel: "email" | "sms" | "in_app";
  ok: boolean;
  skipped?: string;
  error?: string;
};

export async function sendEmail(payload: EmailPayload): Promise<DispatchResult> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    return { channel: "email", ok: false, skipped: "RESEND_API_KEY missing" };
  }
  const from = payload.from ?? process.env.RESEND_FROM ?? "noreply@pikatransport.fr";
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        authorization: `Bearer ${apiKey}`,
        "content-type": "application/json",
      },
      body: JSON.stringify({
        from,
        to: payload.to,
        subject: payload.subject,
        html: payload.html,
        text: payload.text,
      }),
    });
    if (!res.ok) {
      const body = await res.text();
      return { channel: "email", ok: false, error: `${res.status} ${body.slice(0, 200)}` };
    }
    return { channel: "email", ok: true };
  } catch (err) {
    return { channel: "email", ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export async function sendSms(payload: SmsPayload): Promise<DispatchResult> {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const from = process.env.TWILIO_FROM_NUMBER;
  if (!sid || !token || !from) {
    return { channel: "sms", ok: false, skipped: "TWILIO_* env missing" };
  }
  try {
    const auth = Buffer.from(`${sid}:${token}`).toString("base64");
    const body = new URLSearchParams({ To: payload.to, From: from, Body: payload.body });
    const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
      method: "POST",
      headers: {
        authorization: `Basic ${auth}`,
        "content-type": "application/x-www-form-urlencoded",
      },
      body: body.toString(),
    });
    if (!res.ok) {
      const text = await res.text();
      return { channel: "sms", ok: false, error: `${res.status} ${text.slice(0, 200)}` };
    }
    return { channel: "sms", ok: true };
  } catch (err) {
    return { channel: "sms", ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export async function notifyInApp(payload: InAppPayload): Promise<DispatchResult> {
  try {
    const sb = getServerSupabase();
    const { error } = await sb.from("notifications").insert({
      user_id: payload.userId,
      title: payload.title,
      message: payload.message,
      type: payload.type ?? "info",
      link: payload.link ?? null,
      read: false,
    });
    if (error) return { channel: "in_app", ok: false, error: error.message };
    return { channel: "in_app", ok: true };
  } catch (err) {
    return { channel: "in_app", ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

/**
 * Dispatcher : envoie le même message sur tous les canaux pertinents.
 * `userId` est requis pour la notification in-app ; `email`/`phone` sont optionnels.
 */
export async function notifyAll(opts: {
  userId?: string;
  email?: string | null;
  phone?: string | null;
  title: string;
  message: string;
  htmlBody?: string;
  link?: string | null;
  type?: InAppPayload["type"];
}): Promise<DispatchResult[]> {
  const results: DispatchResult[] = [];
  if (opts.userId) {
    results.push(
      await notifyInApp({
        userId: opts.userId,
        title: opts.title,
        message: opts.message,
        type: opts.type,
        link: opts.link ?? null,
      }),
    );
  }
  if (opts.email) {
    results.push(
      await sendEmail({
        to: opts.email,
        subject: opts.title,
        html: opts.htmlBody ?? `<p>${escapeHtml(opts.message)}</p>`,
        text: opts.message,
      }),
    );
  }
  if (opts.phone) {
    results.push(
      await sendSms({
        to: opts.phone,
        body: `${opts.title} — ${opts.message}`,
      }),
    );
  }
  return results;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
