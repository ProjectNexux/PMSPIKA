import { supabase } from "@/lib/db";
import type { InvoiceClient } from "@/lib/invoice-queries";
import { assertArray, assertObject } from "@/lib/utils";

// ─── Types ────────────────────────────────────────────────────────────────────

export type TourneeAFacturer = {
  id: string;
  reference: string;
  name: string;
  scheduled_date: string;
  status: string;
  client_id: string;
  client_name: string;
  /** Revenu facturable HT calculé (forfait + majorations) */
  revenue_ht: number;
  billed_invoice_id: string | null;
};

export type GroupeClient = {
  client_id: string;
  client_name: string;
  tournees: TourneeAFacturer[];
  total_ht: number;
  nb_tournees: number;
};

// ─── Requêtes ─────────────────────────────────────────────────────────────────

/**
 * Retourne les tournées associées à un client facturable pour une période donnée.
 * Filtre optionnel : `nonFacturees = true` exclut celles déjà facturées.
 */
export async function getTourneesAFacturer(
  dateDebut: string,
  dateFin: string,
  nonFacturees = true,
): Promise<TourneeAFacturer[]> {
  let q = supabase
    .from("tournees")
    .select(
      "id, reference, name, scheduled_date, status, client_id, billed_invoice_id, " +
      "flat_rate_revenue, surcharge_fuel, surcharge_adr, surcharge_wait, surcharge_other, other_revenue, " +
      "invoice_clients!client_id(name)",
    )
    .gte("scheduled_date", dateDebut)
    .lte("scheduled_date", dateFin)
    .not("client_id", "is", null)
    .order("scheduled_date", { ascending: true });

  if (nonFacturees) {
    q = q.is("billed_invoice_id", null);
  }

  const { data, error } = await q;
  if (error) {
    console.error("[prefacturation-queries] getTourneesAFacturer:", error.message);
    return [];
  }

  return assertArray<Record<string, unknown>>(data, []).map((row) => {
    type TourneeRow = {
      id: string;
      reference: string | null;
      name: string | null;
      scheduled_date: string | null;
      status: string | null;
      client_id: string | null;
      billed_invoice_id: string | null;
      flat_rate_revenue: number | null;
      surcharge_fuel: number | null;
      surcharge_adr: number | null;
      surcharge_wait: number | null;
      surcharge_other: number | null;
      other_revenue: number | null;
      invoice_clients?: { name: string } | null;
    };
    
    const typedRow = assertObject<TourneeRow>(row, {
      id: "",
      reference: null,
      name: null,
      scheduled_date: null,
      status: null,
      client_id: null,
      billed_invoice_id: null,
      flat_rate_revenue: null,
      surcharge_fuel: null,
      surcharge_adr: null,
      surcharge_wait: null,
      surcharge_other: null,
      other_revenue: null,
    });

    const flat   = typedRow.flat_rate_revenue   ?? 0;
    const sFuel  = typedRow.surcharge_fuel      ?? 0;
    const sAdr   = typedRow.surcharge_adr       ?? 0;
    const sWait  = typedRow.surcharge_wait      ?? 0;
    const sOther = typedRow.surcharge_other     ?? 0;
    const other  = typedRow.other_revenue       ?? 0;
    const revenue_ht = flat + sFuel + sAdr + sWait + sOther + other;

    const clientName = typedRow.invoice_clients?.name ?? "Client inconnu";

    return {
      id:                typedRow.id,
      reference:         typedRow.reference ?? "",
      name:              typedRow.name ?? "",
      scheduled_date:    typedRow.scheduled_date ?? "",
      status:            typedRow.status ?? "",
      client_id:         typedRow.client_id ?? "",
      client_name:       clientName,
      revenue_ht,
      billed_invoice_id: typedRow.billed_invoice_id ?? null,
    };
  });
}

/**
 * Groupe les tournées à facturer par client.
 */
export function grouperParClient(tournees: TourneeAFacturer[]): GroupeClient[] {
  const map = new Map<string, GroupeClient>();

  for (const t of tournees) {
    const existing = map.get(t.client_id);
    if (existing) {
      existing.tournees.push(t);
      existing.total_ht   += t.revenue_ht;
      existing.nb_tournees++;
    } else {
      map.set(t.client_id, {
        client_id:   t.client_id,
        client_name: t.client_name,
        tournees:    [t],
        total_ht:    t.revenue_ht,
        nb_tournees: 1,
      });
    }
  }

  return Array.from(map.values()).sort((a, b) =>
    a.client_name.localeCompare(b.client_name),
  );
}

/** KPIs globaux pour la période */
export function computePrefacKpis(groupes: GroupeClient[]) {
  const totalHT       = groupes.reduce((s, g) => s + g.total_ht, 0);
  const nbClients     = groupes.length;
  const nbTournees    = groupes.reduce((s, g) => s + g.nb_tournees, 0);
  return { totalHT, nbClients, nbTournees };
}

/** Récupère le détail d'un client facturable */
export async function getInvoiceClientById(id: string): Promise<InvoiceClient | null> {
  const { data, error } = await supabase
    .from("invoice_clients")
    .select("*")
    .eq("id", id)
    .single();
  if (error || !data) return null;
  return data as InvoiceClient;
}
