export function formatNumber(value: number | null | undefined) {
  return new Intl.NumberFormat("fr-FR").format(value ?? 0);
}

export function formatCurrency(value: number | null | undefined) {
  return new Intl.NumberFormat("fr-FR", {
    style: "currency",
    currency: "EUR",
    maximumFractionDigits: 0
  }).format(value ?? 0);
}

export function formatDate(value: string | null | undefined) {
  if (!value) return "Non renseigne";
  return new Intl.DateTimeFormat("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric"
  }).format(new Date(`${value}T00:00:00`));
}

export function pct(value: number | null | undefined) {
  return `${(value ?? 0).toLocaleString("fr-FR", {
    maximumFractionDigits: 1,
    minimumFractionDigits: 1
  })} %`;
}
