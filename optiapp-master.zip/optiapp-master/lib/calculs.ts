import type {
  Salarie,
  Vehicule,
  CoutVariable,
  Tournee,
  Scenario,
  Parametres,
  CategorieCout,
} from "./types";

/* ---------- Formatters ---------- */

export const fmtEur = (n: number, dec = 2) =>
  isFinite(n)
    ? n.toLocaleString("fr-FR", {
        minimumFractionDigits: dec,
        maximumFractionDigits: dec,
      }) + " €"
    : "—";

export const fmtEurK = (n: number) => {
  if (!isFinite(n)) return "—";
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return (n / 1_000_000).toLocaleString("fr-FR", { maximumFractionDigits: 2 }) + " M€";
  if (abs >= 1_000) return (n / 1_000).toLocaleString("fr-FR", { maximumFractionDigits: 1 }) + " k€";
  return n.toLocaleString("fr-FR", { maximumFractionDigits: 0 }) + " €";
};

export const fmtNum = (n: number, dec = 2) =>
  isFinite(n)
    ? n.toLocaleString("fr-FR", {
        minimumFractionDigits: dec,
        maximumFractionDigits: dec,
      })
    : "—";

export const fmtPct = (n: number, dec = 1) =>
  isFinite(n)
    ? n.toLocaleString("fr-FR", {
        minimumFractionDigits: dec,
        maximumFractionDigits: dec,
      }) + " %"
    : "—";

export const fmtKm = (n: number) =>
  isFinite(n) ? n.toLocaleString("fr-FR", { maximumFractionDigits: 0 }) + " km" : "—";

/* ---------- Coûts ---------- */

/** Coût chargé d'un salarié (mensuel) : brut chargé + primes non taxables */
export const coutSalarieMensuel = (s: Salarie) =>
  s.salaireBrut * (1 + s.chargesPct / 100) + (s.primesNonTaxables ?? 0);

/** Totaux mensuels par catégorie + total global */
export function totauxMensuels(
  salaries: Salarie[],
  vehicules: Vehicule[],
  coutsVariables: CoutVariable[]
) {
  const totalSalaires = salaries.reduce((s, x) => s + coutSalarieMensuel(x), 0);
  const totalVehicules = vehicules.reduce((s, x) => s + x.coutMensuel, 0);
  const totalVariables = coutsVariables.reduce((s, x) => s + x.montantMensuel, 0);
  return {
    totalSalaires,
    totalVehicules,
    totalVariables,
    totalMensuel: totalSalaires + totalVehicules + totalVariables,
  };
}

/** Sous-totaux des coûts variables par catégorie */
export function totauxParCategorie(coutsVariables: CoutVariable[]) {
  const map = new Map<CategorieCout, number>();
  coutsVariables.forEach((c) => {
    map.set(c.categorie, (map.get(c.categorie) ?? 0) + c.montantMensuel);
  });
  return Array.from(map.entries())
    .map(([categorie, montant]) => ({ categorie, montant }))
    .sort((a, b) => b.montant - a.montant);
}

/** Top postes de coût (toutes catégories) */
export function topPostes(
  salaries: Salarie[],
  vehicules: Vehicule[],
  coutsVariables: CoutVariable[],
  n = 5
) {
  type Poste = { nom: string; type: "Salaire" | "Véhicule" | "Variable"; montant: number };
  const all: Poste[] = [
    ...salaries.map<Poste>((s) => ({
      nom: `${s.prenom} ${s.nom}`.trim() || s.poste,
      type: "Salaire",
      montant: coutSalarieMensuel(s),
    })),
    ...vehicules.map<Poste>((v) => ({ nom: v.nom, type: "Véhicule", montant: v.coutMensuel })),
    ...coutsVariables.map<Poste>((c) => ({
      nom: c.nom || c.categorie,
      type: "Variable",
      montant: c.montantMensuel,
    })),
  ];
  return all.sort((a, b) => b.montant - a.montant).slice(0, n);
}

/** Coûts d'exploitation déclinés sur les différentes périodes */
export function coutsExploitation(totalMensuel: number, p: Parametres) {
  const hebdo = totalMensuel / Math.max(0.01, p.semParMois);
  const journalier = p.joursParSemaine > 0 ? hebdo / p.joursParSemaine : 0;
  const annuelMois = totalMensuel * 12;
  const annuelSem = hebdo * p.semainesParAn;
  const horaire = journalier / 8; // hypothèse 8 h / jour
  return { horaire, journalier, hebdo, mensuel: totalMensuel, annuelMois, annuelSem };
}

/** Seuils de rentabilité pour atteindre la marge cible */
export function seuils(totalMensuel: number, p: Parametres) {
  const m = p.margeCible / 100;
  const facteur = m < 1 ? 1 / (1 - m) : 0; // CA tel que (CA - cout)/CA = m
  const c = coutsExploitation(totalMensuel, p);
  return {
    journalier: c.journalier * facteur,
    hebdo: c.hebdo * facteur,
    mensuel: c.mensuel * facteur,
    annuel: c.annuelMois * facteur,
  };
}

/** Prix de revient au km pour une hypothèse km/jour */
export function prixRevientKm(
  totalMensuel: number,
  p: Parametres,
  kmJour: number
) {
  const c = coutsExploitation(totalMensuel, p);
  const kmAn = kmJour * p.joursParSemaine * p.semainesParAn;
  return kmAn > 0 ? c.annuelSem / kmAn : 0;
}

/* ---------- Évaluation tournées ---------- */

export type TourneeEval = {
  id: string;
  nom: string;
  prixJour: number;          // partie fixe
  prixKmFacture: number;     // €/km facturé
  prixJourEffectif: number;  // prixJour + kmJour * prixKmFacture
  kmJour: number;
  coutFixeJour: number;      // coût journalier fixe (charges mensuelles / jours)
  coutKmJour: number;        // coût variable km (carburant + véhicule) × kmJour
  coutJourTotal: number;     // coutFixeJour + coutKmJour
  margeJour: number;
  margePct: number;
  revientKm: number;
  prixKm: number;
  caAnnuel: number;     // si elle était faite tous les jours dispo
  kmAnnuel: number;
};

export function evaluerTournees(
  tournees: Tournee[],
  coutJournalier: number,
  p: Parametres
): TourneeEval[] {
  const joursAn = p.joursParSemaine * p.semainesParAn;
  const coutKmRate = (p.coutKmCarburant ?? 0) + (p.coutKmVehicule ?? 0);
  return tournees.map((t) => {
    const prixKmFacture = t.prixKmFacture ?? 0;
    const prixJourEffectif = t.prixJour + t.kmJour * prixKmFacture;
    const coutKmJour = t.kmJour * coutKmRate;
    const coutJourTotal = coutJournalier + coutKmJour;
    const margeJour = prixJourEffectif - coutJourTotal;
    const margePct = prixJourEffectif > 0 ? (margeJour / prixJourEffectif) * 100 : 0;
    const revientKm = t.kmJour > 0 ? coutJourTotal / t.kmJour : 0;
    const prixKm = prixKmFacture > 0 ? prixKmFacture : 0;
    return {
      id: t.id,
      nom: t.nom,
      prixJour: t.prixJour,
      prixKmFacture,
      prixJourEffectif,
      kmJour: t.kmJour,
      coutFixeJour: coutJournalier,
      coutKmJour,
      coutJourTotal,
      margeJour,
      margePct,
      revientKm,
      prixKm,
      caAnnuel: prixJourEffectif * joursAn,
      kmAnnuel: t.kmJour * joursAn,
    };
  });
}

/* ---------- Évaluation scénarios ---------- */

export type ScenarioEval = {
  id: string;
  nom: string;
  totalJours: number;
  caHebdo: number;
  coutFixeHebdo: number;     // charges mensuelles converties en hebdo
  coutKmHebdo: number;       // coût variable km sur la semaine
  coutHebdo: number;         // total = fixe + km
  resultatHebdo: number;
  marge: number; // %
  kmHebdo: number;
  // Projections
  caAnnuel: number;
  coutAnnuel: number;
  resultatAnnuel: number;
  caMensuel: number;
  resultatMensuel: number;
  kmAnnuel: number;
  prixRevientKm: number; // €/km
  prixVenteKm: number;   // €/km
};

/** Calcule le CA et la marge hebdo d'un scénario + projections */
export function evaluerScenario(
  s: Scenario,
  tournees: Tournee[],
  coutHebdo: number,
  p: Parametres
): ScenarioEval {
  const caHebdo = s.lignes.reduce((acc, l) => {
    const t = tournees.find((x) => x.id === l.tourneeId);
    if (!t) return acc;
    const prixJourEffectif = t.prixJour + t.kmJour * (t.prixKmFacture ?? 0);
    return acc + prixJourEffectif * l.nbParSemaine;
  }, 0);
  const kmHebdo = s.lignes.reduce((acc, l) => {
    const t = tournees.find((x) => x.id === l.tourneeId);
    return acc + (t ? t.kmJour * l.nbParSemaine : 0);
  }, 0);
  const totalJours = s.lignes.reduce((acc, l) => acc + l.nbParSemaine, 0);
  const coutKmRate = (p.coutKmCarburant ?? 0) + (p.coutKmVehicule ?? 0);
  const coutKmHebdo = s.lignes.reduce((acc, l) => {
    const t = tournees.find((x) => x.id === l.tourneeId);
    return acc + (t ? t.kmJour * l.nbParSemaine * coutKmRate : 0);
  }, 0);
  const coutHebdoTotal = coutHebdo + coutKmHebdo;
  const resultatHebdo = caHebdo - coutHebdoTotal;
  const marge = caHebdo > 0 ? (resultatHebdo / caHebdo) * 100 : 0;

  const caAnnuel = caHebdo * p.semainesParAn;
  const coutAnnuel = coutHebdoTotal * p.semainesParAn;
  const resultatAnnuel = caAnnuel - coutAnnuel;
  const caMensuel = caAnnuel / 12;
  const resultatMensuel = resultatAnnuel / 12;
  const kmAnnuel = kmHebdo * p.semainesParAn;
  const hasKmBilling = s.lignes.some((l) => {
    const t = tournees.find((x) => x.id === l.tourneeId);
    return t && (t.prixKmFacture ?? 0) > 0;
  });
  const prixRevientKm = hasKmBilling && kmAnnuel > 0 ? coutAnnuel / kmAnnuel : 0;
  const prixVenteKm = hasKmBilling && kmAnnuel > 0 ? caAnnuel / kmAnnuel : 0;

  return {
    id: s.id,
    nom: s.nom,
    totalJours,
    caHebdo,
    coutFixeHebdo: coutHebdo,
    coutKmHebdo,
    coutHebdo: coutHebdoTotal,
    resultatHebdo,
    marge,
    kmHebdo,
    caAnnuel,
    coutAnnuel,
    resultatAnnuel,
    caMensuel,
    resultatMensuel,
    kmAnnuel,
    prixRevientKm,
    prixVenteKm,
  };
}

/** Nombre de jours/semaine du scénario à composer pour atteindre la marge cible.
 *  Hypothèse : on garde la même structure (mix), on multiplie par un facteur. */
export function breakEvenFacteur(s: ScenarioEval, p: Parametres): number | null {
  // CA' = facteur * caHebdo, coût constant => marge = (facteur*CA - cout)/(facteur*CA) = margeCible
  // <=> facteur = cout / (CA * (1 - margeCible))
  const m = p.margeCible / 100;
  if (s.caHebdo <= 0 || m >= 1) return null;
  const f = s.coutHebdo / (s.caHebdo * (1 - m));
  return f > 0 && isFinite(f) ? f : null;
}

/* ---------- Niveau de confort ---------- */

export function niveauConfort(marge: number) {
  if (marge < 0) return { label: "Perte", color: "red", icon: "⛔" };
  if (marge < 10) return { label: "Tendu", color: "red", icon: "⚠️" };
  if (marge < 15) return { label: "Correct léger", color: "yellow", icon: "🟡" };
  if (marge < 20) return { label: "Bon", color: "blue", icon: "🟦" };
  if (marge < 25) return { label: "Très bon", color: "emerald", icon: "✅" };
  if (marge < 30) return { label: "Confortable", color: "green", icon: "🟢" };
  if (marge < 40) return { label: "Très confortable", color: "teal", icon: "💎" };
  return { label: "Exceptionnel", color: "purple", icon: "🚀" };
}

export function colorClasses(color: string) {
  const map: Record<string, { bg: string; text: string; border: string; barFill: string }> = {
    red:      { bg: "bg-red-50",     text: "text-red-700",     border: "border-red-200",     barFill: "#ef4444" },
    yellow:   { bg: "bg-yellow-50",  text: "text-yellow-700",  border: "border-yellow-200",  barFill: "#eab308" },
    blue:     { bg: "bg-blue-50",    text: "text-blue-700",    border: "border-blue-200",    barFill: "#3b82f6" },
    emerald:  { bg: "bg-emerald-50", text: "text-emerald-700", border: "border-emerald-200", barFill: "#10b981" },
    green:    { bg: "bg-green-50",   text: "text-green-700",   border: "border-green-200",   barFill: "#22c55e" },
    teal:     { bg: "bg-teal-50",    text: "text-teal-700",    border: "border-teal-200",    barFill: "#14b8a6" },
    purple:   { bg: "bg-purple-50",  text: "text-purple-700",  border: "border-purple-200",  barFill: "#8b5cf6" },
    slate:    { bg: "bg-slate-50",   text: "text-slate-700",   border: "border-slate-200",   barFill: "#64748b" },
    orange:   { bg: "bg-orange-50",  text: "text-orange-700",  border: "border-orange-200",  barFill: "#f97316" },
  };
  return map[color] ?? map.slate;
}

/* ---------- Sensibilité ---------- */

/**
 * Analyse de sensibilité : pour un CA hebdo donné, calcule le résultat
 * et la marge en faisant varier le coût hebdo de ± deltas %.
 */
export function sensibilite(caHebdo: number, coutHebdo: number, deltas: number[]) {
  return deltas.map((d) => {
    const cout = coutHebdo * (1 + d / 100);
    const resultat = caHebdo - cout;
    const marge = caHebdo > 0 ? (resultat / caHebdo) * 100 : 0;
    return { delta: d, cout, resultat, marge };
  });
}

/**
 * Inverse : à coût fixe, on fait varier le CA.
 */
export function sensibiliteCA(caHebdo: number, coutHebdo: number, deltas: number[]) {
  return deltas.map((d) => {
    const ca = caHebdo * (1 + d / 100);
    const resultat = ca - coutHebdo;
    const marge = ca > 0 ? (resultat / ca) * 100 : 0;
    return { delta: d, ca, resultat, marge };
  });
}

/* ---------- Charges annuelles "salarié" (info RH) ---------- */

/** Détail annuel d'un salarié (info utile pour comparaisons RH) */
export function detailAnnuelSalarie(s: Salarie) {
  const mensuelChargé = coutSalarieMensuel(s);
  return {
    brutAnnuel: s.salaireBrut * 12,
    chargesAnnuelles: s.salaireBrut * 12 * (s.chargesPct / 100),
    chargéAnnuel: mensuelChargé * 12,
    chargéMensuel: mensuelChargé,
  };
}
