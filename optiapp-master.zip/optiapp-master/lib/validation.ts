import "server-only";
import { z } from "zod";

/**
 * Helpers de parsing pour Server Actions.
 *
 * Usage :
 *   const parsed = parseFormData(MySchema, formData);
 *   if (!parsed.ok) return flashAndFinalize(formData, path, parsed.error, "error");
 *
 * → Tous les champs sont récupérés via FormData (Server Actions),
 *   on ne renvoie qu'un message agrégé prêt à passer au toast.
 */

export type ParseResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string };

export function parseFormData<S extends z.ZodTypeAny>(
  schema: S,
  formData: FormData,
): ParseResult<z.infer<S>> {
  const raw: Record<string, FormDataEntryValue | FormDataEntryValue[]> = {};
  for (const key of new Set(Array.from(formData.keys()))) {
    const all = formData.getAll(key);
    raw[key] = all.length > 1 ? all : all[0];
  }
  const result = schema.safeParse(raw);
  if (result.success) return { ok: true, data: result.data };
  const message = result.error.issues
    .map((i) => `${i.path.join(".") || "(form)"}: ${i.message}`)
    .slice(0, 3)
    .join(" • ");
  return { ok: false, error: message || "Données invalides" };
}

/* ── Primitives partagées ──────────────────────────────────── */

/** Chaîne obligatoire (trim, min 1). */
export const zNonEmpty = z.preprocess(
  (v) => (typeof v === "string" ? v.trim() : v),
  z.string().min(1, "requis"),
);

/** Chaîne optionnelle → undefined si vide. */
export const zOptional = z
  .preprocess(
    (v) => (typeof v === "string" ? v.trim() : v),
    z.string().optional(),
  )
  .transform((v) => (v && v.length > 0 ? v : undefined));

/** UUID strict. */
export const zUuid = z.preprocess(
  (v) => (typeof v === "string" ? v.trim() : v),
  z.string().uuid("UUID invalide"),
);

/** Identifiant texte (clé applicative comme une slug). */
export const zId = zNonEmpty;

/** Date ISO (YYYY-MM-DD) ou vide → undefined. */
export const zDateOpt = z
  .preprocess(
    (v) => (typeof v === "string" ? v.trim() : v),
    z.union([z.literal(""), z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date invalide (AAAA-MM-JJ)")]),
  )
  .transform((v) => (v === "" ? undefined : v));

/** Nombre depuis FormData (FormData ne contient que des strings). */
export const zNumber = z.preprocess(
  (v) => (typeof v === "string" && v.trim() !== "" ? Number(v) : v),
  z.number({ message: "doit être un nombre" }).finite(),
);

export const zNumberOpt = z
  .preprocess(
    (v) => (typeof v === "string" && v.trim() !== "" ? Number(v) : v === "" ? undefined : v),
    z.number().finite().optional(),
  );

/** Email standard. */
export const zEmailOpt = z
  .preprocess(
    (v) => (typeof v === "string" ? v.trim() : v),
    z.union([z.literal(""), z.string().email("Email invalide")]),
  )
  .transform((v) => (v === "" ? undefined : v));

/** Booléen depuis checkbox HTML ("on", "true", "1"). */
export const zCheckbox = z
  .preprocess(
    (v) => (typeof v === "string" ? ["on", "true", "1"].includes(v.toLowerCase()) : Boolean(v)),
    z.boolean(),
  );
