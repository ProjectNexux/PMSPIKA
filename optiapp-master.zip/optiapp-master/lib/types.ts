export type Salarie = {
  id: string;
  nom: string;
  prenom: string;
  poste: string; // ex: "Conducteur SPL"
  salaireBrut: number; // mensuel €
  chargesPct: number; // % charges patronales (ex: 42)
  primesNonTaxables: number; // primes mensuelles non soumises à charges (panier repas, etc.)
};

export type Vehicule = {
  id: string;
  nom: string; // ex: "Camion 26T bâché hayon"
  coutMensuel: number; // location/leasing + assurance + entretien mensualisé
};

export const CATEGORIES_COUT = [
  "Carburant",
  "Péages",
  "Entretien",
  "Assurance",
  "Pneumatiques",
  "AdBlue",
  "Télématique",
  "Frais de route",
  "Autre",
] as const;
export type CategorieCout = (typeof CATEGORIES_COUT)[number];

export type CoutVariable = {
  id: string;
  nom: string; // ex: "Gasoil flotte"
  categorie: CategorieCout;
  montantMensuel: number;
};

export type Tournee = {
  id: string;
  nom: string; // ex: "IDF", "Dep. 77", "Dep. 80"
  prixJour: number; // CA fixe généré par jour de tournée
  kmJour: number; // km parcourus par jour
  prixKmFacture?: number; // tarif au km facturé (€/km) — si renseigné, le CA effectif = prixJour + kmJour * prixKmFacture
  notes?: string;
};

export type LigneScenario = {
  tourneeId: string;
  nbParSemaine: number; // nombre de jours par semaine sur cette tournée
};

export type Scenario = {
  id: string;
  nom: string;
  lignes: LigneScenario[];
  notes?: string;
};

export type Parametres = {
  joursParSemaine: number; // ex: 5
  semainesParAn: number;   // ex: 52
  semParMois: number;      // ex: 4.33
  margeCible: number;      // % marge cible pour seuil de rentabilité (ex: 20)
  tauxTVA: number;         // % TVA appliquée (ex: 20)
  // Coûts au km (séparés des charges fixes mensuelles)
  coutKmCarburant: number; // €/km carburant
  coutKmVehicule: number;  // €/km usure véhicule (pneus, entretien variable)
};

/** Forme du snapshot exporté/importé en JSON */
export type Snapshot = {
  version: 1;
  exportedAt: string;
  salaries: Salarie[];
  vehicules: Vehicule[];
  coutsVariables: CoutVariable[];
  tournees: Tournee[];
  scenarios: Scenario[];
  parametres: Parametres;
  activeScenarioId: string | null;
};
