import "server-only";
import { getServerSupabase } from "@/lib/db-server";

export type PricingProfile = {
  id: string;
  company_id: string;
  base_fee: number;
  per_km: number;
  per_kg: number;
  cold_unit_fee: number;
  adr_fee: number;
  priority_multiplier: number;
};

export type PriceBreakdown = {
  base_fee: number;
  distance_km: number;
  per_km_amount: number;
  weight_kg?: number | null;
  per_kg_amount?: number | null;
  cold_fee?: number | null;
  adr_fee?: number | null;
  fuel_surcharge_percent?: number | null;
  fuel_surcharge_amount?: number | null;
  total: number;
};

/** Récupère le pricing profile de la société, ou un profil par défaut. */
export async function getPricingProfile(companyId: string): Promise<PricingProfile> {
  const sb = getServerSupabase();
  const { data } = await sb
    .from("pricing_profiles")
    .select("id, company_id, base_fee, per_km, per_kg, cold_unit_fee, adr_fee, priority_multiplier")
    .eq("company_id", companyId)
    .limit(1);

  if (data && data.length) return data[0] as PricingProfile;

  // Fallback minimal profile
  return {
    id: "__default__",
    company_id: companyId,
    base_fee: 5,
    per_km: 1.2,
    per_kg: 0,
    cold_unit_fee: 0,
    adr_fee: 0,
    priority_multiplier: 1,
  };
}

/** Dernier prix du litre enregistré pour la société (ou global si NULL company_id). */
export async function getLatestFuelPrice(companyId?: string): Promise<number | null> {
  const sb = getServerSupabase();
  // Recherche d'abord par company_id, sinon global (company_id IS NULL)
  const { data } = await sb
    .from("fuel_price_rates")
    .select("price_per_l")
    .or(`company_id.eq.${companyId},company_id.is.null`)
    .order("effective_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!data) return null;
  // Type-safe extraction of price_per_l from fuel price record
  if (typeof data === 'object' && data !== null && 'price_per_l' in data) {
    const price = (data as Record<string, unknown>).price_per_l;
    return typeof price === 'number' ? price : null;
  }
  return null;
}

/**
 * Calculate price for a mission using distance, weight, flags.
 * - mission: { company_id, distance_km, weight_kg, requires_cold, requires_adr, priority }
 * Returns price and breakdown.
 */
export async function computeMissionPrice(mission: {
  company_id: string;
  distance_km: number | null;
  weight_kg?: number | null;
  requires_cold?: boolean | null;
  requires_adr?: boolean | null;
  priority?: string | null; // e.g. 'normal'|'urgent'
}): Promise<{ price: number; breakdown: PriceBreakdown; fuel_price_used?: number | null; fuel_surcharge_percent?: number | null }>{
  const profile = await getPricingProfile(mission.company_id);
  const distance = mission.distance_km ?? 0;
  const weight = mission.weight_kg ?? null;

  const base_fee = Number(profile.base_fee ?? 0);
  const per_km_amount = Number((profile.per_km ?? 0) * distance);
  const per_kg_amount = weight ? Number((profile.per_kg ?? 0) * weight) : 0;
  const cold_fee = mission.requires_cold ? Number(profile.cold_unit_fee ?? 0) : 0;
  const adr_fee = mission.requires_adr ? Number(profile.adr_fee ?? 0) : 0;
  const priorityMult = mission.priority === "urgent" ? Number(profile.priority_multiplier ?? 1.2) : Number(profile.priority_multiplier ?? 1);

  const subtotal = base_fee + per_km_amount + per_kg_amount + cold_fee + adr_fee;

  // Fuel surcharge calculation: compare latest price_per_l to a baseline (e.g. 1.6 €/L)
  const latestFuel = await getLatestFuelPrice(mission.company_id);
  const baseline = 1.6; // configuration future
  let fuelSurchargePercent: number | null = null;
  let fuelSurchargeAmount = 0;
  if (latestFuel != null && latestFuel > baseline) {
    // surcharge percent proportional to delta (example: each 0.1€ -> +0.5%)
    const delta = Math.max(0, Number(latestFuel) - baseline);
    fuelSurchargePercent = Math.round((delta / 0.1) * 0.5 * 100) / 100; // percent
    fuelSurchargeAmount = Math.round((subtotal * (fuelSurchargePercent / 100)) * 100) / 100;
  }

  let total = subtotal + fuelSurchargeAmount;
  total = total * priorityMult;
  total = Math.round(total * 100) / 100;

  const breakdown: PriceBreakdown = {
    base_fee,
    distance_km: distance,
    per_km_amount: Math.round(per_km_amount * 100) / 100,
    weight_kg: weight ?? undefined,
    per_kg_amount: weight ? Math.round(per_kg_amount * 100) / 100 : undefined,
    cold_fee: cold_fee || undefined,
    adr_fee: adr_fee || undefined,
    fuel_surcharge_percent: fuelSurchargePercent ?? undefined,
    fuel_surcharge_amount: fuelSurchargeAmount || undefined,
    total,
  };

  return { price: total, breakdown, fuel_price_used: latestFuel ?? null, fuel_surcharge_percent: fuelSurchargePercent ?? null };
}
