/**
 * lib/session.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Helpers de session côté serveur : récupère l'utilisateur courant + son profil
 * applicatif (rôle, société, site). À appeler dans Server Components / Server Actions.
 */

import { redirect } from "next/navigation";
import { getSupabaseServer } from "./supabase-server";

export type AppRole =
  | "super_admin"
  | "gerant_groupe"
  | "gerant_societe"
  | "chef_site"
  | "chauffeur"
  | "client";

export type CurrentUser = {
  id: string;
  email: string | null;
  full_name: string;
  role: AppRole;
  company_id: string | null;
  site_id: string | null;
  employee_id: string | null;
  company_name: string | null;
  company_color: string | null;
  site_name: string | null;
  is_admin: boolean;       // super_admin OR gerant_groupe
  is_super_admin: boolean; // super_admin seulement
};

/**
 * Retourne l'utilisateur connecté + profil applicatif, ou null.
 * Lit la vue `app_current_user` (intègre les helpers SQL).
 */
export async function getCurrentUser(): Promise<CurrentUser | null> {
  const supabase = await getSupabaseServer();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const { data, error } = await supabase
    .from("app_current_user")
    .select("*")
    .maybeSingle();

  if (error || !data) {
    // Profil non encore créé (e.g. signup juste réalisé) — fallback
    return null;
  }

  return {
    id: data.id,
    email: data.email,
    full_name: data.full_name ?? "",
    role: data.role as AppRole,
    company_id: data.company_id,
    site_id: data.site_id,
    employee_id: data.employee_id,
    company_name: data.company_name,
    company_color: data.company_color,
    site_name: data.site_name,
    is_admin: !!data.is_admin,
    is_super_admin: !!data.is_super_admin,
  };
}

/**
 * Garde-fou : redirige vers /login si non connecté.
 * Utiliser en haut des Server Components protégés.
 */
export async function requireUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  return user;
}

/**
 * Garde-fou : exige un des rôles donnés sinon redirige vers la home du rôle.
 */
export async function requireRole(roles: AppRole[]): Promise<CurrentUser> {
  const user = await requireUser();
  if (!roles.includes(user.role)) {
    redirect(homeForRole(user.role));
  }
  return user;
}

/**
 * URL d'accueil par défaut selon le rôle (mono-société PIKA TRANSPORT).
 */
export function homeForRole(role: AppRole): string {
  switch (role) {
    case "chauffeur":
    case "client":
      return "/chauffeur";
    default:
      return "/";
  }
}

/**
 * Permissions de haut niveau (UI helpers).
 */
export function canAccessHub(role: AppRole): boolean {
  return role === "super_admin" || role === "gerant_groupe";
}

export function canAccessCompany(user: CurrentUser, companyId: string): boolean {
  if (user.is_admin) return true;
  return user.company_id === companyId;
}

export function canAccessSite(user: CurrentUser, siteId: string | null): boolean {
  if (user.is_admin) return true;
  if (user.role === "gerant_societe") return true; // RLS company-level fait le reste
  if (user.role === "chef_site") return user.site_id === siteId;
  return false;
}
