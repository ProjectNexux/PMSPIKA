/**
 * lib/supabase-admin.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Client Supabase avec la service_role key — bypass la RLS.
 * À n'utiliser QUE dans les Server Actions / Route Handlers côté serveur,
 * JAMAIS exposé au client.
 *
 * Fonctions disponibles :
 *   getSupabaseAdmin()  — client Supabase Admin
 *   inviteUser()        — invite un utilisateur par email (Supabase Auth)
 */

import { createClient } from "@supabase/supabase-js";

function cleanEnv(value: string | undefined): string {
  if (!value) return "";
  const trimmed = value.trim();
  return trimmed.replace(/^(["'])(.*)\1$/, "$2").trim();
}

const URL = cleanEnv(process.env.NEXT_PUBLIC_SUPABASE_URL);

function resolveServiceKey(): string {
  return cleanEnv(
    process.env.SUPABASE_SERVICE_ROLE_KEY
    ?? process.env.SUPABASE_SECRET_KEY
    ?? process.env.SUPABASE_SERVICE_KEY,
  );
}

if (!URL) throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL");

/**
 * Client admin Supabase (service_role).
 * Singleton léger — Next.js module cache évite les recréations inutiles.
 */
let _adminClient: ReturnType<typeof createClient> | null = null;

export function getSupabaseAdmin() {
  const serviceRoleKey = resolveServiceKey();
  if (!serviceRoleKey) {
    throw new Error(
      "SUPABASE service key not configured — renseignez SUPABASE_SERVICE_ROLE_KEY (ou SUPABASE_SECRET_KEY) dans .env.local",
    );
  }
  if (!_adminClient) {
    _adminClient = createClient(URL, serviceRoleKey, {
      auth: {
        autoRefreshToken: false,
        persistSession: false,
      },
    });
  }
  return _adminClient;
}

/**
 * Invite un utilisateur par email (envoie un email Supabase Auth).
 * Retourne l'utilisateur créé ou l'erreur.
 */
export async function inviteUserByEmail(
  email: string,
  options?: {
    data?: Record<string, unknown>;
    redirectTo?: string;
  },
) {
  const admin = getSupabaseAdmin();
  const { data, error } = await admin.auth.admin.inviteUserByEmail(email, {
    data: options?.data,
    redirectTo: options?.redirectTo,
  });
  return { data, error };
}
