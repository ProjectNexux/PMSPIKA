import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY");
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

/** Timeout in ms for each RPC call. Prevents page hangs on slow/offline Supabase. */
const RPC_TIMEOUT_MS = 8_000;

export async function rpc<T>(fn: string, params?: Record<string, unknown>): Promise<T[]> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), RPC_TIMEOUT_MS);

  try {
    const { data, error } = await supabase.rpc(fn, params ?? {}, {
      // @ts-expect-error — signal accepted at runtime by supabase-js fetch layer
      signal: controller.signal,
    });
    clearTimeout(timer);
    if (error) throw new Error(`RPC ${fn}: ${error.message}`);
    return (data ?? []) as T[];
  } catch (err) {
    clearTimeout(timer);
    const msg = err instanceof Error ? err.message : String(err);
    console.error(`[db] rpc(${fn}) failed: ${msg}`);
    return [];
  }
}

export async function rpcOne<T>(fn: string, params?: Record<string, unknown>): Promise<T | null | undefined> {
  const rows = await rpc<T>(fn, params);
  return rows[0] ?? null;
}
