import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]): string {
  return twMerge(clsx(inputs));
}

/**
 * Type-safe array assertion for database queries.
 * Ensures the value is an array before casting, avoiding silent failures.
 */
export function assertArray<T>(value: unknown, defaultValue: T[] = []): T[] {
  if (Array.isArray(value)) {
    return value as T[];
  }
  console.warn("Expected array but got:", typeof value, value);
  return defaultValue;
}

/**
 * Type-safe object assertion for database queries.
 * Ensures the value is an object before casting.
 */
export function assertObject<T extends Record<string, unknown>>(
  value: unknown,
  defaultValue?: null
): T | null;
export function assertObject<T extends Record<string, unknown>>(
  value: unknown,
  defaultValue: T
): T;
export function assertObject<T extends Record<string, unknown>>(
  value: unknown,
  defaultValue?: T | null
): T | null {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    return value as T;
  }
  console.warn("Expected object but got:", typeof value, value);
  return defaultValue ?? null;
}
