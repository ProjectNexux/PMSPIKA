/**
 * lib/supabase-server.ts
 * ─────────────────────────────────────────────────────────────────────────────
 * Client Supabase côté serveur, branché sur les cookies de la requête Next.js.
 * Utilise la NEXT_PUBLIC_SUPABASE_ANON_KEY mais avec le JWT utilisateur (cookie),
 * donc la RLS s'applique en fonction de l'utilisateur connecté.
 *
 * À utiliser dans les Server Components, Server Actions, Route Handlers et Middleware.
 * Pour bypasser la RLS (tâches admin), utiliser lib/supabase-admin.ts (service role).
 */

import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

const URL = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const ANON_KEY = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

if (!URL || !ANON_KEY) {
  throw new Error("Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY");
}

/**
 * Pour Server Components / Server Actions / Route Handlers.
 * `cookies()` est async dans Next.js 15+ via App Router.
 */
export async function getSupabaseServer() {
  const cookieStore = await cookies();

  return createServerClient(URL, ANON_KEY, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet: { name: string; value: string; options: CookieOptions }[]) {
        try {
          cookiesToSet.forEach(({ name, value, options }) =>
            cookieStore.set(name, value, options),
          );
        } catch {
          // Server Component — set() interdit, c'est attendu : le middleware s'en charge.
        }
      },
    },
  });
}
