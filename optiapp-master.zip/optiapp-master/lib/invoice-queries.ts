import { supabase } from "@/lib/db";

export type InvoiceClient = {
  id: string;
  name: string;
  address: string | null;
  postal_code: string | null;
  city: string | null;
  email: string | null;
  phone: string | null;
  rcs: string | null;
  code_ape: string | null;
  id_tva: string | null;
  legal_form: string | null;
  capital: number | null;
  iban: string | null;
  bic: string | null;
  notes: string | null;
};

export type InvoiceLine = {
  id: string;
  invoice_id: string;
  sort_order: number;
  line_date: string | null;
  ref: string | null;
  exp_address: string | null;
  dest_address: string | null;
  poids_kg: number | null;
  qty_trips: number | null;
  qty_taxable: number | null;
  total_ht: number;
  ecotaxe: number;
  // Location (location sans chauffeur)
  rental_start_date: string | null;
  rental_end_date: string | null;
  qty_days: number | null;
  unit_price: number | null;
};

export type Invoice = {
  id: string;
  invoice_number: string;
  issue_date: string;
  period: string | null;
  driver_name: string | null;
  vehicle_plate: string | null;

  client_id: string | null;
  client_name: string;
  client_address: string | null;
  client_postal_code: string | null;
  client_city: string | null;
  client_email: string | null;
  client_phone: string | null;
  client_rcs: string | null;
  client_code_ape: string | null;
  client_id_tva: string | null;
  client_legal_form: string | null;
  client_capital: number | null;

  seller_name: string | null;
  seller_address: string | null;
  seller_postal_code: string | null;
  seller_city: string | null;
  seller_email: string | null;
  seller_phone: string | null;
  seller_rcs: string | null;
  seller_code_naf: string | null;
  seller_tva: string | null;
  seller_legal_form: string | null;
  seller_capital: number | null;

  compte: string | null;
  tva_rate: number;
  invoice_type: 'transport' | 'location';

  payment_beneficiary: string | null;
  payment_bic: string | null;
  payment_iban: string | null;

  status: string;
  notes: string | null;
  created_at: string;
  updated_at: string;

  lines?: InvoiceLine[];
};

export type InvoiceListRow = {
  id: string;
  invoice_number: string;
  issue_date: string;
  period: string | null;
  driver_name: string | null;
  vehicle_plate: string | null;
  client_name: string;
  status: string;
  total_ht: number;
  total_ttc: number;
  created_at: string;
};

/** Calcule les totaux d'une facture à partir de ses lignes */
export function computeInvoiceTotals(
  lines: Pick<InvoiceLine, "total_ht" | "ecotaxe">[],
  tvaRate: number,
) {
  const montantHT = lines.reduce((s, l) => s + (l.total_ht ?? 0), 0);
  const ecotaxeTotal = lines.reduce((s, l) => s + (l.ecotaxe ?? 0), 0);
  const tva = Math.round(montantHT * (tvaRate / 100) * 100) / 100;
  const montantTTC = Math.round((montantHT + tva) * 100) / 100;
  return { montantHT, ecotaxeTotal, tva, montantTTC };
}

/** Prochain numéro de facture PREFIX-YYYY-NNN */
export async function getNextInvoiceNumber(): Promise<string> {
  // Charge le préfixe depuis les paramètres
  const { data: settingsRow } = await supabase
    .from("invoice_settings")
    .select("invoice_prefix")
    .limit(1)
    .single();
  const prefix = settingsRow?.invoice_prefix ?? "EUR";

  const year = new Date().getFullYear();
  const fullPrefix = `${prefix}-${year}-`;
  const { data } = await supabase
    .from("invoices")
    .select("invoice_number")
    .like("invoice_number", `${fullPrefix}%`)
    .order("invoice_number", { ascending: false })
    .limit(1);

  if (!data || data.length === 0) return `${fullPrefix}001`;
  const last = data[0].invoice_number;
  const num = parseInt(last.replace(fullPrefix, ""), 10);
  return `${fullPrefix}${String(num + 1).padStart(3, "0")}`;
}

/** Liste des factures avec totaux calculés */
export async function listInvoices(companyId?: string): Promise<InvoiceListRow[]> {
  let q = supabase
    .from("invoices")
    .select(`id, invoice_number, issue_date, period, driver_name, vehicle_plate, client_name, status, tva_rate, created_at, invoice_lines(total_ht, ecotaxe)`)
    .order("created_at", { ascending: false });

  if (companyId) q = q.eq("company_id", companyId);

  const { data, error } = await q;
  if (error) { console.error("[invoice-queries] listInvoices:", error.message); return []; }

  return (data ?? []).map((row) => {
    const lines = (row.invoice_lines as { total_ht: number; ecotaxe: number }[]) ?? [];
    const { montantHT, montantTTC } = computeInvoiceTotals(lines, row.tva_rate);
    return {
      id: row.id,
      invoice_number: row.invoice_number,
      issue_date: row.issue_date,
      period: row.period,
      driver_name: row.driver_name,
      vehicle_plate: row.vehicle_plate,
      client_name: row.client_name,
      status: row.status,
      total_ht: montantHT,
      total_ttc: montantTTC,
      created_at: row.created_at,
    };
  });
}

/** Facture complète avec ses lignes */
export async function getInvoiceById(id: string): Promise<Invoice | null> {
  const { data, error } = await supabase
    .from("invoices")
    .select(`*, invoice_lines(*)`)
    .eq("id", id)
    .single();

  if (error || !data) { console.error("[invoice-queries] getInvoiceById:", error?.message); return null; }

  const lines = ((data.invoice_lines ?? []) as InvoiceLine[]).sort(
    (a, b) => a.sort_order - b.sort_order,
  );
  return { ...data, lines } as Invoice;
}

/** Liste des clients enregistrés */
export async function listInvoiceClients(companyId?: string): Promise<InvoiceClient[]> {
  let q = supabase
    .from("invoice_clients")
    .select("*")
    .order("name");

  if (companyId) q = q.eq("company_id", companyId);

  const { data, error } = await q;
  if (error) { console.error("[invoice-queries] listInvoiceClients:", error.message); return []; }
  return (data ?? []) as InvoiceClient[];
}

// ─── Paramètres de facturation ───────────────────────────────────────────────

export type InvoiceSettings = {
  id: string;
  seller_name: string;
  seller_address: string;
  seller_postal_code: string;
  seller_city: string;
  seller_email: string;
  seller_phone: string;
  seller_rcs: string;
  seller_code_naf: string;
  seller_tva: string;
  seller_legal_form: string;
  seller_capital: number | null;
  invoice_prefix: string;
  tva_rate: number;
  payment_beneficiary: string;
  payment_bic: string;
  payment_iban: string;
  compte_template: string;
};

export const DEFAULT_SETTINGS: InvoiceSettings = {
  id: "",
  seller_name:        "PIKA TRANSPORT",
  seller_address:     "8 AVENUE HENRI BARBUSSE",
  seller_postal_code: "93000",
  seller_city:        "BOBIGNY",
  seller_email:       "pikatransports@gmail.com",
  seller_phone:       "06 80 80 72 05",
  seller_rcs:         "93399600100014",
  seller_code_naf:    "4941B",
  seller_tva:         "FR37933996001",
  seller_legal_form:  "SAS",
  seller_capital:     50000,
  invoice_prefix:     "EUR",
  tva_rate:           20,
  payment_beneficiary: "PIKATRANSPORT",
  payment_bic:        "QNTOFRP1XXX",
  payment_iban:       "FR7616958000013673454356051",
  compte_template:    "",
};

/** Charge les paramètres (retourne les defaults si aucune ligne en base) */
export async function getInvoiceSettings(): Promise<InvoiceSettings> {
  const { data } = await supabase
    .from("invoice_settings")
    .select("*")
    .limit(1)
    .single();
  if (!data) return DEFAULT_SETTINGS;
  return data as InvoiceSettings;
}
