const QONTO_API_URL = (process.env.QONTO_API_URL ?? "https://api.qonto.com/v2").replace(/\/+$/, "");
const QONTO_API_TOKEN = process.env.QONTO_API_TOKEN ?? "";

export type QontoAccount = {
  id: string;
  label: string;
  iban: string | null;
  balance: number;
  currency: string;
  status: string | null;
};

export type QontoTransaction = {
  id: string;
  account_id: string | null;
  date: string;
  label: string;
  amount: number;
  currency: string;
  status: string | null;
};

function parseAmount(value: unknown): number {
  if (typeof value === "number") return value;
  if (typeof value === "string") return Number(value.replace(/,/g, ".")) || 0;
  if (typeof value === "object" && value !== null) {
    const maybeAmount = (value as any).amount ?? (value as any).value ?? (value as any).current;
    return parseAmount(maybeAmount);
  }
  return 0;
}

function parseDate(value: unknown): string {
  if (typeof value === "string" && value.trim()) return value.slice(0, 10);
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return new Date().toISOString().slice(0, 10);
}

function normalizeResponseArray(body: any): any[] {
  if (!body) return [];
  if (Array.isArray(body)) return body;
  if (Array.isArray(body.accounts)) return body.accounts;
  if (Array.isArray(body.data)) return body.data;
  if (Array.isArray(body.data?.accounts)) return body.data.accounts;
  return [];
}

async function qontoFetch(path: string, init?: RequestInit): Promise<Response> {
  if (!QONTO_API_TOKEN) {
    throw new Error("Qonto API token is not configured (QONTO_API_TOKEN missing)");
  }

  const url = path.startsWith("http") ? path : `${QONTO_API_URL}${path}`;
  const headers = {
    Accept: "application/json",
    Authorization: `Bearer ${QONTO_API_TOKEN}`,
    ...(init?.headers as Record<string, string> | undefined),
  };

  return fetch(url, {
    ...init,
    headers,
  });
}

export async function fetchQontoAccounts(): Promise<QontoAccount[]> {
  if (!QONTO_API_TOKEN) return [];

  try {
    const response = await qontoFetch("/accounts");
    if (!response.ok) {
      console.error("[qonto] fetchQontoAccounts failed", response.status, await response.text());
      return [];
    }

    const body = await response.json().catch(() => null);
    const items = normalizeResponseArray(body);
    return items.map((account: any) => ({
      id: String(account.id ?? account.account_id ?? account.uuid ?? account.key ?? ""),
      label: String(account.name ?? account.label ?? account.description ?? "Compte Qonto"),
      iban: account.iban ? String(account.iban) : account.iban_number ? String(account.iban_number) : null,
      balance: parseAmount(account.balance ?? account.current_balance ?? account.amount ?? account.available_balance),
      currency: String(account.currency ?? account.balance?.currency ?? "EUR"),
      status: account.status ? String(account.status) : null,
    }));
  } catch (error) {
    console.error("[qonto] fetchQontoAccounts error", error);
    return [];
  }
}

export async function fetchQontoTransactions(accountId?: string, limit = 20): Promise<QontoTransaction[]> {
  if (!QONTO_API_TOKEN) return [];

  try {
    const params = new URLSearchParams();
    params.set("per_page", String(limit));
    if (accountId) params.set("account_id", accountId);

    const response = await qontoFetch(`/transactions?${params.toString()}`);
    if (!response.ok) {
      console.error("[qonto] fetchQontoTransactions failed", response.status, await response.text());
      return [];
    }

    const body = await response.json().catch(() => null);
    const items = normalizeResponseArray(body);
    return items
      .map((transaction: any) => ({
        id: String(transaction.id ?? transaction.transaction_id ?? transaction.uuid ?? ""),
        account_id: transaction.account_id ? String(transaction.account_id) : null,
        date: parseDate(transaction.date ?? transaction.transaction_at ?? transaction.value_date ?? transaction.created_at),
        label:
          String(transaction.label ?? transaction.description ?? transaction.order_label ?? transaction.details?.payment_details ?? "Opération Qonto"),
        amount: parseAmount(transaction.amount ?? transaction.amount_cents ?? transaction.balance?.amount ?? transaction.transaction_amount),
        currency: String(transaction.currency ?? transaction.amount?.currency ?? "EUR"),
        status: transaction.status ? String(transaction.status) : null,
      }))
      .sort((a, b) => b.date.localeCompare(a.date));
  } catch (error) {
    console.error("[qonto] fetchQontoTransactions error", error);
    return [];
  }
}
