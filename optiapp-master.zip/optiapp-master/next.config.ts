import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Ces packages ne sont chargés qu'à l'exécution du scraper URSSAF.
  // On les déclare comme externes pour que Turbopack ne tente pas de les bundler
  // (et ne plante pas au build s'ils ne sont pas installés).
  serverExternalPackages: ["playwright", "playwright-core", "@sparticuz/chromium"],
};

export default nextConfig;
